﻿/**
 * COPYRIGHT M666 2009-2022 LEFT-ANGLE 2022
 * ALL RIGHTS RESERVED
 */
 // memo on file upload : https://developer.mozilla.org/en-US/docs/Using_files_from_web_applications

// AJAX Class declaration
var AJAX_Class = function(){
    this.xhr_list = [];
    this._up_loaded_bytes = 0;
    this._up_total_bytes = 0;

    this._down_loaded_bytes = 0;
    this._down_total_bytes = 0;

    // if the total size is unknow, these values will contains the upload/download bytes values
    this._up_overload = 0;
    this._down_overload = 0;

    this._up_speed = 0;
    this._down_speed = 0;

    this._consecutive_streams = 10; // how many simultaneous ajax streams are allowed at the same time
    this._busy_stream_count = 0;
    this._running_stream_count = 0;

    this._stream_queue = [];
    // different queue for sending chunk faster
    //~ this._files_queue = [];

    this._last_data_time = 0;

    this._debug = false;
    
    this.timer_modal = false;
    this.timer_modal_is_hide = true;
};
AJAX_Class.prototype.constructor = AJAX_Class;

// these two variables have to be update by PHP script to reflect server the configuration
AJAX_Class.max_upload_size = CONSTANTS.max_upload_size; // max file upload size
AJAX_Class.max_file_uploads = CONSTANTS.max_file_uploads; // max number of simultaneous file uploads

// variable used in conjunction with the PHP AJAX_Class to identify json variables
AJAX_Class.json_list_identifier = CONSTANTS.json_list_identifier; //'_AJAX_json_decode_list';

AJAX_Class.JSON_OFF = 0; // json data stay as strings
AJAX_Class.JSON_ON = 1; // json data are converted to objetcs and arrays
AJAX_Class.JSON_ARRAY = 2; // json data are converted, and objects are converted to associative arrays

//~ AJAX_Class.setFormSubmitter = function(submitDomElement){

    //~ if(submitDomElement.form){
        //~ submitDomElement.form._submitter = submitDomElement;
    //~ }else{
        //~ return false;
    //~ }
    //~ return true;
//~ };
//convert a form as json string...
AJAX_Class.formToObj = function( form ) {
    var obj = {};
    var elements = form.querySelectorAll( "input, select, textarea" );
    for( var i = 0; i < elements.length; ++i ) {
        let element = elements[i];
        let name = element.name;
        let value = element.value;
        let tag_type = element.type.toLowerCase();
        if( name ) {
            if( tag_type == "checkbox" || tag_type == "radio"){
                if(element.checked){
                    obj[ name ] = value;
                }

            }else {
                obj[ name ] = value;
            }
        }
    }

    return obj;
};

AJAX_Class.submitOnChange = function(selectDomElement){

    if(selectDomElement.form){
        selectDomElement.form._submitter = selectDomElement;
        EVENTS_Class.SendEvent(selectDomElement.form , 'submit');
    }else{
        return false;
    }
    return true;
};

// convert a raw bytes length into a human readable string
AJAX_Class.readableFileSize = function(size){
    let cnt = 0;
    let units = ['bytes','KB','MB','GB','TB'];
    while(size > 1024 && cnt < units.length-1){
        size /= 1024;
        cnt ++;
    }
    return size.toFixed(2)+' '+units[cnt];
};

// check if the FILE inputs respect the server limitations
AJAX_Class.checkFileData = function(domElement){
    var lst = [];
    
    if(GENERICS_Class.IsFormdata(domElement)){
        if(domElement.entries){
            let data = domElement.entries();
            let obj = data.next();
            while(undefined !== obj.value) {
                let t = Object.prototype.toString.apply(obj.value[1]);
                if(t == '[object File]'){
                    lst.push(obj.value[1]);
                }
                obj = data.next();
            }
        }else{
            console.log('Formdata.entries not supported !');
        }

    }else if(GENERICS_Class.IsDomObject(domElement)){
        
        if (domElement.tagName == 'INPUT' && domElement.type == 'file' && domElement.files){
            // if the given dom element is a FILE input, get its files
            lst = domElement.files;

        }else if(domElement.tagName == 'FORM'){
            // if the given dom element is a FORM, get all the files from the FILE inputs inside this form
            let elements = domElement.elements;

            for(let i = 0; i < elements.length ; i++){
                if(elements[i].type == 'file'){
                    for(let f = 0; f < elements[i].files.length ; f++){
                        lst.push(elements[i].files[f]);
                    }
                }
            }
        }
    }

    let count = lst.length;
    let size = 0;
    for(let i = 0 ; i < count ;i++){
        size += lst[i].size;
    }
    let message = '';
    if(count > AJAX_Class.max_file_uploads){
        message += CONSTANTS.GetText('too_many_files' , [count,AJAX_Class.max_file_uploads]); //'Too many files ('+count+')! Max = '+AJAX_Class.max_file_uploads;
    }
    if(size > AJAX_Class.max_upload_size){
        message += CONSTANTS.GetText('too_heavy_files' , [AJAX_Class.readableFileSize(size),AJAX_Class.readableFileSize(AJAX_Class.max_upload_size)] ); //'Files are too heavy ('+AJAX_Class.readableFileSize(size)+')! Max = '+AJAX_Class.readableFileSize(AJAX_Class.max_upload_size);
    }

    if(message !== ''){
        UI_Class.MessagePopup(message);
        return false;
    }else{
        return true;
    }
};

//~ AJAX_Class.cancelUpload = function(jsonData){
    //~ let obj = JSON.parse(jsonData);
    //~ obj.cancelFile();
//~ };

AJAX_Class.quick_edit_check = function(event){

    if(event.keyCode == 13){
        EVENTS_Class.StopEvent(event);

        AJAX_Class.quick_edit_send({'target':event.target,'action':'save'});
    }

    if(event.keyCode == 27){
        EVENTS_Class.StopEvent(event);

        AJAX_Class.quick_edit_send({'target':event.target,'action':'cancel'});
    }
};

AJAX_Class.quick_edit_send = function(event){

    let action = '';
    let targetTag = null;
    let field_ID = '';
    let id_lang_data = null;

    if(!GENERICS_Class.IsEvent(event)){
        targetTag = event.target.parentNode;
        action = event.action;
        field_ID = event.target.getAttribute('id');
    }else{
        EVENTS_Class.StopEvent(event);
        let buttonTag = event.target;
        action = buttonTag.getAttribute('value');
        targetTag = buttonTag.parentNode;
        field_ID = buttonTag.getAttribute('data-'+CONSTANTS.quick_edit_field);
    }

    let value_field = document.getElementById(field_ID);

    if(action == 'cancel'){
        if(targetTag._quick_edit_initial_value !== undefined){
            targetTag.innerHTML = targetTag._quick_edit_initial_value;
            delete(targetTag._quick_edit_initial_value);
            return;
        }
    }

    if(!$_v.checkField(value_field)){
        alert(CONSTANTS.GetText('error')+' : '+value_field._validatorIcon.getAttribute('title'));
        value_field.focus();
        return false;
    }

    let data = value_field.getAttribute('data-'+CONSTANTS.quick_edit_data);
    id_lang_data = value_field.getAttribute('data-id_lang_data');

    let dataTag = null;
    if(!data){
        dataTag = value_field.parentNode;
        let loops = 0;
        while(!data && dataTag && loops < 1000){
            data = dataTag.getAttribute('data-'+CONSTANTS.quick_edit_data);
            if(!data){
                dataTag = dataTag.parentNode;
            }
            loops++;
        }
    }

    if(!data){
        return false;
    }

    let id = value_field.getAttribute('data-'+CONSTANTS.quick_edit_id);
    let type = value_field.getAttribute('data-'+CONSTANTS.quick_edit_type);

    let sender = $_a.getSender();
    let settings = {};
    settings.url = dataTag.getAttribute('action');

    settings.data = {'quick_edit':action , 'id':id , 'type':type , 'data':data , 'value':value_field.value , 'id_lang_data':id_lang_data};

    settings.success = function(responseText , ajaxSender){

        if(responseText == 'ERROR!'){
            if(targetTag._quick_edit_initial_value !== undefined){
                targetTag.innerHTML = targetTag._quick_edit_initial_value;
            }
            console.warn('Error in quick edit !');
        }else{
            targetTag.innerHTML = responseText;
        }

        delete(targetTag._quick_edit_initial_value);
    };

    settings.error = function(event){
        debugger;
    };
    sender.setData(settings);
    sender.send();

};

AJAX_Class.quick_edit = function(targetTag){

    if(targetTag._quick_edit_initial_value !== undefined){
        return false;
    }


    let data = targetTag.getAttribute('data-'+CONSTANTS.quick_edit_data);
    let dataTag = null;
    if(!data){
        dataTag = targetTag.parentNode;
        let loops = 0;
        while(!data && dataTag && loops < 1000){
            data = dataTag.getAttribute('data-'+CONSTANTS.quick_edit_data);
            if(!data){
                dataTag = dataTag.parentNode;
            }
            loops++;
        }
    }

    if(!data){
        return false;
    }

    let id = targetTag.getAttribute('data-'+CONSTANTS.quick_edit_id);
    let type = targetTag.getAttribute('data-'+CONSTANTS.quick_edit_type_index);
    let id_lang_data = targetTag.getAttribute('data-id_lang_data');

    targetTag._quick_edit_initial_value = targetTag.innerHTML;

    let sender = $_a.getSender();
    let settings = {};
    settings.url = dataTag.getAttribute('action');
    settings.dom_target = targetTag;
    settings.data = {'quick_edit':true , 'id':id , 'type':type , 'data':data , 'value':targetTag.innerHTML , 'id_lang_data':id_lang_data };

    sender.setData(settings);
    sender.send();
};

AJAX_Class.tinymce_image_upload_handler = function(blobInfo, success, failure) {
    var xhr, formData;

    xhr = new XMLHttpRequest();
    xhr.withCredentials = false;
    xhr.open('POST', this.url);

    xhr.onload = function() {
        let json;

        if (xhr.status != 200) {
            failure('HTTP Error: ' + xhr.status);
            return;
        }

        try{
            json = JSON.parse(xhr.responseText);
        }catch(e){
            json = false;
            console.log(e);
        }

        if (!json || typeof json.location != 'string') {
            failure('Invalid JSON: ' + xhr.responseText);
            return;
        }

        success(json.location);
    };

    formData = new FormData();
    formData.append('file', blobInfo.blob(), blobInfo.filename());
    formData.set('action', this.action);

    console.log(blobInfo.filename());

    xhr.send(formData);
};

// get the first available XHR, if none is found a new one is created
AJAX_Class.prototype.getSender = function(){

    let sender = null;

    for(let i = 0 , c = this.xhr_list.length ; i < c ; i++){
        if(!this.xhr_list[i].busy){
            if(this._debug){
                console.log('reuse sender ',i);
            }
            sender = this.xhr_list[i];
            break;
        }
    }

    if(sender === null){
        if(this._debug){
            console.log('create sender');
        }
        sender = new AJAX_SENDER();
        this.xhr_list.push(sender);
    }

    sender._debug = this._debug;

    return sender;
};

// send data according to the settings
AJAX_Class.prototype.send = function(settings , delay , queue){

    let sender = this.getSender();

    sender._debug = this._debug;

    if(this.running_stream_count <= this._consecutive_streams && !delay && !queue){
        sender.send(settings);
        return sender;
    }else{
        // if too many ajax stream are running, put the current in a waiting queue and run it later
        if(sender.setData(settings)){
            if(delay){
                sender._delayedSendTime = Date.now() + delay;
            }
            //~ if (sender._file) {
                //~ this._files_queue.push(sender);
                //~ return sender;
            //~ }
            this.queue(sender);
        }
        return false;
    }
};

AJAX_Class.prototype.queue = function(sender){

    this._stream_queue.push(sender);

    if(!GENERICS_Class.IsFunction(sender)){
        sender._state = AJAX_SENDER.STATE_QUEUED;
    }

    // try again to run the ajax call in 200ms
    if(this._queue_timer){
        clearTimeout(this._queue_timer);
    }

    this._queue_timer = setTimeout(this._process_queue.bind(this),200);
};

AJAX_Class.prototype._process_queue = function(){

    if(this._queue_timer){
        clearTimeout(this._queue_timer);
    }

    // try to run the next ajax stream
    if(this._stream_queue.length){

        if(GENERICS_Class.IsFunction (this._stream_queue[0])){
            let f = this._stream_queue.shift();
            f();
        }else{

            if(this.running_stream_count <= this._consecutive_streams){

                    let sender = this._stream_queue[0];
                    let send = false;
                    if(sender._delayedSendTime){
                        if(Date.now() >= sender._delayedSendTime){
                            send = true;
                        }
                    }else{
                        send = true;
                    }
                    // test for the big file upload pause
                    if (sender._file && sender.pause_on_next_chunk){
                        send = false;
                    }
                    if(send){
                        sender = this._stream_queue.shift();
                        sender.send();
                    }

            }
        }
        this._queue_timer = setTimeout(this._process_queue.bind(this),200);
    }
};

// compute the global progress for all the ajax streams running
AJAX_Class.prototype.computeProgress = function() {
    let up_bytes_loaded = 0;
    let up_bytes_total = 0;

    let down_bytes_loaded = 0;
    let down_bytes_total = 0;

    let up_unknown_loaded = 0;
    let down_unknown_loaded = 0;

    this._up_overload = 0;
    this._up_speed = 0;
    this._down_speed = 0;
    this._speed = 0;

    this._down_zero_loaded = 0;
    this._down_zero_total = 0;

    for(let i = 0 , c = this.xhr_list.length ; i < c ; i++){
        let x = this.xhr_list[i];
        if(x.busy){
            this._up_speed += x.up_speed;
            this._down_speed += x.down_speed;

            if(x._state == AJAX_SENDER.STATE_UPLOADING){
                this._speed += x.up_speed;
            }

            if(x._state == AJAX_SENDER.STATE_DOWNLOADING){
                this._speed += x.down_speed;
            }

            if(x.up_progress === null){
                up_unknown_loaded += x.up_loaded_bytes;
            }else{
                up_bytes_loaded += x.up_loaded_bytes;
                up_bytes_total += x.up_total_bytes;
            }

            if(x.down_progress === null){
                down_unknown_loaded += x.down_loaded_bytes;
            }else{
                down_bytes_loaded += x.down_loaded_bytes;
                down_bytes_total += x.down_total_bytes;

                if(x._download_done && x.down_total_bytes === 0){
                    this._down_zero_loaded ++;
                    this._down_zero_total ++;
                }
            }


        }
    }

    if(up_unknown_loaded + up_bytes_loaded > up_bytes_total){
        up_bytes_total = up_unknown_loaded + up_bytes_loaded;
        this._up_overload = up_unknown_loaded;
    }

    if(down_unknown_loaded + down_bytes_loaded > down_bytes_total){
        down_bytes_total = down_unknown_loaded + down_bytes_loaded;
        down_bytes_loaded += down_unknown_loaded;
        this._down_overload = down_unknown_loaded;
    }

    this._down_loaded_bytes = down_bytes_loaded;
    this._down_total_bytes = down_bytes_total;

    this._up_loaded_bytes = up_bytes_loaded;
    this._up_total_bytes = up_bytes_total;

    this._last_data_time = Date.now();
};

// indicates a temporary upload info until we had a correct update from the browser
Object.defineProperty(AJAX_Class.prototype, 'up_overload', {
    get: function() {
        return this._up_overload;
    }
});

// indicates a temporary dowload info until we had an answer from the server
Object.defineProperty(AJAX_Class.prototype, 'down_overload', {
    get: function() {
        return this._down_overload;
    }
});

// current overall upload speed
Object.defineProperty(AJAX_Class.prototype, 'up_speed', {
    get: function() {
        return this._up_speed;
    }
});

// current overall download speed
Object.defineProperty(AJAX_Class.prototype, 'down_speed', {
    get: function() {
        return this._down_speed;
    }
});

// number of XHR doing something (initialization, upload, download, finalization ...)
Object.defineProperty(AJAX_Class.prototype, 'busy_stream_count', {
    get: function() {
        this._busy_stream_count = 0;
        for(let i = 0 , c = this.xhr_list.length ; i < c ; i++){
            if(this.xhr_list[i].busy){
                this._busy_stream_count++;
            }
        }
        return this._busy_stream_count;
    }
});

// number of transfer in progress
Object.defineProperty(AJAX_Class.prototype, 'running_stream_count', {
    get: function() {
        this._running_stream_count = 0;
        for(let i = 0 , c = this.xhr_list.length ; i < c ; i++){
            if(this.xhr_list[i].running){
                this._running_stream_count++;
            }
        }
        return this._running_stream_count;
    }
});

// overall upload progress (value between 0 and 1)
Object.defineProperty(AJAX_Class.prototype, 'up_progress', {
    get: function() {
        if(this._last_data_time === 0 || (Date.now() - this._last_data_time) > 100){
            this.computeProgress();
        }
        return this._up_total_bytes > 0 ? this._up_loaded_bytes / this._up_total_bytes : 0;
    }
});

// overall download progress (value between 0 and 1)
Object.defineProperty(AJAX_Class.prototype, 'down_progress', {
    get: function() {
        if(this._last_data_time === 0 || (Date.now() - this._last_data_time) > 100){
            this.computeProgress();
        }
        return this._down_total_bytes > 0 ? this._down_loaded_bytes / this._down_total_bytes : this._down_zero_total > 0 ? this._down_zero_loaded / this._down_zero_total : 0;
    }
});

// overall progression average
Object.defineProperty(AJAX_Class.prototype, 'progress', {
    get: function() {
        return (this.up_progress + this.down_progress) * 0.5;
    }
});

// overall speed average
Object.defineProperty(AJAX_Class.prototype, 'speed', {
    get: function() {
        return this._speed;
    }
});


//****************************************************************************************
// AJAX_SENDER Class declaration
var AJAX_SENDER = function(){
    var _self = this;

    this._xhr = new XMLHttpRequest();

    this._xhr._AJAX_SENDER = this;
    this._xhr.upload._AJAX_SENDER = this;

    this._xhr.addEventListener('loadend',this._onDownLoadend.bind(this));
    this._xhr.addEventListener('progress',this._downProgress.bind(this));

    this._xhr.addEventListener('load' , this.processResponse.bind(this));
    this._xhr.addEventListener('error' , this.processResponse.bind(this));

    this._xhr.upload.addEventListener('loadend',this._onUpLoadend.bind(this));
    this._xhr.upload.addEventListener('progress',this._upProgress.bind(this));
    //~ this._xhr.upload.onerror = (...err) => {
        //~ console.log('Upload failed.', err);
    //~ }
    //~ this._xhr.upload.ontimeout  = (...err) => {
        //~ console.log('Upload timeout.', err);
    //~ }

    this._xhr.addEventListener('readystatechange' , this._readyStateChange.bind(this));

    this._state = AJAX_SENDER.STATE_NOTHING;

    //~ this._files = [];
    //~ this.pause_on_next_chunk = false;

    this._reset();
};
AJAX_SENDER.prototype.constructor = AJAX_SENDER;
//~ class AJAX_SENDER {
    //~ constructor() {
        //~ var _self = this;

        //~ this._xhr = new XMLHttpRequest();

        //~ this._xhr._AJAX_SENDER = this;
        //~ this._xhr.upload._AJAX_SENDER = this;

        //~ this._xhr.addEventListener('loadend',this._onDownLoadend.bind(this));
        //~ this._xhr.addEventListener('progress',this._downProgress.bind(this));

        //~ this._xhr.addEventListener('load' , this.processResponse.bind(this));
        //~ this._xhr.addEventListener('error' , this.processResponse.bind(this));

        //~ this._xhr.upload.addEventListener('loadend',this._onUpLoadend.bind(this));
        //~ this._xhr.upload.addEventListener('progress',this._upProgress.bind(this));

        //~ this._xhr.addEventListener('readystatechange' , this._readyStateChange.bind(this));

        //~ this._state = AJAX_SENDER.STATE_NOTHING;

        //~ this._files = [];

        //~ this._reset();
    //~ }
//~ }

AJAX_SENDER.STATE_NOTHING = 0;
AJAX_SENDER.STATE_QUEUED = 1;
AJAX_SENDER.STATE_UPLOADING = 2;
AJAX_SENDER.STATE_DOWNLOADING = 3;

AJAX_SENDER.prototype._readyStateChange = function(event){

    switch(this.readyState){
        case this.UNSENT:
            if(this._debug){ console.log('init',event); }
        break;

        case this.OPENED:
            if(this._debug){ console.log('connexion open',event); }
        break;

        case this.HEADERS_RECEIVED:
            if(this._debug){
                console.log('header received',event);
                console.log(this.getAllResponseHeaders());
            }
        break;

        case this.LOADING:
            if(this._debug){ console.log('loading ...',event); }
        break;

        case this.DONE:
            if(this._debug){ console.log('all done',event); }
            
        break;

    }

};

AJAX_SENDER.prototype._reset = function(){

    this._data = null;
    this._localdata = null;

    this._busy = false;
    this._action = '';
    this._method = 'POST';

    this._state = AJAX_SENDER.STATE_NOTHING;

    this._up_progress = 0;
    this._down_progress = 0;

    this._up_total_bytes = 0;
    this._down_total_bytes = 0;

    this._up_loaded_bytes = 0;
    this._down_loaded_bytes = 0;

    this._current_success_callback = null;
    this._current_error_callback = null;
    this._current_down_progress_callback = null;
    this._current_up_progress_callback = null;

    this._last_up_time = 0;
    this._last_down_time = 0;

    this._up_speed = 0;
    this._down_speed = 0;

    this._download_done = false;

    //~ this._files.length = 0;
    //~ this.pause_on_next_chunk = false;
};

// compute the current upload progression of this sender
AJAX_SENDER.prototype._upProgress = function(event){

    //let target = this._AJAX_SENDER || this;
    let target = this;

    target._state = AJAX_SENDER.STATE_UPLOADING;

    if(target._last_up_time > 0 && event.loaded != event.total){
        let time_offset = Date.now() - target._last_up_time;
        let bytes_offset = event.loaded - target._up_loaded_bytes;

        target._up_speed = bytes_offset * (1000 / time_offset);
    }
    target._last_up_time = Date.now();

    if(target._send_time <= 0){
        target._send_time = target._last_up_time;
    }

    target._up_loaded_bytes = event.loaded;

    if (event.lengthComputable) {
        target._up_progress = event.loaded / event.total;
        target._up_total_bytes = event.total;

        //~ this._files_count = 0;
        //~ this._files_completed = 0;
        //~ if(this._files){
            //~ this._files_count = this._files.length;

            //~ for(let i = 0 ; i < this._files_count ; i++){
                //~ if(this._files[i].end <= event.loaded){
                    //~ this._files[i].progress = 1;
                    //~ this._files_completed++;

                //~ }else if(this._files[i].start > event.loaded){
                    //~ this._files[i].progress = 0;
                //~ }else{
                    //~ this._files[i].progress = (event.loaded - this._files[i].start) / (this._files[i].file.size);
                //~ }
            //~ }
        //~ }
    }else{
        target._up_progress = null;
        target._up_total_bytes = null;
    }


    if(this._current_up_progress_callback){
        this._current_up_progress_callback(event,this);
    }
};

// compute the current download progression of this sender
AJAX_SENDER.prototype._downProgress = function(event){

    let target = this;
    target._state = AJAX_SENDER.STATE_DOWNLOADING;

    if(target._last_down_time > 0 && event.loaded != event.total){
        let time_offset = Date.now() - target._last_down_time;
        let bytes_offset = event.loaded - target._down_loaded_bytes;
        target._down_speed = bytes_offset * (1000 / time_offset);
    }
    target._last_down_time = Date.now();

    if(target._send_time <= 0){
        target._send_time = target._last_down_time;
    }

    target._down_loaded_bytes = event.loaded;

    if (event.lengthComputable) {

        target._down_progress = event.loaded / event.total;
        target._down_total_bytes = event.total;
    }else{
        target._down_progress = null;
        target._down_total_bytes = null;
    }

    if(this._current_down_progress_callback){
        this._current_down_progress_callback(event,this);
    }
};

// action = url php script
// data = form dom object, formdata object, or and object with variables to send
// extra_data = object with additional variables to send
// down_progress : progress callback for download
// up_progress : progress callback for upload
// error : error callback
// success : success callback
// json_mode:
// AJAX_Class.JSON_OFF = 0 = the json string untouched server side
// AJAX_Class.JSON_ON = 1 = basic json decode server side : js objects are converted to PHP objects and js arrays to PHP arrays
// AJAX_Class.JSON_ARRAY = 2 = (default) automatically convert json strings to PHP associative arrays when an object or an array is sent
AJAX_SENDER.prototype.setData = function(settings){
    settings = settings || {};

    if(settings['skip_container']){
        delete(settings['skip_container']);
        if(!settings.extra_data) settings.extra_data = {};
        settings.extra_data[CONSTANTS.posted_varname] = 1;
    }
    if(settings['container_name']){
        
        if(!settings.extra_data) settings.extra_data = {};
        settings.extra_data[CONSTANTS.posted_varname_container] = settings['container_name'];
        delete(settings['container_name']);
    }

    this._reset();
    
    this._timer_needed = (settings.notimer == undefined);

    let formAction = null;

    if(GENERICS_Class.IsObject(settings) && settings.tagName == 'FORM'){
        formAction = settings.getAttribute('action');
    }

    if(!settings.action && settings.url){
        settings.action = settings.url;
    }

    settings.action = settings.action || this._action;
    settings.method = settings.method || this._method;

    if(settings.json_mode === undefined){
        settings.json_mode = AJAX_Class.JSON_ARRAY;
    }

    // local data retrievable on receipt of the query result, in the sender object
    if(settings.localdata !== undefined){
        this._localdata = settings.localdata;
    }

    let json_decode_list = [];
    let json_list_identifier = AJAX_Class.json_list_identifier;
    
    // Si file présent est a true, on envoie un chunk seulement
    //~ if (settings.file){
        //~ this._file = true;
        //~ this._fileData = settings.fileData;
    //~ } else {
        //~ this._file = false;
        //~ this._fileData = {};
    //~ }
    //~ this._bigFileLst = [];
    this._fileLst = [];
    
    if(GENERICS_Class.IsObject(settings.data)){

        if(GENERICS_Class.IsFormdata(settings.data)){
            //~ console.log('is formData');
            // ok !
            //~ let keys = ;
            //~ console.log(keys);
            //~ for (let key in settings.data.keys()){
                //~ console.log(key);
                //~ let vals = settings.data.getAll(key);
                //~ console.log(vals);
                //~ for (let val in vals){
                    //~ console.log(val);
                //~ }
            //~ }
            let already_parsed = [];
            let toReplace = [];
            for (var pair of settings.data.entries()){
                if (already_parsed.indexOf(pair[0]) == -1){
                    let vals = settings.data.getAll(pair[0]);
                    let is_file = false;
                    let newVal = [];
                    //~ console.log(pair);
                    
                    vals.forEach((val,key)=>{
                        if (!GENERICS_Class.IsString(val)){
                            // a value in formData can be a string or a file
                            this._fileLst.push(val);
                            newVal.push(val.name);
                            is_file = true;
                        }
                    });
                    if (is_file){
                        already_parsed.push(pair[0]);
                        toReplace.push({'key': pair[0], 'val':newVal});
                    }
                    already_parsed.push(pair[0]);
                }
            }
            // toReplace.forEach((obj)=>{settings.data.set(obj.key, obj.val);});
            toReplace.forEach((obj)=>{settings.data.delete(obj.key);});

        }else if(settings.data.tagName === 'FORM'){
            // add form inputs
            settings.action = settings.action || settings.data.getAttribute('action');
            settings.method = settings.method || settings.data.getAttribute('method');

            let only_submitter = false;
            if(settings.data._submitter){
                if(!settings.extra_data){
                    settings.extra_data = {};
                }
                settings.extra_data[settings.data._submitter.name] = settings.data._submitter.value;
                if(settings.data._submitter.getAttribute('data-only')){
                    only_submitter = true;
                }
            }

            let formData;
            if(only_submitter){
                formData = new FormData();
            }else{

                formData = new FormData();

                let el = settings.data.elements;
                for(let i = 0; i < el.length ; i++){
                    let input = el[i];
                    let tag_name = input.tagName.toLowerCase();
                    let tag_type = input.type.toLowerCase();

                    if(tag_name == "button" && tag_type == "submit" && settings.data._submitter && settings.data._submitter !== input){
                        // we exclude submits that are not used
                        continue;
                    }
                    //~ console.log(tag_name);
                    //~ if(tag_name == "textarea"){
                        //~ console.log(input.value);
                        //~ input.value= input.value.replace(/(?:\r\n|\r(?=\n)|\n(?=\r))/g, '\r\n');
                        //~ input.value= input.value.replace(/\n/g, "\r\n").replace(/\r\r/g, "\r");
                        //~ console.log(input.value);
                    //~ }
                    
                    if(tag_name == "input" && tag_type == "file"){
                        if (settings.ignore_file){
                            continue;
                        }
                        for(let f=0 ; f < input.files.length ; f++){
                            //~ if (input.files[f].size < CONSTANTS.file_upload_size){
                                // petit fichier, on l'envoie avec le form
                                //~ formData.append( input.name , input.files[f]);
                            //~ } else {
                                // gros fichier, on l'envoie par chunk
                                this._fileLst.push(input.files[f]);
                                formData.append( input.name , input.files[f].name);
                            //~ }
                            
                        }
                    }else{
                        if(tag_name == "input" && tag_type == "checkbox"){
                            if(input.checked){
                                formData.append( input.name , input.value);
                            }

                        }else if(tag_name == "input" && tag_type == "radio"){
                            if(input.checked){
                                formData.append( input.name , input.value);
                            }
                        }else{
                            formData.append( input.name , input.value);
                        }
                    }

                }


            }

            settings.data = formData;

        }else{
            // add object data
            let formData = new FormData();

            let keys = Object.keys(settings.data);

            for(let i = 0 , c = keys.length ; i < c ; i++){

                let name = keys[i];
                let value = settings.data[name];

                if(value === true){
                    value = 1;
                }

                if(value === false){
                    value = 0;
                }

                if(GENERICS_Class.IsObject(value)){

                    if(GENERICS_Class.IsObject(value)){
                        formData.append( name , JSON.stringify(value));
                        if(settings.json_mode){
                            json_decode_list.push(name);
                        }
                    }else{
                        formData.append( name , value );
                    }

                }else{
                    formData.append( name, value );
                }
            }

            settings.data = formData;
        }

        if(!AJAX_Class.checkFileData(settings.data)){
            return;
        }

        // add extra data
        if(GENERICS_Class.IsObject(settings.extra_data)){

            let keys = Object.keys(settings.extra_data);

            for(let i = 0 , c = keys.length ; i < c ; i++){

                let name = keys[i];
                let value = settings.extra_data[name];

                if(GENERICS_Class.IsObject(value) ){
                    settings.data.append( name , JSON.stringify(value) );
                    if(settings.json_mode){
                        json_decode_list.push( name );
                    }
                }else{
                    settings.data.append( name , value );
                }
            }
        }

        //~ this._files.length = 0;
        //~ let entries = settings.data.entries();
        //~ let obj = entries.next();
        //~ let start = 0;
        //~ while(undefined !== obj.value) {
            //~ let t = Object.prototype.toString.apply(obj.value[1]);
            //~ if(t == '[object File]'){
                //~ this._files.push({'file':obj.value[1] , 'start':start , 'end':start+obj.value[1].size-1 , 'progress':0});
                //~ start += obj.value[1].size;
            //~ }
            //~ obj = entries.next();
        //~ }


        if(settings.json_mode){
            settings.data.append(json_list_identifier , JSON.stringify(json_decode_list));
            settings.data.append(json_list_identifier+'_mode' , settings.json_mode);
        }
    }
//~ console.log(settings);
    if(settings.debug){
        console.log(this);
        for(var pair of settings.data.entries()) {
           console.log(pair[0] ,'=', pair[1]);
        }
    }

    if(GENERICS_Class.IsFunction(settings.success)){
        this._current_success_callback = settings.success;
    }else{
        this._current_success_callback = null;
    }

    if(GENERICS_Class.IsFunction(settings.error)){
        this._current_error_callback = settings.error;
    }else{
        this._current_error_callback = null;
    }

    if(GENERICS_Class.IsFunction(settings.up_progress)){
        this._current_up_progress_callback = settings.up_progress;
    }else{
        this._current_up_progress_callback = null;
    }

    if(GENERICS_Class.IsFunction(settings.down_progress)){
        this._current_down_progress_callback = settings.down_progress;
    }else{
        this._current_down_progress_callback = null;
    }

    this.busy = true;

    this._method = settings.method;

    this._action = formAction || settings.action;

    this._dom_target = DOM_Class.GetDomElement(settings.dom_target);

    this._replace_dom_target = settings.replace_dom_target;

    this._allow_target_update = settings.disableTargetUpdate?false:true;

    this._data = settings.data;

    return true;
};

Object.defineProperty(AJAX_SENDER.prototype, 'dom_target', {
    get: function() {
        return this._dom_target;
    }
});

Object.defineProperty(AJAX_SENDER.prototype, 'data', {
    get: function() {
        return this._data;
    }
});

Object.defineProperty(AJAX_SENDER.prototype, 'method', {
    get: function() {
        return this._method;
    }
});

Object.defineProperty(AJAX_SENDER.prototype, 'action', {
    get: function() {
        return this._action;
    }
});

AJAX_SENDER.prototype.updateResponseData = function(event){
    this._down_total_bytes = event.total;
    this._down_loaded_bytes = event.loaded;

    this._download_done = true;

    // compute the average download speed
    if(this._send_time > 0){
        this._down_speed = event.loaded * (1000 / (Date.now() - this._send_time));
    }

    if(this._current_down_progress_callback !== null){

        // execute the progress call back for a last update
        this._current_down_progress_callback(event , this);

    }
};

AJAX_SENDER.ProcessJson = function(result){
    if(GENERICS_Class.IsObject(result)){

        if(result.reload_after_message){
            result.url = result.reload_after_message;
        }

        if(result.messages){
            UI_Class.MessagePopup(result.messages , result.reload_after_message ? DOM_Class.reload_page.bind(result) : undefined );
        }

        if(result.url === CONSTANTS.reload_noparams){
            DOM_Class.reload_page(result.url);
        }else{
            if(result.errors){
                UI_Class.MessagePopup(result.errors , result.reload_after_message ? DOM_Class.reload_page.bind(result) : undefined );
            }
        }
    }
};

AJAX_SENDER.prototype.processResponse = function(event){

    let type = this._xhr.getResponseHeader('Content-Type');

    //hide waiting modal
    if (!this.timer_modal_is_hide && this.timer_modal){
        this.timer_modal.Hide();
        this.timer_modal_is_hide = true;
    }


    let result = this._xhr.responseText;
    if(type == 'application/json'){
        try{
            result = JSON.parse(result);
        }catch(e){
            result = this._xhr.responseText;
        }
    }

    this.updateResponseData(event);

    if(this._xhr.status >= 400){
        console.error('Ajax Error',this._xhr);
        if(this._current_error_callback){
            this._current_error_callback(result , this);
        }

    }else{

        AJAX_SENDER.ProcessJson(result);

        if(this._dom_target && this._allow_target_update){

            if(GENERICS_Class.IsObject(result)){

                if(result.html !== undefined){
                    if(this._replace_dom_target){
                        DOM_Class.ReplaceElement(this._dom_target , result.html);
                    }else{
                        DOM_Class.WriteHtml(this._dom_target , result.html );
                    }

                }

            }else if(GENERICS_Class.IsString(result)){
                if(this._replace_dom_target){
                    DOM_Class.ReplaceElement(this._dom_target , result);
                }else{
                    DOM_Class.WriteHtml(this._dom_target , result );
                }
            }else{
                console.warn('Wrong ajax result type',result);
            }
        }

        if(this._current_success_callback){
            this._current_success_callback(result , this);
        }
    }
};

AJAX_SENDER.prototype.processError = function(event,...args){
    console.log(event);
    console.log(this._xhr);
    console.log(args);

    let type = this._xhr.getResponseHeader('Content-Type');
    
    //hide waiting modal
     if (!this.timer_modal_is_hide && this.timer_modal){
        this.timer_modal.Hide();
        this.timer_modal_is_hide = true;
    }

    let result = this._xhr.responseText;
    if(type=='application/json'){
        result = JSON.parse(result);
    }

    this.updateResponseData(event);

    if(this._current_error_callback){
        this._current_error_callback(result , this);
    }

    if(this._dom_target && this._allow_target_update){

        if(GENERICS_Class.IsObject(result)){

            if(result.html !== undefined){
                DOM_Class.WriteHtml(this._dom_target , result.html );
            }

        }else if(GENERICS_Class.IsString(result)){
            DOM_Class.WriteHtml(this._dom_target , result );

        }else{
            console.warn('Wrong ajax result type',result);
        }
    }

};

AJAX_SENDER.prototype.send = function(settings){
    // when sending a file, need to save the settings object before the processing
    let originalSettings = settings;
    
    if(settings){
        if(!this.setData(settings)){
            return false;
        }
    }
    
    if (this._fileLst.length > 0){
        originalSettings.ignore_file = true;
        // console.log(this._fileLst);
        let fileSender = new AJAX_FILE(this._fileLst,originalSettings);
        return;
    }

    this._xhr.open(this._method, this._action , true);
    
    this._xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
    this._xhr.setRequestHeader('Cache-Control', 'no-cache');
    
    if (this._xhr.readyState != 1) {
        console.warn("Cannot send this request because the XMLHttpRequest.readyState is not OPENED.");
        console.log(this);
        return;
    }
    if (!this.timer_modal && this._timer_needed ){
        this.timer_modal =  UI_Class.AddWindow(null, {'modal': true, 'nodrag': true, 'class':'timer_requete', 'disableBackgroundClick': true});
        this.timer_modal.SetParent(document.body, 0.5, 0.5);
        this.timer_modal_is_hide = false;
        this.timer_modal._modalMask.classList.add('load_timer');
    } else {
        if (this.timer_modal_is_hide && this._timer_needed) {
            this.timer_modal.Show();
            this.timer_modal_is_hide = false;
        }
    }
    this._xhr.send(this._data);
    this.running = true;

    this._state = AJAX_SENDER.STATE_UPLOADING;

    this._send_time = Date.now();
};


AJAX_SENDER.prototype.Abort = function(event){
    this._current_success_callback = null;
    this._current_error_callback = null;
    this._current_down_progress_callback = null;

    this.busy = false;
    this.running = false;

    this._xhr.abort();
};

AJAX_SENDER.prototype._onDownLoadend = function(event){

    let ajax_sender = this;
    let xhr = ajax_sender._xhr;

    if(ajax_sender._debug){
        console.log('DOWN end',event);
    }

    // compute the average download speed
    if(ajax_sender._send_time > 0){
        ajax_sender._down_speed = event.loaded * (1000 / (Date.now() - ajax_sender._send_time));
    }

    if(ajax_sender._current_down_progress_callback){

        // execute the progress call back for a last update
        ajax_sender._current_down_progress_callback(event , this);

    }

    ajax_sender._current_success_callback = null;
    ajax_sender._current_error_callback = null;
    ajax_sender._current_down_progress_callback = null;

    ajax_sender.busy = false;
    ajax_sender.running = false;

    xhr.abort();

};


AJAX_SENDER.prototype._onUpLoadend = function(event){

    let ajax_sender = this;
    let xhr = ajax_sender._xhr;

    if(this._debug){
        console.log('UP end',event);
    }

    ajax_sender._up_total_bytes = event.total;
    ajax_sender._up_loaded_bytes = event.loaded;

    // compute the average upload speed
    if(ajax_sender._send_time > 0){
        ajax_sender._up_speed = event.loaded * (1000 / (Date.now() - ajax_sender._send_time));
    }

    if(ajax_sender._current_up_progress_callback){

        // execute the progress call back for a last update
        ajax_sender._current_up_progress_callback(event,this);

    }

    ajax_sender._current_up_progress_callback = null;

    // reset time counter for the download step coming after this
    ajax_sender._send_time = Date.now();
};

Object.defineProperty(AJAX_SENDER.prototype, 'busy', {
    get: function() {
        return this._busy;
    },
    set: function(value) {
        this._busy = value === true;
    }
});

Object.defineProperty(AJAX_SENDER.prototype, 'progress', {
    get: function() {
        if(this._up_progress === null || this._down_progress === null){
            return null;
        }
        return (this._up_progress + this._down_progress) * 0.5;
    }
});

//~ Object.defineProperty(AJAX_SENDER.prototype, 'files_up_progress', {
    //~ get: function() {
        //~ return {'completed':this._files_completed , 'total':this._files_count , 'files':this._files };
    //~ }
//~ });

Object.defineProperty(AJAX_SENDER.prototype, 'up_progress', {
    get: function() {
        return this._up_progress;
    }
});

Object.defineProperty(AJAX_SENDER.prototype, 'down_progress', {
    get: function() {
        return this._down_progress;
    }
});

Object.defineProperty(AJAX_SENDER.prototype, 'up_loaded_bytes', {
    get: function() {
        return this._up_loaded_bytes;
    }
});

Object.defineProperty(AJAX_SENDER.prototype, 'up_total_bytes', {
    get: function() {
        return this._up_total_bytes;
    }
});

Object.defineProperty(AJAX_SENDER.prototype, 'down_loaded_bytes', {
    get: function() {
        return this._down_loaded_bytes;
    }
});


Object.defineProperty(AJAX_SENDER.prototype, 'down_total_bytes', {
    get: function() {
        return this._down_total_bytes;
    }
});

Object.defineProperty(AJAX_SENDER.prototype, 'up_speed', {
    get: function() {
        return this._up_speed;
    }
});

Object.defineProperty(AJAX_SENDER.prototype, 'down_speed', {
    get: function() {
        return this._down_speed;
    }
});

var AJAX_FILE = function(fileLst,originalRequest){
    var self = this;
    
    var debug = false;
    
    if (debug){
        console.log('new AJAX_FILE','fileLst',fileLst,'originalRequest',originalRequest);
    }
    
    var slicesTotal = 0; // count the total amount of slice sent
    
    // current start and end byte
    var chunkStart = 0;
    var chunkEnd;
    // index of current chunk 
    var chunkIndex = 0;
    // adaptative size of chunk, depending the upload speed
    var chunkSize = CONSTANTS.slice_upload_size;
    
    // when there is a file in a form or in a request,
    // the request stop and send the file
    // once is done, re-send the original request
    var originalRequest = originalRequest;
    var original_time = (originalRequest.data.has('time')) ? originalRequest.data.get('time') : false;
    
    var queue;
    var file;
    
    var Dom_ID = GENERICS_Class.GetUniqueId();
    
    // handle stop of an upload
    var aborted = false;
    // handle pause of an upload
    var paused = false;
    
    // calculate the number of slices (chunk)
    var startTime = Date.now();
    var lastChunkSendingTime = 0; // enregistre le dernier temps passé à envoyer un chunk
    var chunkStartTime = Date.now();
    
    var xhr = new XMLHttpRequest();
    
    // progress bytes by chunk
    var last_progress_time = 0;
    
    // progress for each chunk
    var chunkTotalBytes = 0;        // chunk size
    var chunkUploadedBytes = 0;     // already loaded 
    var chunkProgress = 0;          // progress, 0 to 1
    
    var errors = [];
    
    this.speed,this.fileCount,this.fileSended;
    
    this.all = {
        'progress': 0,
        'total': 0,
        'loaded': 0
    };
    this.current = {
        'name': '',
        'progress': 0,
        'total': 0,
        'loaded': 0,
        'small': false,
    };
    
    // for tracking time, used for debug
    var startTime,endTime;
    
    var uniqueid = Date.now();
    
    function sendChunk(){
        if (xhr.readyState > 0){
            console.log('not sending next chunk, xhr not ready');
            return false;
        }
        if (paused){
            console.log('not sending next chunk, upload paused');
            return false;
        }
        if (aborted){
            console.log('not sending next chunk, upload aborted');
            return false;
        }
        
        if (!self.current.small){
            
            slicesTotal++; // count total slice for merge
            
            chunkEnd = chunkStart + chunkSize;
            if(chunkEnd > file.size) {
                // Pour que le dernier chunk soit correct
                chunkEnd = file.size;
                chunkSize = chunkEnd - chunkStart;
            }
        
            chunk = file.slice(chunkStart, chunkEnd);
        }
        
        xhr.open('POST', CONSTANTS.base_url + 'public/upload.php' , true);
        
        xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
        xhr.setRequestHeader('Cache-Control', 'no-cache');
        
        let formData = new FormData();
        formData.append('filename', file.name);
        formData.append('uniqueid', uniqueid);
        if (self.current.small){
            formData.append('filesize', file.size);
            formData.append('file', file, file.name + '!s!p!a!d!e!' + uniqueid);
            // formData.append('file', file, file.name);
            formData.append('full', 1);
        } else {
            formData.append('filesize', chunk.size);
            formData.append('chunkIndex', chunkIndex);
            formData.append('file', chunk, file.name);
        }
        if (original_time) formData.append('time', original_time);
        
        xhr.onload = onLoadChunk;
        xhr.onerror = function(evt){
            self.cancelFile(originalRequest.error);
            //~ xhr.abort();
            //~ console.log('error', evt);
        };
        xhr.upload.onprogress = onProgressChunk;
        
        xhr.send(formData);
    }
    
    function onLoadChunk(evt){
        let result = xhr.responseText;
        let sendNextChunk = true;
        // console.log(result);
        if (result != 'ok'){
            /* TODO
             * retry sending current chunk ?
             * display error message ?
             */
            //~ console.log('error sending chunk');
            if (!self.current.small){
                errors.push({'path': file.name,'chunk': chunkIndex});
            } else {
                errors.push({'path': file.name,'chunk': false});
            }

            UI_Class.MessagePopup('An error occured with your upload.');

            self.cancelFile(originalRequest.error);
            return;
        }
        
        xhr.abort();
        
        // add this chunk to loaded
        if (!self.current.small){
            self.current.loaded += chunkSize;
            self.all.loaded += chunkSize;
        } else {
            self.current.loaded = file.size;
            self.all.loaded += file.size;
        }
        
        chunkUploadedBytes = 0;
        
        // what to do next, sending next chunk or sending merge request ?
        if (self.current.small){
            self.fileSended++;
            processQueue();
            return;
        }
        
        if (sendNextChunk){
            if (chunkEnd < file.size){
                // there is still some byte to send, prepare next chunk
                
                // ADAPTATIVE CHUNK
                // calcul le temps passé à envoyer le chunk
                let currentTime = Date.now();
                let chunkSendingTime = currentTime - chunkStartTime;
                // c'est le premier chunk que l'on envoie
                // Taille courante du chunk * le temps que l'on veut pour envoyer un chunk (ici 5s) / le temps passé a envoyé
                chunkSize = Math.round(chunkSize * ( 5000 / chunkSendingTime)); 
                // enregistre le dernier temps pour le prochain passage
                lastChunkSendingTime = chunkSendingTime;
                chunkStartTime = currentTime;
                
                chunkIndex++;
                chunkStart = chunkEnd;
                
                if (debug){
                    console.log('time sending chunk (s)', (lastChunkSendingTime/1000));
                }
                
                sendChunk();
            } else {
                // every byte have been sent, send merge request to the server
                
                // display the real time for uploading the file
                //~ let endChunkTime = Date.now();
                //~ let diff = (endChunkTime - startTime) / 1000;
                //~ console.log('time passed sending all chunk (s)', diff);
                
                mergeFile();
            }
        } else {
            self.fileSended++;
            processQueue();
        }
    }
    
    function onProgressChunk(evt){
        //~ console.log(evt);
        //~ if(last_progress_time > 0 && evt.loaded != evt.total){
        if(last_progress_time > 0){
            let time_offset = Date.now() - last_progress_time;
            let bytes_offset = evt.loaded - chunkUploadedBytes;

            self.speed = Math.round(bytes_offset * (1000 / time_offset)); // byte par seconde
        }
        last_progress_time = Date.now();
        chunkUploadedBytes = evt.loaded;

        if (evt.lengthComputable) {
            chunkProgress = evt.loaded / evt.total;
            chunkTotalBytes = evt.total;
            
            //~ console.log('speed byte/s',up_speed);
            
            computeProgress();
            
            if(GENERICS_Class.IsFunction(originalRequest.up_progress)){
                originalRequest.up_progress(evt,self);
            }
        }else{
            chunkProgress = null;
            chunkTotalBytes = null;
        }
    }
    function computeProgress(){
        let currentLoaded = self.current.loaded + chunkUploadedBytes;
        self.current.progress = currentLoaded / self.current.total;
        self.current.progress = self.current.progress > 1 ? 1 : self.current.progress;
        
        //~ console.log('current', self.current.progress);
        
        let allLoaded = self.all.loaded + chunkUploadedBytes;
        self.all.progress = allLoaded / self.all.total;
        self.all.progress = self.all.progress > 1 ? 1 : self.all.progress;
        //~ console.log('total', self.all.progress);
    }
    function mergeFile(){
        let settings = {};
        settings.url = CONSTANTS.base_url + 'public/upload.php';
        settings.notimer = true;
        settings.data = {
            'merge': 1,
            'name': file.name,
            'type': file.type,
            'size': file.size,
            'index': slicesTotal,
            'uniqueid': uniqueid
            //~ 'relativePath': file.webkitRelativePath
        };
        if (original_time) settings.data.time = original_time;
        // if (file.webkitRelativePath != ''){
        //     settings.data.relativePath = file.webkitRelativePath;
        // }
        settings.up_progress = false;
        settings.success = function(res){
            // file send successfully
            self.fileSended++;
            processQueue();
        };
        if (debug){
            console.log('AJAX_FILE sending merge request');
        }
        $_a.send(settings);
    }
    
    this.cancelFile = function(callback){
        aborted = true;
        // stop current xhr sending
        xhr.abort();
        
        // send a request to delete sent chunk
        let settings = {};
        settings.url = CONSTANTS.base_url + 'public/upload.php';
        settings.notimer = true;
        settings.data = {
            'cancel': 1,
            'name': file.name,
            'uniqueid': uniqueid
        };
        if (original_time) settings.data.time = original_time;
        settings.success = callback;
        $_a.send(settings);
    };
    
    this.pauseFile = function(){
        //~ console.log('PAUSE');
        paused = true;
        
        //~ let btn_pause = document.getElementById(Dom_ID+'_pause');
        //~ let btn_reprendre = document.getElementById(Dom_ID+'_reprendre');
        //~ btn_pause.style.display = 'none';
        //~ btn_reprendre.style.display = 'block';
    };
    
    this.reprendreFile = function(){
        //~ console.log('REPRENDRE');
        paused = false;
        
        sendChunk();
    };

    function processQueue(){
        // check the "file" variable, if not empty, mean that a file have been uploaded, add it to the quota used/remain CONSTANTS variable
        if (file){
            CONSTANTS.left -= file.size;
            CONSTANTS.usage += file.size;
            CONSTANTS.percentage = (CONSTANTS.usage / CONSTANTS.quota) * 100;
        }
        if (queue.length > 0){
            
            //~ console.log(queue);
            // begin by the first element of the list to preserve the index with the file_path list (when uploading a folder in filemanager)
            file = queue.shift();
            
            self.current.total = file.size;
            self.current.small = (file.size <= CONSTANTS.file_upload_size);
            
            self.current.loaded = 0;
            slicesTotal = 0;
            chunkStart = 0;
            chunkIndex = 0;
            
            // can't use webkitRelativePath because it's not supported everywhere
            let filename = file.name;
            if (originalRequest.data.has('file_path[]')){
                let paths = originalRequest.data.getAll('file_path[]');
                filename = paths[self.fileSended] + file.name;
            }
            
            self.current.name = filename;
            originalRequest.data.append('lstFilePath[]', filename + '!s!p!a!d!e!' + uniqueid);
            // originalRequest.data.append('lstFilePath[]', filename);
            
            // send the first chunk
            sendChunk();
            
        } else {
            if (errors) originalRequest.data.append('upload_errors', errors);
            if (originalRequest.data.has('file_path[]')) originalRequest.data.delete('file_path[]');
            $_a.send(originalRequest,10);
        }
    }
    
    function init(fileLst){
        queue = fileLst;
        
        self.fileCount = queue.length;
        self.fileSended = 0;
        
        queue.forEach( (file) => {
            self.all.total += file.size;
        });
        
        if (CONSTANTS.left <= self.all.total) {
            UI_Class.MessagePopup(CONSTANTS.texts.too_heavy_files.replace(['$1','$2'],[self.all.total,CONSTANTS.left]));
            return false;
        }
        
        processQueue();
    }
    init(fileLst);
};
/*jshint esversion: 6 */
//-------------------------------------------------------------
// all manipulation around ONE dom element
var DOM_Class = function(){};
DOM_Class.prototype.constructor = DOM_Class;
//~ class DOM_Class{
    //~ constructor() {
        
    //~ }
//~ }

DOM_Class.debug = false;
DOM_Class.elementsPool = {};
DOM_Class.focusedElement = null;
DOM_Class.dom_parser = new DOMParser();

DOM_Class._currentGlobalCursor = '';

DOM_Class.RELATIVE = 'relative';
DOM_Class.ABSOLUTE = 'absolute';

// write html code inside a div and make sure scripts are executed
DOM_Class.WriteHtml = function(domTarget , htmlData, append=false, before=false){

    let target = DOM_Class.GetDomElement(domTarget);

    if(target){
        if (append){
            target.innerHTML += htmlData;
        } else if (before){
            target.innerHTML = htmlData + target.innerHTML;
        } else {
            target.innerHTML = htmlData;
        }
        

        // when append, detect script that was present before and trig them again
        let scripts = target.querySelectorAll("script");
        for(let i=0; i < scripts.length; i++){

            DOM_Class.AddScriptTag(scripts[i] , i);

        }

    }else{
        console.warn('Cannot find dom target ',domTarget);
    }
};

DOM_Class.AddScriptTag = function(scriptTag , delay){
    if(scriptTag.hasAttribute('defer')){
        if(!delay) {
            delay = 1;
        }
        setTimeout(function(){ DOM_Class.InsertScriptTag(scriptTag); } , 50 + delay);
    }else{
        DOM_Class.InsertScriptTag(scriptTag);
    }
};

DOM_Class.InsertScriptTag = function(scriptTag){

    if(scriptTag.hasAttribute('src')){
        let src = scriptTag.getAttribute('src');
        setTimeout(function(){ scriptTag.remove(); } , 100);

        return DOM_Class.LoadScript(src);

    }else{
        // console.log(scriptTag, scriptTag.innerHTML);
        if(!scriptTag.evaldone){
            eval(scriptTag.innerHTML || scriptTag.text);
            scriptTag.evaldone = true;

            DOM_Class.RemoveElement(scriptTag);
        }
    }

    return true;
};

DOM_Class.reload_page = function(url){

    if(GENERICS_Class.IsEmpty(url) && GENERICS_Class.IsString(this.url)) url = this.url;

    if(GENERICS_Class.IsString(url)){
        if(url === CONSTANTS.reload_noparams){
            document.location = document.location.origin + document.location.pathname;
        }else{
            document.location = url;
        }
    }else{
        document.location.reload();
    }
};

DOM_Class.MoveToHeader = function(id){

    let obj = document.getElementById(id);

    if(obj){
        let type = obj.tagName.toLowerCase();
        let attr_name = '';
        let ref_val = '';

        switch(type){
            case 'script':
                attr_name = 'src';
            break;

            case 'link':
                attr_name = 'href';
            break;

            default:
                console.warn('!!!');
                return false;
        }

        ref_val = obj.getAttribute(attr_name);

        let elements = document.head.getElementsByTagName(type);

        for(let i = 0 ; i < elements.length ; i++){
            let s = elements[i];
            if(s.getAttribute(attr_name) == ref_val){
                if(DOM_Class.debug){
                    console.log('script ',url,' already in header');
                }
                obj.remove();
                return false;
            }
        }
        document.head.appendChild(obj);
    }
};

DOM_Class.LoadScript = function(url){
    let scripts = document.head.getElementsByTagName("script");

    for(let i = 0 ; i < scripts.length ; i++){
        let s = scripts[i];
        if(s.getAttribute('src') == url){
            if(DOM_Class.debug){
                console.log('script ',url,' already in header');
            }
            return false;
        }
    }

    let scriptTag = DOM_Class.CreateElement('SCRIPT');
    scriptTag.onload = function(){
        if(DOM_Class.debug){
            console.log(url , 'loaded');
        }
    };
    scriptTag.src = url;
    document.head.appendChild(scriptTag);
    return true;
};

// 'multiple' allow to retrieve all the elements and not just the first one
DOM_Class.StringToDom = function(str, multiple=false, activScript=false){
    let res = DOM_Class.dom_parser.parseFromString(str,'text/html');
    if (activScript) {
        let newDoc = document.createDocumentFragment();
        while(res.body.firstChild){
            newDoc.appendChild(res.body.firstChild);
        }

        let scripts = newDoc.querySelectorAll('script');
        for (let i = 0; i < scripts.length; i++){
            let parent = scripts[i].parentElement || newDoc;
            let newScript = document.createElement('script');
            if (scripts[i].src) {
                newScript.src = scripts[i].src;
            } else {
                newScript.textContent = scripts[i].textContent;
            }
            parent.replaceChild(newScript, scripts[i]);
        }
        res = newDoc;
        if (!multiple) return res.firstChild;
        else return res.childNodes;
    } else {
        if (!multiple) return res.firstChild.lastChild.firstChild;
        else return res.firstChild.lastChild.childNodes;
    }
};

DOM_Class.HideElement = function(element){
    if(!element._hidden){
        if(element.style.display != 'none'){
            element._originalVisibility = element.style.display;
        }else{
            element._originalVisibility = '';
        }

    }

    element.style.display = 'none';
    element._hidden = true;
};

DOM_Class.ShowElement = function(element , forceVisibilityValue){

    if(element._hidden){
        if(forceVisibilityValue){
            element.style.display = forceVisibilityValue;
        }else{
            element.style.display = element._originalVisibility;
        }

    }else{
        //Get the value of style attribute
        var originalStyle = element.getAttribute('style') || '';

        //var regex = new RegExp(/(width:|height:).+?(;[\s]?|$)/g);
        var regex = new RegExp(/(display:).+?(;[\s]?|$)/g);

        //Replace matches with null
        var modStyle = originalStyle.replace(regex, '');

        element.setAttribute('style', modStyle);

    }
    element._hidden = false;

};

DOM_Class.IsSameElement = function(a,b){

    //~ if(a && b && a._classID === b._classID){
        //~ return true;
    //~ }

    return Object.is(a,b);
};

DOM_Class.FindChildByClassName = function(parentElement,className){

    for(let i = 0; i < parentElement.childNodes.length; i++) {
        let child = parentElement.childNodes[i];
        if(child.classList.contains(className)){
            return child;
        }
    }

    return null;
};

DOM_Class.FindAllChildrenByClassName = function(parentElement,className){
    let result = [];
    for(let i = 0; i < parentElement.childNodes.length; i++) {
        let child = parentElement.childNodes[i];
        if(child.classList && child.classList.contains(className)){
            result.push(child);
        }
    }

    return result;
};

DOM_Class.FindChildIndex = function(parentElement,childElement){
    let result = [];
    for(let i = 0; i < parentElement.childNodes.length; i++) {
        if(parentElement.childNodes[i] === childElement) return i;
    }

    return -1;
};

DOM_Class.GetDomElement = function(domIdOrObject){
    if(GENERICS_Class.IsObject(domIdOrObject)){
        if(GENERICS_Class.IsDomObject(domIdOrObject)){
            return domIdOrObject;
        }else if(GENERICS_Class.IsDomObject(domIdOrObject.domElement)){
            return domIdOrObject.domElement;
        }else{
            return null;
        }

    }else if(GENERICS_Class.IsString(domIdOrObject)){
        if(!domIdOrObject){
            return null;
        }
        return document.getElementById(domIdOrObject);
    }

    return null;
};

DOM_Class.GetDomElementByName = function(domNameOrObject){
    if(GENERICS_Class.IsObject(domNameOrObject)){
        return domNameOrObject;
    }else if(GENERICS_Class.IsString(domNameOrObject)){
        if(!domNameOrObject){
            return null;
        }
        return document.getElementByName(domNameOrObject);
    }

    return null;
};

DOM_Class.GetDomElementIndex = function(node) {
    let index = 0;
    while ( (node = node.previousElementSibling) ) {
        index++;
    }
    return index;
};

DOM_Class.CreateElement = function(tagName,params,content,parent){

    var element;
    params = params || {};
    tagName = tagName.toUpperCase();

    var svg_element = tagName.indexOf('SVG_')===0;

    if(!DOM_Class.elementsPool[tagName]){
        DOM_Class.elementsPool[tagName] = [];
    }
    let xmlns = 'http:/'+'/www.w3.org/2000/svg';
    if(DOM_Class.elementsPool[tagName].length){
        element = DOM_Class.elementsPool[tagName].pop();

    }else if(tagName == 'SVG'){

        element = document.createElementNS(xmlns, 'svg');
        element.setAttribute('xmlns', xmlns);
        element.setAttribute('version', '1.2');

    }else if(svg_element){
        tagName = tagName.substring(4,tagName.length).toLowerCase();

        element = document.createElementNS(xmlns, tagName);

    }else{
        element = document.createElement(tagName);
    }

    var attr_list = element.attributes;
    for(let attr in attr_list){
        if(attr!='xmlns' && attr!='version'){
            element.removeAttribute(attr);
        }
    }

    if(svg_element){
        for(let attr in params){
            element.setAttributeNS(null,attr,params[attr]);
        }

    }else{
        for(let attr in params){
            if (tagName == 'SVG') {
                element.setAttribute(attr,params[attr]);
            } else if(element[attr] !== undefined){
                element[attr] = params[attr];
            }else{
                element.setAttribute(attr,params[attr]);
            }
        }
    }

    element._customClasses = {};
    element._eventListeners = [];

    if(content){
        if(GENERICS_Class.IsDomObject(content)){
            element.appendChild(content);
        }else if (GENERICS_Class.IsString(content)){
            element.innerHTML = content;
        } else {
            element.append(content);
        }
    }

    if(GENERICS_Class.IsDomObject(parent)){
        parent.appendChild(element);
    }

    return element;
};

// add content to a dom element
// it can be an other dom element, a string or an array of those elements
// or an object/class who got an attribute domElement that point to a dom element
DOM_Class.AppendContent = function(domElement , content){

    if(GENERICS_Class.IsDomObject(content)){
        domElement.appendChild(content);

    }else if( GENERICS_Class.IsFilledArray(content) ){
        for(let i in content){
            DOM_Class.AppendContent(domElement , content[i]);
        }

    }else if(GENERICS_Class.IsFilledObject(content)){
        for(let i in content){
            if(content[i].domElement){
                DOM_Class.AppendContent(domElement , content[i].domElement);
            }
        }
    }else{
        DOM_Class.WriteHtml(domElement,content,true);
        //~ domElement.innerHTML += content;
    }

};

DOM_Class.RemoveElement = function(element){
    if(!DOM_Class.elementsPool[element.tagname]){
        DOM_Class.elementsPool[element.tagname] = [];
    }

    // reset all CSS properties
    element.className = '';

    let s = element.style;
    for (let prop in s ) {
        s[prop] = '';
    }

    let cc = element._customClasses;
    for (let prop in cc ) {
        delete(cc[prop]);
    }

    // remove all events
    EVENTS_Class.RemoveAllEvents(element);

    // put in pool list
    DOM_Class.elementsPool[element.tagname].push(element);

    // recursive cleaning
    let ttt = 0;
    if (element.childNodes){
        while(element.childNodes.length > 0 && ttt < 1000){
            DOM_Class.RemoveElement(element.childNodes[0]);
            ttt++;
        }
        if(ttt >=1000){
            debugger;
        }
    }

    element.innerHTML = '';

    // remove from DOM
    if(element.parentNode){
        element.parentNode.removeChild(element);
    }
};

// link a class instance to a dom element
// to eventually redirect all mouse events to that class
DOM_Class.AddClassObject = function(element, type, object){
    if(!element._customClasses){
        element._customClasses = {};
    }
    element._customClasses[type] = object;
};

DOM_Class.GetClassObject = function(element, type){
    if(!element._customClasses){
        element._customClasses = {};
    }

    if(!type){
        let keys = Object.keys(element._customClasses);
        let list = [];
        if(keys.length > 0){
            for(let k in keys){
                list.push(element._customClasses[keys[k]]);
            }
        }
        return list;
    }
    return element._customClasses[type];
};

DOM_Class.CloneDomElement = function(domElement , recursive){

    let newElement = domElement.cloneNode();

    if(recursive){
        for(let i = 0 ; i < domElement.childNodes.length ; i++){
            let child = DOM_Class.CloneDomElement(domElement.childNodes[i] , recursive);
            newElement.appendChild(child);
        }
    }

    if(GENERICS_Class.IsFilledArray(domElement._eventListeners)){
        let lst = domElement._eventListeners;

        if(!GENERICS_Class.IsArray(newElement._eventListeners)){
            newElement._eventListeners = [];
        }

        for(let i = 0 ; i < lst.length ; i++){
            EVENTS_Class.AddEvent(newElement , lst[i].event , lst[i].callback);
        }
    }

    if(GENERICS_Class.IsFilledArray(domElement._customClasses)){
        // TODO
        // add a Clong() function in classes

        let lst = domElement._customClasses;

        if(!GENERICS_Class.IsArray(newElement._customClasses)){
            newElement._customClasses = [];
        }

        for(let i = 0 ; i < lst.length ; i++){
            if(GENERICS_Class.IsFunction(lst[i].clone)){
                lst[i].Clone(newElement); // specify the new dom element to the Clone function
            }else{
                console.log('no clone method found on ',lst[i]);
                debugger;
            }
        }
    }
    
    if (domElement._validator) newElement._validator = domElement._validator;

    return newElement;
};

//---------------------------------------------------------------------

DOM_Class.CanHaveCSS = function(domElement){
    if(GENERICS_Class.IsDomObject(domElement)){
        return domElement.classList != undefined;
    }
    return false;
};

DOM_Class.HasClass = function (domElement , className){
    if(DOM_Class.CanHaveCSS(domElement)){
        return domElement.classList.contains(className);
    }
    return false;
};

DOM_Class.AddClass = function (domElement , className){
    if(DOM_Class.CanHaveCSS(domElement)){
        domElement.classList.add(className);
    }
};

DOM_Class.RemoveClass = function (domElement , className){
    if(DOM_Class.CanHaveCSS(domElement)){
        domElement.classList.remove(className);
    }
};

DOM_Class.ReplaceClass = function (domElement , classNameToReplace, NewClassName){
    if(DOM_Class.CanHaveCSS(domElement)){
        domElement.classList.replace(classNameToReplace,NewClassName);
    }
};

DOM_Class.ToggleClass = function (domElement , className , forceState){
    if(DOM_Class.CanHaveCSS(domElement)){
        domElement.classList.toggle(className , forceState);
    }
};

DOM_Class.ReplaceElement = function(originalElement , newElement){
    // Be careful, do not recreate the old events!
    if(GENERICS_Class.IsString(newElement)){
        originalElement.outerHTML = newElement;
        
    }else if(GENERICS_Class.IsDomObject(newElement)){
        DOM_Class.InsertAfter( newElement , originalElement);
        DOM_Class.RemoveElement(originalElement);
    }

};

DOM_Class.InsertBefore = function(domElement , berforeMe){
    berforeMe.insertAdjacentElement('beforebegin',domElement);
    DOM_Class._SetRectDirty(domElement);
    DOM_Class._SetRectDirty(berforeMe);
};

DOM_Class.InsertAfter = function(domElement , afterMe){
    afterMe.insertAdjacentElement('afterend',domElement);
    DOM_Class._SetRectDirty(domElement);
    DOM_Class._SetRectDirty(afterMe);
};

// give the absolute rect of the element, in page coordinates
DOM_Class.GetGlobalRect = function(domElement , forceRefresh){
    if(!domElement){
        return null;
    }

    if(domElement._RectReady && !forceRefresh){
        return domElement._ComputedStyle.rect;
    }

    if(domElement === document){
        domElement = document.body;
    }


    if(!domElement.getBoundingClientRect){
        debugger;
    }

    let rect = domElement.getBoundingClientRect();

    if(domElement == document.body){
        rect = {left:rect.left , top:rect.top , right:rect.right , bottom:rect.bottom , width:rect.width , height:rect.height};
        if(rect.height === 0){
            rect.bottom = window.innerHeight;
            rect.height = window.innerHeight;
        }

        if(rect.width === 0){
            rect.right = window.innerWidth;
            rect.width = window.innerWidth;
        }
    }
    
    let t = '';
    let sx = window.scrollX || (((t = document.documentElement) || (t = document.body.parentNode)) && typeof t.ScrollLeft == 'number' ? t : document.body).ScrollLeft || 0;
    let sy = window.scrollY || (((t = document.documentElement) || (t = document.body.parentNode)) && typeof t.ScrollTop == 'number' ? t : document.body).ScrollTop || 0;
    if(!domElement._ComputedStyle){
        domElement._ComputedStyle = {};
    }
    if(!domElement._ComputedStyle.rect){
        domElement._ComputedStyle.rect = {};
    }

    domElement._ComputedStyle.rect.left     = rect.left + sx;
    domElement._ComputedStyle.rect.top      = rect.top + sy;
    domElement._ComputedStyle.rect.right    = rect.right + sx;
    domElement._ComputedStyle.rect.bottom   = rect.bottom + sy;
    domElement._ComputedStyle.rect.width    = rect.right - rect.left;
    domElement._ComputedStyle.rect.height   = rect.bottom - rect.top;
    domElement._ComputedStyle.rect.x        = domElement._ComputedStyle.rect.left;
    domElement._ComputedStyle.rect.y        = domElement._ComputedStyle.rect.top;

    domElement._RectReady = true;

    return domElement._ComputedStyle.rect;
};

// convert page coordinates to the element inside local coordinates
DOM_Class.GetGlobalToLocal = function(domElement , x , y , advanced){
    let style = DOM_Class.GetStyle(domElement);

    x = x - style.rect.left - style.BL;
    y = y - style.rect.top - style.BT;

    if(advanced){
        return {'x':x , 'y':y, 'ratiox':x/style.rect.width , 'ratioy':y/style.rect.height};
    }else{
        return {'x':x , 'y':y};
    }
};

DOM_Class.GetPosition = function(domElement){
    return {'x':domElement.offsetLeft , 'y':domElement.offsetTop};
};

DOM_Class.GetRelativePosition = function(domElement){
    return {'x':domElement.left , 'y':domElement.top};
};


DOM_Class.GetGlobalPosition = function(domElement){
    let rect = DOM_Class.GetGlobalRect(domElement);
    return {'x' : rect.x , 'y' : rect.y};
};


// test if the givent global x,y coordinates are inside the element global rect
DOM_Class.PointInsideElement = function( x , y , domElement){
    let rect = DOM_Class.GetGlobalRect(domElement,true);
    return (x >= rect.left && x <= rect.right && y >= rect.top && y <= rect.bottom);
};

// return data about the given point an the specified dom element
DOM_Class.PointInsideElementData = function( x , y , domElement){
    let rect = DOM_Class.GetGlobalRect(domElement);
    let inside = (x >= rect.left && x <= rect.right && y >= rect.top && y <= rect.bottom);
    let localX = x - rect.left;
    let localY = y - rect.top;

    return {'inside':inside , 'rect':rect , 'localX':localX , 'localY':localY};
};

// set the position of the element in page coordinates
DOM_Class.SetGlobalPosition = function(domElement , x , y){
    let parentElement = domElement.parentNode;

    let parentStyle = DOM_Class.GetStyle(parentElement);
    let style = DOM_Class.GetStyle(domElement);
    
    if(style.POS != 'fixed'){
        if (parentStyle.POS == 'relative'){
            x -= parentStyle.rect.left + parentStyle.BL + style.ML;
            y -= parentStyle.rect.top + parentStyle.BT + style.MT;
        }else{
            let t = '';
            let sx = window.scrollX || (((t = document.documentElement) || (t = document.body.parentNode)) && typeof t.ScrollLeft == 'number' ? t : document.body).ScrollLeft || 0;
            let sy = window.scrollY || (((t = document.documentElement) || (t = document.body.parentNode)) && typeof t.ScrollTop == 'number' ? t : document.body).ScrollTop || 0;
            x -= sx;
            y -= sy;
        }
    }

    if(style.POS == 'relative'){

        DOM_Class.SetPosition(domElement ,0 , 0);
        let newStyle = DOM_Class.GetStyle(domElement);

        x -= newStyle.rect.x - (parentStyle.rect.left + parentStyle.BL);
        y -= newStyle.rect.y - (parentStyle.rect.top + parentStyle.BT);
    }
    
    while(parentElement.tagName != 'BODY'){
        if (parentElement.scrollTop > 0){
            y += parentElement.scrollTop;
        }
        if (parentElement.scrollLeft > 0){
            x += parentElement.scrollLeft;
        }
        parentElement = parentElement.parentElement;
    }
    //for page.js
    let snapLeft = style._snapEdge.left;
    let snapTop = style._snapEdge.top;
    let snapRight = style._snapEdge.right;
    let snapBottom = style._snapEdge.bottom;

    if(snapLeft){
        DOM_Class.UnsnapAbsoluteLeft(domElement);
    }
    if(snapTop){
        DOM_Class.UnsnapAbsoluteTop(domElement);
    }
    if(snapRight){
        DOM_Class.UnsnapAbsoluteRight(domElement);
    }
    if(snapBottom){
        DOM_Class.UnsnapAbsoluteBottom(domElement);
    }

    DOM_Class.SetPosition(domElement ,x , y);

    if(snapLeft){
        DOM_Class.SnapAbsoluteLeft(domElement , snapLeft);
    }
    if(snapTop){
        DOM_Class.SnapAbsoluteTop(domElement , snapTop);
    }

    if(snapRight){
        DOM_Class.SnapAbsoluteRight(domElement , snapRight);
    }
    if(snapBottom){
        DOM_Class.SnapAbsoluteBottom(domElement , snapBottom);
    }
    //...
};

// set the rect left position, in page coordinates
DOM_Class.SetGlobalLeft = function(domElement , newLeft){
    let style = DOM_Class.GetStyle(domElement);
    let offset = newLeft - style.rect.left;

    let parentElement = domElement.parentNode;
    
    parentElement._RectReady = false;
    let parentStyle = DOM_Class.GetStyle(parentElement);

    if(style.POS != 'fixed'){
        newLeft -= parentStyle.rect.left + parentStyle.BL + style.ML;
    }else{
        let t = '';
        let sx = window.scrollX || (((t = document.documentElement) || (t = document.body.parentNode)) && typeof t.ScrollLeft == 'number' ? t : document.body).ScrollLeft || 0;
        newLeft -= sx;
        console.log(newLeft);
    }

    if(style.POS == 'relative'){

        DOM_Class.SetPosition(domElement ,0 , parseInt(domElement.style.top));
        let newStyle = DOM_Class.GetStyle(domElement);

        newLeft -= newStyle.rect.x - (parentStyle.rect.left + parentStyle.BL) - style.ML;
        console.log(newLeft);

    }

    switch(style._snapEdge.left){
        case 'rem':
            domElement.style.left = DOM_Class.PxToEm(newLeft , domElement.parentNode , true);
        break;

        case 'em':
            domElement.style.left = DOM_Class.PxToEm(newLeft , domElement.parentNode , true);
        break;

        case '%':
            if(newLeft < 0){
                // overstep the border
                DOM_Class.SetLeft(domElement , newLeft);
            }else{
                let parent_innerwidth = parentStyle.rect.width - parentStyle.BH;
                let leftPercent = ((newLeft / parent_innerwidth)*100).toFixed(3);
                domElement.style.left = leftPercent+'%';
            }

        break;

        default:
            DOM_Class.SetLeft(domElement , newLeft);

            if(style._snapCenter.horizontal){
                DOM_Class.SetHorizontalPercentagePosition(domElement);
            }
        break;
    }

    let newWidth = style.rect.width - offset;

    if(style._snapEdge.right){

        if(style._snapEdge.left){
            domElement.style.width = 'auto';
        }else{
            DOM_Class.SetGlobalWidth(domElement , newWidth);
            domElement.style.left = 'auto';
        }

    }else if(style.POS != 'fixed'){

        DOM_Class.SetGlobalWidth(domElement , newWidth);
    }

    DOM_Class._SetRectDirty(domElement);
};

// set the rect top position, in page coordinates
DOM_Class.SetGlobalTop = function(domElement , newTop){

    let style = DOM_Class.GetStyle(domElement);
    let offset = newTop - style.rect.top;

    let parentElement = domElement.parentNode;

    let parentStyle = DOM_Class.GetStyle(parentElement);

    if(style.POS != 'fixed'){
        newTop -= parentStyle.rect.top + parentStyle.BT + style.MT;
    }else{
        let t = '';
        let sy = window.scrollY || (((t = document.documentElement) || (t = document.body.parentNode)) && typeof t.ScrollTop == 'number' ? t : document.body).ScrollTop || 0;
        newTop -= sy;
    }

    if(style.POS == 'relative'){
        DOM_Class.SetPosition(domElement , parseInt(domElement.style.left) , 0);
        let newStyle = DOM_Class.GetStyle(domElement);

        newTop -= newStyle.rect.y - (parentStyle.rect.top + parentStyle.BT) - style.MT;
    }

    switch(style._snapEdge.top){
        case 'rem':
            domElement.style.top = DOM_Class.PxToEm(newTop , domElement.parentNode , true);
        break;

        case 'em':
            domElement.style.top = DOM_Class.PxToEm(newTop , domElement.parentNode , true);
        break;

        case '%':
            if(newTop < 0){
                // overstep border
                DOM_Class.SetTop(domElement , newTop);
            }else{
                let parent_innerheight = parentStyle.rect.height - parentStyle.BV;
                let topPercent = ((newTop / parent_innerheight)*100).toFixed(3);
                domElement.style.top = topPercent+'%';
            }

        break;

        default:

            DOM_Class.SetTop(domElement , newTop);

            if(style._snapCenter.vertical){
                DOM_Class.SetVerticalPercentagePosition(domElement);
            }

        break;
    }

    let newHeight = style.rect.height - offset;

    if(style._snapEdge.bottom){

        if(style._snapEdge.top){
            domElement.style.height = 'auto';
        }else{
            DOM_Class.SetGlobalHeight(domElement , newHeight);
            domElement.style.top = 'auto';
        }

    }else if(style.POS != 'fixed'){
        DOM_Class.SetGlobalHeight(domElement , newHeight);
    }


    DOM_Class._SetRectDirty(domElement);
};

// set the rect right position, in page coordinates
DOM_Class.SetGlobalRight = function(domElement , newRight){
    let style = DOM_Class.GetStyle(domElement);
    let offset = newRight - style.rect.right;

    let newWidth = style.rect.width + offset;

    if(style._snapEdge.right && style.POS != 'relative'){
        let parentStyle = DOM_Class.GetStyle(domElement.parentNode);

        let pxValue = (parentStyle.rect.right - (style.rect.left + style.rect.width + offset + parentStyle.BR + style.MR));

        switch(style._snapEdge.right){
            case 'rem':
                domElement.style.right = DOM_Class.PxToEm(pxValue , domElement.parentNode , true);
            break;

            case 'em':
                domElement.style.right = DOM_Class.PxToEm(pxValue , domElement.parentNode , true);
            break;

            case '%':
                if(pxValue < 0){
                    // overstep border
                    domElement.style.right = pxValue+'px';
                }else{
                    let parent_innerwidth = parentStyle.rect.width - parentStyle.BH;
                    let rightPercent = ((1 - (style.rect.right - (parentStyle.rect.left + parentStyle.BL) + offset) / parent_innerwidth)*100).toFixed(3);
                    domElement.style.right = rightPercent+'%';
                }

            break;

            default:
                domElement.style.right = pxValue + 'px';
            break;
        }

        if(style._snapEdge.left){
            domElement.style.width = 'auto';
        }else{
            DOM_Class.SetGlobalWidth(domElement , newWidth);
        }


    }else{

        DOM_Class.SetGlobalWidth(domElement , newWidth);
    }

    DOM_Class._SetRectDirty(domElement);
};

// set the rect bottom position, in page coordinates
DOM_Class.SetGlobalBottom = function(domElement , newBottom){
    let style = DOM_Class.GetStyle(domElement);
    let offset = newBottom - style.rect.bottom;

    let newHeight = style.rect.height + offset;

    if(style._snapEdge.bottom && style.POS != 'relative'){
        let parentStyle = DOM_Class.GetStyle(domElement.parentNode);

        let pxValue = (parentStyle.rect.bottom - (style.rect.top + style.rect.height + offset + parentStyle.BB + style.MB));

        switch(style._snapEdge.bottom){
            case 'rem':
                domElement.style.bottom = DOM_Class.PxToEm(pxValue , domElement.parentNode , true);
            break;

            case 'em':
                domElement.style.bottom = DOM_Class.PxToEm(pxValue , domElement.parentNode , true);
            break;

            case '%':

                if(pxValue < 0){
                    // overstep border
                    domElement.style.bottom = pxValue+'px';
                }else{
                    let parent_innerheight = parentStyle.rect.height - parentStyle.BV;
                    let bottomPercent = ((1 - (style.rect.bottom - (parentStyle.rect.top + parentStyle.BT) + offset) / parent_innerheight)*100).toFixed(3);
                    domElement.style.bottom = bottomPercent+'%';
                }
            break;

            default:
                domElement.style.bottom = pxValue + 'px';
            break;
        }


        if(style._snapEdge.top){
            domElement.style.height = 'auto';
        }else{
            DOM_Class.SetGlobalHeight(domElement , newHeight);
        }

    }else{

        DOM_Class.SetGlobalHeight(domElement , newHeight);
    }

    DOM_Class._SetRectDirty(domElement);
};

// set the outside width of the element, taking the border and padding in account
DOM_Class.SetGlobalWidth = function(domElement , newWidth){
    let style = DOM_Class.GetStyle(domElement);

    newWidth -= style.BH + style.PH;

    if(style.POS == 'relative'){
        switch(style._width_unit){
            case 'percent':
                let parentStyle = DOM_Class.GetStyle(domElement.parentNode);
                let percent = (newWidth / parseFloat(parentStyle.all.width)) * 100;
                // correction of rounding errors
                if(percent % 1 < 0.08){
                    percent = Math.round(percent*10)/10;
                }
                    domElement.style.setProperty('width' , Math.min(100,percent) + '%');
            break;

            case 'rem':
                let remWidth = DOM_Class.PxToEm(newWidth);
                domElement.style.setProperty('width' , remWidth + 'rem');
            break;

            case 'em':
                let emWidth = DOM_Class.PxToEm(newWidth);
                domElement.style.setProperty('width' , emWidth + 'em');
            break;

            case '':
            case 'auto':
            case 'max-content':
            case 'min-content':
            case 'fit-content':
            case 'stretch':
            case 'unset':
            case 'inherit':
                domElement.style.setProperty('width' , style._width_unit);
            break;

            case 'px':
                domElement.style.setProperty('width' , newWidth + 'px');
            break;

            default:
                domElement.style.setProperty('width' , newWidth + 'px');
            break;
        }
    }else{
        domElement.style.setProperty('width' ,newWidth + 'px');
    }

    DOM_Class._SetRectDirty(domElement);
};

// set the outside width of the element, taking the border and padding in account
DOM_Class.SetGlobalMinWidth = function(domElement , newWidth){
    let style = DOM_Class.GetStyle(domElement);

    switch(style._minwidth_unit){
        case 'percent':
            let parentStyle = DOM_Class.GetStyle(domElement.parentNode);
            let percent = (newWidth / parseFloat(parentStyle.all.width)) * 100;
            domElement.style.setProperty('min-width' , Math.min(100,percent) + '%');
        break;

        case 'rem':
            let remWidth = DOM_Class.PxToEm(newWidth);
            domElement.style.setProperty('min-width' , remWidth + 'rem');
        break;

        case 'em':
            let emWidth = DOM_Class.PxToEm(newWidth);
            domElement.style.setProperty('min-width' ,emWidth + 'em');
        break;

        case 'auto':
            domElement.style.setProperty('min-width' , 'auto');
        break;

        case 'px':
            domElement.style.setProperty('min-width' , newWidth + 'px');
        break;

        default:
            domElement.style.setProperty('min-width' , newWidth + 'px');
        break;
    }


    DOM_Class._SetRectDirty(domElement);
};


// set the outside height of the element, taking the border and padding in account
DOM_Class.SetGlobalHeight = function(domElement , newHeight){

    let style = DOM_Class.GetStyle(domElement);

    if(newHeight !== undefined && newHeight != ''){
        newHeight -= style.BV + style.PV;
        domElement.style.setProperty('height' , newHeight + 'px');
    }else{
        domElement.style.setProperty('height' , '');
    }

    DOM_Class._SetRectDirty(domElement);
};

// set the outside rect of the element, in page coordinates
DOM_Class.SetGlobalRect = function(domElement , left , top , right , bottom){

    if(GENERICS_Class.IsObject(left)){
        top = left.top;
        right = left.right;
        bottom = left.bottom;
        left = left.left;
    }

    DOM_Class.SetGlobalLeft(domElement , left);
    DOM_Class.SetGlobalTop(domElement , top);

    DOM_Class.SetGlobalRight(domElement , right);
    DOM_Class.SetGlobalBottom(domElement , bottom);

    DOM_Class._SetRectDirty(domElement);
};

// set the width, in local coordinates
DOM_Class.SetWidth = function(domElement , w){
    domElement.style.setProperty('width' , w + 'px');
    DOM_Class._SetRectDirty(domElement);
};

// set the height, in local coordinates
DOM_Class.SetHeight = function(domElement , h){
    domElement.style.setProperty('height' , h + 'px');
    DOM_Class._SetRectDirty(domElement);
};


// set the left/x position, in local coordinates
DOM_Class.SetLeft = function(domElement , x){
    domElement.style.setProperty('left' , x + 'px');
    DOM_Class._SetRectDirty(domElement);
};

// set the top/x position, in local coordinates
DOM_Class.SetTop = function(domElement , y){
    domElement.style.setProperty('top' , y + 'px');
    DOM_Class._SetRectDirty(domElement);
};

// set the width and height, in local coordinates
DOM_Class.SetSize = function(domElement , w , h){
    domElement.style.setProperty('width' , w + 'px');
    domElement.style.setProperty('height' , h + 'px');

    DOM_Class._SetRectDirty(domElement);
};

DOM_Class.GetGlobalWidth = function(domElement){
    if(!domElement._RectReady){
        domElement._ComputedStyle.rect = DOM_Class.GetGlobalRect(domElement);
    }

    return domElement._ComputedStyle.rect.width;
};

DOM_Class.GetGlobalHeight = function(domElement){
    if(!domElement._RectReady){
        domElement._ComputedStyle.rect = DOM_Class.GetGlobalRect(domElement);
    }

    return domElement._ComputedStyle.rect.height;
};

// set the position, in local coordinates
// use DOM_Class.RELATIVE or DOM_Class.ABSOLUTE for specify the cssPosition parameters
DOM_Class.SetPosition = function(domElement , x , y , cssPosition){
    if( cssPosition !== undefined){
        domElement.style.position = cssPosition; // relative or absolute
    }

    if(GENERICS_Class.IsObject(x) && x.x){
        y = x.y;
        x = x.x;
    }

    if(x!==undefined){
        domElement.style.left = Math.round(x)+'px';

        if(domElement._ComputedStyle && domElement._ComputedStyle._snapCenter && domElement._ComputedStyle._snapCenter.horizontal){
            DOM_Class._SetRectDirty(domElement);
            DOM_Class.SetHorizontalPercentagePosition(domElement);
        }
    }
    if(y!==undefined){
        domElement.style.top = Math.round(y)+'px';

        if(domElement._ComputedStyle && domElement._ComputedStyle._snapCenter && domElement._ComputedStyle._snapCenter.vertical){
            DOM_Class._SetRectDirty(domElement);
            DOM_Class.SetVerticalPercentagePosition(domElement);
        }
    }

    DOM_Class._SetRectDirty(domElement);
};

// alignment factor from 0 (left) to 1(right)
DOM_Class.SetAlignment = function(domElement , horizontal , vertical , parentNode , fromWindow = false){
    let parentRect;
    if (fromWindow){
        parentRect = {'left': 0, 'top': 0, 'right': 0, 'bottom': 0, 'width': window.innerWidth, 'height': window.innerHeight};
    } else {
        if(!GENERICS_Class.IsObject(parentNode)) parentNode = domElement.parentNode;
        parentRect = DOM_Class.GetGlobalRect(parentNode, true);
    }
    let rect = DOM_Class.GetGlobalRect(domElement, true);
    let pos = DOM_Class.GetStyleValue(domElement, 'position');
    if (parentNode.tagName == 'BODY' && pos == 'fixed') parentRect = {'left': 0, 'top': 0, 'right': 0, 'bottom': 0, 'width': window.innerWidth, 'height': window.innerHeight};

    let left = parentRect.left + (parentRect.width - rect.width) * horizontal;
    let top = parentRect.top + (parentRect.height - rect.height) * vertical;

    DOM_Class.SetGlobalPosition(domElement, left, top);

    let style = DOM_Class.GetStyle(domElement);

    DOM_Class._SetRectDirty(domElement);

    if(style._snapCenter.horizontal){
        DOM_Class.SetHorizontalPercentagePosition(domElement);
    }

    if(style._snapCenter.vertical){
        DOM_Class.SetVerticalPercentagePosition(domElement);
    }
};

DOM_Class.GetStyleValue = function(domElement , attributeName){
    if(domElement.style[attributeName]){
        return domElement.style[attributeName];
    }
    let style = DOM_Class.GetStyle(domElement);
    let value = style.all.getPropertyValue(attributeName) || undefined;
    return value;
};

// returns the precomputed styles for this element
DOM_Class.GetStyle = function(domElement){

    if(!domElement){
        debugger;
    }

    if(domElement === document){
        domElement = domElement.body;
    }

    if(!domElement._ComputedStyleReady){
        if(DOM_Class.debug){
            console.log('recompute style for ',domElement);
        }

        if(!domElement._ComputedStyle){
            domElement._ComputedStyle = {};
        }

        if(!domElement._RectReady){
            domElement._ComputedStyle.rect = DOM_Class.GetGlobalRect(domElement,true);
        }

        let style = window.getComputedStyle(domElement, '');

        domElement._ComputedStyle.all = style;

        domElement._ComputedStyle.BL = parseInt(style.getPropertyValue('border-left-width')) || 0;
        domElement._ComputedStyle.BT = parseInt(style.getPropertyValue('border-top-width')) || 0;
        domElement._ComputedStyle.BR = parseInt(style.getPropertyValue('border-right-width')) || 0;
        domElement._ComputedStyle.BB = parseInt(style.getPropertyValue('border-bottom-width')) || 0;

        domElement._ComputedStyle.BH = domElement._ComputedStyle.BL + domElement._ComputedStyle.BR;
        domElement._ComputedStyle.BV = domElement._ComputedStyle.BB + domElement._ComputedStyle.BT;

        domElement._ComputedStyle.PL = parseInt(style.getPropertyValue('padding-left')) || 0;
        domElement._ComputedStyle.PT = parseInt(style.getPropertyValue('padding-top')) || 0;
        domElement._ComputedStyle.PR = parseInt(style.getPropertyValue('padding-right')) || 0;
        domElement._ComputedStyle.PB = parseInt(style.getPropertyValue('padding-bottom')) || 0;

        domElement._ComputedStyle.PH = domElement._ComputedStyle.PL + domElement._ComputedStyle.PR;
        domElement._ComputedStyle.PV = domElement._ComputedStyle.PB + domElement._ComputedStyle.PT;

        domElement._ComputedStyle.ML = parseInt(style.getPropertyValue('margin-left')) || 0;
        domElement._ComputedStyle.MT = parseInt(style.getPropertyValue('margin-top')) || 0;
        domElement._ComputedStyle.MR = parseInt(style.getPropertyValue('margin-right')) || 0;
        domElement._ComputedStyle.MB = parseInt(style.getPropertyValue('margin-bottom')) || 0;

        domElement._ComputedStyle.MH = domElement._ComputedStyle.ML + domElement._ComputedStyle.MR;
        domElement._ComputedStyle.MV = domElement._ComputedStyle.MB + domElement._ComputedStyle.MT;

        domElement._ComputedStyle.POS = style.getPropertyValue('position') || 'relative';

        domElement._ComputedStyleReady = true;
        domElement._RectReady = true;
    }

    if(!domElement._RectReady){
        domElement._ComputedStyle.rect = DOM_Class.GetGlobalRect(domElement);
    }
    //page.js 
    if(!domElement._ComputedStyle._snapEdge){
        domElement._ComputedStyle._snapEdge = {};
        domElement._ComputedStyle._snapEdge.top = false;
        domElement._ComputedStyle._snapEdge.left = false;
        domElement._ComputedStyle._snapEdge.right = false;
        domElement._ComputedStyle._snapEdge.bottom = false;
    }

    if(!domElement._ComputedStyle._snapCenter){
        domElement._ComputedStyle._snapCenter = {};
        domElement._ComputedStyle._snapCenter.horizontal = false;
        domElement._ComputedStyle._snapCenter.vertical = false;
    }
    //....

    if(!domElement._ComputedStyle._width_unit){
        let ww = domElement.style.width;
        if(ww.indexOf('px') > 0){
            domElement._ComputedStyle._width_unit = 'px';
        }else if(ww.indexOf('%') > 0){
            domElement._ComputedStyle._width_unit = 'percent';

        }else if(ww.indexOf('rem') > 0){
            domElement._ComputedStyle._width_unit = 'rem';

        }else if(ww.indexOf('em') > 0){
            domElement._ComputedStyle._width_unit = 'em';

        }else{
            domElement._ComputedStyle._width_unit = 'auto';
        }
    }

    if(!domElement._ComputedStyle._minwidth_unit){

        let ww = domElement.style.minWidth;

        if(ww.indexOf('px') > 0){
            domElement._ComputedStyle._minwidth_unit = 'px';
        }else if(ww.indexOf('%') > 0){
            domElement._ComputedStyle._minwidth_unit = 'percent';

        }else if(ww.indexOf('rem') > 0){
            domElement._ComputedStyle._minwidth_unit = 'rem';

        }else if(ww.indexOf('em') > 0){
            domElement._ComputedStyle._minwidth_unit = 'em';

        }else{
            domElement._ComputedStyle._minwidth_unit = 'rem';
        }
    }


    if(!domElement._ComputedStyle._align){
        domElement._ComputedStyle._align = '';
    }

    return domElement._ComputedStyle;
};

// indicates that the styles of the element must be recomputed the next time they are accessed
DOM_Class._SetStyleDirty = function(domElement){
    domElement._ComputedStyleReady = false;
};

// indicates that the rect of the element has to be recomputed
DOM_Class._SetRectDirty = function(domElement){
    domElement._RectReady = false;
    for(let i = 0 ; i < domElement.children.length ; i++){
        DOM_Class._SetRectDirty(domElement.children[i]);
    }
};

DOM_Class.StoreCssRect = function(domElement){

    let style = DOM_Class.GetStyle(domElement);

    if(!style._storedRect) style._storedRect = {};

    if(!style._storedRect[style.POS]){
        if(style.POS == 'relative'){
            style._storedRect[style.POS] = {'left':'' , 'top':'' , 'right':'','bottom':'','width':domElement.style.width , 'height':domElement.style.height};
            return;
        }else{
            style._storedRect[style.POS] = {};
        }
    }

    style._storedRect[style.POS].left  = domElement.style.left;
    style._storedRect[style.POS].top  = domElement.style.top;
    style._storedRect[style.POS].right  = domElement.style.right;
    style._storedRect[style.POS].bottom  = domElement.style.bottom;
    style._storedRect[style.POS].width  = domElement.style.width;
    style._storedRect[style.POS].height  = domElement.style.height;

};

DOM_Class.RestoreCssRect = function(domElement){

    let style = DOM_Class.GetStyle(domElement);

    if(!style._storedRect) style._absRect = {};

    if(style._storedRect[style.POS]){
        domElement.style.left  = style._storedRect[style.POS].left;
        domElement.style.top  = style._storedRect[style.POS].top;
        domElement.style.right  = style._storedRect[style.POS].right;
        domElement.style.bottom  = style._storedRect[style.POS].bottom;
        domElement.style.width  = style._storedRect[style.POS].width;
        domElement.style.height  = style._storedRect[style.POS].height;

    }else if(style.POS == 'relative'){
        domElement.style.left  = '';
        domElement.style.top  = '';
        domElement.style.right  = '';
        domElement.style.bottom  = '';
        domElement.style.width  = domElement.style.width;
        domElement.style.height  = domElement.style.height;
    }
};

DOM_Class.SetStyleValue = function(domElement , attributeName , value){

    let style = DOM_Class.GetStyle(domElement);

    let originalValue = style.all.getPropertyValue(attributeName);

    if(originalValue != value || domElement.style[attributeName] != value){

        domElement.style.setProperty(attributeName , value);
        DOM_Class._SetStyleDirty(domElement);

        if(attributeName == 'display'){
            DOM_Class._SetRectDirty(domElement);
        }
        return true;
    }
    return false;
};

//---------------------------------------------------------------------------------------------------

DOM_Class.LoadCss = function(url){
    let styles = document.head.getElementsByTagName("link");

    for(let i = 0 ; i < styles.length ; i++){
        let s = styles[i];
        if(s.getAttribute('href') == url){
            if(DOM_Class.debug){
                console.log('style ',url,' already in header');
            }
            return false;
        }
    }

    let styleSheetElement = DOM_Class.CreateElement('LINK');

    styleSheetElement.onload = function(){
        if(DOM_Class.debug){
            console.log(url , 'loaded');
        }
    };

    styleSheetElement.setAttribute('type','text/css');
    styleSheetElement.setAttribute('rel','stylesheet');
    styleSheetElement.setAttribute('href',url);

    document.head.appendChild(styleSheetElement);

    return true;
};

DOM_Class.GetStylesheet = function(sheetTitle , sheetMedia, create){
    if(!document.styleSheets) {
        return;
    }

    if(document.getElementsByTagName("head").length === 0) {
        return;
    }

    let styleSheet;
    let mediaType;

    if(document.styleSheets.length > 0) {
        for( let i = 0; i < document.styleSheets.length; i++) {

            if(sheetTitle && document.styleSheets[i].title != sheetTitle) {
                continue;
            }

            let media = document.styleSheets[i].media;
            mediaType = typeof media;

            if(mediaType === "string") {
                if(media === sheetMedia){
                    styleSheet = document.styleSheets[i];
                    break;

                }else if(media === "" || (media.indexOf("screen") != -1)) {
                    styleSheet = document.styleSheets[i];
                }
            } else if(mediaType == "object") {
                if(media === sheetMedia){
                    styleSheet = document.styleSheets[i];
                    break;
                }else if(media.mediaText === "" || (media.mediaText.indexOf("screen") != -1)) {
                    styleSheet = document.styleSheets[i];
                }
            }
        }
    }

    if( styleSheet === undefined && create) {
        // create styleSheet
        let styleSheetElement = DOM_Class.CreateElement('STYLE');
        styleSheetElement.setAttribute('type','text/css');
        styleSheetElement.setAttribute('rel','stylesheet');

        if(sheetMedia){
            styleSheetElement.setAttribute('media',sheetMedia);
        }

        if(sheetTitle){
            styleSheetElement.setAttribute('title',sheetTitle);
        }

        document.head.appendChild(styleSheetElement);

        styleSheet = styleSheetElement.sheet;
    }


    return styleSheet;
};

//create a new css class
DOM_Class.AddCssRule = function(sheetTitle , selector, style, sheetMedia) {
    if(!document.styleSheets) {
        return;
    }

    if(document.getElementsByTagName("head").length === 0) {
        return;
    }

    let styleSheet = null;

    if(GENERICS_Class.IsObject(sheetTitle)){
        styleSheet = sheetTitle;
    }else{
        styleSheet = DOM_Class.GetStylesheet(sheetTitle , sheetMedia);
    }
    

    if( styleSheet === undefined) {

        // create styleSheet
        let styleSheetElement = DOM_Class.CreateElement('STYLE');
        styleSheetElement.setAttribute('type','text/css');
        styleSheetElement.setAttribute('rel','stylesheet');

        if(sheetMedia){
            styleSheetElement.setAttribute('media',sheetMedia);
        }

        if(sheetTitle){
            styleSheetElement.setAttribute('title',sheetTitle);
        }

        document.head.appendChild(styleSheetElement);

        styleSheet = styleSheetElement.sheet;
    }

    let mediaType = typeof styleSheet.media;

    if(mediaType == "string") {
        for( let i = 0; i < styleSheet.rules.length; i++) {
            if(styleSheet.rules[i].selectorText && styleSheet.rules[i].selectorText.toLowerCase() == selector.toLowerCase()) {
                styleSheet.rules[i].style.cssText = style;
                return;
            }
        }

        styleSheet.addRule(selector, style);

    } else if(mediaType == "object") {

        var styleSheetLength = (styleSheet.cssRules) ? styleSheet.cssRules.length : 0;
        for( let i = 0; i < styleSheetLength; i++) {
            if(styleSheet.cssRules[i].selectorText && styleSheet.cssRules[i].selectorText.toLowerCase() == selector.toLowerCase()) {
                styleSheet.cssRules[i].style.cssText = style;
                return;
            }
        }

        styleSheet.insertRule(selector + "{" + style + "}", styleSheetLength);
    }
};

//get a css class for modification
DOM_Class.GetCssRule = function(sheetTitle , ruleName) {
    ruleName = ruleName.toLowerCase();

    if (document.styleSheets) {
        for (let i = 0 ; i < document.styleSheets.length ; i++) {
            let styleSheet = document.styleSheets[i];

            if(sheetTitle && styleSheet.title != sheetTitle){
                continue;
            }

            let j = 0;
            let cssRule = false;
            do {
                if (styleSheet.cssRules) {
                    cssRule = styleSheet.cssRules[j];
                } else {
                    cssRule = styleSheet.rules[j];
                }
                if (cssRule)  {
                    if (cssRule.selectorText.toLowerCase() == ruleName) {
                        return cssRule;
                    }
                }
                j++;
            } while (cssRule);
        }
    }
   return false;
};

DOM_Class.RemoveCssRule = function(sheetTitle , ruleName) {
    ruleName = ruleName.toLowerCase();

    if (document.styleSheets) {
        for (let i = 0 ; i < document.styleSheets.length ; i++) {
            let styleSheet = document.styleSheets[i];

            if(sheetTitle && styleSheet.title != sheetTitle){
                continue;
            }

            let j = 0;
            let cssRule = false;
            do {
                if (styleSheet.cssRules) {
                    cssRule = styleSheet.cssRules[j];
                } else {
                    cssRule = styleSheet.rules[j];
                }
                if (cssRule)  {
                    if (cssRule.selectorText.toLowerCase() == ruleName) {
                        if (styleSheet.cssRules) {
                            styleSheet.deleteRule(j);
                        } else {
                            styleSheet.removeRule(j);
                        }
                        return true;
                    }
                }
                j++;
            } while (cssRule);
        }
    }
   return false;
};


DOM_Class.DisableCssSheet = function(sheetTitle) {
    if(!sheetTitle){
        return false;
    }

    if (document.styleSheets) {
        for (let i = 0 ; i < document.styleSheets.length ; i++) {
            let styleSheet = document.styleSheets[i];

            if(styleSheet.title == sheetTitle){
                styleSheet.disabled = true;
                styleSheet.ownerNode.setAttribute('disabled','disabled');
                return true;
            }
        }
    }
   return false;
};


//activate a css class for modification or delete it
DOM_Class.EnableCssSheet = function(sheetTitle) {

    if(!sheetTitle){
        return false;
    }

    if (document.styleSheets) {
        for (let i = 0 ; i < document.styleSheets.length ; i++) {
            let styleSheet = document.styleSheets[i];

            if(styleSheet.title == sheetTitle){
                styleSheet.disabled = false;
                styleSheet.ownerNode.removeAttribute('disabled');
                return true;
            }
        }
    }
   return false;
};

DOM_Class.SetGlobalCursor = function(cursorValue){
    if(DOM_Class._currentGlobalCursor == cursorValue){
        return false;
    }
    DOM_Class._currentGlobalCursor = cursorValue;
    DOM_Class.AddCssRule('temp_cursor' , '*' , 'cursor:'+cursorValue+' !important;');
    DOM_Class.EnableCssSheet('temp_cursor');
};

DOM_Class.UnsetGlobalCursor = function(){
    DOM_Class._currentGlobalCursor = '';
    DOM_Class.DisableCssSheet('temp_cursor');
};


DOM_Class.DisableMouseEvents = function(domElement){

    //if(!domElement) debugger;

    if(domElement && !domElement._firstPointerEvents){
        domElement._originalPointerEvents = domElement.style.pointerEvents;
        domElement._firstPointerEvents = true;
    }

    domElement.style.pointerEvents = 'none';
};

DOM_Class.EnableMouseEvents = function(domElement){

    //if(!domElement) debugger;

    if(domElement && !domElement._firstPointerEvents){
        domElement._originalPointerEvents = domElement.style.pointerEvents;
        domElement._firstPointerEvents = true;
    }

    domElement.style.pointerEvents = 'auto';
};

DOM_Class.RestoreMouseEvents = function(domElement){

    //if(!domElement) debugger;

    if(domElement && domElement._firstPointerEvents){
        domElement._firstPointerEvents = false;
        domElement.style.pointerEvents = domElement._originalPointerEvents;
    }

};

DOM_Class.MoveToFront = function(domElement){

    if(domElement && !domElement._firstZindex){
        domElement._originalZindex = domElement.style.zIndex;
        domElement._firstZindex = true;
    }

    domElement.style.zIndex = 99999;
};

DOM_Class.RestoreZindex = function(domElement){

    if(domElement && domElement._firstZindex){
        domElement._firstZindex = false;
        domElement.style.zIndex = domElement._originalZindex;
    }
};

DOM_Class.GetCssPrefix = function prefixed () {
    if(this._prefix !== undefined) return this._prefix;

    var prefixes = ["","-webkit-","-moz-","-o-"], el;
    for (var i = 0; i < prefixes.length; i++) {
        el = document.createElement('div');
        el.style.cssText = "width:" + prefixes[i] + "calc(9px)";
        if (el.style.length){
            this._prefix = prefixes[i];
            console.log('prefix =',this._prefix);
            return prefixes[i];
        }
    }
};

//ex dom_css_manager_class_part
DOM_Class.GetEmUnitValue = function(parentNode){
    if (!parentNode) {
        parentNode = document.body;
    }

    if(!DOM_Class._EMscopeTester){
        DOM_Class._EMscopeTester = document.createElement('DIV');
        DOM_Class._EMscopeTester.style = 'display: block; font-size: 1em; margin: 0; padding:0; height: auto; line-height: 1; border:0;';
        DOM_Class._EMscopeTester.innerHTML = '&nbsp;';
    }

    parentNode.appendChild(DOM_Class._EMscopeTester);

    let scopeVal = DOM_Class._EMscopeTester.offsetHeight;
    DOM_Class._EMscopeTester.remove();

    return parseFloat(scopeVal);
};

DOM_Class.PxToEm = function(pxValue , parentNode , addEmSuffix){

    if (!parentNode || (pxValue+'').toLowerCase().indexOf("rem") >= 0) {
      parentNode = document.body;
    }

    let emScale = DOM_Class.GetEmUnitValue(parentNode);

    return (parseFloat(pxValue) / emScale) + (addEmSuffix?'rem':0);
};
//manage all events and avoid redondancies... 
//to switch event activation on dom element without removing it look at DOM_Class.XXXMouseEvents in dom.js

var EVENTS_Class = function(){
    this._eventHandlers = {};
};
EVENTS_Class.prototype.constructor = EVENTS_Class;
//~ class EVENTS_Class{
    //~ constructor() {
        //~ this._eventHandlers = {};
    //~ }
//~ }

EVENTS_Class.debug = false;
EVENTS_Class.currentMouseOverElement = null;
EVENTS_Class.currentMouseDownEvent = null;
EVENTS_Class.previousMouseDownEvent = null;
EVENTS_Class.hideOnMouseDownOutside = [];
EVENTS_Class.eventOnMouseDownOutside = [];
EVENTS_Class.clickTimer = 0;
EVENTS_Class.keys = {shiftKey:false,ctrlKey:false,altKey:false};
EVENTS_Class.mouse = {left:false,right:false,middle:false};
EVENTS_Class.lockEventsRemoving = false;
EVENTS_Class.eventsToRemove = [];

// For disabling doubleclick on element
EVENTS_Class.disableDoubleClick = [];

EVENTS_Class.EVENT_FOCUS = 'focus';
EVENTS_Class.EVENT_BLUR = 'blur';
// ces noms de variables ne sont pas ceux du html pour que tout les cliques passent par les GlobalMouseDown et GlobalMouseUp
// et executé toute les events du tableau _eventHandlers
EVENTS_Class.EVENT_MOUSEDOWN = 'MouseDown';
EVENTS_Class.EVENT_MOUSEUP = 'MouseUp';
EVENTS_Class.EVENT_CLICK = 'Click';
EVENTS_Class.EVENT_DOUBLECLICK = 'DblClick';

EVENTS_Class.EVENT_MOUSEENTER = 'mouseenter';
EVENTS_Class.EVENT_MOUSEOVER = 'mouseover';

EVENTS_Class.EVENT_MOUSEOUT = 'mouseout';
EVENTS_Class.EVENT_MOUSELEAVE = 'mouseleave';

EVENTS_Class.EVENT_KEYUP = 'KeyUp';
EVENTS_Class.EVENT_KEYDOWN = 'KeyDown';
EVENTS_Class.EVENT_CHANGE = 'change';

EVENTS_Class.outsideEvents = {};

EVENTS_Class.EVENT_MOUSEUP_OUTSIDE = 'MouseUpOutSide';
EVENTS_Class.EVENT_MOUSEDOWN_OUTSIDE = 'MouseDownOutSide';

EVENTS_Class.EVENT_TOUCHSTART = 'touchstart';
EVENTS_Class.EVENT_TOUCHEND = 'touchend';
EVENTS_Class.EVENT_TOUCHMOVE = 'touchmove';

EVENTS_Class.defaultDropCallback = null;

EVENTS_Class._windowResizeTimer = 0;

EVENTS_Class._resizeData = {left:false , top:false , right:false , bottom:false , domElement:null , cursor:'auto' , resizing:false };
EVENTS_Class._dragging = false;
EVENTS_Class._dragInitialized = false;

EVENTS_Class._windowOnLoadHandlers = [];
EVENTS_Class._windowOnResizeHandlers = [];

EVENTS_Class._windowLoaded = false;

var isMac = navigator.userAgent.toUpperCase().indexOf('MAC') >= 0;
// console.log(navigator);
var isMacLike = /(Mac|iPhone|iPod|iPad)/i.test(navigator.userAgent);
// var isIOS = /(iPhone|iPod|iPad)/i.test(navigator.userAgent);
var isIOS = (() => {
    if (/iPad|iPhone|iPod/.test(navigator.platform)) {
      return true;
    } else {
      return navigator.maxTouchPoints &&
        navigator.maxTouchPoints > 2 &&
        /MacIntel/.test(navigator.platform);
    }
  })();
var isIpadOS = (() => {
    return navigator.maxTouchPoints && 
      navigator.maxTouchPoints > 2 &&
      /MacIntel/.test(navigator.platform);
  })();

var isMobile =/(Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini)/i.test(navigator.userAgent);
var is_chrome = navigator.userAgent.indexOf('Chrome') > -1;
var is_firefox = navigator.userAgent.indexOf('Firefox') > -1;
var is_safari = navigator.userAgent.indexOf("Safari") > -1;
var is_opera = navigator.userAgent.toLowerCase().indexOf("op") > -1;
if ((is_chrome)&&(is_safari)) { is_safari = false; }
if ((is_chrome)&&(is_opera)) { is_chrome = false; }
//~ EVENTS_Class._passiveSupported = false;
/* Feature detection for touch */
//~ try {
    //~ window.addEventListener("test", null, Object.defineProperty({}, "passive", { get: function() { EVENTS_Class._passiveSupported = true; } }));
//~ } catch(err) {}

// EVENTS_Class.prototype.constructor = EVENTS_Class;

//----------------------------------------------------------------------------------
EVENTS_Class.Init = function(){
    //~ EVENTS_Class.AddEvent(document,'mouseup',EVENTS_Class.GlobalMouseUp);
    //~ EVENTS_Class.AddEvent(document,'mousedown',EVENTS_Class.GlobalMouseDown);
    //~ EVENTS_Class.AddEvent(document,'mousemove',EVENTS_Class.GlobalMouseMove);
    
    // console.log('event '+isIOS);
    if ((isMac || isMacLike) && !isIOS){
        // if (isIOS){
        //     if(EVENTS_Class.debug){
        //         console.log('ios');
        //     }
        //     document.addEventListener("touchstart",EVENTS_Class.TouchHandler);
        //     document.addEventListener("touchmove",EVENTS_Class.TouchHandler, {'passive':false});
        //     document.addEventListener("touchend",EVENTS_Class.TouchHandler);
        //     document.addEventListener("touchcancel",EVENTS_Class.TouchHandler);
        // }else{
            if(EVENTS_Class.debug){
                console.log('mac');
            }
            document.addEventListener('mouseup',EVENTS_Class.GlobalMouseUp);
            document.addEventListener('mousedown',EVENTS_Class.GlobalMouseDown);
            document.addEventListener('mousemove',EVENTS_Class.GlobalMouseMove);
        // }
    } else {
        //~ document.addEventListener('mouseup',EVENTS_Class.GlobalMouseUp);
        document.addEventListener('pointerup',EVENTS_Class.GlobalMouseUp);
        //~ document.addEventListener('mousedown',EVENTS_Class.GlobalMouseDown);
        document.addEventListener('pointerdown',EVENTS_Class.GlobalMouseDown);
        //~ document.addEventListener('mousemove',EVENTS_Class.GlobalMouseMove);
        document.addEventListener('pointermove',EVENTS_Class.GlobalMouseMove);
        //~ document.addEventListener('pointercancel',EVENTS_Class.GlobalMouseUp);
    }
    
    //~ if (event.pointerType == 'touch'){
    EVENTS_Class.TouchHandlerIsActive = true;
    //dedié artisan ?
    document.addEventListener("touchmove", EVENTS_Class.disableScrollOnTouch, {'passive':false});
    document.addEventListener("touchend", ()=>{
        //~ console.log('touchend');
        EVENTS_Class.longPress = -1;
        if (!EVENTS_Class.TouchHandlerIsActive){
            EVENTS_Class.TouchHandlerIsActive = true;
            document.addEventListener("touchmove", EVENTS_Class.disableScrollOnTouch, {'passive':false});
        }
    });


    //~ }
    // remove old event
    //~ let events_to_remove = ['mousedown', 'click', 'dblclick', 'touchstart', 'touchend', 'touchmove', 'mousemove', 'mouseup'];
    //~ let events_to_remove = ['touchmove'];
    //~ events_to_remove.forEach((eventName)=>{
        //~ document.addEventListener(eventName, (event)=>{
            //~ EVENTS_Class.StopEvent(event);
            //~ return false;
        //~ });
    //~ });
    
    // transform touch event to mouse event
    // document.addEventListener("touchstart",EVENTS_Class.TouchHandler);
    // document.addEventListener("touchmove",EVENTS_Class.TouchHandler, {'passive':false});
    // document.addEventListener("touchend",EVENTS_Class.TouchHandler);
    // document.addEventListener("touchcancel",EVENTS_Class.TouchHandler);

    //~ EVENTS_Class.AddEvent(document,'keydown',EVENTS_Class.GlobalKeyDown);
    //~ EVENTS_Class.AddEvent(document,'keyup',EVENTS_Class.GlobalKeyUp);
    document.addEventListener('keydown',EVENTS_Class.GlobalKeyDown);
    document.addEventListener('keyup',EVENTS_Class.GlobalKeyUp);
    
    EVENTS_Class.EnableDrop(document , EVENTS_Class.GlobalDrop);

    //~ EVENTS_Class.AddEvent(window,'resize',EVENTS_Class.WindowResize);
    window.addEventListener('resize',EVENTS_Class.WindowResize);
    
    window.addEventListener('load',EVENTS_Class.WindowLoad);
    //~ EVENTS_Class.AddEvent(window,'load',EVENTS_Class.WindowLoad);
};

EVENTS_Class.AddLoadHandler = function(handler,timed=false){
    if (timed){
        handler=eval(handler);
    }
    if (GENERICS_Class.IsString(handler)) {
         setTimeout(EVENTS_Class.AddLoadHandler , 50 , handler, true);
    }else{
        if (handler === undefined){
            console.log('!!! LOAD HANDLER BAD REGISTRATION !!!');
        }else{
            
            if(EVENTS_Class._windowOnLoadHandlers.indexOf(handler) < 0){
                if(EVENTS_Class._windowLoaded){
                    //window already loaded, execute directly !
                    handler();
                }else{
                    EVENTS_Class._windowOnLoadHandlers.push(handler);
                }
            }else{
                console.log('load already registered ',handler);
            }
        }
    }
};

EVENTS_Class.RemoveLoadHandler = function(handler){
    let pos = EVENTS_Class._windowOnLoadHandlers.indexOf(handler);
    if(pos >= 0){
        EVENTS_Class._windowOnLoadHandlers.splice(pos,1);
    }else{
        console.log('handler not found ',handler);
    }
};

EVENTS_Class.WindowLoad = function(event){
    for(let i = 0 ; i < EVENTS_Class._windowOnLoadHandlers.length ; i++){
        let func = EVENTS_Class._windowOnLoadHandlers[i];
        if(GENERICS_Class.IsFunction(func)){
            func();
        }else{
            console.log('wrong onload handler registered ',func.name);
        }
    }
    EVENTS_Class._windowLoaded = true;
};

EVENTS_Class.MouseInteracting = function(){
    return EVENTS_Class._dragging || EVENTS_Class._dragInitialized || EVENTS_Class._resizeData.resizing;
};

EVENTS_Class.AddResizeHandler = function(handler,timed=false){
    if (timed){
        handler=eval(handler);
    }
    if (GENERICS_Class.IsString(handler)) {
         setTimeout(EVENTS_Class.AddResizeHandler , 50 , handler, true);
    }else{
        if (handler === undefined){
            console.log('!!! RESIZE HANDLER BAD REGISTRATION !!!');
        }else{
            if(EVENTS_Class._windowOnResizeHandlers.indexOf(handler) < 0){
                EVENTS_Class._windowOnResizeHandlers.push(handler);
            }else{
                console.log('handler already registered ',handler);
            }
        }
    }
};

EVENTS_Class.RemoveResizeHandler = function(handler){
    let pos = EVENTS_Class._windowOnResizeHandlers.indexOf(handler);
    if(pos >= 0){
        EVENTS_Class._windowOnResizeHandlers.splice(pos,1);
    }else{
        console.log('handler not found ',handler);
    }
};

EVENTS_Class.WindowResize = function(event){
    if(EVENTS_Class._windowResizeTimer){
        clearTimeout(EVENTS_Class._windowResizeTimer);
    }
    EVENTS_Class._windowResizeTimer = setTimeout(DOM_Class._SetRectDirty , 100 , document.body);
    for(let i = 0 ; i < EVENTS_Class._windowOnResizeHandlers.length ; i++){
        let func = EVENTS_Class._windowOnResizeHandlers[i];
        if(GENERICS_Class.IsFunction(func)){
            func();
        }else{
            console.log('wrong resize handler registered ',func);
        }
    }
};

EVENTS_Class.GlobalKeyDown = function(event){
    if(EVENTS_Class.debug){
        console.log('keydown',event);
    }

    EVENTS_Class.keys.shiftKey = event.shiftKey;
    EVENTS_Class.keys.ctrlKey = event.ctrlKey;
    EVENTS_Class.keys.altKey = event.altKey;
    EVENTS_Class.keys[event.keyCode] = true;
    
    EVENTS_Class.ApplyEvent(EVENTS_Class.EVENT_KEYDOWN , event);
};

EVENTS_Class.GlobalKeyUp = function(event){
    if(EVENTS_Class.debug){
        console.log('keyup',event);
    }
    
    EVENTS_Class.keys.shiftKey = event.shiftKey;
    EVENTS_Class.keys.ctrlKey = event.ctrlKey;
    EVENTS_Class.keys.altKey = event.altKey;
    EVENTS_Class.keys[event.keyCode] = false;
    
    EVENTS_Class.ApplyEvent(EVENTS_Class.EVENT_KEYUP , event);
};

EVENTS_Class.GlobalMouseDown = function(event){
    
    if (event.pointerType == 'touch'){
        EVENTS_Class.TouchHandlerIsActive = true;
        document.addEventListener("touchmove", EVENTS_Class.disableScrollOnTouch, {'passive':false});
    }
    
    if (event.target.hasPointerCapture(event.pointerId)) {
        event.target.releasePointerCapture(event.pointerId);
    }
    
    if(EVENTS_Class.previousMouseDownEvent){
        if(!DOM_Class.IsSameElement( EVENTS_Class.previousMouseDownEvent.target , event.target )){
            EVENTS_Class.ApplyBlur(EVENTS_Class.previousMouseDownEvent);
        }
    }

    EVENTS_Class.DetectMouseButtons(event);
    
    if (EVENTS_Class.mouse.left) {
        if(EVENTS_Class.currentMouseDownEvent){
            EVENTS_Class.previousMouseDownEvent = EVENTS_Class.currentMouseDownEvent;
        }

        EVENTS_Class._InitMouseDownEvent(event);
        
        if(EVENTS_Class.IsDraggable(EVENTS_Class.currentMouseDownEvent.target)){
            EVENTS_Class.StopEvent(event);
        }

        EVENTS_Class.ApplyEvent(EVENTS_Class.EVENT_MOUSEDOWN , event , EVENTS_Class.previousMouseDownEvent);

        // don't initiate resize or drag on touch, wait for a long press that will be detect by move
        if (event.pointerType != 'touch'){
            if(EVENTS_Class._InitResize(EVENTS_Class.currentMouseDownEvent)){


            }else if(EVENTS_Class.IsDraggable(EVENTS_Class.currentMouseDownEvent.target)){
                // disable init drag on mousedown when touch, it will be trig by touchmove after a long press , see function touchHandler below
                if(EVENTS_Class.currentMouseDownEvent.button == 0){
                    //~ console.log('init drag');
                    EVENTS_Class._InitDrag(EVENTS_Class.currentMouseDownEvent.target);
                }
            }
        }

        EVENTS_Class.ApplyHideMouseDownOutside(event);
    }
};

EVENTS_Class.DetectMouseButtons = function(event){
    EVENTS_Class.mouse.left = (event.buttons & 1) > 0?true:false;
    EVENTS_Class.mouse.right = (event.buttons & 2) > 0?true:false;
    EVENTS_Class.mouse.middle = (event.buttons & 4) > 0?true:false;
};

EVENTS_Class._InitMouseDownEvent = function(event){

    EVENTS_Class.currentMouseDownEvent = event;
    
    EVENTS_Class.currentMouseDownEvent.realTime = new Date().getTime();

    // compute exact local position of the mouse pointer inside the clicked element
    let localPos = DOM_Class.GetGlobalToLocal(event.target , event.pageX , event.pageY );
    EVENTS_Class.currentMouseDownEvent.localX = localPos.x;
    EVENTS_Class.currentMouseDownEvent.localY = localPos.y;

    // get the offset between the mouse position and the out bound of the clicked element
    let rect = DOM_Class.GetGlobalRect(event.target,true);
    EVENTS_Class.currentMouseDownEvent.offsetLeft = rect.left - event.pageX;
    EVENTS_Class.currentMouseDownEvent.offsetTop = rect.top - event.pageY;
    EVENTS_Class.currentMouseDownEvent.offsetRight = rect.right - event.pageX;
    EVENTS_Class.currentMouseDownEvent.offsetBottom = rect.bottom - event.pageY;

};

EVENTS_Class.DisableEventCallback = function(event){
    event.preventDefault();
    return false;
};

EVENTS_Class.TouchHandlerIsActive = false;
EVENTS_Class.GlobalMouseUp = function(event){
    
    //~ console.log('up', event);
    
    if(EVENTS_Class.debug){
        console.log('global mouseup');
        console.log(event);
    }
    
    // no detect mouse for mouseup because it's already done by previous mousedown event
    //do not work with touch
    if(EVENTS_Class.currentMouseDownEvent && EVENTS_Class.mouse.left){

        EVENTS_Class.ApplyEvent(EVENTS_Class.EVENT_MOUSEUP , event);

        // same target
        if(DOM_Class.IsSameElement(EVENTS_Class.currentMouseDownEvent.target , event.target)){

            // same position, within a circle of 3px
            let difX = event.pageX - EVENTS_Class.currentMouseDownEvent.pageX;
            let difY = event.pageY - EVENTS_Class.currentMouseDownEvent.pageY;
            if(difX < 3 && difX > -3 && difY < 3 && difY > -3){

                let delay = event.timeStamp - EVENTS_Class.currentMouseDownEvent.timeStamp;

                let prevDelay = 1000;
                
                if(EVENTS_Class.previousMouseDownEvent){
                    prevDelay = event.timeStamp - EVENTS_Class.previousMouseDownEvent.timeStamp;
                }
                
                if(EVENTS_Class.debug){
                    console.log(EVENTS_Class.previousMouseDownEvent);
                    console.log('prevDelay',prevDelay);
                }
                
                if(prevDelay < 500 && DOM_Class.IsSameElement(EVENTS_Class.previousMouseDownEvent.target , event.target) && EVENTS_Class.disableDoubleClick.indexOf(event.target.id) == -1){
                    clearTimeout(EVENTS_Class.clickTimer);

                    EVENTS_Class.ApplyEvent(EVENTS_Class.EVENT_DOUBLECLICK , event);

                }else if(delay < 300){
                    clearTimeout(EVENTS_Class.clickTimer);
                    var eventA = event;
                    var eventB = EVENTS_Class.previousMouseDownEvent;

                    EVENTS_Class.clickTimer = setTimeout(function(){EVENTS_Class.ApplyEvent( EVENTS_Class.EVENT_CLICK , eventA);},5);
                }else{
                    if(EVENTS_Class.debug){
                        console.log('long click');
                    }
                }
            }else{
                // same target but not same position
                if(EVENTS_Class.debug){
                    console.log('drag over the same element');
                }
            }
        }else{
            EVENTS_Class.ApplyEvent(EVENTS_Class.EVENT_MOUSEUP_OUTSIDE , event , EVENTS_Class.previousMouseDownEvent );
        }
    }

    EVENTS_Class._EndGlobalMove(event);

    EVENTS_Class.previousMouseDownEvent = EVENTS_Class.currentMouseDownEvent;
    EVENTS_Class.currentMouseDownEvent = null;
};

// when a class method is send as a callback for an event, a bind must be done to the original class
// to keep the right reference for the 'this' variable in the class method
// bound methods are stored in an array to not have to recreate them each time
// and to keep the same pointer adress in memory to allow the RemoveEventOnMouseDownOutside() function to identify them properly
// examples in colorpicker.js and page.js
EVENTS_Class.BindCallback = function(sourceClass , callback){

    // create the internal list of bound callbacks for the specified class object
    if(!sourceClass.__callbacks){
        sourceClass.__callbacks = {};
    }

    // there is now native way to clearly identify a function, so a unique identifier is assigned to it
    if(!callback.__uniqueID){
        callback.__uniqueID = 'FUNC_'+GENERICS_Class.GetUniqueId();
    }

    if(!sourceClass.__callbacks[callback.__uniqueID]){
        if(arguments.length == 2){
            sourceClass.__callbacks[callback.__uniqueID] = callback.bind(sourceClass);
        }else{
            let args = [];
            for(let i = 2; i < args.length ; i++){
                args.push('arguments['+i+']');
            }
            let command = 'sourceClass.__callbacks[callback.__uniqueID] = callback.bind(sourceClass,'+args.join(',')+');';
            debugger;
            eval(command);
        }
    }

    return sourceClass.__callbacks[callback.__uniqueID];
};


EVENTS_Class._eventsListeners = {};

// send a global event to all related elements
// eventName : name of the event
// data : data received by the event’s callback
// from (optional) : sender of the event
// if from is not specified, all elements listening to an event with the name specified in eventName will be invoked
EVENTS_Class.BroadcastEvent = function(eventName , data , from){

    let id = '__all__';

    if(from){
        if(!from._eventBroadcasterId){
            from._eventBroadcasterId = GENERICS_Class.GetUniqueId();
        }
        id = from._eventBroadcasterId;
    }

    if(EVENTS_Class._eventsListeners[eventName] === undefined){
        EVENTS_Class._eventsListeners[eventName] = {};
    }

    if(EVENTS_Class._eventsListeners[eventName][id] !== undefined){
        let lst = EVENTS_Class._eventsListeners[eventName][id];
        for(let i = 0 ; i< lst.length ; i++){
            EVENTS_Class.SendEvent(lst[i] , eventName , data);
        }
    }
};

// associates  a global event to one element
// to : element receiving the event
// eventName : name of the event
// callback : function to be executed
// from (optional) : sender of the event
// if from is not specified, all elements listening to an event with the name specified in eventName will be invoked
EVENTS_Class.ListenToEvent = function(to , eventName , callback , from){
    if(EVENTS_Class._eventsListeners[eventName] === undefined){
        EVENTS_Class._eventsListeners[eventName] = {};
    }

    let id = '__all__';

    if(from){
        if(!from._eventBroadcasterId){
            from._eventBroadcasterId = GENERICS_Class.GetUniqueId();
        }
        id = from._eventBroadcasterId;
    }

    if(EVENTS_Class._eventsListeners[eventName][id] === undefined){
        EVENTS_Class._eventsListeners[eventName][id] = [];
    }

    if(EVENTS_Class._eventsListeners[eventName][id].indexOf(to) === -1){
        EVENTS_Class._eventsListeners[eventName][id].push(to);
        EVENTS_Class.AddEvent(to, eventName, callback);
    }
};

// dispatch a classic event at an element of the dom
EVENTS_Class.SendEvent = function(domElement,type,data,bubbles,cancelable){

    if(bubbles === undefined){
        bubbles = true;
    }

    if(cancelable === undefined){
        cancelable = true;
    }

    bubbles = bubbles?true:false;
    cancelable = cancelable?true:false;

    var event = false;
    switch (type){
        // mouse events
        case EVENTS_Class.EVENT_MOUSEDOWN:
        case EVENTS_Class.EVENT_MOUSEUP:
        case EVENTS_Class.EVENT_CLICK:
        case EVENTS_Class.EVENT_DOUBLECLICK:
            event = new MouseEvent(type, {detail: data, bubbles: bubbles , cancelable: true });
        break;

        // others
        default:
            event = new CustomEvent(type, {detail: data, bubbles: bubbles , cancelable: true } );
        break;
    }
    if (event) domElement.dispatchEvent(event);
    else console.log('can\'t dispatch event', event);
};

EVENTS_Class.AddEvent = function (domElement, eventName, callback, useCapture,timed=false) {
    // if(EVENTS_Class.debug){
    //     console.log(domElement);
    //     console.log(callback);
    // }
    if (timed){
        callback=eval(callback);
    }
    if (GENERICS_Class.IsString(callback)) {
        setTimeout(EVENTS_Class.AddEvent,50, domElement, eventName, callback, useCapture, true);
    }else{
        if (callback === undefined){
            console.log('!!! ADD EVENT BAD CALLBACK !!!');
        }else{
            if (!domElement._eventListeners) {
                domElement._eventListeners = [];
            }
            
            let foundEvent = false;
            let foundCallback = false;
            for(let i = 0 ; i < domElement._eventListeners.length ; i++){
                if(domElement._eventListeners[i].event === eventName ){
                    foundEvent = true;
                    if (domElement._eventListeners[i].callback === callback ){
                        foundCallback= true;
                        break;
                    }
                }
            }
            //no listener, should add it
            if(!foundEvent){
                useCapture = useCapture ? true : false;
                domElement.addEventListener(eventName, EVENTS_Class.HandlerEvent, useCapture);
            }
            //and push the callback !
            if(!foundCallback){
                domElement._eventListeners.push({'event':eventName,'callback':callback});
                if (CONSTANTS.sids){
                    if (domElement.dataset){
                        let callbackName = callback.name != '' ? callback.name : callback;
                        if (!domElement.dataset.debug) {
                            domElement.dataset.debug='event:'+eventName+' - callback:'+callbackName+' |';
                        }else{
                            domElement.dataset.debug+='event:'+eventName+' - callback:'+callbackName+' |';
                        }
                    }
                }
                switch(eventName){
                    case EVENTS_Class.EVENT_MOUSEUP_OUTSIDE:
                    case EVENTS_Class.EVENT_MOUSEDOWN_OUTSIDE:
                        if( !EVENTS_Class.outsideEvents[eventName] ){
                            EVENTS_Class.outsideEvents[eventName] = [];
                        }

                        if(EVENTS_Class.outsideEvents[eventName].indexOf(domElement) == -1){
                            EVENTS_Class.outsideEvents[eventName].push(domElement);
                        }
                    break;
                }

                return true;
            }
            return false;
        }
    }

    
};

EVENTS_Class.HandlerEvent = function(event){
    EVENTS_Class.ApplyEvent(event.type, event);
};

EVENTS_Class.AddEventDelayed = function(domElement, eventName, callback, useCapture , delay){
    if(!delay){
        delay = 3;
    }
    setTimeout(EVENTS_Class.AddEvent , delay , domElement, eventName, callback, useCapture);
};

EVENTS_Class.ApplyEvent = function(eventName , event , otherEvent){
    
    switch(eventName){
        case EVENTS_Class.EVENT_MOUSEUP_OUTSIDE:
        case EVENTS_Class.EVENT_MOUSEDOWN_OUTSIDE:

            if(GENERICS_Class.IsFilledArray(EVENTS_Class.outsideEvents[eventName])){
                let lst = EVENTS_Class.outsideEvents[eventName];
                let isInside = false;

                for(let i = 0 ; i < lst.length ; i++){
                    let domElement = lst[i];
                    
                    if( DOM_Class.PointInsideElement(event.pageX , event.pageY , domElement) ){
                        // click is inside
                        // do nothing
                        isInside = true;
                        continue;
                    }else{
                        for(let i = 0; i < domElement._eventListeners.length; i++){
                            if(domElement._eventListeners[i].event === eventName){
                                domElement._eventListeners[i].callback(event , otherEvent);

                                if(EVENTS_Class.debug){
                                    console.log('Apply ',eventName , ' to ', domElement, 'callback', document._eventListeners[i]);
                                }
                            }
                        }
                    }
                }
                if (isInside) return false;
            }
        break;

        case EVENTS_Class.EVENT_MOUSEDOWN:
            EVENTS_Class.ApplyEvent(EVENTS_Class.EVENT_MOUSEDOWN_OUTSIDE , event , otherEvent);
        break;

        case EVENTS_Class.EVENT_MOUSEUP:
            EVENTS_Class.ApplyEvent(EVENTS_Class.EVENT_MOUSEUP_OUTSIDE , event , otherEvent);
        break;

        case 'contextmenu':
            EVENTS_Class.ApplyEvent(EVENTS_Class.EVENT_MOUSEDOWN_OUTSIDE , event , otherEvent);
            EVENTS_Class.ApplyEvent(EVENTS_Class.EVENT_MOUSEUP_OUTSIDE , event , otherEvent);
        break;
    }

    var classObject = DOM_Class.GetClassObject(event.target);

    EVENTS_Class.lockEventsRemoving = true;
    if(GENERICS_Class.IsFilledArray(classObject)){
        for(var i=0;i<classObject.length;i++){
            if(classObject[i][eventName]){
                classObject[i][eventName](event , otherEvent);

                if(EVENTS_Class.debug){
                    console.log(eventName+' '+event.target.id);
                }
            }
        }
    }else if(classObject && classObject[eventName]){
        classObject[eventName](event , otherEvent);

        if(EVENTS_Class.debug){
            console.log(eventName+' '+event.target.id);
        }
    }
    
    let domElement = event.target;

    let executed = false;

    if(GENERICS_Class.IsFilledArray(domElement._eventListeners)){
        for(let i = 0; i < domElement._eventListeners.length; i++){
            if(domElement._eventListeners[i].event === eventName){

                domElement._eventListeners[i].callback(event , otherEvent);

                executed = true;

                if(EVENTS_Class.debug){
                    console.log('Apply ',eventName , ' to ', domElement, 'callback', document._eventListeners[i]);
                }
            }
        }
    }
    
    if (eventName == EVENTS_Class.EVENT_KEYUP || eventName == EVENTS_Class.EVENT_KEYDOWN){
        // in case of keyUp or keyDown, much event are on document but the target depends of the last clicked item.
        // this may be the best way to trig event on document when there is no event on the targeted item 
        // this way, when pressing a key in an input the event from document will not be trigged 
        if(GENERICS_Class.IsFilledArray(document._eventListeners)){
            for(let i = 0; i < document._eventListeners.length; i++){
                if(document._eventListeners[i].event === eventName){

                    document._eventListeners[i].callback(event , otherEvent);

                    executed = true;

                    if(EVENTS_Class.debug){
                        console.log('Apply ',eventName , ' to ', document, 'callback', document._eventListeners[i]);
                    }
                }
            }
        }
    }

    if(event.cancelBubble == false){
        if(domElement.children){
            for(let j = 0 ; j < domElement.children.length ; j ++){
                let child = domElement.children[j];
                if( DOM_Class.PointInsideElement(event.pageX , event.pageY , child) ){
                    
                    let pointerEventsNone = getComputedStyle(child)['pointer-events'] == 'none';

                    if(child._eventListeners && (!pointerEventsNone || (child.dataset && child.dataset.disabled == 'true'))){
                        for(let k = 0; k < child._eventListeners.length; k++){
                            if(child._eventListeners[k].event === eventName){
                                
                                child._eventListeners[k].callback(event , otherEvent);
                                
                                if (EVENTS_Class.debug){
                                    console.log('should Apply ',eventName , ' to ', child, 'callback', child._eventListeners[k]);
                                }

                                executed = true;
                            }
                        }
                    }

                }
            }
        }else{
            //~ console.log('bug !');
        }
    }
    
    
    

    /*
     * TODO : upstream of the event on the parents
     * NOT SURE !
    if(event.cancelBubble == false){
        let p = domElement.parentNode;
        while(p && event.cancelBubble == false){
            if( DOM_Class.PointInsideElement(event.pageX , event.pageY , p) ){
                if(p._eventListeners){
                    for(let k = 0; k < p._eventListeners.length; k++){
                        if(p._eventListeners[k].event === eventName){
                            p._eventListeners[k].callback(event , otherEvent);
                            executed = true;
                        }
                    }
                }
            }
            p = p.parentNode;
        }
    }
*/

    EVENTS_Class.lockEventsRemoving = false;

    if ( GENERICS_Class.IsFilledArray(EVENTS_Class.eventsToRemove)) {
        for(let c = 0 ; c < EVENTS_Class.eventsToRemove.length ; c++){
            let infos = EVENTS_Class.eventsToRemove[c];

            if(infos.length == 1){
                EVENTS_Class.RemoveAllEvents(infos[0]);

            }else if (infos.length == 3){
                EVENTS_Class.RemoveEvent(infos[0] , infos[1] , infos[2]);

            }else{
                debugger;
            }
        }
        EVENTS_Class.eventsToRemove.length = 0;
    }
};

EVENTS_Class.HasEvent = function (domElement, eventName) {
    if ( !GENERICS_Class.IsFilledArray(domElement._eventListeners)) {
        return false;
    }

    for(let i = 0 ; i < domElement._eventListeners.length ; i++){
        if(domElement._eventListeners[i].event === eventName){
            return true;
        }
    }

    return false;
};

EVENTS_Class.HasEventCallback = function (domElement, eventName , callback) {

    if ( !GENERICS_Class.IsFilledArray(domElement._eventListeners)) {
        return false;
    }

    for(let i = 0 ; i < domElement._eventListeners.length ; i++){
        if(domElement._eventListeners[i].event === eventName && domElement._eventListeners[i].callback === callback){
            return true;
        }
    }

    return false;
};

EVENTS_Class.RemoveEvent = function(domElement, eventName, callback) {

    if ( !GENERICS_Class.IsFilledArray(domElement._eventListeners)) {
        return false;
    }

    if(EVENTS_Class.lockEventsRemoving){
        EVENTS_Class.eventsToRemove.push([domElement , eventName , callback]);
        return false;
    }

    for(let i = 0, len = domElement._eventListeners.length; i < len; i++) {
        let e = domElement._eventListeners[i];
        if((e.event === eventName && e.callback === callback) || (e.event == eventName && !callback) ){
            if ( domElement.removeEventListener ) {
                domElement.removeEventListener(e.event, e.callback);

            } else if ( domElement.attachEvent ) {
                domElement.detachEvent( 'on' + e.event, e.callback );
            }

            domElement._eventListeners.splice(i,1);

            if(EVENTS_Class.outsideEvents){
                switch(eventName){
                    case EVENTS_Class.EVENT_MOUSEUP_OUTSIDE:
                    case EVENTS_Class.EVENT_MOUSEDOWN_OUTSIDE:
                        if( GENERICS_Class.IsFilledArray(EVENTS_Class.outsideEvents[eventName])){
                            let pos = EVENTS_Class.outsideEvents[eventName].indexOf(domElement);
                            if( pos > -1){
                                EVENTS_Class.outsideEvents[eventName].splice(pos,1);
                            }
                        }
                    break;
                }
            }

            len--;
            i--;
        }
    }
};

EVENTS_Class.RemoveAllEvents = function(domElement) {
    if ( !GENERICS_Class.IsFilledArray(domElement._eventListeners)) {
        return false;
    }

    if(EVENTS_Class.lockEventsRemoving){
        EVENTS_Class.eventsToRemove.push([domElement]);
        return false;
    }

    for(let i = 0, len = domElement._eventListeners.length; i < len; i++) {
        let e = domElement._eventListeners[i];
        if ( domElement.removeEventListener ) {
            domElement.removeEventListener(e.event, e.callback);

        } else if ( elem.attachEvent ) {
            domElement.detachEvent( "on" + e.event, e.callback );
        }
    }

    domElement._eventListeners.length = 0;

    if(EVENTS_Class.outsideEvents){
        let keys = Object.keys(EVENTS_Class.outsideEvents);
        for(let i = 0 ; i < keys.length ; i++){
            let pos = EVENTS_Class.outsideEvents[keys[i]].indexOf(domElement);
            if(pos > -1){
                EVENTS_Class.outsideEvents[keys[i]].splice(pos,1);
            }
        }
    }
};

EVENTS_Class._moveList = [];

EVENTS_Class.StartGlobalMove = function(domElement,moveHandler,endMoveHandler){

    let lst = EVENTS_Class._moveList;
    for(let i = 0 ; i < lst.length ; i++){
        if(lst[i].domElement === domElement && lst[i].moveHandler === moveHandler && EVENTS_Class._moveList[i].moveHandler){
            return false;
        }
    }

    EVENTS_Class._moveList.push({'domElement':domElement , 'moveHandler':moveHandler , 'endMoveHandler':endMoveHandler});
    //EVENTS_Class._currentMoveHandler = moveHandler;
    //EVENTS_Class._currentEndMoveHandler = endMoveHandler;

    if(this.debug){
        console.log("start move");
    }

    //~ EVENTS_Class.AddEvent(document,'mousemove', EVENTS_Class.GlobalMouseMove);
    //~ EVENTS_Class.AddEvent(document,'mouseup', EVENTS_Class._EndGlobalMove);

};

// long press determine si on doit déclencher le drag pour le touch,
// remis a false par mouseUp
// -1 , pas assigné, 0 press normal, 1 long press
EVENTS_Class.longPress = -1;
EVENTS_Class.GlobalMouseMove = function(event){
    //~ console.log('move', event);

    // on touch, the move is initialised after a long press, do nothing if the move is too little
    // Apparently there is no need to do the test for the little move.
    if (event.pointerType == 'touch'){
        //~ console.log(EVENTS_Class.currentMouseDownEvent);
        if (EVENTS_Class.currentMouseDownEvent === null){
            return false;
        }
        let difX = Math.abs(EVENTS_Class.currentMouseDownEvent.screenX - event.screenX);
        let difY = Math.abs(EVENTS_Class.currentMouseDownEvent.screenY - event.screenY);
        if (difX < 5 && difY < 5){
            return false;
        }
        
        if (EVENTS_Class.longPress == -1){
            let now = new Date().getTime();
            let difT = now - EVENTS_Class.currentMouseDownEvent.realTime;
            // console.log(difT);
            if (difT < 500){
                EVENTS_Class.longPress = 0;
                
                if (EVENTS_Class.currentMouseDownEvent.pointerType == 'touch'){
                    EVENTS_Class.TouchHandlerIsActive = false;
                    document.removeEventListener("touchmove", EVENTS_Class.disableScrollOnTouch);
                }
                
            } else {
                EVENTS_Class.longPress = 1;
                
                if(EVENTS_Class._InitResize(EVENTS_Class.currentMouseDownEvent)){


                }else if(EVENTS_Class.IsDraggable(EVENTS_Class.currentMouseDownEvent.target)){
                    // disable init drag on mousedown when touch, it will be trig by touchmove after a long press , see function touchHandler below
                    if(EVENTS_Class.currentMouseDownEvent.button == 0){
                        //~ console.log('init drag');
                        EVENTS_Class._InitDrag(EVENTS_Class.currentMouseDownEvent.target);
                    }
                }
            }
        }
        
        if (EVENTS_Class.longPress == 0){
            return false;
        }
    }

    if(GENERICS_Class.IsFilledArray(EVENTS_Class._moveList)){
        for(let i = 0; i < EVENTS_Class._moveList.length ; i++){
            if(EVENTS_Class._moveList[i].moveHandler){
                EVENTS_Class._moveList[i].moveHandler(event , EVENTS_Class._moveList[i].domElement);
            }
        }
    }

    let prevElement = EVENTS_Class.currentMouseOverElement;

    EVENTS_Class.currentMouseOverElement = event.target;

    if(prevElement != EVENTS_Class.currentMouseOverElement){
        if(prevElement){
            EVENTS_Class.ApplyEvent(EVENTS_Class.EVENT_MOUSELEAVE , event , prevElement);
        }
        EVENTS_Class.ApplyEvent(EVENTS_Class.EVENT_MOUSEENTER , event);
    }

    if(!EVENTS_Class._dragging && !EVENTS_Class._resizeData.resizing){

        if(EVENTS_Class.IsResizable(EVENTS_Class.currentMouseOverElement)){
            let doResize = EVENTS_Class._CheckResize(event);

            if(doResize){

                DOM_Class.SetGlobalCursor(EVENTS_Class._resizeData.cursor);

                EVENTS_Class._overResizable = true;

            }else if(EVENTS_Class._overResizable){

                EVENTS_Class._overResizable = false;
                DOM_Class.UnsetGlobalCursor();
            }

        }else if(EVENTS_Class._overResizable){

            EVENTS_Class._overResizable = false;

            DOM_Class.UnsetGlobalCursor();

        }else{
            EVENTS_Class._overResizable = false;
        }
    }
    
    EVENTS_Class.ParsingMouseMove = false;

};

EVENTS_Class._EndGlobalMove = function(event){

    if(GENERICS_Class.IsFilledArray(EVENTS_Class._moveList)){
        for(let i = 0; i < EVENTS_Class._moveList.length ; i++){
            if(EVENTS_Class._moveList[i].endMoveHandler){
                EVENTS_Class._moveList[i].endMoveHandler(event , EVENTS_Class._moveList[i].domElement);
            }
        }
        EVENTS_Class._moveList.length = 0;
    }

    //~ if(this.debug){
        //~ console.log("end move",EVENTS_Class._moveList);
    //~ }
};

EVENTS_Class.StopEvent = function (event){
    //~ console.log('stop event');
    if(event.stopPropagation){
        event.stopPropagation();
    }

    if(event.preventDefault && event.cancelable){
        event.preventDefault();
    }
    //~ else{
        //~ event.returnValue = false;
    //~ }

    return false;
};

EVENTS_Class.StopPropagation = function (event){

    if(event.stopPropagation){
        event.stopPropagation();
    }
};

EVENTS_Class.PreventDefault = function (event){
    if(event.preventDefault){
        event.preventDefault();
    }else{
        event.returnValue = false;
    }
};

//------------------------------------------------------
EVENTS_Class.EnableResize = function (domElement , startResizeHandler , resizeHandler , endResizeHandler , boderDetectionSize){

    if(!boderDetectionSize){
        boderDetectionSize = 10;
    }

    domElement.setAttribute('data-resizeable',true);
    domElement.setAttribute('data-resizeborder',boderDetectionSize);
    domElement.draggable = false;

    domElement._startResizeHandler = startResizeHandler;
    domElement._resizeHandler = resizeHandler;
    domElement._endResizeHandler = endResizeHandler;
};
//NOT USED !
EVENTS_Class.DisableResize = function (domElement){
    domElement.removeAttribute('data-resizeable');
    domElement.draggable = false;
};

EVENTS_Class.IsResizable = function (domElement){
    return domElement && domElement.getAttribute?domElement.getAttribute('data-resizeable'):false;
};

EVENTS_Class._CheckResize = function (event){
    if(!EVENTS_Class.IsResizable(event.target)){
        return false;
    }

    let domElement = event.target;

    let b = parseInt(domElement.getAttribute('data-resizeborder'));

    let rect = DOM_Class.GetGlobalRect(event.target);
    let offsetLeft = rect.left - event.pageX;
    let offsetTop = rect.top - event.pageY;
    let offsetRight = rect.right - event.pageX;
    let offsetBottom = rect.bottom - event.pageY;

    if( b*2 >= rect.height || b*2 >= rect.width){
        b = Math.max(5,b/2);
    }


    let doResize = false;

    let css_cursor = '';
    let style = null;
    if(domElement._sourceElement){
        style = DOM_Class.GetStyle(domElement._sourceElement);
    }else{
        style = DOM_Class.GetStyle(domElement);
    }
    let is_relative = style.POS != 'absolute' && style.POS != 'fixed';

    EVENTS_Class._resizeData.left = false;
    EVENTS_Class._resizeData.top = false;
    EVENTS_Class._resizeData.right = false;
    EVENTS_Class._resizeData.bottom = false;
    EVENTS_Class._resizeData.domElement = domElement;

    // a relative element with width auto cannot be resized
    let auto_width = is_relative && style._width_unit == 'auto';

    let left_resize = true;
    let right_resize = true;
    if(is_relative && style._align == '') left_resize = false;
    if(is_relative && style._align == 'right') right_resize = false;

    if(Math.abs(offsetTop) < b && !is_relative){// cannot change top of relative items
        EVENTS_Class._resizeData.top = true;
        doResize = true;
        css_cursor += 'n';

    }else if(Math.abs(offsetBottom) < b && !is_relative){ // cannot change height on relative items
        EVENTS_Class._resizeData.bottom = true;
        doResize = true;

        css_cursor += 's';
    }

    if(Math.abs(offsetRight) < b && !auto_width && right_resize){
        EVENTS_Class._resizeData.right = true;
        doResize = true;

        css_cursor += 'e';

    }else if(Math.abs(offsetLeft) < b && !auto_width && left_resize){
        EVENTS_Class._resizeData.left = true;
        doResize = true;

        css_cursor += 'w';
    }

    if(doResize){
        css_cursor += '-resize';
    }

    EVENTS_Class._resizeData.cursor = css_cursor;

    return doResize;
};

EVENTS_Class._InitResize = function (mouseDownEvent){

    if(!EVENTS_Class.IsResizable(mouseDownEvent.target)){
        return false;
    }

    let doResize = EVENTS_Class._CheckResize(mouseDownEvent);

    if(doResize){
        // update current rect
        DOM_Class.GetGlobalRect(mouseDownEvent.target);

        EVENTS_Class._resizeData.resizing = true;

        // activate drag
        EVENTS_Class.StartGlobalMove(mouseDownEvent.target , EVENTS_Class._Resize , EVENTS_Class._EndResize);

        if(mouseDownEvent.target._startResizeHandler){
            mouseDownEvent.target._startResizeHandler();
        }
    }else{

    }

    return doResize;
};

EVENTS_Class._EndResize = function (event){
    EVENTS_Class._resizeData.resizing = false;

    if(event.target._endResizeHandler){
        event.target._endResizeHandler();
    }
};

EVENTS_Class._Resize = function (event){
    let domElement = EVENTS_Class.currentMouseDownEvent.target;
    let areaRect = null;

    if(domElement._dragArea){
        areaRect = DOM_Class.GetGlobalRect(domElement._dragArea);
    }

    if(EVENTS_Class._resizeData.left){
        if(areaRect){
            DOM_Class.SetGlobalLeft(domElement , Math.max(areaRect.left , event.pageX + EVENTS_Class.currentMouseDownEvent.offsetLeft) );

        }else{
            DOM_Class.SetGlobalLeft(domElement , event.pageX + EVENTS_Class.currentMouseDownEvent.offsetLeft);
        }

    }else if(EVENTS_Class._resizeData.right){
        if(areaRect){
            DOM_Class.SetGlobalRight(domElement , Math.min(areaRect.right , event.pageX + EVENTS_Class.currentMouseDownEvent.offsetRight));
        }else{
            DOM_Class.SetGlobalRight(domElement , event.pageX + EVENTS_Class.currentMouseDownEvent.offsetRight);
        }
    }

    if(EVENTS_Class._resizeData.top){
        if(areaRect){
            DOM_Class.SetGlobalTop(domElement , Math.max(areaRect.top , event.pageY + EVENTS_Class.currentMouseDownEvent.offsetTop));
        }else{
            DOM_Class.SetGlobalTop(domElement , event.pageY + EVENTS_Class.currentMouseDownEvent.offsetTop);
        }

    }else if(EVENTS_Class._resizeData.bottom){
        if(areaRect){
            DOM_Class.SetGlobalBottom(domElement , Math.min(areaRect.bottom , event.pageY + EVENTS_Class.currentMouseDownEvent.offsetBottom));
        }else{
            DOM_Class.SetGlobalBottom(domElement , event.pageY + EVENTS_Class.currentMouseDownEvent.offsetBottom);
        }
    }

    if(domElement._resizeHandler){
        domElement._resizeHandler();
    }
};

//----------------------------------------------------------------------------------
EVENTS_Class.EnableDrag = function (domElement , startHandler , moveHandler , endHandler , avatarHandler){

    if(EVENTS_Class.HasDrag(domElement)){
        if (EVENTS_Class.debug) console.log('Drag already assigned to ',domElement);
        return false;
    }
    domElement.setAttribute('data-draggable',true);
    domElement.draggable = false;

    domElement._dragStart = undefined;
    domElement._dragMove = undefined;
    domElement._dragEnd = undefined;

    if(startHandler && !GENERICS_Class.IsFunction(startHandler) && GENERICS_Class.IsObject(startHandler) ){
        let settings = startHandler;

        domElement._dragStart = settings.startHandler;
        domElement._dragMove = settings.moveHandler;
        domElement._dragEnd = settings.endHandler;
        domElement._useAvatar = settings.avatar;

    }else{
        domElement._dragStart = startHandler;
        domElement._dragMove = moveHandler;
        domElement._dragEnd = endHandler;
        domElement._useAvatar = avatarHandler;
    }


    return true;
};

EVENTS_Class.HasDrag = function (domElement){
    if(domElement === document){
        domElement = document.body;
    }

    return domElement.getAttribute('data-draggable');
};

EVENTS_Class.DisableDrag = function (domElement){
    domElement.removeAttribute('data-draggable');
    domElement.draggable = false;
};

EVENTS_Class.IsDraggable = function (domElement){
    return domElement.getAttribute('data-draggable');
};

EVENTS_Class.SetDragArea = function (domElement , areaDomElement , padding){
    domElement._dragArea = areaDomElement;
    domElement._dragAreaPadding = padding === undefined ? 0:parseInt(padding);

    if(domElement._overlay){
        domElement._overlay.domElement._dragArea = areaDomElement;
    }
};
//NOT USED ANYWHERE ! But should !
EVENTS_Class.UnsetDragArea = function (domElement){
    domElement._dragArea = null;
};

EVENTS_Class._InitDrag = function (domElement){
    //~ console.log('init drag');
    EVENTS_Class._dragInitialized = true;

    // update current rect
    let rect = DOM_Class.GetGlobalRect(domElement,true);
    DOM_Class.GetGlobalRect(domElement._dragArea,true);

    domElement._dragStarted = false;

    // activate drag
    EVENTS_Class.StartGlobalMove(domElement , EVENTS_Class._Drag , EVENTS_Class._DragEnd);

    DOM_Class.SetGlobalCursor('move');

    if(!domElement._sourceRect){
        domElement._sourceRect = {};
    }
    GENERICS_Class.CopyObject(rect , domElement._sourceRect);

    domElement._sourceParent = domElement.parentNode;

    if(!EVENTS_Class._currentDragElement){
        EVENTS_Class._currentDragElement = [];
    }
    EVENTS_Class._currentDragElement.push(domElement);
};

EVENTS_Class._Drag = function (event , b){
    
    EVENTS_Class.StopEvent(event);

    let difx = Math.abs(event.pageX - EVENTS_Class.currentMouseDownEvent.pageX);
    let dify = Math.abs(event.pageY - EVENTS_Class.currentMouseDownEvent.pageY);

    if(difx < 3 && dify < 3){
        return;
    }

    let domElement = EVENTS_Class.currentMouseDownEvent.target;



    if(!domElement._dragStarted){

        if(GENERICS_Class.IsString(domElement._useAvatar)){

            domElement._avatar = DOM_Class.StringToDom(domElement._avatar);
            document.body.appendChild(domElement._avatar);

        }else if(GENERICS_Class.IsFunction(domElement._useAvatar)){

            let tmp = domElement._useAvatar(domElement);
            
            if(GENERICS_Class.IsString(tmp)){
                tmp = DOM_Class.StringToDom(tmp);
            }
            
            domElement._avatar = tmp;
            document.body.appendChild(domElement._avatar);

        }else{
            domElement._avatar = domElement;
        }



        if(domElement._avatar !== domElement){
            let style = DOM_Class.GetStyle(domElement._avatar);
            domElement._avatar._originalPositionStyle = style.POS;

            DOM_Class.SetStyleValue(domElement._avatar , 'position' , 'absolute');

            let pos = DOM_Class.GetGlobalPosition(domElement);
            DOM_Class.SetGlobalPosition(domElement._avatar , pos.x , pos.y);
        }


        DOM_Class.DisableMouseEvents(domElement._avatar);
        DOM_Class.MoveToFront(domElement._avatar);

        // activate custom functions
        //EVENTS_Class.StartGlobalMove(domElement , domElement._dragMove , domElement._dragEnd);
    }

    EVENTS_Class._dragging = true;
    let avatar = domElement._avatar || domElement;

    if(domElement._dragArea){
        let rect = DOM_Class.GetGlobalRect(avatar);
        let areaRect = DOM_Class.GetGlobalRect(domElement._dragArea);

        let x = event.pageX + EVENTS_Class.currentMouseDownEvent.offsetLeft;
        let y = event.pageY + EVENTS_Class.currentMouseDownEvent.offsetTop;
        let w = DOM_Class.GetGlobalWidth(avatar);
        let h = DOM_Class.GetGlobalHeight(avatar);
        let right = x + w;
        let bottom = y + h;

        let padding = domElement._dragAreaPadding;

        if(x < areaRect.left - padding){
            x = areaRect.left - padding;
        }
        if(y < areaRect.top - padding){
            y = areaRect.top - padding;
        }
        if(right > areaRect.right + padding){
            x = (areaRect.right + padding) - w;
        }
        if(bottom > areaRect.bottom + padding){
            y = (areaRect.bottom + padding) - h;
        }

        DOM_Class.SetGlobalPosition(avatar , x,y);

    }else{
        let px = event.pageX + EVENTS_Class.currentMouseDownEvent.offsetLeft;
        let py = event.pageY + EVENTS_Class.currentMouseDownEvent.offsetTop;
        DOM_Class.SetGlobalPosition(avatar , px , py);
    }

    if(!domElement._dragStarted && domElement._dragStart){
        domElement._dragStart(event , domElement);
    }

    domElement._dragStarted = true;

    if(domElement._dragMove) domElement._dragMove(event , domElement);
};

EVENTS_Class._DragEnd = function (event){
    EVENTS_Class._dragging = false;
    EVENTS_Class._dragInitialized = false;

    DOM_Class.UnsetGlobalCursor();

    let domElement = EVENTS_Class.currentMouseDownEvent.target;

    if(domElement._dragStarted){

        // event.detail.target used for touch
        dropOnElement = event.target || event.detail.target;
        //~ console.log(event);

        if(dropOnElement.tagName == 'HTML' || dropOnElement==document){
            dropOnElement = document.body;
        }

        if(EVENTS_Class.HasDrop(dropOnElement)){
            //~ console.log(event);
            EVENTS_Class.SendEvent(dropOnElement,'drop' , {'dropEvent':event ,'elements':EVENTS_Class._currentDragElement.slice()});
        }

        if(domElement._dragEnd) domElement._dragEnd(event , domElement);
    }else{
        //console.log('drag aborted');
    }

    if(domElement._avatar && domElement._avatar !== domElement){
        DOM_Class.RemoveElement(domElement._avatar);

    }else if(domElement._avatar) {
        DOM_Class.SetStyleValue(domElement._avatar , 'position' , domElement._avatar._originalPositionStyle);

    }else if( domElement._originalPositionStyle !== undefined ){
        DOM_Class.SetStyleValue(domElement , 'position' , domElement._originalPositionStyle);
    }

    for(let i = 0; i < EVENTS_Class._currentDragElement.length ; i++){
        DOM_Class.RestoreMouseEvents(EVENTS_Class._currentDragElement[i]);
        DOM_Class.RestoreZindex(EVENTS_Class._currentDragElement[i]);
    }
    EVENTS_Class._currentDragElement.length = 0;

    EVENTS_Class.currentMouseOverElement = document.elementFromPoint(event.pageX, event.pageY);
};

EVENTS_Class.disableScrollOnTouch = function(event){
    //~ if (event.cancelable){
    //~ console.log('disable touchmove');
    event.preventDefault();
    //~ }
    return false;
};
//----------------------------------------------------------------------
EVENTS_Class.SetDefaultDropCallback = function(callback){
    EVENTS_Class.defaultDropCallback = callback;
};

EVENTS_Class.GlobalDrop = function(event){
    EVENTS_Class.StopEvent(event);

    if(GENERICS_Class.IsFunction(EVENTS_Class.defaultDropCallback)){

        EVENTS_Class.defaultDropCallback(event);
    }

};

EVENTS_Class.EnableDrop = function (domElement , callback){

    if(domElement === document){
        if(!document.body){
            // body not loaded yet, try again later;
            setTimeout(EVENTS_Class.EnableDrop , 100 , domElement , callback);
            return false;
        }

        EVENTS_Class.AddEvent(domElement , 'dragover' , EVENTS_Class.DisableEventCallback , false);
        EVENTS_Class.AddEvent(domElement , 'drop' , callback , false);
        domElement = document.body;
    }
    
    if(EVENTS_Class.HasDrop(domElement)){
        console.log('Drop event already assigned to ',domElement);
        return false;
    }
    if(domElement){
        domElement.setAttribute('data-drop',true);

        EVENTS_Class.AddEvent(domElement , 'dragover' , EVENTS_Class.DisableEventCallback , false);
        EVENTS_Class.AddEvent(domElement , 'drop' , callback , false);
    }else{
        //~ console.log('Wrong target for EnableDrop',domElement);
    }

    return true;
};

EVENTS_Class.DisableDrop = function (domElement){
    if(domElement === document){
        EVENTS_Class.RemoveEvent(domElement , 'dragover' , EVENTS_Class.DisableEventCallback);
        EVENTS_Class.RemoveEvent(domElement , 'drop');
        domElement = document.body;
    }

    domElement.setAttribute('data-drop',false);

    EVENTS_Class.RemoveEvent(domElement , 'dragover' , EVENTS_Class.DisableEventCallback);
    EVENTS_Class.RemoveEvent(domElement , 'drop');
};

EVENTS_Class.HasDrop = function (domElement){
    if(domElement === document){
        domElement = document.body;
    }
    if(!domElement) debugger;
    let has = domElement.getAttribute('data-drop');
    if (has) has = (has == 'true') ? 1 : 0;
    return has;
};

EVENTS_Class.DROP_FILES = 'Files';
EVENTS_Class.DROP_HTML = 'text/html';
EVENTS_Class.DROP_TEXT = 'text/plain';

EVENTS_Class.ExtractDataFromDropEvent = function(event , filter){

    let result = {};

    let eventType = GENERICS_Class.GetType(event);

    switch(eventType){
        case 'DragEvent':
            for(let i in event.dataTransfer.types){
                let type = event.dataTransfer.types[i];

                if(filter && filter.indexOf(type) == -1 ){
                    continue;
                }

                switch(type){
                    case EVENTS_Class.DROP_FILES:
                        result[type] = event.dataTransfer.files;
                    break;

                    default:
                        result[type] = event.dataTransfer.getData(type);
                    break;
                }
            }
            result.destination = event.currentTarget;
        break;

        case 'CustomEvent':
            result.dropData = {'pageX':event.detail.dropEvent.pageX , 'pageY':event.detail.dropEvent.pageY , 'elements':event.detail.elements};
            result.destination = event.target;
        break;
    }

    if(result.destination === document){
        result.destination = document.body;
    }

    return result;
};

//----------------------------------------------------------------------

EVENTS_Class.ApplyHideMouseDownOutside = function(event){
    if(EVENTS_Class.hideOnMouseDownOutside.length){

        for(let i = 0 ; i < EVENTS_Class.hideOnMouseDownOutside.length ; i++){
            var rect = DOM_Class.GetGlobalRect(EVENTS_Class.hideOnMouseDownOutside[i], true);
            if(event.pageX >= rect.left && event.pageX <= rect.right && event.pageY >= rect.top && event.pageY <= rect.bottom){

            }else{
                var classObject = DOM_Class.GetClassObject(EVENTS_Class.hideOnMouseDownOutside[i]);
                if(GENERICS_Class.IsArray(classObject)){
                    for(let j = 0 ; j < classObject.length ; j++){
                        if(classObject[j].Hide){
                            classObject[j].Hide(event);
                        }
                    }
                }else if(classObject && classObject.Hide){
                    classObject.Hide(event);
                    console.log("HIDED EVENTS");
                }
            }
        }
    }
};
//colorpicker and csseditor only !
EVENTS_Class.AddHideOnMouseDownOutside = function(domElement){
    if(EVENTS_Class.hideOnMouseDownOutside.indexOf(domElement) == -1){
        EVENTS_Class.hideOnMouseDownOutside.push(domElement);
    }
};
//colorpicker and csseditor only !
EVENTS_Class.RemoveHideOnMouseDownOutside = function(domElement){
    let i = EVENTS_Class.hideOnMouseDownOutside.indexOf(domElement);
    if(i>-1){
        EVENTS_Class.hideOnMouseDownOutside.splice(i,1);
    }
};

EVENTS_Class.ApplyBlur = function(event){
    var classObject = DOM_Class.GetClassObject(event.target);

    if(DOM_Class.debug){
        console.log('blur '+event.target.id);
    }

    if(GENERICS_Class.IsArray(classObject)){
        for(var i=0;i<classObject.length;i++){
            if(classObject[i].Blur){
                classObject[i].Blur(event);
            }
        }
    }else if(classObject && classObject.Blur){
        classObject.Blur(event);
    }
};

EVENTS_Class.Touch = {};
EVENTS_Class.Touch.mousedownElem = null;
EVENTS_Class.Touch.prevOverElem = null;
EVENTS_Class.Touch.history = [];
EVENTS_Class.Touch.preveventtime = 0;
EVENTS_Class.Touch.prevbtn = '';
EVENTS_Class.Touch.eventsList = [];
EVENTS_Class.Touch.prevtouch = "";
EVENTS_Class.Touch.prevclicktime = 0;
EVENTS_Class.Touch.clickcount = 0;
EVENTS_Class.Touch.prevX = 0;
EVENTS_Class.Touch.prevY = 0;
EVENTS_Class.Touch.has_moved = false;

EVENTS_Class.TouchHandler = function(event){
    var touches = event.changedTouches, first = touches[0], type = "";
    
    //~ EVENTS_Class.debug = true;
    //~ console.log(event);

    switch(event.type){
        case "touchstart":
            type = "mousedown";
        break;

        case "touchmove":
            type="mousemove";
            //~ event.preventDefault();
            //~ window.scroll(0,0);
        break;

        case "touchend":
            type="mouseup";
        break;
        
        default:
            EVENTS_Class.StopEvent(event);
            return;
    }
    
    let whichbtn = 0;
    let btnFlags = 1;
    let relatedTarget = null;
    
    if (event.touches.length > 1){
        whichbtn = 2;
        btnFlags = 1+2;
    }
    
    if (type =="mouseup") whichbtn = EVENTS_Class.prevbtn;
    
    if(type == "mousedown"){
        EVENTS_Class.Touch.mousedownElem = first.target;
        EVENTS_Class.Touch.prevOverElem = null;
    }
    
    let difX = 0;
    let difY = 0;
    var now = new Date().getTime();
    var difT = now - EVENTS_Class.Touch.preveventtime;
    
    var longPress = difT > 500;
    
    if(type == "mousemove"){
        //~ let difT = (EVENTS_Class.Touch.history[EVENTS_Class.Touch.history.length-1].time - first.time);
        
        //~ console.log('difT', difT, 'longPress', longPress);
        
        var overElem = document.elementFromPoint(first.pageX , first.pageY );
    
        if(EVENTS_Class.Touch.prevOverElem && overElem != EVENTS_Class.Touch.prevOverElem){
            EVENTS_Class.SendEvent(EVENTS_Class.Touch.prevOverElem,'mouseout');
            EVENTS_Class.SendEvent(overElem,'mouseover');
            //~ console.log('moved out');
        }
        EVENTS_Class.Touch.prevOverElem = overElem;

        if(EVENTS_Class.Touch.history.length > 1){
            let t = EVENTS_Class.Touch.history[EVENTS_Class.Touch.history.length-1];            
            difX = Math.abs(t.x - first.screenX);
            difY = Math.abs(t.y - first.screenY);
            //dbg(difX+" "+difY);

            if(difX < 5 && difY < 5){
                EVENTS_Class.StopEvent(event);
                return false;
            }
        }
    }
    
    if(event.type != 'touchmove') EVENTS_Class.Touch.history.push({'type':event.type,'x':first.screenX,'y':first.screenY,'time':now});
    var cnt = EVENTS_Class.Touch.history.length;

    if(type != 'click' && cnt>2 && (event.type == "touchend" || event.type == "touchcancel") && EVENTS_Class.Touch.mousedownElem == first.target){
        let t = EVENTS_Class.Touch.history[cnt-2];
        let difX = Math.abs(t.x - first.screenX);
        let difY = Math.abs(t.y - first.screenY);
        let difT = (now - t.time);

        if(t.type == "touchstart" && difT < 300 && difX < 30 * window.devicePixelRatio && difY < 30 * window.devicePixelRatio ){
            type = "click";
            EVENTS_Class.Touch.history.push({'type':event.type,'x':first.screenX,'y':first.screenY,'time':now});
        }

    }
    
    while(EVENTS_Class.Touch.history.length > 4){
        EVENTS_Class.Touch.history.shift();
    }

    if(type == "click"){
        whichbtn = EVENTS_Class.Touch.prevbtn;
    }

    var dif = 999;
    EVENTS_Class.Touch.preveventtime = now;

    cnt = EVENTS_Class.Touch.eventsList.length;
    if(type == "click"){
        if(cnt > 1){
            let o = EVENTS_Class.Touch.eventsList[cnt-1];
            let difX = Math.abs(o.x - first.screenX);
            let difY = Math.abs(o.y - first.screenY);
            let difT = (EVENTS_Class.Touch.preveventtime - o.time);

            if(o.type=="click" && difX < 30 * window.devicePixelRatio && difY < 30 * window.devicePixelRatio &&  difT < 300 ){
                type = "dblclick";
                EVENTS_Class.previousMouseDownEvent;
            }
        }
        EVENTS_Class.Touch.eventsList.push({'type':type,'x':first.screenX,'y':first.screenY,'time':now});
    }

    while(EVENTS_Class.Touch.eventsList.length > 4){
        EVENTS_Class.Touch.eventsList.shift();
    }

    EVENTS_Class.Touch.prevtouch = event.type;
    EVENTS_Class.Touch.prevbtn = whichbtn;
    
    if (EVENTS_Class.debug){
        console.log('touch type',type);
        console.log('event.type',event.type);
    }
    
    //~ if (type != 'mousemove'){
    //~ EVENTS_Class.StopEvent(event);
    //~ }
    
    if(type == "click" || type == "dblclick" || type == 'mouseup'){
        let simulatedEvent = EVENTS_Class.createMouseEvent("mouseup" , first.screenX , first.screenY , first.clientX , first.clientY , false , false , false , false , whichbtn , btnFlags , relatedTarget);
        if (EVENTS_Class.debug){
            console.log('simulate mouseup');
        }
        first.target.dispatchEvent(simulatedEvent);
        //~ document.dispatchEvent(simulatedEvent);
        
        // the touch moved (can be a scroll or a drag) we don't want the normal behavior of sending click event because
        // this will lead to unwanted trig of click event when scrolling but if we do wnat the trig of mouseup event to trig the end handler of dragging
        // mouseup ->  end of drag
        // click -> all our mouse event
        if (EVENTS_Class.Touch.has_moved){
            return false;
        }
        
        
        let clickSimulatedEvent = EVENTS_Class.createMouseEvent("click" , first.screenX , first.screenY , first.clientX , first.clientY , false , false , false , false , whichbtn , btnFlags , relatedTarget);
        if (EVENTS_Class.debug){
            console.log('simulate click');
            console.log(first.target);
        }
        first.target.dispatchEvent(clickSimulatedEvent);
        //~ document.dispatchEvent(clickSimulatedEvent);
        first.target.focus();
    }

    if(type == "mousedown"){
        EVENTS_Class.Touch.has_moved = false;
        let simulatedEvent = EVENTS_Class.createMouseEvent("mouseover" , first.screenX , first.screenY , first.clientX , first.clientY , false , false , false , false , whichbtn , btnFlags , relatedTarget);
        if (EVENTS_Class.debug){
            console.log('simulate mouseover');
        }
        first.target.dispatchEvent(simulatedEvent);
        //~ document.dispatchEvent(simulatedEvent);
        
        let simulatedEventMousedown = EVENTS_Class.createMouseEvent("mousedown" , first.screenX , first.screenY , first.clientX , first.clientY , false , false , false , false , whichbtn , btnFlags , relatedTarget);
        if (EVENTS_Class.debug){
            console.log('simulate mousedown');
        }
        first.target.dispatchEvent(simulatedEventMousedown);
        //~ document.dispatchEvent(simulatedEventMousedown);
        // simulate mousedown
        
    }
   
    if (type == 'mousemove'){
        //~ console.log('MOVED');
        if (longPress){
            EVENTS_Class._InitDrag(EVENTS_Class.currentMouseDownEvent.target);
            EVENTS_Class.Touch.has_moved = true;
            
            //~ overElem.style['touch-action'] = 'none';
            //~ console.log("overElem.style['touch-action']", overElem.style['touch-action']);
            // disable scroll when dragging an item
        }
        
        if (EVENTS_Class.Touch.has_moved){
            //~ EVENTS_Class.StopEvent(event);
            //~ overElem.setAttribute('style', 'touch-action: none;');
            //~ overElem.parentElement.setAttribute('style', 'touch-action: none;');
            /* 
             * For the move and the drag.
             * On Mobile, there is a passive mode on the event that ease the scroll
             * Need to stop the touch event here for disabling the touch
             */
            if(GENERICS_Class.IsFilledArray(EVENTS_Class._moveList)){
                event.preventDefault();
                //~ EVENTS_Class.StopEvent(event);
                //~ if (EVENTS_Class.Touch.mousedownElem == first.target)
                //~ let difT = (EVENTS_Class.Touch.mousedownElem.time - o.time);
                //~ if (difT > 1000){
                    //~ return;
                //~ }
                //~ console.log('moved');
                
                
                //~ event.target.style['touch-action'] = 'none';
            }
            let simulatedEvent = EVENTS_Class.createMouseEvent("mousemove" , first.screenX , first.screenY , first.clientX , first.clientY , false , false , false , false , whichbtn , btnFlags , relatedTarget);
            if (EVENTS_Class.debug){
                console.log('simulate mousemove');
            }
            first.target.dispatchEvent(simulatedEvent);
            //~ document.dispatchEvent(simulatedEvent);
        } else {
            //~ $_e.StopEvent(event);
            //~ overElem.style['touch-action'] = null;
            //~ console.log("overElem.style['touch-action']", overElem.style['touch-action']);
            //~ overElem.parentElement.removeAttribute('style');
            //~ overElem.parentElement.style['touch-action'] = 'initial';
        }
    }
    
    //~ if (type == 'mouseup'){
        //~ let simulatedEvent = EVENTS_Class.createMouseEvent("mouseup" , first.screenX , first.screenY , first.clientX , first.clientY , false , false , false , false , whichbtn , btnFlags , relatedTarget);
        //~ if (EVENTS_Class.debug){
            //~ console.log('simulate mouseup');
        //~ }
        //~ first.target.dispatchEvent(simulatedEvent);
    //~ }

    if(type == "mouseup" || type=="click" || type=="dblclick"){
        mousedownElem = null;
        prevOverElem = null;
        //~ EVENTS_Class.StopEvent(event);
    }
    
    //~ if (event.type == 'touchend'){
        //~ EVENTS_Class.StopEvent(event);
        //~ event.cancelBubble = true;
        //~ event.returnValue = false;
        //~ return false;
    //~ } 

    //~ if (type == "click"){
        
    //~ }else{
        //~ let simulatedEvent = EVENTS_Class.createMouseEvent(type , first.screenX , first.screenY , first.clientX , first.clientY , false , false , false , false , whichbtn , btnFlags , relatedTarget);
        //~ if (EVENTS_Class.debug){
            //~ console.log('simulate '+type);
        //~ }
        //~ first.target.dispatchEvent(simulatedEvent);
        
    //~ }

    //~ if(STOPME){
        //~ STOPME = false;
    //~ }
    
    //~ let mouseEvent = EVENTS_Class.createMouseEvent(type,first.screenX,first.screenY,first.clientX,first.clientY,false,false,false,false,whichbtn,btnFlags,relatedTarget);
    //~ first.target.dispatchEvent(mouseEvent);
    //~ if (type == 'mouseup'){
        //~ let mouseEvent = EVENTS_Class.createMouseEvent('click',first.screenX,first.screenY,first.clientX,first.clientY,false,false,false,false,whichbtn,btnFlags,relatedTarget);
        //~ first.target.dispatchEvent(mouseEvent);
    //~ }
    
    //~ EVENTS_Class.StopEvent(event);

    //~ event.cancelBubble = true;
    //~ event.returnValue = false;

    //~ return false;
};

EVENTS_Class.createMouseEvent = function(type , sX, sY , cX , cY , cK , sK , aK , mK , btnValue , btnFlags , relatedTarget, detail={}){
    return new MouseEvent(type,{
        'screenX':sX,
        'screenY':sY,
        'clientX':cX,
        'clientY':cY,
        'ctrlKey':cK,
        'shiftKey':sK,
        'altKey':aK,
        'metaKey':mK,
        'button':btnValue,
        'buttons':btnFlags,
        'relatedTarget':relatedTarget,
        'detail': detail,
        'bubbles': true,
        'cancelable': true,
    });
};

/*
 * SHORTCUT FUNCTION 
 * All module use those functions to manage their events
 */
 
/* ADD EVENT */
EVENTS_Class.AddEventClick = function(domElement, callback, useCapture,timed=false){
    EVENTS_Class.AddEvent(domElement, EVENTS_Class.EVENT_CLICK, callback, useCapture,timed);
};
EVENTS_Class.AddEventDblClick = function(domElement, callback, useCapture,timed=false){
    EVENTS_Class.AddEvent(domElement, EVENTS_Class.EVENT_DOUBLECLICK, callback, useCapture,timed);
};
EVENTS_Class.AddEventKey = function(domElement, callback, useCapture,timed=false){
    EVENTS_Class.AddEvent(domElement, EVENTS_Class.EVENT_KEYUP, callback, useCapture,timed);
};
EVENTS_Class.AddEventClickOutside = function(domElement, callback, useCapture,timed=false){
    EVENTS_Class.AddEvent(domElement, EVENTS_Class.EVENT_MOUSEDOWN_OUTSIDE, callback, useCapture,timed);
};

/* REMOVE EVENT */
EVENTS_Class.RemoveEventClick = function(domElement, callback){
    EVENTS_Class.RemoveEvent(domElement, EVENTS_Class.EVENT_CLICK, callback);
};
EVENTS_Class.RemoveEventDblClick = function(domElement, callback){
    EVENTS_Class.RemoveEvent(domElement, EVENTS_Class.EVENT_DOUBLECLICK, callback);
};
EVENTS_Class.RemoveEventKey = function(domElement, callback){
    EVENTS_Class.RemoveEvent(domElement, EVENTS_Class.EVENT_KEYUP, callback);
};
EVENTS_Class.RemoveEventClickOutside = function(domElement, callback){
    EVENTS_Class.RemoveEvent(domElement, EVENTS_Class.EVENT_MOUSEDOWN_OUTSIDE, callback);
};

/* SEND EVENT */
/* DO NOT USED FROM ANOTHER EVENT ! NESTED EVENT SYNDROME WILL OCCURED WITH dispatchEvent */
EVENTS_Class.SendEventClick = function(domElement, data, bubbles, cancelable){
    EVENTS_Class.SendEvent(domElement, EVENTS_Class.EVENT_CLICK, data, bubbles, cancelable);
};
EVENTS_Class.SendEventDblClick = function(domElement, data, bubbles, cancelable){
    EVENTS_Class.SendEvent(domElement, EVENTS_Class.EVENT_DOUBLECLICK, data, bubbles, cancelable);
};
EVENTS_Class.SendEventKey = function(domElement, data, bubbles, cancelable){
    EVENTS_Class.SendEvent(domElement, EVENTS_Class.EVENT_KEYUP, data, bubbles, cancelable);
};
EVENTS_Class.SendEventClickOutside = function(domElement, data, bubbles, cancelable){
    EVENTS_Class.SendEvent(domElement, EVENTS_Class.EVENT_MOUSEUP_OUTSIDE, data, bubbles, cancelable);
};
/*jshint esversion: 6 */
var GENERICS_Class = function(){
    this._eventHandlers = {};
};
GENERICS_Class.prototype.constructor = GENERICS_Class;
//~ class GENERICS_Class{
    //~ constructor() {
        //~ this._eventHandlers = {};
    //~ }
//~ }

GENERICS_Class.debug = false;
GENERICS_Class.uniqueId = 0;

GENERICS_Class.CopyObject = function(a,b){
    let keys = Object.keys(a);
    for(let k = 0 ; k < keys.length ; k++){
        b[keys[k]] = a[keys[k]];
    }
};

GENERICS_Class.GetUniqueId = function(){
    return GENERICS_Class.uniqueId++;
};

GENERICS_Class.IsObject = function(a){
    if(!a){
        return false;
    }
    return typeof(a) == 'object';
};

GENERICS_Class.IsEmpty = function(a){
    if(!a) return true;
    if(GENERICS_Class.IsArray(a) && a.length == 0) return true;
    if(GENERICS_Class.IsObject(a) && !GENERICS_Class.IsFilledObject(a) ) return true;

    return false;
};

GENERICS_Class.IsDomObject = function(a){
    if(!a){
        return false;
    }
    if(typeof(a) == 'object'){
        return a.nodeType?true:false;
    }

    return false;
};

GENERICS_Class.IsFormdata = function(a){
    return Object.prototype.toString.apply(a) === '[object FormData]';
};

GENERICS_Class.IsString = function(a){
    return typeof(a) == 'string';
};

GENERICS_Class.IsFunction = function(a){
    let t = typeof(a);
    return t == 'function';
};

GENERICS_Class.IsProperty = function(a){
    return (typeof(a) != "function" && a !== null && a !== undefined);
};

GENERICS_Class.IsArray = function(a){
    return Object.prototype.toString.apply(a) === '[object Array]';
};

GENERICS_Class.IsEvent = function(a){
    return Object.prototype.toString.apply(a).indexOf('Event]') > 0;
};

GENERICS_Class.IsFilledArray = function(a){
    if(Object.prototype.toString.apply(a) === '[object Array]'){
        return a.length;
    }
    return false;
};

GENERICS_Class.IsFilledObject = function(a){
    if(GENERICS_Class.IsObject(a)){
        return Object.keys(a).length;
    }
    return false;
};

GENERICS_Class.IsUndefined = function(a){
    return a === undefined;
};

GENERICS_Class.IsNumeric = function(a){
    return !isNaN(a);
};
//only for page.js
GENERICS_Class.IsCssMeasure = function(str){
    let f = parseFloat(str);
    if(isNaN(f)){
        for(let i = 0 ; i < str.length ; i++){
            let o = str.charCodeAt(i);
            if(o >= 48 && o <= 57 || o == 46){
                str = str.substr(i,str.len);
                break;
            }
        }
        if(str==''){
            return false;
        }
        f = parseFloat(str);
        if(isNaN(f)){
            return false;
        }
    }
    return true;
};

GENERICS_Class.GetType = function(a){
    let str = Object.prototype.toString.apply(a).split(' ');
    return str[1].substr(0,str[1].length-1);
};

GENERICS_Class.MergeObjects = function(a,b){
    let result = {};
    if(!a){
        a = {};
    }

    if(!b){
        b = {};
    }
    let keys = Object.keys(a);

    for(let i = 0 ; i < keys.length ; i++){
        result[keys[i]] = a[keys[i]];
    }

    keys = Object.keys(b);

    for(let i = 0 ; i < keys.length ; i++){
        result[keys[i]] = b[keys[i]];
    }

    return result;
};

//----------------------------------------------------------------------------------
// STRINGS
var STRINGS_Class = function(){
    this._eventHandlers = {};
};
STRINGS_Class.prototype.constructor = STRINGS_Class;
//~ class STRINGS_Class{
    //~ constructor() {
        //~ this._eventHandlers = {};
    //~ }
//~ }
STRINGS_Class.dom_parser = null;
STRINGS_Class.xml_http = null;

STRINGS_Class.CompleteString = function(str , replace_array){
    if(replace_array){
        if(!GENERICS_Class.IsArray(replace_array)){
            replace_array = [replace_array];
        }
        if(GENERICS_Class.IsFilledArray(replace_array)){
            for(let i=0; i<replace_array.length; i++){
                str = str.replace('$'+i,replace_array[i]);
            }
        }
    }

    return str;
};

STRINGS_Class.EscapeHtml = function(text){
  var map = {
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#039;'
  };

  return text.replace(/[<>"']/g, function(m) { return map[m]; });
};

String.prototype.hashCode = function() {
    var hash = 0, i, chr;
    if (this.length === 0) return hash;
    for (i = 0; i < this.length; i++) {
      chr = this.charCodeAt(i);
      hash = ((hash << 5) - hash) + chr;
      hash |= 0; // Convert to 32bit integer
    }
    return hash;
  };
//--------------------------------------------------------------------------
// MATH
//CLASSE TOTALEMENT INUTILSEE NUL PART POUR LE MOMENT !!! Wtf ?
var MATH_Class = function(){
    this._eventHandlers = {};
};
MATH_Class.prototype.constructor = MATH_Class;
//~ class MATH_Class{
    //~ constructor() {
        //~ this._eventHandlers = {};
    //~ }
//~ }

MATH_Class.ExtractFloat = function(str){
    let f = parseFloat(str);
    if(isNaN(f)){
        for(let i = 0 ; i < str.length ; i++){
            let o = str.charCodeAt(i);
            if(o >= 48 && o <= 57 || o == 46){
                str = str.substr(i,str.len);
                break;
            }
        }
        f = parseFloat(str);
        if(isNaN(f)){
            return 0.0;
        }
    }
    return f;
};

MATH_Class.ExtractInt = function(str){
    let f = parseInt(str);
    if(isNaN(f)){
        for(let i = 0 ; i < str.length ; i++){
            let o = str.charCodeAt(i);
            if(o >= 48 && o <= 57){
                str = str.substr(i,str.len);
                break;
            }
        }
        f = parseInt(str);
        if(isNaN(f)){
            return 0;
        }
    }
    return f;
};

MATH_Class.IsRound = function(a){
    if(isNaN(a)){
        return false;
    }else{
        return Math.round(a) == a;
    }
    return false;
};

// nombre impair
MATH_Class.IsOdd = function(a){
    if(isNaN(a)){
        return NaN;
    }else{
        return a%2>0;
    }
};

// nombre pair
MATH_Class.IsEven = function(a){
    if(isNaN(a)){
        return NaN;
    }else{
        return a%2 === 0;
    }
};

MATH_Class.RoundFloat = function(fl,rn){
    if(!rn){
        rn = 8;
    }
    rn = Math.pow(10,rn);
    return Math.round(fl*rn)/rn;
};
/*
function Storage_access_check(){
    // if (!!document.hasStorageAccess) {
        
    //     // setTimeout(function(){
    //         document.hasStorageAccess().then(result => {
    //             if (!result) {
    //                 console.log("nostaorageaccess");
    //                 // Show the button and tie to the click.
    //                 var requestStorageAccessButton = document.getElementById('requestStorageAccessButton');
    //                 if(requestStorageAccessButton==undefined || requestStorageAccessButton==null){
    //                     requestStorageAccessButton = DOM_Class.CreateElement('BUTTON',{'class':'artiviewer_markerdel', 'id':'artrequestStorageAccessButton'},'Allow local storage access');
    //                     let artihome_exist=document.getElementById('artihome_container');
    //                     if (artihome_exist!=undefined) {
    //                         artihome_exist.appendChild(requestStorageAccessButton);
    //                     }else{
    //                         document.getElementById('lemain').appendChild(requestStorageAccessButton);
    //                     }
    //                 }
    //                 requestStorageAccessButton.style.display = "block";
    //                 requestStorageAccessButton.addEventListener("click", event => {
        
    //                     // On UI event, consume the event by requesting access.
    //                     document.requestStorageAccess().then(result => {
        
    //                         // Finally, we are allowed! Reload to get the cookie.
    //                         window.location.reload();
    //                     }).catch(err => {
        
    //                         // notgood
    //                     });
    //                 });
    //             }else{
    //                 console.log('storageaccessok');
    //             }
    //         }).catch(err => console.error(err));
        // },500);
    // }
    var is_safari = navigator.userAgent.indexOf("Safari") > -1;
    var is_chrome = navigator.userAgent.indexOf("Chrome") > -1;
    if ((!is_chrome) && (is_safari)){
        // if (document.hasStorageAccess()){
        //     console.log('hasStorageAccess', "granted");
        // } else {
        //     var storageModal = new UI_Window({'modal': true, 'disableBackgroundClick': true, 'nodrag': true, 'disableKeydownClose': true});
        //     var btn = DOM_Class.CreateElement('BUTTON',{ 'id':'artrequestStorageAccessButton'},'Storage Access Request');
        //     storageModal.SetContent(btn);
        //     storageModal.SetParent(document.body, 0.5, 0.5);
        //     $_e.AddEventClick(btn, function(){
        //         document.requestStorageAccess().then(
        //             function() {
        //                 console.log("requestStorageAccess", "granted");
        //                 storageModal.Remove();
        //             },
        //             function() {
        //                 console.log("requestStorageAccess", "rejected");
        //                 top.window.location.reload();
        //             }
        //         );
        //     });

            
            // var butnewtab = document.getElementById('artihome_safari_open');
            // if(butnewtab==undefined || butnewtab==null){
            //     butnewtab = DOM_Class.CreateElement('BUTTON',{ 'id':'artrequestStorageAccessButton'},'Open in new tab');
            //     let artihome_exist=document.getElementById('artihome_container');
            //     if (artihome_exist!=undefined) {
            //         artihome_exist.appendChild(requestStorageAccessButton);
            //     }else{
            //         document.getElementById('lemain').appendChild(butnewtab);
            //     }
            // }
            // document.getElementById('artihome_safari_msg').style.display = "block";
            // butnewtab.style.display = "block";
            // butnewtab.addEventListener("click", event => {
            //     window.open(document.location,'_blank');
            // });
            // console.log('hasStorageAccess', "rejected");
            // document.requestStorageAccess().then(
                // function() {
                    // console.log("requestStorageAccess", "granted");
                // },
                // function() {
                    // console.log("requestStorageAccess", "rejected");
                // }
            // );
        // }
        var butnewtab = document.getElementById('artihome_safari_open');
        if(butnewtab==undefined || butnewtab==null){
            butnewtab = DOM_Class.CreateElement('BUTTON',{ 'id':'artrequestStorageAccessButton'},'Open in new tab');
            let artihome_exist=document.getElementById('artihome_container');
            if (artihome_exist!=undefined) {
                artihome_exist.appendChild(requestStorageAccessButton);
            }else{
                document.getElementById('lemain').appendChild(butnewtab);
            }
        }
        document.getElementById('artihome_safari_msg').style.display = "block";
        butnewtab.style.display = "block";
        butnewtab.addEventListener("click", event => {
            window.open(document.location,'_blank');
        });
    }
}
*/
//AUTOGRAPH SECTION
var qTw='nope';
var qTwA='nope';
var qtwAl=[];
var qtwAlc=[];

function dlLinkScrambler (mode){
    links = document.querySelectorAll('[data-scram]');
    if (mode=="kill"){
        for (let i = 0; i < links.length; i++){
            let link = links[i];
            link.href="#connection=true";
            link.classList.add("pleaseconnect");
            link.innerHTML="Please sign in to access this link.";
        }
    }else{
        for (let i = 0; i < links.length; i++){
            let link = links[i];
            let command=link.dataset.scram;
            let hash=link.href.hashCode();
            if (qtwAl[hash]==undefined){
                qtwAl[hash]=link.href;
            }
            link.href=hash;
            link.addEventListener('click', function (e) {e.preventDefault();});
            if (mode=="auto"){
                if (qtwAlc[hash]==undefined){
                    qtwAlc[hash]=command;
                }
                $_e.AddEventClick(link,qtSender);
            }else{
                $_e.AddEventClick(link,extOpener);
            }
            
        }
    }
}

function qtSender(event){
    let hash=event.target.href;
    hash=hash.split('/').pop();
    if (qtwAlc[hash]!=undefined && qtwAl[hash]!=undefined){
        let json='{\"command\":\"'+qtwAlc[hash]+'\",\"params\":{\"url\":\"'+qtwAl[hash]+'\"}}';
        if (qTwA!=undefined && qTwA!='nope'){
            qTwA.entryPoint(json,false);
        }else{
            console.log('qTwA not connected'); 
        }
    }else{
        console.log('hash part not found');
    }
   
}

function extOpener(event){
    let hash=event.target.href;
    hash=hash.split('/').pop();
    if (qtwAl[hash]!=undefined){
        window.open(qtwAl[hash],'_blank').focus();
    }else{
        console.log('hash part not found');
    }
    
}

function desactiveContextMenu(elem){
    elem.oncontextmenu = function(){return false;};
    if (elem.children.length > 0){
        for (let index = 0; index < elem.children.length; index++) {
            desactiveContextMenu(elem.children[index]);
        }
    }

}
//Spade 3 History script to manage ajax calls from history move
var tablehash=new Array('');
var timer_modal = false;
var timer_modal_is_hide = true;

// handle the hash change event
function detect_hash(){
    let hash = document.location;
    hash=hash.toString();
    hash=hash.split('#');

    if (hash[1] !== "" && hash[1] !== undefined) {
        // full hash compare
        let full_hash = decodeURI(hash[1]);
        let previous_hash = '';
        if(tablehash.length){
            previous_hash = tablehash[tablehash.length-1];
        }
        if(previous_hash != full_hash){
            // not the same need to do something
            // split by � to handle multiple ajax call in one hash
            // the symbol � is not accepted by javascript, so we use the encodeURI replacement
            // if we add decodeURI on the hash, it will break this code
            let hashArray = full_hash.split("%C2%A4");
            // get the first part of the hash
            let new_hash = hashArray.shift();
            // console.log(new_hash);
            // handle the first part of the hash and pass the rest of the call
            // when first part done will pass the next hash in array
            //redirect check
            let recheck=new_hash.split("|")[0];
            if (recheck!='artiredirect'){
                set_hash(new_hash,hashArray);
            }
        }
    }else{
        //if we're back to start
        if (tablehash.length>1){
            set_hash('');
        }
    }
}


// handle the hash with multiple ajax call to chain
//~ function multiple_hash(hashArray){
    //~ let new_hash = hashArray.shift();
    //~ let previous_hash = '';
    //~ if(tablehash.length){
        //~ previous_hash = tablehash[tablehash.length-1];
    //~ }
    //~ if(previous_hash.includes(new_hash) === false){
        //~ set_hash(new_hash,hashArray);
    //~ } else {
        //~ if (hashArray.length > 0) multiple_hash(hashArray);
    //~ }
//~ }

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// new_hash is the current one
// hashArray contains the next call to do
function set_hash(new_hash,hashArray=false){
    //close burger
    if (UI_Burger!=undefined){
        UI_Burger.Close();
    }
    var modal = false;
    let previous_hash = '';
    if(tablehash.length){
        previous_hash = tablehash[tablehash.length-1];
    }
    // back to the home
    if (new_hash == ''){
        document.location = document.location.toString().split('#')[0].split('?')[0];
        return;
    }
    // if the previous hash contains the new hash, that mean that this part of the hash is already loaded
    // nothing more to do here except (if there is one) loading the next part of the hash 
    //~ console.log(new_hash);
    //~ console.log(hashArray);
    //~ console.log(previous_hash.includes(new_hash));
    if(previous_hash.includes(new_hash) === false || hashArray.length==0){  //si pas de hasharray il n'y a plus rien � splitter il faut reload le module, cas du #news
        //Parse and send ajax call
        let params=new_hash.split('-');
        // hash format : moduleData-lang-container
        let settings = {};
        settings.url = document.baseURI.split('?')[0];
        if (params[2] !== "" && params[2] !== undefined) {
            settings.dom_target=params[2];
        }else{
            settings.dom_target='lemain';
        }
        settings.data = {};
        // always needed
        // without will try to load the full site not only the wanted module
        settings.data.core_action = 'core_mono';
        let module_name='';
        params[0] = params[0].replace('<>', '-');
        if (params[0].includes('|')){
            // if it's a custom link (with multiple parameters in it)
            // need to get all the parameters and populate them in the settings data.
            let module = params[0].split('|');
            //~ module_name = module[0].split('/')[0];
            module_name = (module[0].endsWith('=')) ? module[0].slice(0,-1) : module[0];
            module.splice(0,1);
            module.forEach( (str) => {
                let tt = str.split('=');
                settings.data[tt[0]] = tt[1];
            });
            // don't forget to add the module name (with no parameters in this case)
            // without that the module will not load (security ?)
            settings.data[module_name]='';
        } else {
            let custom = false;
            let module=params[0].split('=');
            module_name=module[0];
            let module_param=module[1];
            settings.data[module_name]=module_param;
            // and a switch of language
        }
        if (params[1] !== "" && params[1] !== undefined) {
            settings.data.language = params[1];
        }
        
        // we have a request for an indexable module
        //~ if (module_name !== "" && module_name !== undefined) {
            
            
        //~ if (settings.url.replace(CONSTANTS.base_url, '').split('/').length == 1){
            settings.success = function(res){
                if (window.anim){
                    detect_anime(res);
                }
                // if (!timer_modal_is_hide){
                //     timer_modal.Hide();
                //     timer_modal_is_hide = true;
                // }
                
                // if we have hashArray, that mean that we are doing a multiple call, need to exec the next
                if (hashArray && hashArray.length > 0) {
                    new_hash = hashArray.shift();
                    set_hash(new_hash,hashArray);
                } else {
                    // add the full hash to the list
                    // can't use new_hash because it can be just a part of the full hash (when in a multiple call)
                    tablehash.push(document.location.toString().split('#')[1]);
                }
            };
            
            // if (!timer_modal){
            //     timer_modal =  UI_Class.AddWindow(null, {'modal': true, 'nodrag': true, 'class':'timer_requete', 'disableBackgroundClick': true});
            //     timer_modal.SetParent(document.body, 0.5, 0.5);
            //     timer_modal_is_hide = false;
            // } else {
            //     if (timer_modal_is_hide) {
            //         timer_modal.Show();
            //         timer_modal_is_hide = false;
            //     }
            // }
        //~ }
        $_a.send(settings,10);
        window.scrollTo(0, 0);
        //~ }
    } else if (hashArray) {
        //~ console.log(hashArray);
        new_hash = hashArray.shift();
        set_hash(new_hash,hashArray);
    }
}
//la m�me chose que set-hash mais sans toucher � l'historique
// same thing than set-hash but without modify history
function jump_hash(new_hash){

    let params=new_hash.split('-');
    // hash format : moduleData-lang-container
    let settings = {};
    settings.url = document.baseURI.split('?')[0];
    if (params[2] !== "" && params[2] !== undefined) {
        settings.dom_target=params[2];
    }else{
        settings.dom_target='lemain';
    }
    settings.data = {};
    // always needed
    // without will try to load the full site not only the wanted module
    settings.data.core_action = 'core_mono';
    let module_name='';
    params[0] = params[0].replace('<>', '-');
    if (params[0].includes('|')){
        // if it's a custom link (with multiple parameters in it)
        // need to get all the parameters and populate them in the settings data.
        let module = params[0].split('|');
        //~ module_name = module[0].split('/')[0];
        module_name = (module[0].endsWith('=')) ? module[0].slice(0,-1) : module[0];
        module.splice(0,1);
        module.forEach( (str) => {
            let tt = str.split('=');
            settings.data[tt[0]] = tt[1];
        });
        // don't forget to add the module name (with no parameters in this case)
        // without that the module will not load (security ?)
        settings.data[module_name]='';
    } else {
        let custom = false;
        let module=params[0].split('=');
        module_name=module[0];
        let module_param=module[1];
        settings.data[module_name]=module_param;
        // and a switch of language
    }
    if (params[1] !== "" && params[1] !== undefined) {
        settings.data.language = params[1];
    }
    
    // we have a request for an indexable module
    //~ if (module_name !== "" && module_name !== undefined) {
        
        
    //~ if (settings.url.replace(CONSTANTS.base_url, '').split('/').length == 1){
        settings.success = function(res){
            if (window.anim){
                detect_anime(res);
            }
            if (!timer_modal_is_hide){
                timer_modal.Hide();
                timer_modal_is_hide = true;
            }
            
            // if we have hashArray, that mean that we are doing a multiple call, need to exec the next
            // if (hashArray && hashArray.length > 0) {
            //     new_hash = hashArray.shift();
            //     set_hash(new_hash,hashArray);
            // } else {
            //     // add the full hash to the list
            //     // can't use new_hash because it can be just a part of the full hash (when in a multiple call)
            //     tablehash.push(document.location.toString().split('#')[1]);
            // }
        };
        
        if (!timer_modal){
            timer_modal =  UI_Class.AddWindow(null, {'modal': true, 'nodrag': true, 'class':'timer_requete', 'disableBackgroundClick': true});
            timer_modal.SetParent(document.body, 0.5, 0.5);
            timer_modal_is_hide = false;
        } else {
            if (timer_modal_is_hide) {
                timer_modal.Show();
                timer_modal_is_hide = false;
            }
        }
    //~ }
    $_a.send(settings,10);
    window.scrollTo(0, 0);
    //~ console.log(new_hash);
    // var modal = false;
    // //Parse and send ajax call
    // let params=new_hash.split('-');
    // let settings = {};
    // settings.url = document.baseURI;
    // if (params[2] !== "" && params[2] !== undefined) {
    //     settings.dom_target=params[2];
    // }else{
    //     settings.dom_target='lemain';
    // }
    // let module=params[0].split('=');
    // let module_name=module[0];
    // let module_param=module[1];
    // settings.data = {};
    // we have a request for an indexable module
    // if (module_name !== "" && module_name !== undefined) {
        // settings.data[module_name]=module_param;
        // settings.data.core_action = 'core_mono';
        // // and a switch of language
        // if (params[1] !== "" && params[1] !== undefined) {
        //     settings.data.language = params[1];
        // }
        // if (settings.url.replace(CONSTANTS.base_url, '').split('/').length == 1){
        //     settings.success = function(res){
        //         if (window.anim){
        //             detect_anime(res);
        //         }
        //         if (!timer_modal_is_hide){
        //             timer_modal.Hide();
        //             timer_modal_is_hide = true;
        //         }
        //     };
            
        //     if (!timer_modal){
        //         timer_modal =  UI_Class.AddWindow(null, {'modal': true, 'nodrag': true, 'class':'timer_requete', 'disableBackgroundClick': true});
        //         timer_modal.SetParent(document.body, 0.5, 0.5);
        //         timer_modal_is_hide = false;
        //     } else {
        //         if (timer_modal_is_hide) {
        //             timer_modal.Show();
        //             timer_modal_is_hide = false;
        //         }
        //     }
        // }
        // $_a.send(settings,10);
        // window.scrollTo(0, 0);
    // }
    //}
}

var try_socials=false;
function update_socials(module_name,module_param,language=false,collapse=false){
    let social_container = document.getElementById('socials_public_container');
    if (social_container){
        let settings = {};
        let url = CONSTANTS.base_url+'public/socials/index.php';
        settings.url = url;
        //settings.dom_target='';
        settings.data = {};
        if (language) {
            settings.data.language = language;
        }
        if (social_container.children.length == 3 || collapse){
            settings.data.social_collapse = true;
        }
        //~ settings.data['core_insert']=false;
        settings.skip_container = true;
        settings.data.module_name = module_name;
        settings.data.module_param = module_param;

        settings.success = function(res, e){
            if (!res.includes('Error')) {
                let container = document.getElementById('socials_public_container');
                container.innerHTML=res;
                if (container.children.length == 3){
                    Socials.init(1);
                }
            }
        };
        try_socials=false;
        $_a.send(settings);
    }else{
        if (try_socials==false){
            try_socials=true;
            //~ console.log(module_name+module_param+language);
            setTimeout(function(){update_socials(module_name,module_param,language);},500);
        }
    }
}
//complexe UI objects or method that are not related to only ONE dom element (see dom.js for that).
var UI_Class = function(){};
UI_Class.prototype.constructor = UI_Class;
//~ class UI_Class{
    //~ constructor() {
        //~ this._eventHandlers = {};
    //~ }
//~ }
UI_Class.lastZIndex;
UI_Class.img = false;

// params : css class of the buttons
// buttons must have data-id_target that points to the corresponding tinyMce field
UI_Class.CopyPasteTinymce = function(copyClass, pasteClass) {
    var tinyContent;
    var btnsCopy = document.getElementsByClassName(copyClass);
    var btnsPaste = document.getElementsByClassName(pasteClass);
    for (let i = 0; i < btnsCopy.length; i++) {
        btnsPaste[i].style.display = 'none';
        btnsCopy[i].addEventListener('click', function(e){
            var id = e.target.dataset.id_target;
            var elem = document.getElementById(id);
            tinyContent = elem._tinymce.getContent();
            curLang = elem.name.split('[')[3].replace(']', '');
            for (let i = 0; i < btnsPaste.length; i++) {
                btnsPaste[i].style.display = 'inline-block';
                if (!$_e.HasEvent(btnsPaste[i], EVENTS_Class.EVENT_CLICK)){
                    EVENTS_Class.AddEvent(btnsPaste[i], EVENTS_Class.EVENT_CLICK, function(e){
                        var id = e.target.dataset.id_target;
                        var elem = document.getElementById(id);
                        let domContent = DOM_Class.StringToDom(tinyContent, true);
                        UI_Class.img = false;
                        for (let j = 0; j < domContent.length; j++){
                            UI_Class.RecurseGetImg(domContent[j]);
                        }
                        if (UI_Class.img){
                            let old_field_identifier = UI_Class.img.dataset.field_identifier;
                            let new_field_identifier = old_field_identifier.replace(curLang, elem.name.split('[')[3].replace(']', ''));
                            let re = new RegExp(old_field_identifier, 'g');
                            tinyContent = tinyContent.replace(re,  new_field_identifier);
                            let settings = {};
                            settings.url = document.baseURI.split('?')[0].split('#')[0] + 'media/index.php';
                            settings.skip_container = true;
                            settings.dom_target = '';
                            settings.data = {
                                'media_action': 'media_copy_tinymce',
                                'src_field_identifier': old_field_identifier,
                                'dst_field_identifier': new_field_identifier
                            };
                            settings.success = function(){
                                elem._tinymce.focus();
                                elem._tinymce.insertContent(tinyContent);
                            };
                            $_a.send(settings);
                        } else {
                            //~ elem._tinymce.focus();
                            elem._tinymce.insertContent(tinyContent);
                        }
                    });
                }
            }
        });
    }
};

UI_Class.RecurseGetImg = function(domElem){
    if (domElem.tagName == 'IMG' && domElem.dataset.field_identifier){
        UI_Class.img = domElem;
        return;
    } else if (domElem.children){
        for (let k = 0; k < domElem.children.length; k++){
            UI_Class.RecurseGetImg(domElem.children[k]);
        }
    }
};

// params:  cible -> css class of the elements receiving the click 
//          cssClass -> the css class to toggle
//          customFunc -> custom function executed when displaying an elem
//          indicator -> id of the collapse indicator
// the target must have "data-target_id" that points to the element to toggle
UI_Class.ToggleAccordion = function(cible, cssClass, customFunc=false, indicator=false) {
    var elems = document.getElementsByClassName(cible);
    for (let i = 0; i < elems.length; i++) {
        var elem = elems[i];
        let indic = false;
        if (!indicator){
            indic = elem.previousElementSibling;
        } else {
            indic = document.getElementById(indicator);
        }
        if (!$_e.HasEvent(elem, EVENTS_Class.EVENT_CLICK)){
            EVENTS_Class.AddEvent(elem, EVENTS_Class.EVENT_CLICK, onClick);
        }
        if (indic && !$_e.HasEvent(indic, EVENTS_Class.EVENT_CLICK)){
            indic.dataset.cible = '1';
            $_e.AddEvent(indic, EVENTS_Class.EVENT_CLICK, onClick);
        }
    }
    
    function onClick(e){
        let elem = e.target;
        if (elem.dataset.cible){
            elem = elem.nextElementSibling;
        }
        var targ = document.getElementById(elem.dataset.target_id);
        DOM_Class.ToggleClass(targ, cssClass);
        var indicator = elem.previousElementSibling;
        if (!indicator) {
            indicator = document.getElementById(indicator);
        }
        if (indicator){
            if (indicator.textContent.includes('►')) {
                indicator.textContent = '▼';
                if (customFunc){
                    customFunc(e);
                }
            } else {
                indicator.textContent = '►';
            }
        }
    }
};

UI_Class.ChangeImageClass = function(classname){
    var imgs = document.getElementsByClassName(classname);
    var i = 0;
    while(imgs.length > 0) {
        var img = imgs[i];
        let rect = DOM_Class.GetGlobalRect(img);
        var height = DOM_Class.GetGlobalHeight(img);
        var width = DOM_Class.GetGlobalWidth(img);
        if (width >= height) {
            DOM_Class.ToggleClass(img, classname);
            DOM_Class.ToggleClass(img, classname+'_paysage');
        } else {
            DOM_Class.ToggleClass(img, classname);
            DOM_Class.ToggleClass(img, classname+'_portrait');
        }
    }
};

// params :
//      container -> id of the container to refresh
//      params -> parameters for the post
UI_Class.RefreshContainer = function(container, params, pub = true){
    if (!container) {
        return false;
    }
    var settings = {};
    settings.dom_target = container;
    var moduleName = container.split('_');
    moduleName = moduleName[0];

    settings.skip_container = true;

    var url = document.baseURI;
    url = url.split('#');
    url = url[0].split('?');
    url = url[0];
    if (pub) url += 'public/';
    url += moduleName +'/index.php';

    settings.url = url;


    settings.data = {};
    if (params){
        settings.data = params;
    }

    $_a.send(settings);
};

UI_Class.LoadModuleInPage = function(domElem, params){

    let settings={};

    settings.url = CONSTANTS.base_url + 'public/core/index.php';

    settings.dom_target = domElem;

    settings.data = {'core_action': 'core_mono'};
    Object.entries(params).forEach((arr) => {
        settings.data[arr[0]] = arr[1];
    });

    settings.success = function(res){
        if (document.baseURI.includes('page')){
            domElem._overlay.mceEditor.editorManager.execCommand('mceRemoveEditor',true, domElem.id);
            domElem._overlay.EnableTextEditor();
        }
    };
    $_a.send(settings);

};

UI_Class.ShowBigImage = function(evt, newUrl = false){
    let url = document.baseURI;
    if (evt && url.replace(CONSTANTS.base_url, '').split('/').length == 1){
        let targ = evt.target;

        // make container big image
        let big = document.getElementById('ui_container_big_image');
        if (!big){
            big = DOM_Class.CreateElement('DIV', {'class': 'ui_container_big_image', 'id': 'ui_container_big_image'});
            let div = DOM_Class.CreateElement('DIV');
            let img = DOM_Class.CreateElement('IMG', {'class': 'ui_big_image'});
            let croix = DOM_Class.CreateElement('DIV', {'class': 'galerie_close'});
            DOM_Class.AppendContent(div, img);
            DOM_Class.AppendContent(div, croix);
            DOM_Class.AppendContent(big, div);
            DOM_Class.AppendContent(document.body, big);

            $_e.AddEventClick(croix, closeBigImage);
        }
        let img = big.firstElementChild.firstElementChild;
        if (newUrl) img.src = newUrl;
        else img.src = targ.src;

        // make overlay
        let overlay = document.getElementById('ui_overlay_big_image');
        if (!overlay){
            overlay = DOM_Class.CreateElement('DIV', {'class': 'ui_overlay_big_image', 'id': 'ui_overlay_big_image'});
            DOM_Class.AppendContent(document.body, overlay);
        }
        // DOM_Class.ToggleClass(big, 'hide', false);
        // DOM_Class.ToggleClass(overlay, 'hide', false);
        DOM_Class.ToggleClass(big, 'hidden', false);
        DOM_Class.ToggleClass(overlay, 'hidden', false);

        $_e.AddEventClick(overlay, closeBigImage);

        function closeBigImage(evt){
            console.log(evt);
            // DOM_Class.ToggleClass(big, 'hide', true);
            // DOM_Class.ToggleClass(overlay, 'hide', true);
            DOM_Class.ToggleClass(big, 'hidden', true);
            DOM_Class.ToggleClass(overlay, 'hidden', true);
        }
    }
    return;
};

// elemID -> dom id of the dom target
// nbrPx -> number of pixel to scroll before add the css class
// className -> name of the css class to add
UI_Class.ScrollToggleClass = function(elemID, nbrPx, className){
    $_e.AddEvent(window, 'scroll', function(event){
        let elem = document.getElementById(elemID);
        if (elem){
            let py = event.pageY || document.body.scrollTop || window.pageYOffset;
            if (py > nbrPx && !DOM_Class.HasClass(elem, className)){
                DOM_Class.ToggleClass(elem, className, true);
            }
            if (py <= nbrPx && DOM_Class.HasClass(elem, className)){
                DOM_Class.ToggleClass(elem, className, false);
            }
        }
    });
};
// specific for siteLA public, be carefull to don't break it
UI_Class.ScrollTo = function(domID, offset=0){
    let domElem = document.getElementById(domID);
    let rect = DOM_Class.GetGlobalRect(domElem, true);
    
    let top = Math.round(rect.top - 70);
    console.log(top);
    
    window.scrollTo(0, top);
};

UI_Class.getToken = function(evt,fromForm = false){
    //~ $_e.StopEvent(evt);
    //~ let targ = evt.target;
    //~ console.log('get token');
    let form = (fromForm) ? evt.target : evt.target.form;
    //~ let form = evt.target.form;
    let settings = {};
    settings.url = form.action;
    settings.skip_container = true;
    settings.dom_target = '';
    settings.data = {
        'action': 'formgettoken'
    };
    settings.success = function(res){
        if (res){
            //~ console.log(res.trim());
            //~ let form = evt.target.form;
            let id = form.id + '-token';
            let inpHidden = document.getElementById(id);
            if (inpHidden) {
                inpHidden.value = res.trim();
            } else {
                inpHidden = DOM_Class.CreateElement('INPUT', {'id': id,'type': 'hidden', 'name': 'jsToken', 'value': res.trim(),'data-alwaysposted':1});
            }
            DOM_Class.AppendContent(form, inpHidden);
            
            //~ console.log('token added');
            //~ AJAX_Class.setFormSubmitter(evt.target);
            
            $_e.SendEvent(form, 'submit');
        }
    };
    $_a.send(settings);
};

UI_Class.popup = function(lapage,titre,w,h,scroll){ // open a window
    sx = screen.availWidth;
    sy = screen.availHeight;

    if(String(scroll)=="undefined" ) scroll=1;

    if(String(w)!="undefined" && String(h)=="undefined"){
        h = Math.floor(sy * w/100);
        w = Math.floor(sx * w/100);
    }

    if(h<2){ h = sy*h; }
    if(w<2){ w = sx*w; }

    if(h>sy) h=sy-64;
    if(w>sx) w=sx;

    titre = String(titre);
    if(titre=="undefined") titre="_new";

    px = ((sx - w) / 2);
    py = ((sy - (h+64)) / 2);

    params='scrollbars='+scroll+',status=1,resizable=1,width='+w+',height='+h+',screenx='+px+',left='+px+',screeny='+py+',top='+py;
    //titre="";
    open(String(lapage),String(titre),String(params));
    //~ open(String(lapage),String(titre));
    //~ top.opener.window.open('',String(titre));
};

UI_Class.newtab = function(lapage){ //ouvre un nouvel onglet...
    params='_blank';
    window.open(String(lapage),String(params));
};
//------------------------------------------------------------

UI_Class.popupModal = false;
UI_Class.popupSpecial = [];
// start moduleName with public/ to indicate that is a public url (automaticly add public to the url)
UI_Class.openPopupModal = function(evt, moduleName, params, special=false, special_level=1){
    //~ console.log(moduleName);
    //~ console.log(params);
    if (!moduleName) {
        console.log('no moduleName');
        return;
    }
    
    let is_public = false;
    if (moduleName.includes('public/')){
        moduleName = moduleName.replace('public/','');
        is_public = true;
    }
    
    
    if (special !== false){
        if (!UI_Class.popupSpecial[special]){
            UI_Class.popupSpecial.push(special);
            UI_Class.popupSpecial[special] = UI_Class.AddWindow(document.body, {'nodrag': false, 'hidden': true, 'modal': true, 'class': 'ui_window special '+moduleName, 'special':true, 'special_level': special_level});
            UI_Class.popupSpecial[special].domElement.setAttribute('id', 'popup_special_'+special);
            UI_Class.popupSpecial[special]._modalContent.setAttribute('id', 'popup_special_content_'+special);
        } else {
            UI_Class.popupSpecial[special].domElement.setAttribute('class', 'ui_window special hidden '+moduleName);
        }
    } else {
        if (!UI_Class.popupModal){
            UI_Class.popupModal = UI_Class.AddWindow(document.body, {'nodrag': false, 'hidden': true, 'modal': true, 'class': 'ui_window '+moduleName});
            UI_Class.popupModal.domElement.setAttribute('id', 'popup_modal');
            UI_Class.popupModal._modalContent.setAttribute('id', 'popup_modal_content');
        } else {
            UI_Class.popupModal.domElement.setAttribute('class', 'ui_window hidden '+moduleName);
        }
    }
    
    var url = document.baseURI;
    url = url.split('#');
    url = url[0].split('?');
    if (is_public) url = url[0] + 'public/' + moduleName + '/index.php';
    else url = url[0] + moduleName + '/index.php';

    let settings = {};
    settings.url = url;
    settings.dom_target = '';
    settings.skip_container = true;
    settings.container_name = 'popup_modal';
    if (params && GENERICS_Class.IsObject(params)) settings.data = params;
    else settings.data = {};
    settings.success = function(res){
        if (special !== false){
            UI_Class.popupSpecial[special].SetContent(res);
            UI_Class.popupSpecial[special].close = 'x';
            UI_Class.popupSpecial[special].Show();
            setTimeout(function(){DOM_Class.SetAlignment(UI_Class.popupSpecial[special].domElement, 0.5 , 0.5, false, true);},50);
        } else {
            UI_Class.popupModal.SetContent(res);
            UI_Class.popupModal.close = 'x';
            UI_Class.popupModal.Show();
            setTimeout(function(){DOM_Class.SetAlignment(UI_Class.popupModal.domElement, 0.5 , 0.5, false, true);},50);
        }
    };
    $_a.send(settings);
};

//---------------------------------------------
UI_Class.AddWindow = function(parentNode,settings){
    let win = new UI_Window(settings);

    if(parentNode){
        win.SetParent(parentNode);
    }

    return win;
};

UI_Class.modalKeyDownHandler = [];
UI_Class.modalKeyDownHandlerMaxLevel = 1;
UI_Class.modalErr = false;
//---------------------------------------------

UI_Window = function(settings){
    settings = settings || {};

    if(!settings.class) settings.class = 'ui_window';

    this.domElement = DOM_Class.CreateElement('DIV',{'class':settings.class});
    this.domElement._ui_object = this;

    EVENTS_Class.EnableDrag(this.domElement);

    this._modal = false;
    this._modalMask = null; // background div
    this._modalClose = null; // close button
    this._modalContent = DOM_Class.CreateElement('DIV',{'class':'ui_window_content'});
    this.domElement.appendChild(this._modalContent);
    this._special = false;
    this._special_level = 1;

    if(settings.disableBackgroundClick) this._disableBackgroundClick = true;
    // has to be before modal
    if(settings.special) this._special = true;
    if(settings.special_level) {
        this._special_level = settings.special_level;
        if (settings.special_level == 'err'){
            UI_Class.modalErr = this;
        } else {
            UI_Class.modalKeyDownHandlerMaxLevel = (UI_Class.modalKeyDownHandlerMaxLevel < this._special_level) ? this._special_level : UI_Class.modalKeyDownHandlerMaxLevel;
        }
    }
    if(settings.modal) this.modal = true;
    if(settings.close) this.close = settings.close;
    if(settings.hidden) this.Hide();
    if(settings.nodrag) EVENTS_Class.DisableDrag(this.domElement);
    
    if(!settings.disableKeydownClose && !this._disableBackgroundClick){
        UI_Class.modalKeyDownHandler.push(this);
    }
};
UI_Window.prototype.constructor = UI_Window;

Object.defineProperty(UI_Window.prototype, 'modal', {
    set: function(value) {
        if(value){
            if(!this._modalMask){
                this._modalMask = DOM_Class.CreateElement('DIV',{'class':'ui_modal_mask'});
                if(!this._disableBackgroundClick){
                    //~ EVENTS_Class.AddEvent(this._modalMask , EVENTS_Class.EVENT_DOUBLECLICK , this.OnDoubleClickMask.bind(this));
                    EVENTS_Class.AddEvent(this._modalMask , $_e.EVENT_CLICK , this.OnDoubleClickMask.bind(this));
                    //~ EVENTS_Class.AddEvent(this.domElement , $_e.EVENT_CLICK , this.OnDoubleClickMask.bind(this));
                }
            }
            if(this.domElement.parentNode){
                this.domElement.parentNode.insertBefore(this._modalMask , this.domElement);
            }
            this._modal = true;
            let base_zIndex = 100;
            if (this._special) {
                if (this._special_level == 'err'){
                    base_zIndex += 10;
                } else {
                    base_zIndex = base_zIndex - (this._special_level+2);
                }
                DOM_Class.SetStyleValue(this._modalMask , 'z-index',base_zIndex);
                DOM_Class.SetStyleValue(this.domElement , 'z-index',base_zIndex+1);
            } else {
                DOM_Class.SetStyleValue(this._modalMask , 'z-index',base_zIndex);
                DOM_Class.SetStyleValue(this.domElement , 'z-index',base_zIndex+1);
            }
        }else{
            if(this._modal){
                this._modalMask.remove();
            }
            this._modal = false;
            DOM_Class.SetStyleValue(this.domElement , 'z-index','');
        }
    }
});

Object.defineProperty(UI_Window.prototype, 'visible', {
    get: function() {
        // if (document.body.contains(this.domElement) && !this.domElement.classList.contains('hidden'))
        return (document.body.contains(this.domElement) && !this.domElement.classList.contains('hidden'));
    }
});

Object.defineProperty(UI_Window.prototype, 'close', {
    set: function(value) {
        //~ console.log(value);
        if (value){
            if (!this._modalClose) {
                this._modalClose = DOM_Class.CreateElement('BUTTON',{'class':'ui_window_close'}, value);
                EVENTS_Class.AddEvent(this._modalClose, $_e.EVENT_CLICK, this.Toggle.bind(this));
            }
            if(this.domElement){
                this.domElement.appendChild(this._modalClose);
            }
            //~ console.log(this._modalClose);
            //~ console.log(this.domElement);
            
        }
    }
});

UI_Window.prototype.onKeyPress = function(evt){
    // When key ESC press, close the modal
    if (evt.keyCode == 27 || evt.key == 'Escape' || evt.key == 'Esc'){
        // console.log(evt);
        let has_delete = false;
        // first we hide the err modal
        if (UI_Class.modalErr && UI_Class.modalErr.visible){
            UI_Class.modalErr.Hide();
            has_delete = true;
        }
        if (!has_delete){
            // second we hide all the modal that are not special
            UI_Class.modalKeyDownHandler.forEach((obj)=>{
                if (obj && !obj._special && obj.visible) {
                    obj.Hide();
                    has_delete = true;
                }
            });
            if (!has_delete){ // no normal, so we hide the first level of special
                for(let i=0;i < UI_Class.modalKeyDownHandlerMaxLevel;i++){
                    let levelFound = false;
                    UI_Class.modalKeyDownHandler.every((obj)=>{
                        if (obj && obj.visible && obj._special_level == (i+1)) {
                            obj.Hide();
                            levelFound = true;
                            return false;
                        }
                        return true;
                    });
                    // stop execution if we hide an element from the current level
                    if (levelFound) break;
                }
            }
        }
        // if (!has_delete){
            
        // }
    }
};

UI_Window.prototype.SetContent = function(content){
    if(GENERICS_Class.IsString(content)){
        DOM_Class.WriteHtml(this._modalContent, content);
        //~ this.domElement.innerHTML = content;
        //~ if (this._modalClose) this._modalContent.appendChild(this._modalClose);
    }else if(GENERICS_Class.IsDomObject(content)){
        this._modalContent.innerHTML = '';
        this._modalContent.appendChild(content);
        //~ if (this._modalClose) this._modalContent.appendChild(this._modalClose);
    } else if (GENERICS_Class.IsArray(content)){
        this._modalContent.innerHTML = '';
        content.forEach((elem)=>{
            if (GENERICS_Class.IsDomObject(elem)){
                this._modalContent.appendChild(elem);
            } else if(GENERICS_Class.IsString(content)){
                this._modalContent.innerHTML += content;
            }
        });
        //~ if (this._modalClose) this._modalContent.appendChild(this._modalClose);
    }
};

UI_Window.prototype.SetParent = function(parentNode , alignHorizontal , alignVertical){
    if(this._modalMask){
        parentNode.appendChild(this._modalMask);
    }
    parentNode.appendChild(this.domElement);
    DOM_Class._SetRectDirty(this.domElement);
    if(alignHorizontal) DOM_Class.SetAlignment(this.domElement , alignHorizontal , alignVertical);
    if (this.domElement._ComputedStyle && this.domElement._ComputedStyle.POS != 'fixed'){
        this.UpdateScrollPosition();
    }
};

UI_Window.prototype.UpdateScrollPosition = function(){
    let scrollY = window.pageYOffset;
    if(scrollY > 0){
        if (this.domElement){
            let top = parseInt(this.domElement.style.top.replace('px', ''));
            this.domElement.style.top = top + scrollY + 'px';
        }
    }
};

UI_Window.prototype.Toggle = function(){
    if(this.visible){
        this.Hide();
    }else{
        this.Show();
    }
    DOM_Class._SetRectDirty(this.domElement);
};

UI_Window.prototype.Hide = function(){
    if(this._modal){
        this._modalMask.classList.toggle('hidden',true);
    }
    this.domElement.classList.toggle('hidden',true);
    
    if (UI_Class.modalKeyDownHandler.indexOf(this) > -1){
        let disableKeyPressEvent = true;
        for (let index = 0; index < UI_Class.modalKeyDownHandler.length; index++) {
            let obj = UI_Class.modalKeyDownHandler[index];
            if (obj && obj.visible){
                disableKeyPressEvent = false;
                break;
            }
        }
        if (disableKeyPressEvent){
            console.log('disable event KeyUp');
            $_e.RemoveEventKey(document, this.onKeyPress);
        }
    }
};

UI_Window.prototype.Show = function(){
    if(this._modal){
        this._modalMask.classList.toggle('hidden',false);
    }
    this.domElement.classList.toggle('hidden',false);
    
    if (UI_Class.modalKeyDownHandler.indexOf(this) > -1){
        console.log('add event KeyUp');
        $_e.AddEventKey(document, this.onKeyPress);
    }
};

UI_Window.prototype.Remove = function(){
    if(this._modal){
        this._modalMask.remove();
    }
    this.domElement.remove();

    if (UI_Class.modalKeyDownHandler.indexOf(this) > -1){
        UI_Class.modalKeyDownHandler.splice(UI_Class.modalKeyDownHandler.indexOf(this), 1);
    }

};


UI_Window.prototype.OnDoubleClickMask = function(event){
    EVENTS_Class.StopEvent(event);
    this.Hide();
};

//------------------------------------------------------------
// UI_Button and UI_input only used in page and cropdrop at the moment
// to release or to evolve into a real class, is not convertible into a class as it is?

UI_Button = function(settings){
    var self = this;
    settings = settings || {};
    let domElement = settings.domElement;

    if(GENERICS_Class.IsString(domElement)){
        domElement = DOM_Class.GetDomElement(domElement);
    }
    if(GENERICS_Class.IsDomObject(domElement)){
        this.domElement = domElement;
        this.domElement.classList.toggle('ui_btn',true);
        this.domElement.classList.toggle('default',true);
    }else{
        this.domElement = DOM_Class.CreateElement('DIV',{'class':'ui_btn default'});
    }

    this.domElement._ui_object = this;

    if(settings.icon){
        this.domElement.innerHTML = '';
        this.domElement.classList.toggle('icon' , true);
        this.domElement.classList.toggle(settings.icon , true);

        this.domElement.classList.toggle('default' , false);

    }else if(settings.label){
        this.domElement.innerHTML = settings.label;
    }

    if(settings.css){
        this.domElement.className += ' '+settings.css;
    }

    if(settings.tooltip){
        this.tooltip = settings.tooltip;
        this.domElement.title = this.tooltip;
    }

    // indicates that this element can only be activated if a selection is present in the editing document
    this.select_active = settings.select_active || false;

    this.action = settings.action || null;

    if(settings.onclick){
        this._handler = settings.onclick;
    }

    EVENTS_Class.AddEvent(this.domElement , EVENTS_Class.EVENT_MOUSEUP , EVENTS_Class.BindCallback(this , this.OnClick) );
    if(settings.returnclick){
        EVENTS_Class.AddEvent(document, EVENTS_Class.EVENT_KEYDOWN , EVENTS_Class.BindCallback(this , this.ReturnClick) );
    }
};

UI_Button.prototype.constructor = UI_Button;

UI_Button.prototype.SetParent = function(parentNode){
    if(!parentNode){
        this.domElement.remove();
    }else{
        parentNode.appendChild(this.domElement);
    }
    //parentNode.appendChild(this.domElement);
    DOM_Class._SetRectDirty(this.domElement);
};

UI_Button.prototype.OnClick = function(event){
    if(event.button === 0){
        EVENTS_Class.StopEvent(event);
        if(GENERICS_Class.IsFunction(this._handler)){
            this._handler(event);
        }
    }
};

UI_Button.prototype.ReturnClick = function(event){
    if(event.key == "Enter" || event.keyCode == 13){
        EVENTS_Class.StopEvent(event);
        if(GENERICS_Class.IsFunction(self._handler)){
            self._handler(event);
        }
        // event.button=0;
        // this.OnClick(event);
    }
};

//------------------------------------------------------------

UI_Input = function(settings){
    settings = settings || {};

    let domElement = settings.domElement;

    if(GENERICS_Class.IsString(domElement)){
        domElement = DOM_Class.GetDomElement(domElement);
    }
    if(GENERICS_Class.IsDomObject(domElement)){
        this.domElement = domElement;
        this.domElement.classList.toggle('ui_input',true);
        this.domElement.innerHTML = '';
    }else{
        this.domElement = DOM_Class.CreateElement('DIV',{'class':'ui_input'});
    }


    this._input = DOM_Class.CreateElement('INPUT');
    this._label = DOM_Class.CreateElement('LABEL');
    this._text = document.createTextNode('');

    this.select_active = settings.select_active || false;

    this._label.appendChild(this._text);
    this._label.appendChild(this._input);
    this.domElement.appendChild(this._label);


    this.domElement._ui_object = this;

    if(settings.restrict){
        this._input.dataset.restrict = settings.restrict;
        $_v.protectInput(this._input);
    }

    if(settings.label){
        this._text.textContent = settings.label;
    }

    if(settings.css){
        this.domElement.className += ' '+settings.css;
    }

    if(settings.tooltip){
        this.tooltip = settings.tooltip;
        this.domElement.title = this.tooltip;
    }

    if(GENERICS_Class.IsFunction(settings.onchange)){

        this._onchange = settings.onchange;

        EVENTS_Class.AddEvent(this._input , EVENTS_Class.EVENT_CHANGE , this.OnChange.bind(this) );
        EVENTS_Class.AddEvent(this._input , EVENTS_Class.EVENT_KEYUP , this.OnChange.bind(this) );
        EVENTS_Class.AddEvent(this._input , EVENTS_Class.EVENT_MOUSEUP , this.OnChange.bind(this) );
    }

    this.action = settings.action || null;

};
UI_Input.prototype.constructor = UI_Input;

UI_Input.prototype.SetParent = function(parentNode){
    if(this.domElement.parent != parentNode){
        if(!parentNode){
            this.domElement.remove();
        }else{
            parentNode.appendChild(this.domElement);
        }
    }
    DOM_Class._SetRectDirty(this.domElement);
};

UI_Input.prototype.OnChange = function(event){
    if(this._onchange){
        if(this.action){
            this._onchange(this.action , this._input.value);
        }else{
            this._onchange(this._input.value);
        }
    }
};

Object.defineProperty(UI_Input.prototype, 'value', {
    get: function() {
        return this._input.value;
    },set: function(v) {
        this._input.value = v;
    }
});

Object.defineProperty(UI_Input.prototype, 'label', {
    get: function() {
        return this._label.value;
    },set: function(v) {
        this._label.value = v;
    }
});

//------------------------------------------------------------

UI_Class.MessagePopup = function(message , ok_handler){
    let settings = {};

    if(GENERICS_Class.IsArray(message)) message = message.join('<br>');

    settings.content = message;

    settings.buttons = [];
    settings.buttons.push({'label':CONSTANTS.texts.tlc_ok,'css':'btnokpopup','handler':ok_handler,'keyPress': ['Enter','Escape']});

    let w = new UI_PromptWindow(settings);
    w.SetParent(document.body,0.5,0.3);
};

UI_Class.ConfirmPopup = function(message , ok_handler , cancel_handler){
    let settings = {};

    if(GENERICS_Class.IsArray(message)) message = message.join('<br>');

    settings.content = message;

    settings.buttons = [];
    settings.buttons.push({'label':CONSTANTS.texts.tlc_ok,'handler':ok_handler,'keyPress': 'Enter'});
    settings.buttons.push({'label':CONSTANTS.texts.tlc_annuler,'handler':cancel_handler,'keyPress': 'Escape'});

    let w = new UI_PromptWindow(settings);
    w.SetParent(document.body,0.5,0.3);
    // console.log(w);
};

UI_PromptWindow = function(settings){
    settings.modal = true;
    settings.disableBackgroundClick = true;

    this.fields = settings.fields || {};

    UI_Window.call(this,settings);

    this.contentDiv = DOM_Class.CreateElement('DIV',{'class':'ui_prompt_message'});
    this.domElement.appendChild(this.contentDiv);
    if(settings.contentClass){
        this.contentDiv.className += ' '+settings.contentClass;
    }
    DOM_Class.AppendContent(this.contentDiv , settings.content);

    this.keyPress_btns = [];

    if(GENERICS_Class.IsArray(settings.buttons)){
        this.buttonsDiv = DOM_Class.CreateElement('DIV',{'class':'ui_prompt_buttons'});
        this.domElement.appendChild(this.buttonsDiv);

        for(let i = 0; i < settings.buttons.length ; i++){
            let b = settings.buttons[i];
            let btn = new UI_Button(b);
            btn.SetParent(this.buttonsDiv);
            btn.domElement._handler = b.handler;
            $_e.AddEventClick(btn.domElement,EVENTS_Class.BindCallback(this , this.OnClickButton));
            if (b.keyPress){
                if (GENERICS_Class.IsString(b.keyPress)){
                    this.keyPress_btns.push({'target': btn.domElement, 'key': b.keyPress});
                } else {
                    b.keyPress.forEach( key => {
                        this.keyPress_btns.push({'target': btn.domElement, 'key': key});
                    });
                }
                
            }
        }
    }else{
        let cancel_btn = new UI_Button({'tooltip':CONSTANTS.texts.tlc_annuler,'label':CONSTANTS.texts.tlc_annuler});
        cancel_btn.SetParent(this.domElement);
        cancel_btn.domElement._handler = settings.cancel_handler ? settings.cancel_handler : null;
        $_e.AddEventClick(cancel_btn.domElement,EVENTS_Class.BindCallback(this , this.OnClickButton));
        this.keyPress_btns.push({'target': cancel_btn, 'key': 'Escape'});
    }

    if (this.keyPress_btns.length > 0){
        $_e.AddEvent(document, EVENTS_Class.EVENT_KEYUP, EVENTS_Class.BindCallback(this , this.OnKeyPress));
    }
};
UI_PromptWindow.prototype = new UI_Window();

UI_PromptWindow.prototype.OnClickButton = function(event){
    if(event.button === 0){
        EVENTS_Class.StopEvent(event);
        if(event.target._handler) event.target._handler(this.fields , this.domElement);
        this.Remove();
        if (this.keyPress_btns.length > 0){
            $_e.RemoveEvent(document, EVENTS_Class.EVENT_KEYUP, EVENTS_Class.BindCallback(this , this.OnKeyPress));
        }
    }
};

UI_PromptWindow.prototype.OnKeyPress = function(event){
    // $_e.StopEvent(event);
    this.keyPress_btns.forEach((obj) => {
        if (obj.key == event.key){
            $_e.SendEventClick(obj.target);
        }
    });
};

UI_PromptWindow.prototype.HideButtons = function(event){
    this.buttonsDiv.classList.toggle('hidden',true);
};

UI_PromptWindow.prototype.ShowButtons = function(event){
    this.buttonsDiv.classList.toggle('hidden',false);
};


//

function on_show_translate_block(evt){
    let button = evt.target;

    let selector = button.parentNode;
    let isolist = [];
    for(let i=0 ; i<selector.children.length;i++){
        let child = selector.children[i];
        if(child.dataset.iso == button.dataset.iso){
            child.classList.toggle('selected',true);
        }else if(!evt.shiftKey){
            child.classList.toggle('selected',false);
        }
        if(child.classList.contains('selected')){
            isolist.push(child.dataset.iso);
        }
    }

    let container = selector.parentNode;

    for(let i=0 ; i < container.children.length;i++){
        let child = container.children[i];
        if(child.dataset && child.dataset.iso){
            if(isolist.indexOf(child.dataset.iso) > -1){
                child.classList.toggle('selected',true);
            }else{
                child.classList.toggle('selected',false);
            }
        }

    }
}
//window screen logarythmique ratio calculator and base CSS var creation, called from init.js
function detect_screen_infos(){
  let root = document.documentElement;
  root.style.setProperty('--screen-x', window.screen.width*window.devicePixelRatio);
  root.style.setProperty('--screen-y', window.screen.height*window.devicePixelRatio);
  root.style.setProperty('--inner-x', window.innerWidth);
  root.style.setProperty('--inner-y', window.innerHeight);
  root.style.setProperty('--ar', window.screen.width/window.screen.height);
  root.style.setProperty('--innerar', window.innerWidth/window.innerHeight);
  if (window.screen.height <= 1080) {
      root.style.setProperty('--fhd-hr', 1);
      root.style.setProperty('--fhd-vr', 1);
      fhdVR=1;
  }else{
        if (window.outerWidth > 2230 ){
            let hr = 1+(Math.log(window.screen.width/window.devicePixelRatio) -  Math.log(1920));
            hr=(hr<1)?1:hr;
            let vr = 1+(Math.log(window.screen.height/window.devicePixelRatio) - Math.log(1080));
            vr=(vr<1)?1:vr;
            root.style.setProperty('--fhd-hr', hr);
            root.style.setProperty('--fhd-vr', vr);
            fhdVR=vr;
        }else{
            let hr = 1+(Math.log(window.outerWidth/window.devicePixelRatio) -  Math.log(1920));
            hr=(hr<1)?1:hr;
            let vr = 1+(Math.log(window.outerHeight/window.devicePixelRatio) - Math.log(1080));
            vr=(vr<1)?1:vr;
            root.style.setProperty('--fhd-hr', hr);
            root.style.setProperty('--fhd-vr', vr);
            fhdVR=vr;
        }
    }
}

function updateCssfhdvr(){
  let root = document.documentElement;
  if (window.innerWidth > 1920 && window.innerWidth < 2230 ) {
    let hr = 1+(Math.log(window.outerWidth/window.devicePixelRatio) -  Math.log(1920));
    hr=(hr<1)?1:hr;
    root.style.setProperty('--fhd-vr', hr);
    root.style.setProperty('--innerar', window.innerWidth/window.innerHeight);
    fhdVR=hr;
  }
  if (window.innerWidth > 2230){
       let vr = 1+(Math.log(window.screen.height/window.devicePixelRatio) - Math.log(1080));
       root.style.setProperty('--fhd-vr',vr);
       fhdVR=vr;
  }
}

// Search functions
function recherche(){
    this.shouldSearch = function(event,moduleName=''){
        if (event.keyCode == 13) {
            //~ document.getElementById(moduleName+'_admin_btn_search').click();
            document.getElementById(moduleName+'_admin_btn_search').click();
        }
    };
    this.filter=function(val,moduleName=''){
        document.getElementById(moduleName+'_order_filter').value=val;
        let page_jumper=document.getElementById(moduleName+'_page_jumper');
        if (page_jumper!=undefined){
            page_jumper.value=1;
        }
        document.getElementById(moduleName+'_admin_btn_search').click();
    };
    
    this.prev = function (moduleName=''){
        let start_index=document.getElementById(moduleName+'_start_index');
        let nbr_res = document.getElementById(moduleName+'_nbr_resultat');
        nbr_res = nbr_res.selectedOptions[0].value;
        let index_value = start_index.value != '' ? parseInt(start_index.value) : 0;
        start_index.value=index_value-parseInt(nbr_res);
        if (start_index.value<0) start_index.value=0;
        let page_jumper=document.getElementById(moduleName+'_page_jumper');
        if (page_jumper!=undefined){
            page_jumper.value=1;
        }
        // in this case we don't send with event.js because it's the normal behavior of submit button to submit the form
        // there is no special event click for this
        document.getElementById(moduleName+'_admin_btn_search').click();
    };
     
    this.next = function (moduleName=''){
        let start_index=document.getElementById(moduleName+'_start_index');
        let nbr_res = document.getElementById(moduleName+'_nbr_resultat');
        nbr_res = nbr_res.selectedOptions[0].value;
        let index_value = start_index.value != '' ? parseInt(start_index.value) : 0;
        start_index.value=index_value+parseInt(nbr_res);
        let page_jumper=document.getElementById(moduleName+'_page_jumper');
        if (page_jumper!=undefined){
            page_jumper.value=1;
        }
        document.getElementById(moduleName+'_admin_btn_search').click();
    };
    
    this.jumpto = function (e,moduleName=''){
        let start_index=document.getElementById(moduleName+'_start_index');        
        let startpageindex = e.target.selectedOptions[0].value;
        start_index.value=startpageindex;
        let page_jumper=document.getElementById(moduleName+'_page_jumper');
        if (page_jumper!=undefined){
            page_jumper.value=1;
        }
        document.getElementById(moduleName+'_admin_btn_search').click();
    };
    
    this.ToggleMessage = function(tgt,moduleName=''){
        let target = document.getElementById(tgt);
        DOM_Class.ToggleClass(target, 'messageoff');
    };
    
    this.changeFilter = function(evt,moduleName=''){
        let form = document.getElementById(moduleName+'_form');
        let btn = document.getElementById(moduleName+'_btn_send');
        for (let i = 0; i  < form.length; i++){
            let elem = form[i];
            if (elem.tagName == 'INPUT' || elem.tagName == 'SELECT'){
                $_e.AddEvent(elem, 'change', function(){
                    //~ let btn = document.getElementById('dumplist_btn_send');
                    DOM_Class.ToggleClass(btn, 'filter_change', true);
                });
            }
        }
    };
    
    this.save = function(moduleName=''){
        let btn = document.getElementById(moduleName+'_admin_btn_save');
        //shouldn't it be separated in a this.search method ?
        let btnSrch = document.getElementById(moduleName+'_admin_btn_search');
        if (btn) btn.click();
        if (btnSrch) setTimeout(()=>{btnSrch.click();},200);
        //if (modal) modal.Hide();
    };
    
    this.del = function(evt, moduleName='', id=0){
        let txt = evt.target.dataset.confirm;
        UI_Class.ConfirmPopup(txt, ()=>{
            if (id>0){
                let btn = document.getElementById(moduleName+'_admin_btn_del_'+id);
                let btnSrch = document.getElementById(moduleName+'_admin_btn_search');
                if (modal) modal.Hide();
                btn.click();
                setTimeout(()=>{btnSrch.click();}, 500);
            }
        });
    };

    var modal = false;
    this.modalEdit = function(id=0,moduleName='',tableName='',action=''){
        if (!modal){
            modal = UI_Class.AddWindow(document.body, {'hidden': true, 'modal': true, 'close': 'x'});
            modal.domElement.setAttribute('id', 'edit_modal');
            let div = DOM_Class.CreateElement('div', {'class': 'edit_modal_container','id':'edit_modal_container'});
            modal.SetContent(div);
        }
        var url = document.baseURI;
        url = url.split('#');
        url = url[0].split('?');
        url = url[0] + moduleName + '/index.php';
        
        //~ var url = CONSTANTS.base_url + moduleName + '/index.php';

        let settings = {};
        settings.url = url;
        settings.dom_target = 'edit_modal_container';
        settings.skip_container = true;
        settings.data = {};
        settings.data[moduleName+'_action'] = moduleName+'_'+action;
        settings.data[moduleName+'-'+tableName+'-id'] = id;
        settings.success = function(res){
            modal.Show();
            DOM_Class.SetAlignment(modal.domElement, 0.5, 0.5);
        };
        $_a.send(settings);
    };
}
var srch = new recherche();

function autocomplete(){
    var self = this;
    var lst = [];
    
    var closeOnClick=false;
    //~ var toInit=[];
    
    this.init=function(name,moduleName,tableName,fieldName,submit,confirm,callback){
        //~ console.log(fieldName);
        if (name){
            lst[name]=[];
            lst[name]['submit']=submit;
            lst[name]['confirm']=confirm;
            lst[name]['inp']=document.getElementById(name+'_id');
            lst[name]['moduleName']=moduleName;
            lst[name]['tableName']=tableName;
            lst[name]['fieldName']=fieldName;
            lst[name]['callback'] = callback;
            lst[name]['txt']=document.getElementById(name+'_autocomp');
            
            lst[name]['txt'].addEventListener('input', (e)=>{onInput(e,name);});
            lst[name]['txt'].addEventListener('keydown', (e)=>{onKeyDown(e,name);});
            
            //~ console.log(lst[id]['txt']);
            if (!closeOnClick){
                // EVENTS_Class.AddEventClickOutside()
                // $_e.AddEventClickOutside()
                $_e.AddEvent(window, EVENTS_Class.EVENT_CLICK, closeAllLists);
                // closeOnClick=true;
            }
        }
    };
    
    //~ this.preInit=function(...params){
        //~ let t = params;
        //~ toInit.push(t);
        //~ console.log(toInit);
    //~ }
    
    //~ function activate(id){
        
        //~ $_e.AddEvent(lst[id]['txt'],'input',onInput);
        //~ $_e.AddEvent(lst[id]['txt'],'keydown',onKeyDown);
    //~ };
    
    function onInput(e,name){
        lst[name]['val'] = e.target.value;
        if (lst[name]['val'].length>1){
            /*close any already open lists of autocompleted values*/
            closeAllLists();
            if (!lst[name]['val']) {return false;}
            lst[name]['currentFocus'] = -1;
            /*create a DIV element that will contain the items (values):*/
            lst[name]['a'] = DOM_Class.CreateElement('DIV', {'id': name + '_autocomplete-list', 'class': 'autocomplete-items'});

            /*append the DIV element as a child of the autocomplete container:*/
            //~ e.target.parentNode.appendChild(lst[name]['a']);
            e.target.parentNode.parentNode.appendChild(lst[name]['a']);
            //now we're getting our datas :
            let settings = {};
            let url = e.target.form.action;
            // let url = document.baseURI.split('?')[0].split('#')[0]+lst[name]['moduleName']+'/index.php';
            settings.url = url;
            settings.dom_target = '';
            settings.skip_container = true;
            settings.notimer = true;
            settings.data = {};
            settings.data[lst[name]['moduleName']+'_action']=lst[name]['moduleName']+'_autocomp';
            settings.data['table']= lst[name]['tableName'];
            settings.data['fields']= lst[name]['fieldName'];
            settings.data['value']= lst[name]['val'];
            // get the extra data with data-autocomp from parent form
            let form=lst[name]['inp'].form;
            for(let i=0;i<form.length;i++){
                if (form[i].getAttribute('data-autocomp')){
                    settings.data[form[i].name]=form[i].value;
                }
            }
            settings.success = function(res){
                /*for each item in the array...*/
                //~ console.log(res);
                arr=JSON.parse(res);
                // remove all elements from the list before adding the new one
                while(lst[name]['a'].firstChild){
                    lst[name]['a'].removeChild(lst[name]['a'].firstChild);
                }
                for (i = 0; i < arr.length; i++) {
                    //~ console.log(arr[i]);
                    let txt = arr[i].name;
                    let id = arr[i].id;
                    /*check if the item starts with the same letters as the text field value:*/
                    //remove extract slaches
                    //~ txt=txt.stripSlashes();
                    //~ if (txt.substr(0, lst[name]['val'].length).toUpperCase() == lst[name]['val'].toUpperCase()) {
                        /*create a DIV element for each matching element:*/
                        lst[name]['b'] = DOM_Class.CreateElement('DIV');
                        /*make the matching letters bold:*/
                        lst[name]['b'].innerHTML = "<strong>" + txt.substr(0, lst[name]['val'].length) + "</strong>";
                        lst[name]['b'].innerHTML += txt.substr(lst[name]['val'].length);
                        /*insert a input field that will hold the current array item's value:*/
                        lst[name]['b'].innerHTML += '<input type="hidden" value="' + txt + '">';
                        /*execute a function when someone clicks on the item value (DIV element):*/
                        lst[name]['b'].addEventListener("click", function(e) {
                            /*insert the value for the autocomplete text field:*/
                            lst[name]['txt'].value = txt;
                            lst[name]['inp'].value = id;
                            /*close the list of autocompleted values,
                            (or any other open lists of autocompleted values:*/
                            closeAllLists();
                            if (lst[name]['confirm'] == 'false'){
                                if(lst[name]['submit']) EVENTS_Class.SendEvent(lst[name]['inp'].form , 'submit');
                                EVENTS_Class.SendEvent(lst[name]['inp'],'change');
                            } else {
                                UI_Class.ConfirmPopup(lst[name]['confirm'], ()=>{
                                    if(lst[name]['submit']) EVENTS_Class.SendEvent(lst[name]['inp'].form , 'submit');
                                    EVENTS_Class.SendEvent(lst[name]['inp'],'change');
                                });
                            }
                            // if (window.confirm(lst[name]['confirm'])) {
                            //     if(lst[name]['submit']) EVENTS_Class.SendEvent(lst[name]['inp'].form , 'submit');
                            //     EVENTS_Class.SendEvent(lst[name]['inp'],'change');
                            // }
                            if (lst[name]['callback']) lst[name]['callback'](e);
                        });
                        lst[name]['a'].appendChild(lst[name]['b']);
                    //~ }
                }
            };
            $_a.send(settings);
        }
    }
    
    function closeAllLists(){
        /*close all autocomplete lists in the document,
        except the one passed as an argument:*/
        var x = document.getElementsByClassName("autocomplete-items");
        for (var i = 0; i < x.length; i++) {
            //~ if (elmnt != x[i] && elmnt != inp) {
            x[i].parentNode.removeChild(x[i]);
            //~ }
        }
    }
    
    function onKeyDown(e,name){
        lst[name]['x'] = document.getElementById(name + "_autocomplete-list");
        if (lst[name]['x']) lst[name]['x'] = lst[name]['x'].getElementsByTagName("div");
        if (e.keyCode == 40) {
            /*If the arrow DOWN key is pressed,
            increase the currentFocus variable:*/
            lst[name]['currentFocus']++;
            /*and and make the current item more visible:*/
            addActive(lst[name]['x'],name);
        } else if (e.keyCode == 38) { //up
            /*If the arrow UP key is pressed,
            decrease the currentFocus variable:*/
            lst[name]['currentFocus']--;
            /*and and make the current item more visible:*/
            addActive(lst[name]['x'],name);
        } else if (e.keyCode == 13) {
            /*If the ENTER key is pressed, prevent the form from being submitted,*/
            e.preventDefault();
            if ( lst[name]['currentFocus'] > -1) {
                /*and simulate a click on the "active" item:*/
                if (lst[name]['x']) lst[name]['x'][lst[name]['currentFocus']].click();
            }
        }
    }
  
    function addActive(x,name) {
        /*a function to classify an item as "active":*/
        if (!x) return false;
        /*start by removing the "active" class on all items:*/
        removeActive(x);
        if (lst[name]['currentFocus'] >= x.length) lst[name]['currentFocus'] = 0;
        if (lst[name]['currentFocus'] < 0) lst[name]['currentFocus'] = (x.length - 1);
        /*add class "autocomplete-active":*/
        x[lst[name]['currentFocus']].classList.add("autocomplete-active");
    }
    function removeActive(x) {
        /*a function to remove the "active" class from all autocomplete items:*/
        for (var i = 0; i < x.length; i++) {
            x[i].classList.remove("autocomplete-active");
        }
    }
}
var autocomp = new autocomplete();

function initRangeTracks(){
    //update size of track subitem for a styled input range with styled_progress class
    for (let e of document.querySelectorAll('input[type="range"].styled_progress')) {
      e.style.setProperty('--value', e.value);
      e.style.setProperty('--min', e.min == '' ? '0' : e.min);
      e.style.setProperty('--max', e.max == '' ? '100' : e.max);
      e.addEventListener('input', () => e.style.setProperty('--value', e.value));
    }
}

var UI_Multi_State_lst = {};
var UI_Multi_State = function(domId,side='',toggle_mode=false){
    var self = this;
    var buttons = [];
    var container,toggler,active,toggle;
    var avatar_active=false;
    var sided = (side != '') ? true : false;
    var opened = false;
    
    this.domID = domId;
    this.avatar = false;
    
    function init(){
        //~ console.log(toggle_mode);
        
        container = document.getElementById(domId);
        //~ $_e.AddEventClick(container, ()=>{});
        
        // the element to click on for opening
        toggler = document.getElementById(domId + '-toggler');
        
        // the element to toggle when opening
        toggle = document.getElementById(domId + '-toggle');
        
        for (let i = 0; i < toggle.children.length; i++){
            let btn = toggle.children[i];
            // add on every buttons the close event
            $_e.AddEventClick(btn,onClickBtn);
            if (!toggle_mode){ // no active by default in toggle mode
                if (DOM_Class.HasClass(btn,'state_active')){
                    // the currently selected item
                    active = btn;
                }
            } else { // but need to add the first item to active for creating the avatar
                active = buttons[0];
            }
            DOM_Class.AddClass(active, 'current_avatar');
            
            buttons.push(btn);
        }
        
        if (sided){
            // move the element to toggle as a child of document for him to be in front of every other elements (like a modal)
            DOM_Class.AppendContent(document.body, toggle);
        }
        
        changeAvatar();
        toggleButtons();
    }
    function onClickToggler(evt){
        //~ console.log('toggle');
        if (!opened) {
            // show every buttons
            toggleButtons(false);
            // hide toggler
            toggler.style.display = 'none';
            opened = true;
        } else {
            onClose(evt);
        }
        
    }
    function onClickBtn(evt, btn = false){
        // console.log(evt);
        let targ = (btn !== false) ? btn : evt.target;
        //~ if (buttons.indexOf(targ) > -1){
        if (targ.dataset.no_toggle) {
            onClose();
            return;
        }
        if (toggle_mode){
            if (DOM_Class.HasClass(targ,'state_active')){
                DOM_Class.RemoveClass(targ,'state_active');
            } else {
                DOM_Class.AddClass(targ,'state_active');
            }
        } else {
            if (targ != active){
                // remove class from previous
                DOM_Class.RemoveClass(active, 'current_avatar');
                DOM_Class.RemoveClass(active, 'state_active');
                
                active = targ;
                DOM_Class.AddClass(active,'state_active');
                DOM_Class.AddClass(active,'current_avatar');
                changeAvatar();
            }
            onClose();
        }
        //~ }
    }
    function onClose(evt){
        opened = false;
        toggler.style.display = '';
        toggleButtons();
    }
    // toggle every button except the active one
    function toggleButtons(hide=true){
        if (hide){
            toggle.style.display = 'none';
            if (!sided) avatar_active.style.display = '';
            $_e.RemoveEventClickOutside(toggle,onClickOutside);
        } else {
            toggle.style.display = '';
            if (!sided) avatar_active.style.display = 'none';
            else {
                let rect = DOM_Class.GetGlobalRect(container,true);
                let rectToggle = DOM_Class.GetGlobalRect(toggle,true);
                let difWidth = rectToggle.width - rect.width;
                switch (side) {
                    case 'left':
                        toggle.style.top = Math.round(rect.top) + 'px';
                        toggle.style.left = Math.round(rect.left - rectToggle.width) + 'px';
                    break;
                    case 'right':
                        toggle.style.top = Math.round(rect.top) + 'px';
                        toggle.style.left = Math.round(rect.right) + 'px';
                    break;
                    case 'top':
                        //~ let rectToggle = DOM_Class.GetGlobalRect(toggle,true);
                        if (difWidth >= 0){
                            toggle.style.left = Math.round(rect.left - (difWidth / 2)) + 'px';
                        } else {
                            toggle.style.left = Math.round(rect.left + (difWidth / 2)) + 'px';
                        }
                        toggle.style.bottom = Math.round(rect.top) + 'px';
                    break;
                    case 'down':
                    //~ case '':
                        //~ console.log(difWidth);
                        //~ console.log(difWidth / 2);
                        //~ console.log(rect.left - (difWidth / 2));
                        //~ console.log(rect.left + (difWidth / 2));
                        //~ if (difWidth >= 0){
                        toggle.style.left = Math.round(rect.left - (difWidth / 2)) + 'px';
                        //~ } else {
                            //~ toggle.style.left = Math.round(rect.left + (difWidth / 2)) + 'px';
                        //~ }
                        toggle.style.top = Math.round(rect.bottom) + 'px';
                    break;
                }
            }
            $_e.AddEventClickOutside(toggle,onClickOutside);
        }
    }
    function onClickOutside(evt){
        // if the click is on toggler, do nothing.
        // the function that handle the click on the toggler will trigger the close
        // this is like a clickOutside execpt this element
        //~ console.log(evt);
        if (evt.target != avatar_active){
            onClose(evt);
        }
    }
    // take the active element to create an avatar
    // put the avatar as the toggler 
    function changeAvatar(){
        // remove old avatar
        let old_avatar = false;
        if (avatar_active){
            old_avatar = avatar_active;
        }
        
        avatar_active = active.cloneNode();
        avatar_active.id += 'clone';
        avatar_active.innerHTML = active.innerHTML;
        DOM_Class.AddClass(avatar_active, 'avatar');
        DOM_Class.RemoveClass(avatar_active, 'current_avatar');
        // to remove if we add the automatic addEvent for onclick
        if (avatar_active.onclick) avatar_active.onclick = '';
        //~ $_e.RemoveAllEvents(avatar_active);
        
        if (old_avatar){
            DOM_Class.ReplaceElement(old_avatar, avatar_active);
        } else {
            DOM_Class.ReplaceElement(toggler, avatar_active);
        }
        
        $_e.AddEventClick(avatar_active,onClickToggler);

        self.avatar = avatar_active;
        //~ DOM_Class.AppendContent(toggler, avatar_active);
        //~ DOM_Class.InsertAfter(avatar_active,toggler);
    }
    
    this.next = function(loop=false){
        let nextBtn = active.nextElementSibling;
        if (nextBtn){
            $_e.SendEventClick(nextBtn);
        } else if (loop){
            $_e.SendEventClick(buttons[0]);
        }
    };
    this.prev = function(loop=false){
        let prevBtn = active.previousElementSibling;
        if (prevBtn){
            $_e.SendEventClick(prevBtn);
        } else if (loop){
            $_e.SendEventClick(buttons[buttons.length - 1]);
        }
    };
    
    this.setAvatar = function(domId = ''){
        buttons.forEach((btn)=>{
            if (btn.id == domId){
                onClickBtn(false, btn);
            }
        });
    };
    
    this.clean = function(){
        if (sided){
            // remove element from document
            DOM_Class.RemoveElement(toggle);
        }
    };
    
    init();
};
UI_Multi_State.create_instance = function(domId,side='',toggle_mode=false){
    
    if (UI_Multi_State_lst[domId]){
        UI_Multi_State_lst[domId].clean();
        delete(UI_Multi_State_lst[domId]);
    }
    UI_Multi_State_lst[domId] = new UI_Multi_State(domId,side,toggle_mode);

    UI_Multi_State.clean_instances();
};
UI_Multi_State.clean_instances = function(){
    let toClean = [];
    for (var key in UI_Multi_State_lst) {
        let exist = document.getElementById(UI_Multi_State_lst[key].domID);
        if (!exist) {
            UI_Multi_State_lst[key].clean();
            toClean.push(key);
        }
    }
    toClean.forEach((key)=>{
        delete(UI_Multi_State_lst[key]);
    });
};

// call create_instance with domId and settings.
// if a button from settings.buttons has dataset.child = true, don't put hide event on it but show child
var UI_Context_Menu = function(domId, settings){
    var self = this;
    this.domID = domId;
    this.buttons = settings.buttons;
    var openCallback = (settings.openCallback) ? settings.openCallback : false;
    var hideCallback = (settings.hideCallback) ? settings.hideCallback : false;
    
    let modSetts = {
        'modal': false,
        'disableBackgroundClick': true,
        'class': 'ui_window contextmenu',
        'nodrag': true,
        'disableKeydownClose': true,
        'hidden': true
    };
    if (settings.class) modSetts.class += settings.class;
    this.modal = new UI_Window(modSetts);
    this.content = DOM_Class.CreateElement('DIV',{'id': domId, 'class': 'UI_context_menu'});
    this.buttons.forEach((btn)=>{
        if (btn.dataset && btn.dataset.child == 'true'){
            $_e.AddEventClick(btn, toggleChild);
        } else {
            $_e.AddEventClick(btn, ()=>{self.modal.Hide();});
        }
        DOM_Class.AppendContent(this.content, btn);
    });
    this.modal.SetContent(this.content);
    this.modal.SetParent(document.body, 0.5, 0.5);
    
    this.clean = function(){
        this.modal.Remove();
    };
    
    this.open = function(evt){
        $_e.StopEvent(evt);
        
        if (openCallback) openCallback(evt);
        
        // console.log(self);
        if (evt.pointerType == 'touch'){
            return false;
        }
        self.modal.Show();
        
        let rect = DOM_Class.GetGlobalRect(self.modal.domElement, true);
        let parentRect = DOM_Class.GetGlobalRect(self.modal.domElement.parentElement, true);
        
        // verify if it's smaller than the window
        let display = false;
        if (parentRect.height > rect.height) display = true;
        
        // verify if it's going outside the window
        let left = evt.clientX + window.pageXOffset;
        let right = left + rect.width;
        if (right < parentRect.width) {
            self.modal.domElement.style.left = left + 'px';
        } else {
            self.modal.domElement.style.left = (left - rect.width) + 'px';
        }
        
        let top = evt.clientY + window.pageYOffset;
        let bottom = top + rect.height;
        if (bottom < parentRect.height) {
            self.modal.domElement.style.top = top + 'px';
        } else if ((top - rect.height) > parentRect.top){
            self.modal.domElement.style.top = (top - rect.height) + 'px';
        } else {
            self.modal.domElement.style.top = (parentRect.height - rect.height - 1) + 'px';
        }
        
        self.modal.domElement.style.visibility = 'visible';
        $_e.AddEventClickOutside(self.modal.domElement, self.hide);
    };
    
    this.hide = function(evt){
        self.modal.Hide();
        // console.log('hide');
        $_e.RemoveEventClickOutside(self.modal.domElement, self.hide);
        if (hideCallback) hideCallback(evt);
    };
    
    function toggleChild(evt){
        let targ = evt.target;
        for (let i = 0; i < targ.children.length; i++){
            DOM_Class.RemoveClass(targ.children[i], 'hidden');
        }
        $_e.AddEventClickOutside(targ, hideChild);
    }
    function hideChild(evt){
        let targ = evt.target;
        for (let i = 0; i < targ.children.length; i++){
            DOM_Class.RemoveClass(targ.children[i], 'hidden');
        }
        $_e.RemoveEventClickOutside(targ, hideChild);
    }
    //~ init();
};
UI_Context_Menu.lst = {};
UI_Context_Menu.create_instance = function(domId, settings){
    
    if (UI_Context_Menu.lst[domId]){
        UI_Context_Menu.lst[domId].clean();
        delete(UI_Context_Menu.lst[domId]);
    }
    UI_Context_Menu.lst[domId] = new UI_Context_Menu(domId,settings);

    UI_Context_Menu.clean_instances();
    
    //~ console.log(UI_Context_Menu.lst[domId]);
    return UI_Context_Menu.lst[domId];
};
UI_Context_Menu.clean_instances = function(){
    let toClean = [];
    for (var key in UI_Context_Menu.lst) {
        let exist = document.getElementById(UI_Context_Menu.lst[key].domID);
        if (!exist) {
            UI_Context_Menu.lst[key].clean();
            toClean.push(key);
        }
    }
    toClean.forEach((key)=>{
        delete(UI_Context_Menu.lst[key]);
    });
};

var UI_Upload_Progress = function(files,parent,domId){
    var self = this;
    this.numberFiles,this.totalPercent,this.speed,this.totalBarProgress;
    this.btn_stop, this.btn_play;
    this.files = {'dom': false, 'lst': [], 'hidden': true};
    
    this.show = function(files, parent = false, domId = ''){
        if (files){
            // console.log(files);
            //~ let blockFiles;
            if (!UI_Class.popupSpecial['upload_'+domId]){
                UI_Class.popupSpecial['upload_'+domId] = new UI_Window({'modal': false, 'nodrag':true, 'disableKeydownClose': true, 'special': true, 'class': 'upload_progress', 'hidden': true});
                
                let content = [];
                let total = DOM_Class.CreateElement('DIV', {'class':'upload_total'});
                    let label = DOM_Class.CreateElement('SPAN', {'class':'upload_total_label'}, UI_Upload_Progress.tl['upload_ttl']);
                    this.numberFiles = DOM_Class.CreateElement('SPAN', {'id':'fileupload_total_files'});
                    this.totalPercent = DOM_Class.CreateElement('SPAN', {'id':'fileupload_percent'}, '0%');
                    this.speed = DOM_Class.CreateElement('SPAN', {'id':'fileupload_speed'});
                    this.totalBarProgress = DOM_Class.CreateElement('DIV', {'class':'filemanager_progress_upload_total_bar_progress', 'id':'fileupload_bar_progress'});
                    let totalBar = DOM_Class.CreateElement('DIV', {'class':'filemanager_progress_upload_total_bar', 'id':'fileupload_bar'}, this.totalBarProgress);
                DOM_Class.AppendContent(total, [label, this.numberFiles,this.totalPercent,this.speed,totalBar]);
                
                    // this.btn_stop = DOM_Class.CreateElement('BUTTON', {'class':'upload_btn_pause'}, 'pause');
                    // this.btn_play = DOM_Class.CreateElement('BUTTON', {'class':'upload_btn_play hidden'}, 'play');
                    let btn_cancel = DOM_Class.CreateElement('BUTTON', {'class':'upload_btn_cancel'}, 'cancel');
                
                DOM_Class.AppendContent(total, btn_cancel);
                content.push(total);
                
                this.files.dom = DOM_Class.CreateElement('DIV', {'id':'fileupload_block_files'});
                content.push(this.files.dom);
                
                UI_Class.popupSpecial['upload_'+domId].SetContent(content);
                if (!parent) UI_Class.popupSpecial['upload_'+domId].SetParent(document.body);
                else UI_Class.popupSpecial['upload_'+domId].SetParent(parent);
                
                
                
                $_e.AddEventClick(total, this.toggleFileBlock);
                // $_e.AddEventClick(this.btn_stop, this.stop);
                // $_e.AddEventClick(this.btn_play, this.play);
                $_e.AddEventClick(btn_cancel, this.cancel);
                
            }
            
            DOM_Class.AddClass(this.files.dom, 'hidden');
            this.files.hidden = true;
            
            files.forEach((file, index)=>{
                let filename = file.webkitRelativePath != '' ? file.webkitRelativePath : file.name;
                this.files.lst[filename] = {};
                
                let line = DOM_Class.CreateElement('DIV', {'class':'upload_file'});
                    let name = DOM_Class.CreateElement('SPAN', {'class':'upload_file_name'}, filename);
                    let size = DOM_Class.CreateElement('SPAN', {'class':'upload_file_size'}, AJAX_Class.readableFileSize(file.size));
                    this.files.lst[filename].percent = DOM_Class.CreateElement('SPAN', {'class':'upload_file_percent'}, '0%');
                    this.files.lst[filename].barProgress = DOM_Class.CreateElement('DIV', {'class':'upload_file_bar_progress'});
                    let bar = DOM_Class.CreateElement('DIV', {'class':'upload_file_bar'}, this.files.lst[filename].barProgress);
                DOM_Class.AppendContent(line, [name,size,this.files.lst[filename].percent,bar]);
                DOM_Class.AppendContent(this.files.dom, line);
            });
            
            UI_Class.popupSpecial['upload_'+domId].Show();
        }
    };
    this.hide = function(){
        // hide and reinit
        
        UI_Class.popupSpecial['upload_'+domId].Remove();
        
        // while(this.files.dom.firstChild){
        //     DOM_Class.RemoveElement(this.files.dom.firstChild);
        // }
        
        // this.files.lst = [];
        // this.numberFiles.textContent = '';
        // this.totalPercent.textContent = '0%';
        // this.speed.textContent = '';
        // this.totalBarProgress.style.width = '0%';
        
        // this.prevReq = false;
    };
    this.toggleFileBlock = function(evt){
        if (self.files.hidden){
            self.updateCurrentFile();
            DOM_Class.RemoveClass(self.files.dom, 'hidden');
            self.files.hidden = false;
        } else {
            DOM_Class.AddClass(self.files.dom, 'hidden');
            self.files.hidden = true;
        }
    };
    this.prevReq = false;
    this.update = function(res,req){
        
        //~ console.log(res);
        //~ console.log(req);
        
        if (!req.speed) return;
        
        //~ console.log('test');
        if (!self.prevReq || self.prevReq.fileSended != req.fileSended){
            self.numberFiles.textContent = (req.fileSended + 1) + '/' + req.fileCount;
        }
        
        let percent = Math.round(req.all.progress * 100) + '%';
        self.totalPercent.textContent = percent;
        self.speed.textContent = '('+ AJAX_Class.readableFileSize(req.speed) +'/s )';
        self.totalBarProgress.style.width = percent;
        
        self.prevReq = Object.assign({}, req);
        
        if (!self.files.hidden) self.updateCurrentFile();
    };
    this.updateCurrentFile = function(){
        // current file progress
        //~ console.log(this.prevReq);
        let req = this.prevReq;
        let filename = req.current.name;
        let currentPercent = Math.round(req.current.progress * 100) + '%';
        this.files.lst[filename].percent.textContent = currentPercent;
        this.files.lst[filename].barProgress.style.width = currentPercent;
    };
    
    this.stop = function(evt){
        if (self.prevReq){
            self.prevReq.pauseFile();
            // DOM_Class.AddClass(this.btn_stop, 'hidden');
            DOM_Class.RemoveClass(self.btn_play, 'hidden');
        }
    };
    this.play = function(evt){
        if (self.prevReq){
            self.prevReq.reprendreFile();
            DOM_Class.AddClass(self.btn_play, 'hidden');
            DOM_Class.RemoveClass(self.btn_stop, 'hidden');
        }
    };
    this.cancel = function(evt){
        if (self.prevReq){
            self.prevReq.cancelFile(()=>{
                self.hide();
                // sp3_job.cleanBar();
                // sp3_job.initBar();
            });
        }
    };

    this.show(files,parent,domId);
};
UI_Upload_Progress.tl = [];

function inputCopyToClipboard(id,popup=true,html=false){
    let inp = document.getElementById(id);
    // Select the text field
    inp.select();
    if (isMobile){
        inp.setSelectionRange(0, 99999); // For mobile devices
    }
    // Copy the text inside the text field
    if (html){
        if(typeof ClipboardItem === "undefined") {
            //ff polyfill
            const el = document.createElement('textarea');
            el.value = inp.value;
            document.body.appendChild(el);
            el.select();
            el.addEventListener('copy', (event) => {
                event.clipboardData.setData('text/html',content);
            });
            const result = document.execCommand('copy');
            document.body.removeChild(el);
        }else{
            const blob = new Blob([inp.value], { type: "text/html" });
            const richTextInput = new ClipboardItem({ "text/html": blob });
            navigator.clipboard.write([richTextInput]);
        }
    }else{
        navigator.clipboard.writeText(inp.value);
    }
    if(popup){
        popup=(GENERICS_Class.IsString(popup))?popup:'Copied to clipboard';
        UI_Class.MessagePopup(popup);
    }   
}
function copyToClipboard(content,popup=true,html=false){
    // Copy the text inside the text field
    if (html){
        // if(typeof ClipboardItem === "undefined") {
            //ff polyfill
            const el = document.createElement('textarea');
            el.value = content;
            document.body.appendChild(el);
            el.select();
            el.addEventListener('copy', (event) => {
                event.clipboardData.setData('text/html',content);
            });
            const result = document.execCommand('copy');
            document.body.removeChild(el);
        // }else{
        //     const blob = new Blob([content], { type: "text/html" });
        //     // const richTextInput = new ClipboardItem({ "text/html": blob });
        //     // navigator.clipboard.write([richTextInput]);
        //     let data = [new ClipboardItem({ [blob.type]: blob })];
        //     navigator.clipboard.write(data);
        // }
    }else{
        navigator.clipboard.writeText(content);
    }
    if(popup){
        popup=(GENERICS_Class.IsString(popup))?popup:'Copied to clipboard';
        UI_Class.MessagePopup(popup);
    }   
}
var UI_Precomplete = function(domId, data, submitOnChange){
    // console.log(domId, data, submitOnChange);
    var self = this;

    this.domID = domId;
    this.data = data;
    this.submit = (submitOnChange) ? submitOnChange : false;

    this.init = function(){
        this.list = document.getElementById(this.domID + '_list');
        this.input_txt = document.getElementById(this.domID + '_input_search');
        $_e.AddEventKey(this.input_txt, this.changeInput);
        $_e.AddEvent(this.input_txt, 'focus', this.focusIn);
        // $_e.AddEvent(this.input_txt, 'blur', this.focusOut);
        this.value = document.getElementById(this.domID + '_value');
        this.form  = this.value.form;

        // elements when clicked on don't close the list (validatorDiv parent, precomplete search block, label before)
        this.keep_focus_elem = [];
        this.keep_focus_elem.push(document.getElementById(this.domID + '_input_search_label'), this.list);

        if (this.data){
            this.data.forEach((row,index) =>{
                row.domElem = document.getElementById(this.domID + '_row_' + row.id);
                row.domElem.dataset.key = index;
                $_e.AddEventClick(row.domElem, this.onClickRow);
                this.keep_focus_elem.push(row.domElem);
            });
        }
    };
    this.onClickRow = function(evt){
        self.focusOut(evt, false, true);
        let index = evt.target.dataset.key;
        self.value.value = self.data[index].id; // change the value in the hidden field (the submitted one)
        self.input_txt.value = self.data[index].name; // change the value in the input field
        
        if (self.submit){ // auto submit form
            if (GENERICS_Class.IsString(self.submit)){
                eval(self.submit);
            } else {
                $_e.SendEvent(self.form, 'submit');
            }
        }
    };
    this.changeInput = function(evt){
        let currentVal = evt.target.value;
        
        self.data.forEach((row)=>{
            if (currentVal == '' || row.name.includes(currentVal)){
                DOM_Class.ToggleClass(row.domElem, 'hidden', false);
            } else {
                DOM_Class.ToggleClass(row.domElem, 'hidden', true);
            }
        });
    };
    this.focusIn = function(evt){
        $_e.StopEvent(evt);
        DOM_Class.ToggleClass(self.list, 'hidden', false);
        $_e.AddEventClickOutside(self.input_txt, self.focusOut);
    };
    this.focusOut = function(evt, otherEvt=false, force=false){
        if (self.keep_focus_elem.indexOf(evt.target) == -1 || force){
            DOM_Class.ToggleClass(self.list, 'hidden', true);
            $_e.RemoveEventClickOutside(self.input_txt, self.focusOut);
        }
    };
    this.init();
};
var VALIDATOR_Class = function(){};
VALIDATOR_Class.prototype.constructor = VALIDATOR_Class;
//~ class VALIDATOR_Class{
    //~ constructor() {
        
    //~ }
//~ }
VALIDATOR_Class.dateSeparator = ' / ';

VALIDATOR_Class.usernameValidString = CONSTANTS && CONSTANTS.usernameValidString ? CONSTANTS.usernameValidString : 'abcdefghijklmnopqrstuvwxyz-ABCDEFGHIJKLMNOPQRSTUVWXYZ_0123456789';
VALIDATOR_Class.alphaValidString = ' abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
VALIDATOR_Class.integerValidString = '-0123456789';
VALIDATOR_Class.floatValidString = '-0123456789.,';

VALIDATOR_Class.OK = 0;
VALIDATOR_Class.tooSmall = 1;
VALIDATOR_Class.tooBig = 2;

VALIDATOR_Class.modal = null;

VALIDATOR_Class.translated = {
    'fr': {
        'err_form': 'Problème avec le formulaire :',
        'err_red': 'Veuillez remplir les champs bordés de rouge.',
        'close': 'Fermer',
        'required_field': 'Champ requis',
        'invalid_content': 'Contenu invalide',
        'short_content': 'Contenu trop court',
        'long_content': 'Contenu trop long',
        'out_of_bounds': 'Contenu hors limites'
    },
    'en': {
        'err_form': 'Problem with form :',
        'err_red': 'Please complete the fields lined with red.',
        'close': 'Close',
        'required_field': 'Required field',
        'invalid_content': 'Invalid content',
        'short_content': 'Content is too short',
        'long_content': 'Content is too long',
        'out_of_bounds': 'Value is out of bounds'
    },
    'de': {
        'err_form': 'Problem mit dem Formular :',
        'err_red': 'Bitte füllen Sie die rot umrandeten Felder aus.',
        'close': 'Schließen',
        'required_field': 'Champ requis',
        'invalid_content': 'Contenu invalide',
        'short_content': 'Contenu trop court',
        'long_content': 'Contenu trop long',
        'out_of_bounds': 'Contenu hors limites'
    },
    'es': {
        'err_form': 'Problema con la forma :',
        'err_red': 'Complete los campos bordeados de rojo.',
        'close': 'Cerrar',
        'required_field': 'Champ requis',
        'invalid_content': 'Contenu invalide',
        'short_content': 'Contenu trop court',
        'long_content': 'Contenu trop long',
        'out_of_bounds': 'Contenu hors limites'
    }
};

// to limit the fields when entering, take a look at : https://www.w3.org/TR/DOM-Level-3-Events/#event-type-beforeinput

VALIDATOR_Class.prototype.parseFields = function(formDomObject){
    if (GENERICS_Class.IsString(formDomObject)){
        let test = document.getElementById(formDomObject);
        if (test){
            formDomObject = test;
        } else {
            setTimeout(()=>{this.parseFields(formDomObject);},100);
            formDomObject = false;
        }
    }
    
    if(!formDomObject){
        console.log('Form not found...');
        return false;
    }

    let lst = formDomObject.elements;

    formDomObject._validator = this;

    EVENTS_Class.RemoveAllEvents(formDomObject);

    EVENTS_Class.AddEvent(formDomObject,'submit',this.onSubmitForm);

    var previous_field = null;
    var first_field = null;

    for(let i = 0 ; i < lst.length ; i++){
        let input = lst[i];
        
        this.displayErrorField(input,[]);
        
        // skip tinymce fields or unidentified fields
        let parent_id = input.parentNode.getAttribute('id');
        if(parent_id){
            if(parent_id.substr(0,4)=='mce_' || parent_id.substr(0,5)=='mceu_' || input.id.substr(0,4)=='mce_' || input.id.substr(0,5)=='mceu_' || (!input.id && !input.name)){
                //console.log('skip',input.id);
                continue;
            }
        }

        if(!this.protectInput(input)){
            continue;
        }

        if(!first_field){
            first_field = input;
        }

        if(previous_field){
            input._prev = previous_field;
            previous_field._next = input;
        }
        previous_field = input;
    }

    if(first_field){
        first_field._prev = previous_field;
        previous_field._next = first_field;
    }

    //~ setTimeout(this.checkForm , 100 , formDomObject);
};

VALIDATOR_Class.prototype.protectInput = function(input){

    let type = input.getAttribute('data-type') || input.type;

    input._validator = this;
    if (type != 'submit' || type != 'button') input.classList.toggle('validatorField',true);
    input._originalValue = input.value;

    //~ EVENTS_Class.RemoveAllEvents(input);

    switch(type){
        case 'hidden':
            return false;

        case 'textarea':
        case 'text':
        case 'password':
        case 'email':
        case 'select-one':
            EVENTS_Class.AddEvent(input , 'change' , this.checkEventText);
            EVENTS_Class.AddEvent(input , 'keydown' , this.checkEventText);
            EVENTS_Class.AddEvent(input , 'blur' , this.checkEventText);
            EVENTS_Class.AddEvent(input , 'input' , this.checkEventValidity);
        break;

        case 'int':
        case 'float':
            EVENTS_Class.AddEvent(input , 'change' , this.checkEventText);
            EVENTS_Class.AddEvent(input , 'keydown' , this.checkEventText);

            EVENTS_Class.AddEvent(input , 'blur' , this.checkEventLimits);
            EVENTS_Class.AddEvent(input , 'input' , this.checkEventValidity);
        break;

        case 'date':
            EVENTS_Class.AddEvent(input , 'change' , this.checkEventDate);
        break;
    }

    EVENTS_Class.AddEvent(input , 'dblclick' , EVENTS_Class.StopPropagation);


    //~ switch(type){
        //~ case 'textarea':
        //~ case 'text':
        //~ case 'password':
        //~ case 'int':
        //~ case 'float':
        //~ case 'date':
        //~ case 'email':

            //~ let inputStyle = window.getComputedStyle(input);

            //~ let offsetHeight = input.offsetHeight;

            //~ let icon = document.createElement('DIV');

            //~ if(input._tinymce){
                //~ let tiny_container = input._tinymce.editorContainer;

                //~ if(tiny_container){
                    //~ tiny_container.style.display = 'inline-block';
                    //~ tiny_container.style.verticalAlign = 'middle';
                    //~ offsetHeight = tiny_container.offsetHeight;

                    //~ tiny_container.insertAdjacentElement('afterend',icon);
                //~ }
            //~ }else{
                //~ input.insertAdjacentElement('afterend',icon);
            //~ }

            //~ icon.classList.toggle('validatorIcon',true);
            //~ let style = window.getComputedStyle(icon);

            //~ let bs = parseInt(style.borderLeftWidth);

            //~ let height = (offsetHeight-bs*2);
            //~ icon.style.height = height+'px';
            //~ icon.style.width = Math.min(20,height)+'px';

            //~ input._validatorIcon = icon;

            //~ // TODO : completely clear these icons and replace them with a tooltip
            //~ //grumph not so sure...
            //~ icon.style.display = 'none';

        //~ break;
    //~ }

    return true;
};

VALIDATOR_Class.prototype.onSubmitForm = function(event,confirmed = undefined){
    //~ console.log(event);

    let formDomObject = event.currentTarget;
    
    if (event.submitter) formDomObject._submitter = event.submitter;

    if(formDomObject._disableNextSubmit){
        EVENTS_Class.StopEvent(event);
        formDomObject._disableNextSubmit = false;
        return false;
    }

    let validator = formDomObject._validator;
    let test = validator.checkForm(formDomObject);

    if(!test){
        EVENTS_Class.StopEvent(event);
/*
        if (!validator.modal){

            let cur_lng = CONSTANTS.current_lang_iso;
            validator.modal = UI_Class.AddWindow(null, {'modal': true, 'nodrag': true, 'close': CONSTANTS.GetText('close'), 'special': true, 'special_level': 'err'});

                // modal's content
                let container_info = DOM_Class.CreateElement('DIV', {'class': 'validator_info_container'});
                let msg_err = DOM_Class.CreateElement('DIV', {'class': 'validator_info_general'}, CONSTANTS.GetText('err_form'));
                DOM_Class.AppendContent(container_info, msg_err);

                let container_spe = DOM_Class.CreateElement('DIV', {'class': 'validator_info_spe_container'});
                let spe = DOM_Class.CreateElement('DIV', {'class': 'validator_info_spe'}, CONSTANTS.GetText('err_red'));
                DOM_Class.AppendContent(container_spe, spe);

                DOM_Class.AppendContent(container_info, container_spe);

            validator.modal.SetContent(container_info);
            validator.modal.SetParent(document.body);
            validator.modal.domElement.classList.add('err_form');

        } else {
            validator.modal.Show();
        }
*/
        if(validator.error_field){
            validator.error_field.focus();
        }

        return false;
    }else{

        EVENTS_Class.StopEvent(event);

        if(formDomObject._submitter){
            if (formDomObject._submitter.dataset.withtoken){
                let id = formDomObject.id + '-token';
                let inpHidden = document.getElementById(id);
                if (!inpHidden){
                    UI_Class.getToken(event, formDomObject);
                    return;
                }
            } 
            
            let tmp = formDomObject._submitter.getAttribute('data-submit_function');
            if(tmp){
                submit_handler_name = tmp;
            }

            let confirm_message = formDomObject._submitter.getAttribute('data-confirm');
            if(confirm_message){
                UI_Class.ConfirmPopup(confirm_message, ()=>{validator.onSubmitFormConfirmed(formDomObject);}, null);
                return false;
            }else{
                validator.onSubmitFormConfirmed(formDomObject);
            }
        }else{

            validator.onSubmitFormConfirmed(formDomObject);
        }

    }

    return true;
};

VALIDATOR_Class.prototype.onSubmitFormConfirmed = function(formDomObject){
    var settings = {};

    let submit_handler_name = formDomObject.getAttribute('data-submit_function');
    let dom_target_name = formDomObject.getAttribute('data-dom_target');

    if(dom_target_name){
        
        if(dom_target_name == '.parent'){
            settings.dom_target = formDomObject.parentNode;
        }else{
            let dom_target = document.getElementById(dom_target_name);
            if(dom_target){
                settings.dom_target = dom_target;
            }
        }
    }

    let upload_tinymce = false;
    if(formDomObject._submitter){

        if(formDomObject._submitter.getAttribute('data-tinymce_save')){
            if(tinymce && tinymce.activeEditor){
                tinymce.triggerSave();
                upload_tinymce = true;
            }
        }

        // if a target is specified in the submit button
        // it replaces the one on the form
        let dom_target_name = formDomObject._submitter.getAttribute('data-dom_target');

        if(dom_target_name){
            let dom_target = document.getElementById(dom_target_name);
            if(dom_target){
                settings.dom_target = dom_target;
            }
        }
        //~ console.log(dom_target_name);
        // send only the data set in the submit button
        let tmp = formDomObject._submitter.getAttribute('data-only');
        if(tmp){
            settings.data = {};
            // action / value of the submit button
            settings.data[formDomObject._submitter.name] = formDomObject._submitter.value;

            // add fields that must always be posted
            for(let i = 0; i < formDomObject.length ;i++){
                let input = formDomObject[i];
                if(input.getAttribute('data-alwaysposted')){
                    settings.data[input.name] = input.value;
                }
            }

            // if a select is used for the submit  of the form
            // it can (and should) contain two attributes to determine the action to be taken
            // data-actionname = name of the variable to post (equivalent to the name of a submit button)
            // data-actionvalue = value to post in this variable (equivalent to the value of a submit button)
            //
            // it also works with any other input
            let actionName = formDomObject._submitter.getAttribute('data-actionname');
            if(actionName){
                let actionValue = formDomObject._submitter.getAttribute('data-actionvalue');
                if(actionValue !== null){
                    settings.data[actionName] = actionValue;
                }
            }

        }else{
            settings.data = formDomObject;
        }
        
        let extra_parameters = formDomObject._submitter.dataset.parameters;
        if(extra_parameters){
            extra_parameters = JSON.parse(extra_parameters);
            if(GENERICS_Class.IsFilledObject(extra_parameters)){
                settings.extra_data = GENERICS_Class.MergeObjects(settings.extra_data,extra_parameters);
            }
        }

        // use the action from the submit button if one is defined
        settings.url = formDomObject._submitter.getAttribute('action') || formDomObject.getAttribute('action');

    }else{
        settings.data = formDomObject;
        settings.url = formDomObject.getAttribute('action');
    }

    if(upload_tinymce){
        // tinymce images must be uploaded before the form is submitted
        tinymce.activeEditor.uploadImages(function(success) {
            if(submit_handler_name){
                let func = window[submit_handler_name];
                if(typeof func == 'function'){
                    // EVENTS_Class.StopEvent(event);
                    func(settings);
                }else{
                    console.log('Invalid submit function');
                }
            }else{
                $_a.send(settings);
            }
        });
    }else{

        if(submit_handler_name){
            let func;
            if (submit_handler_name.includes('.')){
                submit_handler_name = submit_handler_name.split('.');
                //~ console.log(window[submit_handler_name[0]]);
                //~ console.log(window[submit_handler_name[0]][submit_handler_name[1]]);
                func = window[submit_handler_name[0]][submit_handler_name[1]];
            } else {
                func = window[submit_handler_name];
            }
            
            if(typeof func == 'function'){
                // EVENTS_Class.StopEvent(event);
                func(settings);
            }else{
                console.log('Invalid submit function');
            }

        }else{

            $_a.send(settings);
        }
    }
    return false;
};

VALIDATOR_Class.prototype.SendForm = function(settings){
    $_a.send(settings);
};

VALIDATOR_Class.prototype.checkForm = function(formDomObject){

    let lst = formDomObject.elements;
    let validator = formDomObject._validator;
    let submitter = formDomObject._submitter;
    let errorCount = 0;

    this.error_field = null;

    let only_submiter = false;
    if(submitter){
        only_submiter = submitter.getAttribute('data-only') !== null;
        if(submitter.getAttribute('data-cancel') !== null){
            return true;
        }
    }

    for(let i = 0 ; i < lst.length ; i++){

        let field = lst[i];
        
        //~ if (validator.firstTime){
            //~ validator.displayErrorField(field,[]);
            //~ validator.firstTime = false;
        //~ } else {
            
        //~ }
        
        //~ let parent = document.getElementById(id+'_parent');
        //~ if (!parent){
            //~ moved = true;
            //~ parent = DOM_Class.CreateElement('DIV',{'id':id+'_parent', 'class':'validatorParent'});
            //~ DOM_Class.InsertAfter(parent,input);
            //~ DOM_Class.AppendContent(parent, input);
            //~ input.focus();
        //~ }

        if(only_submiter && field.getAttribute('data-alwaysposted') === null){
            continue;
        }

        if (field.tagName == 'FIELDSET'){   // fieldset doesn't need validation
            continue;
        }

        if(!validator.checkField(field)){
            if(!this.error_field){
                this.error_field = field;
            }
            errorCount++;
        }
    }

    return errorCount === 0;
};

VALIDATOR_Class.prototype.checkField = function(input){

    let validator = input._validator;
    if(!validator){
        return true;
    }

    let type = input.getAttribute('data-type') || input.type;
    if(type == "submit"){
        return true;
    }

    let test = true;
    let formDomObject = input.form;
    let icon = input._validatorIcon;
    
    let err_list = [];

    let sizeTest = validator.evaluateSize(input);
    let required = input.getAttribute('data-required') !== null ? parseInt(input.getAttribute('data-required')) > 0 : false;
    let optional = input.getAttribute('data-optional') !== null ? parseInt(input.getAttribute('data-optional')) > 0 : false;

    if(optional && input.value == ''){
        return true;
    }

    // replace tinymce \n
    let parent_id = input.parentNode.getAttribute('id');
    if(input.id){
        if(input.id.substr(0,8)=='tinymce_'){
            input.value = input._tinymce.getContent({format: 'raw'}).replace(/data-mce(.*?)"(.*?)"/g, '');
        }
    }

    // original field
    // input = confirmation field
    let checkfield_id = input.getAttribute('data-checkfield');
    if(checkfield_id){
        let checkfield = document.getElementById(checkfield_id);
        if(checkfield){
            let ok = true;
            // if the original field has changed :
            if(checkfield._originalValue != checkfield.value && checkfield.value != input.value){
                
                ok = false;
            }else if(input.value.length > 0 && checkfield.value != input.value){
                ok = false;
            }

            if(ok){
                input.classList.toggle('wrong',false);
                input.classList.toggle('good',required);
            }else{
                input.classList.toggle('wrong',true);
                input.classList.toggle('good',false);
                return false;
            }
        }
    }

    let confirm_id = input.getAttribute('data-confirmfield');
    if(confirm_id){
        let confirm = document.getElementById(confirm_id);
        if(confirm){
            let ok = true;
            if(input._originalValue != input.value){
                if(confirm.value != input.value){
                    ok = false;
                }
            }else{
                if(confirm.value.length > 0 && confirm.value != input.value){
                    ok = false;
                }
            }
            if(ok){
                input.classList.toggle('wrong',false);
                input.classList.toggle('good',true);
                confirm.classList.toggle('wrong',false);
            }else{
                confirm.classList.toggle('wrong',true);
                confirm.classList.toggle('good',false);
            }
        }
    }

    if(input.value === '' && !required && sizeTest == VALIDATOR_Class.OK){
        input.classList.toggle('wrong',false);
        input.classList.toggle('good',false);
        if(icon){
            icon.classList.toggle('wrong',false);
            icon.classList.toggle('good',false);
        }
        return true;
    }

    switch(type){
        case 'text':
        case 'textarea':
        case 'password':
            let restriction = input.getAttribute('data-restrict');
            let exclusion = input.getAttribute('data-exclude');
            test = validator.checkText(input.value,restriction,exclusion);
        break;

        case 'int':
            test = validator.checkInt(input.value);
        break;

        case 'float':
            test = validator.checkFloat(input.value);
        break;

        case 'date':
            test = validator.checkDate(input.value);
        break;

        case 'email':
            test = validator.checkEmail(input.value);
        break;

    }


    if(icon){
        icon.title = '';
        input.title = '';
    }

    let length = input.value.trim().length;
    if (input.type == 'checkbox' && !input.checked) {
        length = 0;
    }
    let cur_lng = CONSTANTS.current_lang_iso;

    if(!test){
        if(icon){ icon.title += CONSTANTS.GetText('invalid_content'); }
        input.title += CONSTANTS.GetText('invalid_content');
        
        err_list.push('invalid_content');
    }
    
    if(length === 0 && required){
        // nothing entered in a required field.
        test = false;
        if(icon){ icon.title = CONSTANTS.GetText('required_field')+'\n'; }
        input.title = CONSTANTS.GetText('required_field')+'\n';
        
        err_list.push('required_field');
    }

    //let sizeTest = validator.evaluateSize(input);
    if(sizeTest !== VALIDATOR_Class.OK){
        test = false;
        if(sizeTest == VALIDATOR_Class.tooSmall){
            if(icon){ icon.title += CONSTANTS.GetText('short_content'); }
            input.title += CONSTANTS.GetText('short_content');
            err_list.push('short_content');
        }
        if(sizeTest == VALIDATOR_Class.tooBig){
            if(icon){ icon.title += CONSTANTS.GetText('long_content'); }
            input.title += CONSTANTS.GetText('long_content');
            err_list.push('long_content');
        }

    }

    if(type == 'int' || type=='float'){
        if(validator.checkInputLimits(input) !== VALIDATOR_Class.OK){
            test = false;
            if(icon){ icon.title += CONSTANTS.GetText('out_of_bounds'); }
            input.title += CONSTANTS.GetText('out_of_bounds');
            
            err_list.push('out_of_bounds');
        }
    }

    if(test && input.value !== ''){

        input.classList.toggle('wrong',false);
        input.classList.toggle('good',true);

        if(icon){
            icon.classList.toggle('wrong',false);
            icon.classList.toggle('good',true);
        }
    }else if(!test){

        input.classList.toggle('wrong',true);
        input.classList.toggle('good',false);

        if(icon){
            icon.classList.toggle('wrong',true);
            icon.classList.toggle('good',false);
        }
    }
    
    validator.displayErrorField(input, err_list);

    return test;
};

VALIDATOR_Class.prototype.displayErrorField = function(input,err_list){
    //~ console.log(input);
    //~ console.log(err_list);
    if (input.type == 'hidden' || input.tagName == 'FIELDSET' || input.tagName == 'BUTTON' || input.type == 'button') return;
    if (input._tinymce) return;
    
    if (input.id == ''){
        input.id = GENERICS_Class.GetUniqueId();
    }
    let id = input.id;
    
    let parent = document.getElementById(id+'_parent');
    if (!parent){
        moved = true;
        parent = DOM_Class.CreateElement('DIV',{'id':id+'_parent', 'class':'validatorParent'});
        DOM_Class.InsertAfter(parent,input);
        DOM_Class.AppendContent(parent, input);
        //~ input.focus();
    } else {
        while (parent.lastChild && parent.lastChild.tagName != 'INPUT' && parent.lastChild.tagName != 'SELECT' && parent.lastChild.tagName != 'TEXTAREA'){
            DOM_Class.RemoveElement(parent.lastChild);
        }
    }
    
    if (err_list.length > 0){
        err_list.forEach((tl)=>{
            let msg = DOM_Class.CreateElement('DIV',{'class':'msg_err'},CONSTANTS.GetText(tl));
            DOM_Class.AppendContent(parent, msg);
        });
    }
    
    //~ input.focus();
};

VALIDATOR_Class.prototype.badFieldModal = function(input){
    let validator = input._validator;
    if (!validator.modal) validator.modal = [];
    if (!validator.modal[input.name]){
        let cur_lng = CONSTANTS.current_lang_iso;
        validator.modal[input.name] = UI_Class.AddWindow(null, {'modal': true, 'nodrag': true, 'class': 'modal_validator_info','id':input.name+'_validator'});

            // modal's content
            let container_info = DOM_Class.CreateElement('DIV', {'class': 'validator_info_container'});
            let msg_err = DOM_Class.CreateElement('DIV', {'class': 'validator_info_general'}, CONSTANTS.GetText('required_field'));
            DOM_Class.AppendContent(container_info, msg_err);

        validator.modal[input.name].SetContent(container_info);
        DOM_Class.InsertAfter(validator.modal[input.name].domElement, input);
        let rect = DOM_Class.GetGlobalRect(input);
        console.log(rect);
        DOM_Class.SetPosition(validator.modal[input.name].domElement, rect.right, rect.y-rect.height);
        
        //~ validator.modal.SetParent(document.getElementById('lemain'));
        //~ validator.modal.domElement.classList.add('err_form');

    } else {
        validator.modal[input.name].Show();
    }

    if(validator.error_field){
        validator.error_field.focus();
    }
};


VALIDATOR_Class.prototype.checkEmail = function(email){
  var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  return re.test(email);
};

VALIDATOR_Class.prototype.checkEventDate = function(event){
    
    let input = event.target;
    let validator = input._validator;
    
    validator.checkField(input);
    return;
    
    
/*
    let chunks = input.value.split(VALIDATOR_Class.dateSeparator);
    if(chunks.length != 3){
        chunks = ['01','01','1900'];
        input.value = chunks.join(VALIDATOR_Class.dateSeparator);
    }
    let currentValue = input.value;

    let minimums = [1,1,1900];
    let maximums = [31,12,9999];
    let paddings = ['00','00','0000'];

    let positions = [];
    let cumul = 0;



    for(let i = 0; i < chunks.length ; i++){
        cumul += chunks[i].length;
        positions.push(cumul);
        cumul += 3;
        chunks[i] = Math.min(maximums[i],Math.max(isNaN(parseInt(chunks[i]))?minimums[i]:parseInt(chunks[i]) , minimums[i]));
    }

    while(positions.length < 2){
        positions.push(input.value.length);
        input.value += VALIDATOR_Class.dateSeparator;
    }

    let dateIndex = positions.length;
    for(let i = 0 ; i < positions.length ; i++){
        if(input.selectionStart <= positions[i]+1){
            dateIndex = i;
            break;
        }
    }

    let maxDays = new Date(parseInt(chunks[2]), parseInt(chunks[1]), 0).getDate();
    let sepLength = VALIDATOR_Class.dateSeparator;

    maximums[0] = maxDays;

    if(event.type == 'keydown'){

        let s_s = input.selectionStart;
        let s_e = input.selectionEnd;

        let v = parseInt(chunks[dateIndex]);

        if(isNaN(v)){
            v = 0;
        }

        switch(event.keyCode){
            case 8: // backspace

                for(let i = 0 ; i < positions.length ; i++){
                    if(input.selectionStart >=positions[i]+1 && input.selectionStart <= positions[i]+sepLength){
                        EVENTS_Class.StopEvent(event);
                        return false;
                    }
                }

                return false;

            case 46: // delete
                for(let i = 0 ; i < positions.length ; i++){
                    if(input.selectionStart >=positions[i] && input.selectionStart <= positions[i]+(sepLength-1)){
                        EVENTS_Class.StopEvent(event);
                        return false;
                    }
                }

                return false;

            case 9: // tab
                if(event.shiftKey){
                    dateIndex--;
                    if(dateIndex < 0){
                        return false;
                    }
                }else{
                    dateIndex++;
                    if(dateIndex >= chunks.length){
                        return false;
                    }
                }

                s_s = positions[dateIndex-1]+sepLength;
                s_e = s_s;
                input.selectionStart = s_s;
                input.selectionEnd = s_e;
                EVENTS_Class.StopEvent(event);
                return false;

            case 13: // return
            case 35: // page down
            case 36: // page up
                //case 37: // left
                //case 39: // right
                return false;

            case 38:
                v++;
                if(v > maximums[dateIndex]){
                    if(dateIndex == 2){
                        v = maximums[dateIndex];
                    }else{
                        let j = dateIndex;
                        let w = v;
                        v = minimums[dateIndex];
                        while(j < 2 && w > maximums[j]){
                            j++;
                            w = chunks[j];
                            w++;
                            let n = w;
                            if( n > maximums[j]){
                                n = minimums[j];
                            }
                            chunks[j] = (paddings[j]+n).slice(-paddings[j].length);
                        }
                    }
                }

                chunks[dateIndex] = v;

                if(dateIndex == 1){
                    maxDays = new Date(parseInt(chunks[2]), parseInt(chunks[1]), 0).getDate();
                    if(chunks[0] > maxDays){
                        chunks[0] = maxDays;
                    }
                }

                for(let i = 0; i < chunks.length ; i++){
                    chunks[i] = (paddings[i]+chunks[i]).slice(-paddings[i].length);
                }
                input.value = chunks.join(VALIDATOR_Class.dateSeparator);
                input.selectionStart = s_s;
                input.selectionEnd = s_e;
                EVENTS_Class.StopEvent(event);
                return false;


            case 40:
                v--;
                if(v < minimums[dateIndex]){
                    if(dateIndex == 2){
                        v = minimums[dateIndex];
                    }else{
                        let j = dateIndex;
                        let w = v;
                        v = maximums[dateIndex];
                        while(j < 2 && w < minimums[j]){
                            j++;
                            w = chunks[j];
                            w--;
                            let n = w;
                            if( n < minimums[j]){
                                n = maximums[j];
                            }
                            chunks[j] = (paddings[j]+n).slice(-paddings[j].length);
                            if(j == 1 && dateIndex === 0){
                                v = new Date(parseInt(chunks[2]), parseInt(chunks[1]), 0).getDate();
                            }
                        }
                    }
                }

                chunks[dateIndex] = v;

                if(dateIndex == 1){
                    maxDays = new Date(parseInt(chunks[2]), parseInt(chunks[1]), 0).getDate();
                    if(chunks[0] > maxDays){
                        chunks[0] = maxDays;
                    }
                }

                for(let i = 0; i < chunks.length ; i++){
                    chunks[i] = (paddings[i]+chunks[i]).slice(-paddings[i].length);
                }
                input.value = chunks.join(VALIDATOR_Class.dateSeparator);
                input.selectionStart = s_s;
                input.selectionEnd = s_e;
                EVENTS_Class.StopEvent(event);
                return false;


        }

        if(event.keyCode == 37){
            let currentPos = 0;
            if(input.selectionStart != input.selectionEnd){
                currentPos = input.selectionStart;
            }else{
                currentPos = Math.max(input.selectionStart - 1 , 0);
            }

            for(let i = 0 ; i < positions.length ; i++){
                if(currentPos >= positions[i] && currentPos <= positions[i]+(sepLength-1)){
                    input.selectionStart = positions[i];
                    break;
                }
            }

            return false;
        }

        if(event.keyCode == 39){
            let currentPos = 0;
            if(input.selectionStart != input.selectionEnd){
                currentPos = input.selectionEnd;
            }else{
                currentPos = Math.min(input.selectionEnd + 1 , input.value.length);
            }

            for(let i = 0 ; i < positions.length ; i++){
                if(currentPos > positions[i] && currentPos <= positions[i]+(sepLength-1)){
                    input.selectionStart = positions[i]+(sepLength-1);
                    break;
                }
            }

            return false;
        }

        let restriction = '0123456789';
        if(restriction.indexOf(event.key) == -1){
            EVENTS_Class.StopEvent(event);
            return false;
        }
    }

    if(event.type == 'mouseup'){
        for(let i = 0 ; i < positions.length ; i++){
            if(input.selectionStart > positions[i] && input.selectionStart <= positions[i]+(sepLength-1)){
                input.selectionStart = input.selectionEnd = positions[dateIndex-1]+sepLength;
                break;
            }
        }
    }

    if(event.type == 'focus' || event.type == 'blur'){
        var d = new Date(chunks[2], chunks[1] - 1, chunks[0]);

        if(validator.checkDate(input.value)){
            // ok
        }else{
            chunks[0] = d.getDate();
            chunks[1] = d.getMonth()+1;
            chunks[2] = d.getFullYear();
            for(let i = 0; i < chunks.length ; i++){
                chunks[i] = (paddings[i]+chunks[i]).slice(-paddings[i].length);
            }
            input.value = chunks.join(VALIDATOR_Class.dateSeparator);
        }
        if(event.type == 'focus'){
            input.selectionStart = input.selectionEnd = input.value.length;
        }
    }


    validator.checkField(input);
    //console.log(input.selectionStart,' -> ',input.selectionEnd);
    */
};

VALIDATOR_Class.prototype.checkEventValidity = function(event){
    let input = event.target;
    let validator = input._validator;
    validator.checkField(input);
};

VALIDATOR_Class.prototype.checkDate = function(dateString){
    // TODO : modify to take into account native html date fields
    // useless, they are necessarily valid even if they may be illogical. . .
    // the prepared queries will clean up.
    return true;
};

VALIDATOR_Class.prototype.validateDate = function(dateString){
    let chunks = dateString.split(VALIDATOR_Class.dateSeparator);

    let minimums = [1,1,1900];
    let maximums = [31,12,9999];
    let paddings = ['00','00','0000'];

    for(let i = 0; i < chunks.length ; i++){
        chunks[i] = Math.min(maximums[i],Math.max(isNaN(chunks[i])?0:parseInt(chunks[i]) , minimums[i]));
    }

    let d = new Date(chunks[2], chunks[1] - 1, chunks[0]);
    while(!(d && (d.getMonth() + 1) == parseInt(chunks[1]))){

        d = new Date(chunks[2], chunks[1] - 1, chunks[0]);
    }

    return chunks.join(VALIDATOR_Class.dateSeparator);
};


VALIDATOR_Class.convertStringFilter = function(restriction){
    switch(restriction){
        case '_username':
            restriction = VALIDATOR_Class.usernameValidString;
        break;

        case '_alpha':
            restriction = VALIDATOR_Class.alphaValidString;
        break;

        case '_int':
            restriction = VALIDATOR_Class.integerValidString;
        break;

        case '_float':
        case '_num':
            restriction = VALIDATOR_Class.floatValidString;
        break;
    }

    return restriction;
};

// return false if str contains bad caracters
VALIDATOR_Class.prototype.checkText = function(str,restriction,exclusion){

    restriction = VALIDATOR_Class.convertStringFilter(restriction);
    exclusion = VALIDATOR_Class.convertStringFilter(exclusion);

    if(restriction || exclusion){
        let result = '';
        for(let i = 0 , c = str.length ; i < c ; i++){
            if((restriction && restriction.indexOf(str.charAt(i)) == -1) || (exclusion && exclusion.indexOf(str.charAt(i)) > -1) ){
                return false;
            }
        }
        return true;
    }else{
        return true;
    }
};


// return false if str is not an int value
VALIDATOR_Class.prototype.checkInt = function(str){
    return (!isNaN(parseInt(str)) && parseInt(str)+'' == str+'');
};

// return false if str is not a float value
VALIDATOR_Class.prototype.checkFloat = function(str){
    return !isNaN(parseFloat(str));
};

VALIDATOR_Class.prototype.evaluateSize = function(input){

    let sizemin = parseInt(input.getAttribute('data-sizemin'));
    let sizemax = parseInt(input.getAttribute('data-sizemax'));

    let length = input.value.trim().length;
    let required = input.getAttribute('data-required') !== null ? parseInt(input.getAttribute('data-required')) > 0 : false;

    if(length === 0 && !required){
        return VALIDATOR_Class.OK;
    }

    if(!isNaN(sizemin) && length < sizemin){
        return VALIDATOR_Class.tooSmall;

    }else if(!isNaN(sizemax) && length > sizemax){
        return VALIDATOR_Class.tooBig;
    }

    return VALIDATOR_Class.OK;
};

VALIDATOR_Class.prototype.checkEventText = function(event){

    let input = event.target;
    let type = input.getAttribute('data-type') || input.type;
    let s_s = input.selectionStart;
    let s_e = input.selectionEnd;
    let validator = input._validator;

    if(input.tagName == 'TEXTAREA'){
        switch(event.keyCode){
            case 8: // backspace
            case 9: // tab
            case 46: // delete
                validator.checkField(input);
            break;
        }
        return true;
    }

    switch(event.keyCode){

        case 35: // page down
        case 36: // page up
        case 37: // left
        case 39: // right
            return false;


        case 13: // return
            let auto_submit = input.getAttribute('data-returnsubmit');
            if(auto_submit){

                let form = input.form;
                form._disableNextSubmit = false;

                if(GENERICS_Class.IsString(auto_submit)){
                    let json = null;
                    try{
                        json = JSON.parse(auto_submit);
                    }catch(e){
                    }
                    if(GENERICS_Class.IsObject(json)){
                        let k = Object.keys(json)[0];

                        let submitter = DOM_Class.CreateElement('INPUT',{'name':k , 'value':json[k] , 'type':'hidden'});
                        form._validator.protectInput(submitter);
                        form.appendChild(submitter);

                        AJAX_Class.setFormSubmitter(submitter);

                    }else{
                        for(let i=0; i<form.elements.length ; i++){
                            let e = form.elements[i];
                            if(e.name == auto_submit){
                                AJAX_Class.setFormSubmitter(e);
                                break;
                            }
                        }
                    }
                }

                EVENTS_Class.StopEvent(event);

                EVENTS_Class.SendEvent(form,'submit');

                return false;
            }else{

                let form = input.form;
                form._disableNextSubmit = true;
            }

            return true;

        case 8: // backspace
        case 9: // tab

        case 46: // delete
            validator.checkField(input);
            return false;

        case 38: // up
            let max = parseFloat(input.getAttribute('max'));

            if(type == 'int'){
                if(isNaN(max)){
                    input.value = parseInt(input.value||0)+1;
                }else{
                    input.value = Math.min(parseInt(input.value||0)+1 , max);
                }

                input.selectionStart = s_s;
                input.selectionEnd = s_e;

                EVENTS_Class.StopEvent(event);
                return false;
            }

            if(type == 'float'){
                if(!input.value){
                    input.value = '0.0';
                }
                let comma = '.';
                if(input.value.indexOf(',') > -1){
                    comma = ',';
                }

                let tmp = input.value.split(comma);
                let v = parseInt(tmp[0]);
                if(isNaN(v)){
                    v = 0;
                }
                v++;
                v += (tmp.length>1?'.'+tmp[1]:'.0');
                if(!isNaN(max) && v > max){
                    v = max+'';
                    if(v.indexOf('.') == -1){
                        v += '.0';
                    }
                }
                if(comma != '.'){
                    v = v.replace('.',comma);
                }
                input.value = v;

                input.selectionStart = s_s;
                input.selectionEnd = s_e;

                EVENTS_Class.StopEvent(event);
                return false;
            }

            return true;

        case 40: // down
            let min = parseFloat(input.getAttribute('min'));

            if(type == 'int'){
                if(isNaN(min)){
                    input.value = parseInt(input.value||0)-1;
                }else{
                    input.value = Math.max(parseInt(input.value||0)-1 , min);
                }

                input.selectionStart = s_s;
                input.selectionEnd = s_e;
                EVENTS_Class.StopEvent(event);
                return false;
            }

            if(type == 'float'){
                if(!input.value){
                    input.value = '0.0';
                }
                let comma = '.';
                if(input.value.indexOf(',') > -1){
                    comma = ',';
                }

                let tmp = input.value.split(comma);
                let v = parseInt(tmp[0]);
                if(isNaN(v)){
                    v = 0;
                }
                v--;
                v += (tmp.length>1?'.'+tmp[1]:'.0');
                if(!isNaN(min) && v < min){
                    v = min+'';
                    if(v.indexOf('.') == -1){
                        v += '.0';
                    }
                }
                if(comma != '.'){
                    v = v.replace('.',comma);
                }
                input.value = v;

                input.selectionStart = s_s;
                input.selectionEnd = s_e;
                EVENTS_Class.StopEvent(event);
                return false;
            }

            return true;
    }


    let restriction = input.getAttribute('data-restrict');
    let exclusion = input.getAttribute('data-exclude');

    switch(restriction){
        case '_alpha':
            restriction = VALIDATOR_Class.alphaValidString;
        break;

        default:
            switch(type){
                case 'int':
                    restriction = VALIDATOR_Class.integerValidString;
                    if(event.key=='-' && (input.value.indexOf('-') > -1 || input.selectionStart > 0)){
                        EVENTS_Class.StopEvent(event);
                        return false;
                    }
                break;

                case 'float':
                    restriction = VALIDATOR_Class.floatValidString;
                    if((event.key=='-' && (input.value.indexOf('-') > -1 || input.selectionStart > 0)) || (event.key=='.' || event.key==',') && (input.value.indexOf('.') > -1 || input.value.indexOf(',') > -1) ){
                        EVENTS_Class.StopEvent(event);
                        return false;
                    }
                break;
            }
        break;
    }

    if(event.type == 'keydown'){
        restriction = VALIDATOR_Class.convertStringFilter(restriction);
        exclusion = VALIDATOR_Class.convertStringFilter(exclusion);

        if((restriction && restriction.indexOf(event.key) == -1) || (exclusion && exclusion.indexOf(event.key) > -1)){
            EVENTS_Class.StopEvent(event);
            return false;
        }

    }else{
        if(restriction){
            input.value = validator.restrictString(input.value , restriction , exclusion);
        }
    }

    validator.checkField(input);
};

VALIDATOR_Class.prototype.restrictString = function(str,restriction,exclusion){

    restriction = VALIDATOR_Class.convertStringFilter(restriction);
    exclusion = VALIDATOR_Class.convertStringFilter(exclusion);

    if(restriction || exclusion){
        let result = '';
        for(let i = 0 , c = str.length ; i < c ; i++){
            if((restriction && restriction.indexOf(str.charAt(i)) > -1) || (exclusion && exclusion.indexOf(str.charAt(i)) == -1) ){
                result += str.charAt(i);
            }
        }
        return result;
    }else{
        return str;
    }
};

VALIDATOR_Class.prototype.checkEventLimits = function(event){
    let validator = event.target._validator;
    validator.applyInputLimits(event.target);
};

VALIDATOR_Class.prototype.applyInputLimits = function(input){

    let s_s = input.selectionStart;
    let s_e = input.selectionEnd;
    let min,max,v;
    switch(input.getAttribute('data-type')){
        case 'float':

            min = parseFloat(input.getAttribute('min'));
            max = parseFloat(input.getAttribute('max'));
            v = parseFloat(input.value);

            if(!isNaN(min) && v < min){
                input.value = min;
            }

            if(!isNaN(max) && v > max){
                input.value = max;
            }
            input.selectionStart = s_s;
            input.selectionEnd = s_e;
        break;

        case 'int':
            min = parseInt(input.getAttribute('min'));
            max = parseInt(input.getAttribute('max'));
            v = parseInt(input.value);

            if(!isNaN(min) && v < min){
                input.value = min;
            }

            if(!isNaN(max) && v > max){
                input.value = max;
            }
            input.selectionStart = s_s;
            input.selectionEnd = s_e;
        break;
    }
};

VALIDATOR_Class.prototype.checkInputLimits = function(input){

    let min,max,v;
    switch(input.getAttribute('data-type')){
        case 'float':

            min = parseFloat(input.getAttribute('min'));
            max = parseFloat(input.getAttribute('max'));
            v = parseFloat(input.value);
        break;

        case 'int':
            min = parseInt(input.getAttribute('min'));
            max = parseInt(input.getAttribute('max'));
            v = parseInt(input.value);
        break;
    }

    if(!isNaN(min) && !isNaN(v) && v < min){
                return VALIDATOR_Class.tooSmall;
    }

    if(!isNaN(max) && !isNaN(v) && v > max){
        return VALIDATOR_Class.tooBig;
    }

    return VALIDATOR_Class.OK;
};
var SPD_hierarchy = function(domElementOrID){
    this.domElement = DOM_Class.GetDomElement(domElementOrID);
    this._DirtyList = [];
    this.url = SPD_hierarchy._url;
    this.Parse();
};
SPD_hierarchy.prototype.constructor = SPD_hierarchy;

SPD_hierarchy._url = document.baseURI.split('?')[0].split('#')[0] + 'hierarchy/index.php';
SPD_hierarchy.instance = null;

SPD_hierarchy.Activate = function(domElementOrID , id_structure){
    SPD_hierarchy.instance = new SPD_hierarchy(domElementOrID);
    SPD_hierarchy.instance.id_structure = id_structure;
};

SPD_hierarchy.Parse = function(domElementOrID){
    if(SPD_hierarchy.instance){
        let target = DOM_Class.GetDomElement(domElementOrID);

        if(DOM_Class.HasClass(target,'hierarchy_admin_tree_elem')){
            target = target.parentNode;
        }
        SPD_hierarchy.instance.Parse(target);
    }
};


SPD_hierarchy.ShowModifyStructure = function(evt){
    
    let settings = {};
    settings.url = SPD_hierarchy._url;
    settings.dom_target = 'hierarchy_admin_sub_container';
    settings.skip_container = true;
    settings.data = {
        'hierarchy_action': 'hierarchy_create',
        'hierarchy-structure-id': SPD_hierarchy.instance.id_structure
    };
    $_a.send(settings);
};

// if evt contains an event, it means that we want to display an item to modify
// if evt is empty, that means we want to create a new item
SPD_hierarchy.ShowModifyItem = function(evt){
    let settings = {};
    settings.url = SPD_hierarchy._url;
    settings.dom_target = 'hierarchy_form_item';
    settings.skip_container = true;
    settings.data = {
        'hierarchy_action': 'hierarchy_edit_item',
        
    };
    
    if(evt){
        settings.data['hierarchy-item-id'] = evt.target.dataset.id || 0;
        if(evt.target.dataset.id_tree) settings.data['hierarchy-structure-id_tree'] = evt.target.dataset.id_tree;
    }else{
        settings.data['hierarchy-structure-id_parent'] = SPD_hierarchy.instance.id_structure;
    }
    
    
    $_a.send(settings);
    
};
SPD_hierarchy.DeleteStructure = function(id_structure){

    let ok_handler = function(){
        let settings = {};
        settings.url = SPD_hierarchy._url;
        settings.data = {
            'hierarchy_action': 'hierarchy_delete_item',
            'hierarchy-structure-id': id_structure
        };
        $_a.send(settings);
        let domElement = DOM_Class.GetDomElement('item_'+id_structure);
        if(domElement){
            DOM_Class.RemoveElement(domElement);
        }
        if (window.spd2_koldron) spd2_koldron.reloadPreview();
    };

    let c = new UI_Class.ConfirmPopup('Confirmation de la suppression ?',ok_handler);

    
};

SPD_hierarchy.toggleChoiceImg = function(evt){
    let targ = document.getElementById(evt.target.dataset.target);
    let prev = targ.nextElementSibling;
    if (evt.target.checked == true){
        targ.style.display = 'block';
    }else{
        targ.style.display = 'none';
    }
};

// update the content of a three item after modification
// if only id_structure is specified, it means updating an element already present in the arbo
// if there is id_structure and id_parent, it is that we have just created this element, then we must create its html tag in the parent tree
SPD_hierarchy.RefreshItem = function(id_structure , id_parent){

    let settings = {};
    settings.url = SPD_hierarchy._url;
    settings.dom_target = 'item_'+id_structure;
    settings.replace_dom_target = true;
    settings.skip_container = true;

    if(id_parent){
        let target = DOM_Class.GetDomElement(settings.dom_target);
        if(!target){
            let parent = DOM_Class.GetDomElement('item_'+id_parent);
            let sub_container;
            if(parent){
                sub_container = DOM_Class.FindChildByClassName(parent , 'hierarchy_admin_tree_parent');
            }else{
                sub_container = DOM_Class.GetDomElement('hierarchy_tree_root');
            }

            if(sub_container){
                target = DOM_Class.CreateElement('li',{'id':settings.dom_target});
                sub_container.appendChild(target);
            }   
            
        }

        if(!target){
            console.log('refresh error');
            debugger;
            return;
        }
    }

    settings.data = {
        'hierarchy_action': 'hierarchy_refresh_structure',
        'hierarchy-structure-id': id_structure
    };

    settings.success = function(){
        SPD_hierarchy.Parse(settings.dom_target);
    };
    
    $_a.send(settings);
};

// update of an item that represents a tree structure internal to the item’s module (DATA TREE)
SPD_hierarchy.RefreshSubItem = function(id_structure){

    let settings = {};
    settings.url = SPD_hierarchy._url;
    settings.dom_target = 'item_sub_'+id_structure;
    settings.replace_dom_target = true;
    settings.skip_container = true;
    settings.data = {
        'hierarchy_action': 'hierarchy_refresh_structure',
        'hierarchy-structure-id_tree': id_structure
    };
    $_a.send(settings);
};




// this function scans the tree to update level values and assign events to items if they do not have them
SPD_hierarchy.prototype.Parse = function(parentNode , level){
    if(!parentNode) parentNode = this.domElement;
    if(!parentNode) return;
    if(!level) level = parseInt(parentNode.dataset.level) || 0;

    let itemList = DOM_Class.FindAllChildrenByClassName(parentNode , 'hierarchy_admin_tree_elem');
    for(let i = 0; i < itemList.length; i++) {
        let item = itemList[i];
        item.dataset.level = level;
        
        if(!EVENTS_Class.HasDrag(item)){

            EVENTS_Class.AddEventDblClick(item, this.onToggleCollapse.bind(this), false);
            EVENTS_Class.EnableDrag(item, this.onStartDrag.bind(this), this.onDragMove.bind(this), this.onDragEnd.bind(this) , this.onMakeAvatar.bind(this) );
            EVENTS_Class.EnableDrop(item, this.onDrop.bind(this) );
        }
        if(item.dataset.internaltree > 0){
            EVENTS_Class.SetDragArea(item , parentNode);
        }

        let sub_container = DOM_Class.FindChildByClassName(item , 'hierarchy_admin_tree_parent');
        
        item._subcontainer = sub_container;

        if(sub_container){
            sub_container.dataset.level = level + 1;
            this.Parse(sub_container , level + 1);
        }
    }
};

SPD_hierarchy.prototype.onToggleCollapse = function(event){
    EVENTS_Class.StopEvent(event);
    DOM_Class.ToggleClass(event.target , 'closed');
};

// this function allows to create a temporary item to be displayed when dragging an item
// it must return a DOM object or a string that contains a correct one
SPD_hierarchy.prototype.onMakeAvatar = function(draggedElement){
    let name = DOM_Class.FindChildByClassName(draggedElement , 'hierarchy_admin_tree_elem_name');
    //~ console.log('<div>'+name.innerHTML+'</div>');
    return '<div>'+name.innerHTML+'</div>';
};

SPD_hierarchy.prototype.onStartDrag = function(event , draggedElement){
    this.lastTarget = null;

    if(draggedElement._subcontainer){
        draggedElement._subcontainer.classList.toggle('drop_disabled' ,true);
    }
};

SPD_hierarchy.prototype.onDragMove = function(event , draggedElement){
    
    let target = event.target;

    if(this.lastTarget && this.lastTarget != target){
        this.lastTarget.classList.toggle('forbidden',false);
        this.lastTarget.classList.toggle('insertBefore',false);
        this.lastTarget.classList.toggle('insertAfter',false);
        this.lastTarget.classList.toggle('insertInside',false);
    }

    if(EVENTS_Class.HasDrop(target)){

        target.classList.toggle('insertBefore',false);
        target.classList.toggle('insertAfter',false);
        target.classList.toggle('insertInside',false);
        target.classList.toggle('forbidden',false);

        let state = this.GetDropState(event , draggedElement);
        if(state !== null){
            target.classList.toggle(state,true);
        }

        this.lastTarget = target;
    }
    
};

// detection of drop possibility and its type if allowed
SPD_hierarchy.prototype.GetDropState = function(event , draggedElement){
    let target = event.target;

    let state = null;
    
    let rect = DOM_Class.GetGlobalRect(target , true);
    let dist_top = Math.abs(rect.top - event.pageY);
    let dist_bottom = Math.abs(rect.bottom - event.pageY);
    
    let dist = Math.min(20 , rect.height / 2);
    let middle = 2;
    
    //~ console.log('near top', dist_top < dist);
    //~ console.log('bottom', dist_bottom);
    //~ console.log('top', dist_top);
    //~ console.log('dist', dist);

    if(dist_top < (dist-middle)){

        if(draggedElement.dataset.internaltree && ( target.parentNode != draggedElement.parentNode) ){
            state = 'forbidden';
        }else{
            state = 'insertBefore';
        }
        

    }else if(dist_bottom < (dist-middle)){
        
        if(draggedElement.dataset.internaltree && ( target.parentNode != draggedElement.parentNode) ) {
            state = 'forbidden';
        }else{
            state = 'insertAfter';
        }
    }else{
        state = 'insertInside';

        if((draggedElement === target) || (draggedElement.dataset.internaltree && target !== draggedElement.parentNode.parentNode) || (target.dataset && target.dataset.internaltree) ){
            state = 'forbidden';

        }
    }

    return state;
};

SPD_hierarchy.prototype.onDragEnd = function(event , draggedElement){

    let target = event.target;

    if(this.lastTarget && this.lastTarget.classList){
        this.lastTarget.classList.toggle('forbidden',false);
        this.lastTarget.classList.toggle('insertBefore',false);
        this.lastTarget.classList.toggle('insertAfter',false);
        this.lastTarget.classList.toggle('insertInside',false);
    }
    this.lastTarget = null;

    if(draggedElement._subcontainer){
        draggedElement._subcontainer.classList.toggle('drop_disabled' ,false);
    }


};

SPD_hierarchy.prototype.onDrop = function(event){
    //console.log("drop on "+event.target.id);
    EVENTS_Class.StopEvent(event);
    let data = EVENTS_Class.ExtractDataFromDropEvent(event);
    
    if(!data.dropData.elements.length) return;

    let draggedElement = data.dropData.elements[0];

    if(!draggedElement) return;
    let target = event.target;
    data.dropData.target = target;
    let state = this.GetDropState(data.dropData , draggedElement);

    switch(state){
        case 'insertBefore':
            DOM_Class.InsertBefore(draggedElement , target);
            this.Parse(draggedElement.parentNode);
            
            // as the order is changed, all items at the same level as this one must be updated
            this.SetDirty(draggedElement.parentNode.childNodes);
        break;

        case 'insertAfter':
            DOM_Class.InsertAfter(draggedElement , target);
            this.Parse(draggedElement.parentNode);
            
            // cas the order is changed, all items at the same level as this one must be updated
            this.SetDirty(draggedElement.parentNode.childNodes);
        break;

        case 'insertInside':
            target._subcontainer.appendChild(draggedElement);
            this.Parse(draggedElement.parentNode);
            
            // as the order is changed, all items at the same level as this one must be updated
            this.SetDirty(draggedElement.parentNode.childNodes);
        break;
    }

    return false;
};

// add items to update in the queue
SPD_hierarchy.prototype.SetDirty = function(domElement){
    
    let added = false;

    if(domElement.length){
        for(let i =0;i<domElement.length;i++){
            if(this._DirtyList.indexOf(domElement[i]) < 0){
                if(DOM_Class.HasClass(domElement[i],'hierarchy_admin_tree_elem')){
                    this._DirtyList.push(domElement[i]);
                    added = true;
                }
                
            }
        }

    }else{
        if(this._DirtyList.indexOf(domElement) < 0){

            if(DOM_Class.HasClass(domElement,'hierarchy_admin_tree_elem')){
                this._DirtyList.push(domElement);
                added = true;
            }
        }
    }

    if(added || this._DirtyList.length > 0){
        this._dirtyTimeout = clearTimeout(this._dirtyTimeout);
        setTimeout(this.SendDirty.bind(this) , 500);
    } 
    
};

// send the update queue to the server
SPD_hierarchy.prototype.SendDirty = function(){

    let list = [];
    for(let i=0;i<this._DirtyList.length;i++){
        let item = this._DirtyList[i];

        let id = item.dataset.id;
        let id_parent = item.parentNode.dataset.id;

        if(id != id_parent && id_parent > 0){
            let data = {'id_parent':id_parent , 'ordre':DOM_Class.FindChildIndex(item.parentNode , item) };
            if(item.dataset.internaltree){
                
                data.id_tree = id_parent;
            }else{
                data.id = id;
            }
            list.push(data);
        }else{
            debugger;
        }
    }

    let settings = {};
    settings.url = this.url;
    settings.data = {
        'hierarchy_action': 'hierarchy_set_structure_data',
        'hierarchy-structure-data_list': list
    };
    $_a.send(settings);

    this._DirtyList.length = 0;
};
/*jshint esversion: 6 */
var CSS_EDITOR = function(){};
CSS_EDITOR.prototype.constructor = CSS_EDITOR;

CSS_EDITOR.normalMediaId = 1;
CSS_EDITOR.normalMediaValue = 'general';
CSS_EDITOR.fullPreview = false;
//~ CSS_EDITOR._variable = new CSS_EDITOR.Variable();
//~ CSS_EDITOR._zoneText = new CSS_EDITOR.ZoneText();
//~ CSS_EDITOR._preview = new CSS_EDITOR.Preview();

CSS_EDITOR.init = function(){
    var _self = this;
    
    // theme id
    //~ let themeDom = document.getElementById('css_editor_theme');
    //~ this.currentTheme = parseInt(themeDom.selectedOptions[0].value);
    
    // media id et media value
    //~ let mediaDom = document.getElementById('css_choix_media');
    //~ this.currentMediaId = parseInt(mediaDom.selectedOptions[0].value);
    //~ this.currentMediaValue = mediaDom.selectedOptions[0].dataset.value;
    
    //~ let cssTheme = JSON.parse(themeDom.selectedOptions[0].dataset.custom);
    this._variable = new this.Variable();
    
    this._zoneText = new this.ZoneText();
    //~ this._zoneText.reset();
    
    this._preview = new this.Preview();
    
    // la bar au dessus de la zone text
    this._toolbar = document.getElementById('csseditor_container_toolbar');
    if (this._toolbar){
        for (let i = 0; i < this._toolbar.children.length; i++){
            let elem = this._toolbar.children[i];
            if (DOM_Class.HasClass(elem, 'vars')){
                
            } else if (DOM_Class.HasClass(elem, 'highlight')){
                $_e.AddEventClick(elem, this.togglePreviewHighlight.bind(this));
            }
        }
    }
    
    // le btn variable des outils
    //~ let btnFullVar = document.getElementById('csseditor_btn_variable');
    //~ btnFullVar.addEventListener('mousedown', this._variable.show.bind(this._variable));
    
    // btn full preview
    let btnFullPreview = document.getElementById('csseditor_toolbar_elem_full_preview');
    if (btnFullPreview){
        $_e.AddEventClick(btnFullPreview, this._preview.showFull.bind(this._preview));
    }
    
    // btn picker elem
    let btnPickerElem = document.getElementById('csseditor_toolbar_elem_picker');
    if (btnPickerElem){
        $_e.AddEventClick(btnPickerElem, this._preview.startPickerElem.bind(this._preview));
    }
    
    // les boutons + 
    //~ let btnsPlus = Array.from(document.getElementsByClassName('csseditor_admin_btn_add'));
    //~ btnsPlus.forEach(function(elem, index){
        //~ if (DOM_Class.HasClass(elem, 'class')){
            //~ elem.addEventListener('click', function(){_self.showModalForm.bind(_self)('class')});
        //~ } else if(DOM_Class.HasClass(elem, 'module')){
            //~ elem.addEventListener('click', function(){_self.showModalForm.bind(_self)('module')});
        //~ } else if(DOM_Class.HasClass(elem, 'formatEcran')){
            //~ elem.addEventListener('click', function(){_self.showModalForm.bind(_self)('formatEcran')});
        //~ }
    //~ });
    
    //~ $_e.AddEvent(window, 'keypress', function(evt){
        //~ if(evt.ctrlKey && evt.keyCode == 83){
            //~ EVENTS_Class.StopEvent(evt);
            //~ CSS_EDITOR.saveCurrentClass(evt);
        //~ }
        //~ console.log(evt);
        //~ if (evt.
    //~ });
    
};

// ----------------------------------------------------------------------------------------
// ----------------------------------------------------------------------------------------
// MODULE

CSS_EDITOR.initModule = function(){
    let domModule = document.getElementById('css_choix_module');
    this.currentModule = domModule.selectedOptions[0].value;
    $_e.AddEvent(domModule,'change',this.onChangeModule.bind(this));
    //domModule.addEventListener('change', this.onChangeModule.bind(this));
    if (this.modal) this.modal.Hide();
};

CSS_EDITOR.onChangeModule = function(evt){
    $_e.StopEvent(evt);
    if (!this._preview.full){
        this.currentModule = evt.target.selectedOptions[0].value;
        
        let settings = {};
        settings.url = document.baseURI.split('?')[0].split('#')[0] + 'csseditor/index.php';
        settings.skip_container = true;
        settings.dom_target = 'container_right';
        settings.data = {
            'csseditor_action': 'csseditor_select',
            'csseditor-theme-id': CSS_EDITOR.currentTheme,
            'csseditor-rules-module': CSS_EDITOR.currentModule,
            'csseditor-rules-id_media': CSS_EDITOR.currentMediaId ? CSS_EDITOR.currentMediaId : CSS_EDITOR.normalMediaId
        };
        $_a.send(settings);
        this._preview.showOne();
    } else {
        this.currentModule = evt.target.selectedOptions[0].value;
        
        let settings = {};
        settings.url = document.baseURI.split('?')[0].split('#')[0] + 'csseditor/index.php';
        settings.skip_container = true;
        settings.dom_target = 'container_right';
        settings.data = {
            'csseditor_action': 'csseditor_select',
            'csseditor-theme-id': CSS_EDITOR.currentTheme,
            'csseditor-rules-module': CSS_EDITOR.currentModule,
            'csseditor-rules-id_media': CSS_EDITOR.currentMediaId ? CSS_EDITOR.currentMediaId : CSS_EDITOR.normalMediaId
        };
        $_a.send(settings);
    }
};

// ----------------------------------------------------------------------------------------
// ----------------------------------------------------------------------------------------
// CLASS

CSS_EDITOR.initClass = function(rules){
    this.domChoixClass = document.getElementById('css_choix_class');
    $_e.AddEvent(this.domChoixClass, 'change', this.onChangeClass.bind(this));
    //this.domChoixClass.addEventListener('change', this.onChangeClass.bind(this));
    if (this.domChoixClass.selectedIndex > 0){
        $_e.SendEvent(this.domChoixClass, 'change');
    }
    this.customSelect(this.domChoixClass.parentElement);
    
    this.allRules = rules;
};

CSS_EDITOR.onChangeClass = function(evt){
    $_e.StopEvent(evt);
    
    let rules = evt.target.selectedOptions[0].dataset.rules;
    this.currentSelector = evt.target.selectedOptions[0].textContent;
    this.currentRulesId = parseInt(evt.target.selectedOptions[0].value);
    
    this._zoneText.value = rules;
    
    let btn_save = document.getElementById('csseditor_btn_save_class');
    DOM_Class.ToggleClass(btn_save, 'disable', false);
    $_e.AddEventClick(btn_save, this.saveCurrentClass);
    
    let temp = {};
    temp.target = document.getElementById('csseditor_toolbar_elem_highlight');
    temp.firstTime = this._preview.isHighlighted;
    this.togglePreviewHighlight(temp);
};

// ----------------------------------------------------------------------------------------
// ----------------------------------------------------------------------------------------
// Media type

CSS_EDITOR.initMediaType = function(rules){
    this.domChoixMediaType = document.getElementById('css_choix_media');
    $_e.AddEvent(this.domChoixMediaType, 'change', this.onChangeMediaType.bind(this));
    //this.domChoixMediaType.addEventListener('change', this.onChangeMediaType.bind(this));
    this.currentMediaId = this.domChoixMediaType.selectedOptions[0].value;
    this.currentMediaValue = this.domChoixMediaType.selectedOptions[0].dataset.value;
};

CSS_EDITOR.initNoobMediaType = function(rules){
    this.domChoixMediaType = document.getElementById('css_choix_media');
    this.domChoixMediaType.classList.add('validatorField');
    $_e.AddEvent(this.domChoixMediaType, 'change', this.onChangeMediaType.bind(this));
    //this.domChoixMediaType.addEventListener('change', this.onChangeNoobMediaType.bind(this));
    this.currentMediaId = this.domChoixMediaType.selectedOptions[0].value;
    this.currentMediaValue = this.domChoixMediaType.selectedOptions[0].dataset.value;
};

CSS_EDITOR.onChangeMediaType = function(evt){
    $_e.StopEvent(evt);
    
    this.currentMediaId = this.domChoixMediaType.selectedOptions[0].value;
    this.currentMediaValue = this.domChoixMediaType.selectedOptions[0].dataset.value;
        
    let settings = {};
    settings.url = document.baseURI.split('?')[0].split('#')[0] + 'csseditor/index.php';
    settings.skip_container = true;
    settings.dom_target = 'container_right';
    settings.data = {
        'csseditor_action': 'csseditor_select',
        'csseditor-theme-id': CSS_EDITOR.currentTheme,
        'csseditor-rules-module': CSS_EDITOR.currentModule,
        'csseditor-rules-id_media': CSS_EDITOR.currentMediaId ? CSS_EDITOR.currentMediaId : CSS_EDITOR.normalMediaId
    };
    settings.success = function(){
        setTimeout(()=>{
            let containerOutil = document.getElementById('csseditor_container_outils');
            if (containerOutil) {
                while(containerOutil.firstChild){
                    containerOutil.removeChild(containerOutil.firstChild);
                }
            }
            CSS_EDITOR._variable.parse();
            CSS_EDITOR._preview.changeMediaType();
            CSS_EDITOR._zoneText.reset();
        }, 500);
    };
    $_a.send(settings);
};

CSS_EDITOR.onChangeNoobMediaType = function(evt){
    $_e.StopEvent(evt);
    
    this.currentMediaId = this.domChoixMediaType.selectedOptions[0].value;
    this.currentMediaValue = this.domChoixMediaType.selectedOptions[0].dataset.value;
    
    let containerOutil = document.getElementById('csseditor_container_outils');
    if (containerOutil) {
        while(containerOutil.firstChild){
            containerOutil.removeChild(containerOutil.firstChild);
        }
    }
    
    this._variable.parse();
    this._variable.showNoob.bind(this._variable)({});
    //~ CSS_EDITOR._preview.changeMediaType();
    
    //~ let settings = {};
    //~ settings.url = document.baseURI.split('?')[0].split('#')[0] + 'csseditor/index.php';
    //~ settings.skip_container = true;
    //~ settings.dom_target = 'csseditor_admin_container_noob';
    //~ settings.data = {
        //~ 'csseditor_action': '',
        //~ 'csseditor-theme-id': CSS_EDITOR.currentTheme,
        //~ 'csseditor-rules-id_media': CSS_EDITOR.currentMediaId ? CSS_EDITOR.currentMediaId : CSS_EDITOR.normalMediaId,
        //~ 'mode': 'noob'
    //~ };
    
    //~ $_a.send(settings);
};

// ----------------------------------------------------------------------------------------
// ----------------------------------------------------------------------------------------

CSS_EDITOR.reset = function(){
    this.currentModule = false;
    this.currentMediaId = this.normalMediaId;
    this.currentMediaValue = 'general';
    this.currentSelector = false;
    this.currentRulesId = false;
    this._zoneText.reset();
    this._preview.reset();
};

CSS_EDITOR.colorPickerResult = function(evt){
    colData = evt.detail;
    colData.domElement.style.backgroundColor = '#'+colData.hex;
    if (colData.domElement.tagName == 'INPUT'){
        colData.domElement.value = '#'+colData.hex;
    }else{
        colData.domElement.innerHTML = '#'+colData.hex;
    }
    let r = Math.max(0,Math.round(colData.rgb.r*255));
    let g = Math.max(0,Math.round(colData.rgb.g*255));
    let b = Math.max(0,Math.round(colData.rgb.b*255));
    let tt = r + g + b;
    if (tt > 382) colData.domElement.style.color = '#000';
    else colData.domElement.style.color = '#FFF';
};

CSS_EDITOR.parseFont = function(css){
    if (css){
        this.allCustom = GENERICS_Class.IsString(css) ? JSON.parse(css) : css;
        for (let selector in this.allCustom){
            if (selector == ':root'){ // variable
                continue;
            } else if (selector == '@font-face') { // font
                this.cssFont = {};
                this.cssFont.str = this.allCustom[selector];
                this.cssFont.rules = {};
                this.allCustom[selector].forEach(function(elem, index){
                    let arr = elem.split(';');
                    let name = arr[0].split(':')[1].replace(/[^A-Za-z0-9]/g, '').trim();
                    let url = arr[1].split(':')[1].replace('url(', '').replace(')', '').trim();
                    CSS_EDITOR.cssFont.rules[name] = {'url': url, 'index': index};
                });
            }
        }
    }
    if (!this.cssFont){
        this.cssFont = {};
        this.cssFont.str = [''];
    }
    this.addCustomFontToSelect();
};

CSS_EDITOR.addCustomFontToSelect = function(){
    let selFamily = document.getElementById('fontSelFamily');
    if (this.cssFont.rules && selFamily){
        let exist = [];
        for (let i = 0; i < selFamily.length; i++){
            let elem = selFamily[i];
            if (elem.value == '' || elem.value == 'serif' || elem.value == 'sans-serif' || elem.value == 'monospace') continue;
            let found = false;
            for (let name in this.cssFont.rules){
                if (elem.value == name){
                    found = true;
                    exist.push(name);
                }
            }
            if (!found){
                DOM_Class.RemoveElement(elem);
            }
        }
        for (let name in this.cssFont.rules){
            if (exist.indexOf(name) == -1){
                let opt = DOM_Class.CreateElement('OPTION', {'value': name}, name);
                selFamily.add(opt);
                this._preview.addFont(name, this.cssFont.rules[name].url);
            }
        }
    }
};

CSS_EDITOR.showFontNoob = function(){
    let domElem = document.getElementById('csseditor_container_outils');
    let title = DOM_Class.CreateElement('SPAN', {'class': 'csseditor_admin_outil_fontNoob_title'}, CSS_EDITOR.texts['js_ttl_font']);
    DOM_Class.AppendContent(domElem, title);
    var content = DOM_Class.CreateElement('DIV', {'id': 'csseditor_container_fontNoob', 'class': 'csseditor_container_fontNoob'});
    DOM_Class.AppendContent(domElem, content);
};

// ----------------------------------------------------------------------------------------------------------
// ----------------------------------------------------------------------------------------------------------

CSS_EDITOR.showModalForm = function(type, extraData = false){
    if (!this.modal){
        this.modal = UI_Class.AddWindow(null, {'modal': true, 'class': 'csseditor_admin_modal', 'hidden': true});
        let div_form = DOM_Class.CreateElement('DIV', {'class': 'csseditor_admin_modal_form', 'id':'csseditor_modal_form'});
        this.modal.SetContent(div_form);
        this.modal.SetParent(document.getElementById('lemain'), 0.5, 0.5);
    }
    
    let settings = {};
    settings.url = document.baseURI.split('?')[0].split('#')[0] + 'csseditor/index.php';
    settings.skip_container = true;
    settings.dom_target = 'csseditor_modal_form';
    settings.data = {
        'csseditor_action': 'csseditor_form_'+type,
        'csseditor-theme-id': CSS_EDITOR.currentTheme,
    };
    if (type == 'class'){
        settings.data['csseditor-rules-module'] = CSS_EDITOR.currentModule;
        settings.data['csseditor-rules-id_media'] = CSS_EDITOR.currentMediaId;
    }
    if (extraData){
        for (let key in extraData){
            settings.data[key] = extraData[key];
        }
    }
    settings.success = function(){
        CSS_EDITOR.modal.Show();
    };
    $_a.send(settings);
};

CSS_EDITOR.addClassToCustomSelect = function(){
    let val = document.getElementById('csseditor_input_class_name').value;
    if (val && val != ''){
        let domTarget = document.getElementsByClassName('csseditor_admin_custom_select-items')[0];
        let elem = this.addOptionToSelect(val, -1, domTarget);
        let opt = DOM_Class.CreateElement('OPTION', {'value': '-1', 'data-rules': ''}, val);
        this.domChoixClass.add(opt);
        this.modal.Hide();
        $_e.SendEvent(elem, 'mousedown');
    }
};

CSS_EDITOR.toggleInputModule = function(){
    let divText = document.getElementById('csseditor_container_input_module_name');
    let divCopy = document.getElementById('csseditor_container_input_module_copy');
    if (divText && divCopy){
        DOM_Class.ToggleClass(divText, 'hide');
        DOM_Class.ToggleClass(divCopy, 'hide');
    }
};

CSS_EDITOR.saveModule = function(evt){
    let form = evt.target.form;
    let check = document.getElementById('csseditor_check_duplic_module');
    if (check.checked){
        $_e.SendEvent(form, 'submit');
    } else {
        CSS_EDITOR.addModuleToSelect();
    }
};

CSS_EDITOR.addModuleToSelect = function(){
    let val = document.getElementById('csseditor_select_module').selectedOptions[0].value;
    if (val == ''){
        val = document.getElementById('csseditor_input_module_name').value.trim();
    }
    if (val && val != ''){
        let select = document.getElementById('css_choix_module');
        let opt = DOM_Class.CreateElement('OPTION', {'value': val}, val);
        select.add(opt);
        select.selectedIndex = (select.length-1);
        this.modal.Hide();
        $_e.SendEvent(select, 'change');
    }
};

CSS_EDITOR.saveTheme = function(evt){
    
    let form = evt.target.form;
    let duplic = false;
    let data = {
        'csseditor_action': 'csseditor_save_theme'
    };
    for (let i = 0; i < form.length; i++){
        let inp = form[i];
        if (inp.name == 'duplic_theme' && inp.checked) duplic = true;
        if (inp.name == 'csseditor-theme-id' && duplic) data[inp.name] = inp.value;
        
    }
    
    let name = document.getElementById('csseditor_modal_form_inp_theme').value;
    let checkboxDuplic = document.getElementById('csseditor_modal_form_inp_theme').value;
    if (name != ''){
        let settings = {};
        settings.url = document.baseURI.split('?')[0].split('#')[0] + 'csseditor/index.php';
        settings.skip_container = true;
        settings.dom_target = 'container_right';
        settings.data = {
            'csseditor-theme-name': name
        };
        this.modal.Hide();
        $_a.send(settings);
    }
};

// ----------------------------------------------------------------------------------------------------------
// ----------------------------------------------------------------------------------------------------------

CSS_EDITOR.manageFont = function(){
    this.showModalForm('font');
};

CSS_EDITOR.addCustomFont = function(evt){
    let name = document.getElementById('fontCustomInputNameNew').value.trim();
    let url = document.getElementById('fontCustomInputUrlNew').value.trim();
    if (name != '' && url != ''){
        for(let fontName in this.cssFont.rules){
            if (fontName == name){
                // TODO msg erreur nom ou url déjà pris
                return false;
            }
            if (this.cssFont.rules[fontName].url == url){
                return false;
            }
        }
        let divContent = document.getElementById('csseditor_modal_font_content');
        let div = DOM_Class.CreateElement('DIV', {'class': 'csseditor_admin_modal_manage_font_line'});
        let domName = DOM_Class.CreateElement('SPAN', {'class': 'csseditor_admin_modal_font_name'}, name);
        let labUrl = DOM_Class.CreateElement('LABEL', {'class': 'csseditor_admin_modal_font_lab_url', 'for': 'fontCustomInputUrl_'+name}, 'url');
        let domUrl = DOM_Class.CreateElement('INPUT', {'class': 'csseditor_admin_modal_font_inp_url', 'type': 'text', 'id': 'fontCustomInputUrl_'+name, 'value':url});
        //~ let btnEdit = DOM_Class.CreateElement('BUTTON', {'class': 'csseditor_admin_modal_font_btn_apply_edit', 'type': 'button'}, this.texts['edit']);
        DOM_Class.AppendContent(div, domName);
        DOM_Class.AppendContent(div, labUrl);
        DOM_Class.AppendContent(div, domUrl);
        //~ DOM_Class.AppendContent(div, btnEdit);
        //~ $_e.AddEvent(btnEdit, 'click', this.saveCustomFont.bind(this));
        DOM_Class.AppendContent(divContent, div);
        
        let str = 'font-family: "'+name+'";src: url('+url+');';
        let index = this.cssFont.str.push(str) - 1 ;
        this.cssFont.rules[name] = {'url':url, 'index': index};
        
        this.saveCustomFont();
    }
};

CSS_EDITOR.saveCustomFont = function(evt){
    if (evt){
        let targ = evt.target;
        let newUrl = targ.previousElementSibling.value;
        let name = targ.previousElementSibling.previousElementSibling.previousElementSibling.innerHTML;
        for(let fontName in this.cssFont.rules){
            if (fontName == name && this.cssFont.rules[fontName].url != newUrl){
                this.cssFont.rules[fontName].url = newUrl;
                let str = 'font-family: "'+fontName+'";src: url('+newUrl+');';
                this.cssFont.str[this.cssFont.rules[fontName].index] = str;
            }
        }
    }
    
    let settings = {};
    settings.url = document.baseURI.split('?')[0].split('#')[0] + 'csseditor/index.php';
    settings.skip_container = true;
    settings.dom_target = '';
    settings.data = {
        'csseditor_action': 'csseditor_save_font',
        'customFont': this.cssFont.str,
        'csseditor-theme-id': this.currentTheme
    };
    
    $_a.send(settings);
    
};


CSS_EDITOR.getImgPutUrl = function(type, mediaID){
    if (type == 'add'){
        let img = document.getElementById('media_current_img_'+mediaID);
        if (img){
            let backInpUrl = document.getElementById('backgroundImageInpUrl');
            if (backInpUrl){
                backInpUrl.value = img.src.substring(img.src.indexOf('public'));
            }
        }
    }
};

// ----------------------------------------------------------------------------------------------------------
// ----------------------------------------------------------------------------------------------------------

CSS_EDITOR.Variable = function(css){
    //~ this.parse(css);
    this.instances = [];
};
CSS_EDITOR.Variable.prototype.constructor = CSS_EDITOR.Variable;

CSS_EDITOR.Variable.prototype.parse = function(css){
    if (css){
        css = JSON.parse(css);
        for (let selector in css){
            if (selector == ':root'){ // variable
                for(let media in css[selector]){
                    if (media == 'general'){
                        this.str = css[selector][media].trim();
                        this.rules = {};
                        let temp = this.str.split(';');
                        temp.forEach((elem) => {
                            if (elem != ''){
                                let t = elem.split(':');
                                let selector = t[0] ? t[0].trim() : '';
                                let properties = t[1] ? t[1].trim() : '';
                                let tt = {};
                                tt.properties = properties;
                                tt.currentMedia = true;
                                tt.modified = false;
                                this.rules[selector] = tt;
                            }
                        });
                    }
                    if (!this.allMedia){
                        this.allMedia = {};
                    }
                    this.allMedia[media] = css[selector][media];
                }
            } else continue;
        }
    } else {
        //~ console.log(this);
        //~ console.log(CSS_EDITOR);
        if (this.allMedia[CSS_EDITOR.currentMediaValue]){
            this.str = this.allMedia[CSS_EDITOR.currentMediaValue].trim();
            for(let sel in this.rules){
                this.rules[sel].currentMedia = false;
            }
            let temp = this.str.split(';');
            temp.forEach((elem) => {
                if (elem != ''){
                    let t = elem.split(':');
                    let selector = t[0] ? t[0].trim() : '';
                    let properties = t[1] ? t[1].trim() : '';
                    if (this.rules[selector]){
                        this.rules[selector].properties = properties;
                        this.rules[selector].currentMedia = true;
                    } else {
                        let tt = {};
                        tt.properties = properties;
                        tt.currentMedia = true;
                        tt.modified = false;
                        this.rules[selector] = tt;
                    }
                    if (!CSS_EDITOR._preview.full && !CSS_EDITOR.noob) CSS_EDITOR._preview.changeVar(selector, properties);
                }
            });
        }
    }
};

//~ CSS_EDITOR.Variable.prototype.applyMedia = function(){
    //~ let str = this.othersMedia[CSS_EDITOR.currentMediaValue];
    //~ let temp = str.split(';');
    //~ temp.forEach((elem) => {
        //~ if (elem.trim() != ''){
            //~ let t = elem.split(':');
            //~ let selector = t[0].trim();
            //~ let properties = t[1].trim();
            //~ this.add(selector, properties);
            //~ CSS_EDITOR._preview.changeVar(selector, properties);
        //~ }
    //~ });
//~ };

CSS_EDITOR.Variable.prototype.addToElem = function(target, mode = 'full'){
    this.instances.forEach(function(inst){
        if (!document.getElementById(inst.target.id)){
            inst.remove();
            delete inst;
        }
    });
    if (target){
        let instance = new this.Picker(target, mode, this);
        this.instances.push(instance);
    }
};

CSS_EDITOR.Variable.prototype.add = function(selector, value){
    if (this.rules[selector] && this.rules[selector].properties == value){
        return true;
    } else {
        if (!this.rules[selector]) this.rules[selector] = {};
        this.rules[selector].properties = value;
        this.rules[selector].modified = true;
        this.rules[selector].currentMedia = true;
        let str = '';
        for(let elem in this.rules){
            if (this.rules[elem].currentMedia){
                str += elem + ': ' + this.rules[elem].properties + ';';
            }
        }
        this.str = str;
        return true;
    }
    return false;
};

CSS_EDITOR.Variable.prototype.show = function(evt){
    $_e.StopEvent(evt);
    let domElem = document.getElementById('csseditor_container_outils');
    while(domElem.firstChild){
        domElem.removeChild(domElem.firstChild);
    }
    this.Picker.prototype.make(domElem);
};

CSS_EDITOR.Variable.prototype.showNoob = function(evt){
    $_e.StopEvent(evt);
    let domElem = document.getElementById('csseditor_container_outils');
    while(domElem.firstChild){
        domElem.removeChild(domElem.firstChild);
    }
    this.Picker.prototype.make(domElem, true);
};

CSS_EDITOR.Variable.prototype.toggleEditVariable = function(evt){
    let targ = evt.target;
    
    let prev = targ.previousElementSibling;
    let isImg = false;
    if (prev.dataset.selector == '--background-image'){
        isImg = true;
    }
    
    let inp = document.getElementById('csseditor_modal_input_variable');
    let isColor = JSON.parse(targ.dataset.color);
    let isFont = targ.dataset.font ? true : false;
    //~ console.log(this);
    if (this.previousEdit){
        this.previousEdit.innerHTML = inp.value;
        DOM_Class.ToggleClass(this.previousEdit, 'hide', false);
        DOM_Class.ToggleClass(inp, 'hide', true);
        
        CSS_EDITOR._preview.changeVar(this.previousEdit.previousElementSibling.innerHTML, inp.value);
    
        this.add(this.previousEdit.previousElementSibling.dataset.selector, inp.value);
    }
    
    if (isColor){
        initColorPicker(targ, this.colorPickerResult.bind(this));
    } else if (isFont){
        let self = this;
        this.modalFont = UI_Class.AddWindow(document.getElementById('lemain'), {'hidden': true, 'modal': true, 'disableBackgroundClick': true, 'class': 'csseditor_admin_modal_font', 'close': CONSTANTS.texts['close']});
        let container = DOM_Class.CreateElement('DIV', {'class': 'csseditor_admin_modal_font_lst', 'id': 'csseditor_admin_modal_font_lst'});
        this.modalFont.SetContent(container);
        
        this.previousEdit = targ;
        
        let curFont = targ.innerHTML;
        
        let settings = {};
        settings.url = document.baseURI.split('?')[0].split('#')[0] + 'csseditor/index.php';
        settings.skip_container = true;
        settings.dom_target = '';
        settings.data = {
            'csseditor_action': 'csseditor_load_commons_fonts',
            'currentFont': curFont
        };
        
        settings.success = function(res){
            container.innerHTML = res;
            self.modalFont.Show();
            for (let i = 0; i< container.children.length; i++){
                let font = container.children[i];
                $_e.AddEventClick(font, self.selectCommonFont.bind(self));
            }
            
            let btnClose = container.nextElementSibling;
            $_e.AddEventClick(btnClose, self.closeCommonModal.bind(self));
        };
        
        $_a.send(settings);
        
    } else if (isImg){
        let self = this;
        if (!this.modalImg){
            this.modalImg = UI_Class.AddWindow(document.getElementById('lemain'), {'hidden': true, 'modal': true, 'disableBackgroundClick': true, 'class': 'csseditor_admin_modal_img', 'close': CONSTANTS.texts['close']});
            this.modalImg.container = DOM_Class.CreateElement('DIV', {'class': 'csseditor_admin_modal_img_lst', 'id': 'csseditor_admin_modal_img_lst'});
            this.modalImg.SetContent(this.modalImg.container);
            let btnClose = this.modalImg.container.nextElementSibling;
            $_e.AddEventClick(btnClose, this.closeCommonModal.bind(this));
            
            let curImg = targ.innerHTML.split(')')[0];
            curImg = curImg.split('/')[curImg.split('/').length - 1];
            
            let settings = {};
            settings.url = document.baseURI.split('?')[0].split('#')[0] + 'csseditor/index.php';
            settings.skip_container = true;
            settings.dom_target = this.modalImg.container.id;
            settings.data = {
                'csseditor_action': 'csseditor_load_commons_imgs',
                'currentImg': curImg
            };
            
            settings.success = function(res){
                self.modalImg.Show();
            };
            
            $_a.send(settings);
        } else {
            this.modalImg.Show();
        }
        
        this.previousEdit = targ;
        
        
    } else if (inp){
        DOM_Class.ToggleClass(targ, 'hide', true);
        this.previousEdit = targ;
        
        DOM_Class.InsertAfter(inp, targ);
        DOM_Class.ToggleClass(inp, 'hide', false);
        inp.value = targ.textContent;
        
        let classObject = {};
        classObject.Hide = function(){
            CSS_EDITOR._variable.previousEdit.innerHTML = inp.value;
            DOM_Class.ToggleClass(CSS_EDITOR._variable.previousEdit, 'hide', false);
            DOM_Class.ToggleClass(inp, 'hide', true);
            CSS_EDITOR._preview.changeVar(CSS_EDITOR._variable.previousEdit.previousElementSibling.dataset.selector, inp.value);
            CSS_EDITOR._variable.add(CSS_EDITOR._variable.previousEdit.previousElementSibling.dataset.selector, inp.value);
            CSS_EDITOR._variable.previousEdit = false;
            $_e.RemoveHideOnMouseDownOutside(inp);
        };
        if (!DOM_Class.GetClassObject(inp, 'click')){
            DOM_Class.AddClassObject(inp, 'click', classObject);
        }
        $_e.AddHideOnMouseDownOutside(inp);
    }
};

CSS_EDITOR.Variable.prototype.colorPickerResult = function(evt){
    CSS_EDITOR.colorPickerResult(evt);
    CSS_EDITOR._preview.changeVar(colData.domElement.previousElementSibling.dataset.selector, '#'+colData.hex);
    this.add(colData.domElement.previousElementSibling.dataset.selector, '#'+colData.hex);
};

CSS_EDITOR.Variable.prototype.selectCommonImg = function(evt){
    this.modalImg.Hide();
    //~ console.log(evt.target);
    let url = evt.target.getAttribute('src');
    url = url.substring(url.indexOf('images'));
    //~ console.log(CSS_EDITOR.prefix+url);
    let cssStr = 'url('+CSS_EDITOR.prefix+url+')';
    this.add('--background-image', cssStr);
    CSS_EDITOR._preview.changeVar('--background-image', cssStr);
    this.previousEdit.innerHTML = cssStr;
    this.previousEdit = false;
};

CSS_EDITOR.Variable.prototype.selectCommonFont = function(evt){
    this.modalFont.Hide();
    let targ = evt.target;
    let url = 'fonts/'+targ.dataset.font;
    let fullUrl = 'url('+CSS_EDITOR.prefix+url+')';
    let varName = this.previousEdit.previousElementSibling.dataset.selector;
    let fontName = varName.replace('--', '');
    this.add(varName, fullUrl);
    CSS_EDITOR._preview.changeVar(varName, fullUrl);
    CSS_EDITOR._preview.addFont(fontName, url);
    this.previousEdit.innerHTML = url;
    this.previousEdit = false;
};

CSS_EDITOR.Variable.prototype.closeCommonModal = function(){
    this.previousEdit = false;
    if (this.modalFont && this.modalFont.visible){
        this.modalFont.Hide();
    } else if (this.modalImg && this.modalImg.visible){
        this.modalImg.Hide();
    }
};

CSS_EDITOR.Variable.prototype.save = function(evt){
    let targ = evt.target;
    // attention a la présence de l'input hidden de la modif
    let properties = (targ.previousElementSibling.tagName == 'SPAN') ? targ.previousElementSibling.innerHTML : targ.previousElementSibling.value;
    let selector = (targ.previousElementSibling.tagName == 'SPAN') ? targ.previousElementSibling.previousElementSibling.dataset.selector : targ.previousElementSibling.previousElementSibling.previousElementSibling.dataset.selector;
    
    if (properties != '' && selector != '' && CSS_EDITOR.currentTheme){
        let settings = {};
        settings.url = document.baseURI.split('?')[0].split('#')[0] + 'csseditor/index.php';
        settings.skip_container = true;
        settings.dom_target = '';
        settings.data = {
            'csseditor_action': 'csseditor_save_variable',
            'csseditor-theme-id': CSS_EDITOR.currentTheme,
            'var_media': CSS_EDITOR.currentMediaValue,
            'var_properties': properties,
            'var_selector': selector
        };
        
        //~ console.log(settings.data);
        
        settings.success = function(res){
            if (res) {
                let msg = JSON.parse(res);
                let spanTxt = DOM_Class.CreateElement('DIV', {'class': 'csseditor_admin_info_sav '+msg.type, 'id': 'csseditor_info_sav_'+GENERICS_Class.GetUniqueId()}, msg.msg);
                DOM_Class.InsertAfter(spanTxt, targ.parentElement);
                
                setTimeout(()=>{DOM_Class.RemoveElement(spanTxt);}, 3000);
            }
        };
        
        $_a.send(settings);
    }
};

CSS_EDITOR.Variable.prototype.addVariable = function(evt){
    let targ = evt.target;
    
    if (targ.innerHTML == '+'){
        let label_selector = DOM_Class.CreateElement('SPAN', {'class':'csseditor_admin_label_nom_var'}, CSS_EDITOR.texts['js_nom_var']);
        let prefix = DOM_Class.CreateElement('SPAN', {'class':'csseditor_admin_prefix_nom_var'}, '--');
        let inp_selector = DOM_Class.CreateElement('INPUT', {'type':'text', 'class':'csseditor_admin_input_nom_var', 'id':'csseditor_input_new_variable'});
            
        let div = DOM_Class.CreateElement('DIV', {'class': 'csseditor_admin_add_variable'});
        div.appendChild(label_selector);
        div.appendChild(prefix);
        div.appendChild(inp_selector);
        
        DOM_Class.InsertBefore(div, targ);
        targ.innerHTML = 'ok';
    } else {
        let inp = document.getElementById('csseditor_input_new_variable');
        let selector = (inp.value.startsWith('--')) ? inp.value : '--'+inp.value;
        if (this.rules[selector]){
            let spanTxt = DOM_Class.CreateElement('DIV', {'class': 'csseditor_admin_info_sav bad', 'id': 'csseditor_info_sav_'+GENERICS_Class.GetUniqueId()}, CSS_EDITOR.texts['js_var_exist']);
            DOM_Class.InsertBefore(spanTxt, targ);
            setTimeout(()=>{DOM_Class.RemoveElement(spanTxt);}, 3000);
        } else if(selector != '--') {
            let domSelector = DOM_Class.CreateElement('SPAN', {'class': 'csseditor_admin_outil_variable_selector', 'data-selector': selector}, selector);
            let isColor = selector.includes('color');
            let domProperties = DOM_Class.CreateElement('SPAN', {'class': 'csseditor_admin_outil_variable_properties', 'data-color': isColor});
            if (isColor){
                domProperties.innerHTML = '#FFFFFF';
                domProperties.style.backgroundColor = '#FFFFFF';
            }
            let domSave = DOM_Class.CreateElement('BUTTON', {'type': 'BUTTON', 'class': 'csseditor_admin_outil_variable_btn_save'}, 'save');
            let divLine = DOM_Class.CreateElement('DIV', {'class': 'csseditor_admin_outil_variable_line'});
            divLine.appendChild(domSelector);
            divLine.appendChild(domProperties);
            divLine.appendChild(domSave);
            
            document.getElementById('csseditor_container_vars_content').appendChild(divLine);
            
            $_e.AddEventClick(domSelector, CSS_EDITOR._zoneText.insertVar.bind(CSS_EDITOR._zoneText));
            $_e.AddEventClick(domProperties, this.toggleEditVariable.bind(this));
            $_e.AddEventClick(domSave, this.save.bind(this));
            
            DOM_Class.RemoveElement(inp.parentElement);
            
            targ.innerHTML = '+';
        }
    }
};

CSS_EDITOR.Variable.prototype.saveAll = function(evt){
    let targ = evt.target;
    
    let settings = {};
    settings.url = document.baseURI.split('?')[0].split('#')[0] + 'csseditor/index.php';
    settings.skip_container = true;
    settings.dom_target = '';
    settings.data = {
        'csseditor_action': 'csseditor_save_variable',
        'csseditor-theme-id': CSS_EDITOR.currentTheme,
        'var_media': CSS_EDITOR.currentMediaValue,
        'var_str': this.str,
        'var_all': true
    };
    
    settings.success = function(res){
        if (res) {
            let msg = JSON.parse(res);
            let spanTxt = DOM_Class.CreateElement('DIV', {'class': 'csseditor_admin_info_sav '+msg.type, 'id': 'csseditor_info_sav_'+GENERICS_Class.GetUniqueId()}, msg.msg);
            DOM_Class.InsertAfter(spanTxt, targ.parentElement);
            
            setTimeout(()=>{DOM_Class.RemoveElement(spanTxt);}, 3000);
        }
    };
    
    //~ console.log(settings.data);
    
    $_a.send(settings);
};

CSS_EDITOR.Variable.prototype.askRemove = function(evt){
    let targ = evt.target;
    this.toRemove = targ;
    UI_Class.ConfirmPopup(CSS_EDITOR.texts['msgRemoveVar'], this.remove.bind(this), function(){return false;});
};

CSS_EDITOR.Variable.prototype.remove = function(evt){
    if (this.toRemove){
        let parent = this.toRemove.parentElement;
        let selector = this.toRemove.nextElementSibling.innerHTML;
        
        let settings = {};
        settings.url = document.baseURI.split('?')[0].split('#')[0] + 'csseditor/index.php';
        settings.skip_container = true;
        settings.dom_target = '';
        settings.data = {
            'csseditor_action': 'csseditor_delete_variable',
            'csseditor-theme-id': CSS_EDITOR.currentTheme,
            'variable_selector': selector,
            'variable_media': CSS_EDITOR.currentMediaValue
        };
        settings.success = function(res){
            if (res) {
                DOM_Class.RemoveElement(parent);
                delete(CSS_EDITOR._variable.rules[selector]);
                let str = '';
                for(let elem in CSS_EDITOR._variable.rules){
                    str += elem + ': ' + CSS_EDITOR._variable.rules[elem] + ';';
                }
                CSS_EDITOR._variable.str = str;
            }
        };
        $_a.send(settings);
    }
};

CSS_EDITOR.Variable.prototype.reset = function(){
    if (this.modalImg){
        DOM_Class.RemoveElement(this.modalImg.domElement);
        DOM_Class.RemoveElement(this.modalImg._modalMask);
    }
    if (this.modalFont){
        DOM_Class.RemoveElement(this.modalFont.domElement);
        DOM_Class.RemoveElement(this.modalFont._modalMask);
    }
};

// --------- PICKER

CSS_EDITOR.Variable.prototype.Picker = function(target, mode, parentThis){
    //~ console.log('construc picker ', mode);
    if (target && !this.target){
        this.target = target;
        this.mode = mode;
        this._parent = parentThis;
        
        this.domElement = DOM_Class.CreateElement('DIV', {'class': 'csseditor_admin_variable hide '+this.mode});
        document.body.appendChild(this.domElement);
        this.domElement.style.position = 'absolute';
        
        if (!DOM_Class.GetClassObject(this.domElement, 'click')){
            DOM_Class.AddClassObject(this.domElement, 'click', this);
        }
        
        this.make();
    }
};
CSS_EDITOR.Variable.prototype.Picker.constructor = CSS_EDITOR.Variable.prototype.Picker;

Object.defineProperty(CSS_EDITOR.Variable.prototype.Picker.prototype, 'target', {
    get: function() {
        return this._target;
    },
    set: function(domElem){
        if (domElem) {
            if (!this.domOpener){
                this.domOpener = DOM_Class.CreateElement('BUTTON', {'type': 'BUTTON', 'class': 'csseditor_admin_btn_variable'}, 'vars');
                $_e.AddEventClick(this.domOpener, this.show.bind(this));
            }
            this._target = domElem;
            DOM_Class.InsertAfter(this.domOpener, this._target);
        }
    }
});

CSS_EDITOR.Variable.prototype.Picker.prototype.make = function(domElem, noob = false){
    if (this.mode == 'full' || domElem){
        this._parent = CSS_EDITOR._variable;
        let title = DOM_Class.CreateElement('SPAN', {'class': 'csseditor_admin_outil_variable_title'}, CSS_EDITOR.texts['js_ttl_var']);
        DOM_Class.AppendContent(domElem, title);
        var content = DOM_Class.CreateElement('DIV', {'id': 'csseditor_container_vars_content', 'class': 'csseditor_container_vars_content'});
        DOM_Class.AppendContent(domElem, content);
    }
    
    //~ console.log(noob);
    //~ console.log(this.mode);
    //~ console.log(this._parent);
    
    for(let selector in this._parent.rules) {
        //~ console.log(selector);
        //~ console.log(this._parent.rules[selector]);
        let isColor = selector.includes('color');
        
        if (this.mode == 'color' && isColor){
            let domVariable = DOM_Class.CreateElement('DIV', {'class': 'csseditor_admin_variable_color', 'title': selector, 'style': 'background: '+this._parent.rules[selector].properties, 'data-value': this._parent.rules[selector].properties});
            DOM_Class.AppendContent(this.domElement, domVariable);
            $_e.AddEventClick(domVariable, this.addToTarget.bind(this));
        } else if (this.mode == 'other' && !isColor){
            let domVariable = DOM_Class.CreateElement('DIV', {'class': 'csseditor_admin_variable_other', 'title': selector, 'data-value': this._parent.rules[selector].properties}, selector+': '+this._parent.rules[selector].properties);
            DOM_Class.AppendContent(this.domElement, domVariable);
            $_e.AddEventClick(domVariable, this.addToTarget.bind(this));
        } else if (this.mode == 'full' || domElem) {
            if (noob && (selector == '--shadow-box' || selector == '--shadows-box-invert' || selector == '--double-margin' || selector == '--border-style')){
                continue;
            }
            let domDelete = DOM_Class.CreateElement('BUTTON', {'type': 'BUTTON', 'class': 'csseditor_admin_outil_variable_btn_delete'}, 'x');
            let domSelector = DOM_Class.CreateElement('SPAN', {'class': 'csseditor_admin_outil_variable_selector', 'data-selector': selector}, (noob) ? CSS_EDITOR.textsVariables[selector] : selector);
            let domProperties = DOM_Class.CreateElement('SPAN', {'class': 'csseditor_admin_outil_variable_properties', 'data-color': isColor}, this._parent.rules[selector].properties);
            var domSave = DOM_Class.CreateElement('BUTTON', {'type': 'BUTTON', 'class': 'csseditor_admin_outil_variable_btn_save', 'title':CSS_EDITOR.texts['js_sav']}, CSS_EDITOR.texts['js_sav']);
            let divLine = DOM_Class.CreateElement('DIV', {'class': 'csseditor_admin_outil_variable_line'});
            if (!noob){
                DOM_Class.AppendContent(divLine, domDelete);
            } else if (selector.includes('font-family')){
                domProperties.dataset.font = this._parent.rules[selector].properties;
            }
            
            DOM_Class.AppendContent(divLine, domSelector);
            DOM_Class.AppendContent(divLine, domProperties);
            DOM_Class.AppendContent(divLine, domSave);
            if (isColor) {
                domProperties.setAttribute('style', 'background:'+this._parent.rules[selector].properties+';');
            }
            //~ if (selector == '--background-image'){
                //~ let url = this._parent.rules[selector].properties;
                //~ url = url.split(')')[0].replace('url(', '');
                //~ let domImg = DOM_Class.CreateElement('IMG', {'class': 'csseditor_admin_outil_variable_img', 'src': url, 'alt': url});
                //~ DOM_Class.AppendContent(divLine, domImg);
            //~ }
            
            if (!noob){
                $_e.AddEventClick(domSelector, CSS_EDITOR._zoneText.insertVar.bind(CSS_EDITOR._zoneText));
                $_e.AddEventClick(domDelete, CSS_EDITOR._variable.askRemove.bind(CSS_EDITOR._variable));
            }
            
            $_e.AddEventClick(domProperties, CSS_EDITOR._variable.toggleEditVariable.bind(CSS_EDITOR._variable));
            $_e.AddEventClick(domSave, CSS_EDITOR._variable.save.bind(CSS_EDITOR._variable));
            DOM_Class.AppendContent(content, divLine);
        }
    }
    
    if (this.mode == 'full' || domElem){
        let inputModif = DOM_Class.CreateElement('TEXTAREA', {'class': 'csseditor_admin_modal_variable_input hide', 'id': 'csseditor_modal_input_variable'});
        let btn_add = DOM_Class.CreateElement('BUTTON', {'type': 'BUTTON', 'class': 'csseditor_admin_outil_variable_footer_btn_save'}, '+');
        //~ let btn_save_all = DOM_Class.CreateElement('BUTTON', {'type': 'BUTTON', 'class': 'csseditor_admin_outil_variable_footer_btn_save all'}, CSS_EDITOR.texts['js_sav_all']);
        let divFooter = DOM_Class.CreateElement('DIV', {'class': 'csseditor_admin_outil_variable_footer'});
        if (!noob){
            DOM_Class.AppendContent(divFooter, btn_add);
        }
        //~ DOM_Class.AppendContent(divFooter, btn_save_all);
        DOM_Class.AppendContent(domElem, inputModif);
        DOM_Class.AppendContent(domElem, divFooter);
        if (!noob){
            $_e.AddEventClick(btn_add, CSS_EDITOR._variable.addVariable.bind(CSS_EDITOR._variable));
        }
        //~ $_e.AddEvent(btn_save_all, 'mousedown', CSS_EDITOR._variable.saveAll.bind(CSS_EDITOR._variable));
    }
};

CSS_EDITOR.Variable.prototype.Picker.prototype.show = function(evt){
    DOM_Class.ToggleClass(this.domElement, 'hide', false);
    let rectTarg = DOM_Class.GetGlobalRect(this.target, true);
    let rectElem = DOM_Class.GetGlobalRect(this.domElement, true);
    
    let posx = rectTarg.x;
    let posy = rectTarg.y - rectElem.height;
    
    DOM_Class.SetPosition(this.domElement,posx,posy, DOM_Class.ABSOLUTE);
    $_e.AddHideOnMouseDownOutside(this.domElement);
};

CSS_EDITOR.Variable.prototype.Picker.prototype.Hide = function(evt){
    $_e.RemoveHideOnMouseDownOutside(this.domElement);
    DOM_Class.ToggleClass(this.domElement, 'hide', true);
};

CSS_EDITOR.Variable.prototype.Picker.prototype.addToTarget = function(evt){
    //~ let val = evt.target.dataset.value;
    if (this.mode == 'color'){
        let val = evt.target.dataset.value;
        this.target.style.backgroundColor = val;
        this.target.value = val;
    }else if (this.mode == 'other'){
        let val = evt.target.title;
        this.target.value = 'var('+val+')';
    }
};

CSS_EDITOR.Variable.prototype.Picker.prototype.remove = function(evt){
    DOM_Class.RemoveElement(this.domElement);
};

// ----------------------------------------------------------------------------------------------------------
// ----------------------------------------------------------------------------------------------------------

CSS_EDITOR.saveCurrentClass = function(evt){
    
    if (CSS_EDITOR.currentRulesId) {
        let properties = CSS_EDITOR._zoneText.value;
        
        var target = evt.target;
        
        let settings = {};
        settings.url = document.baseURI.split('?')[0].split('#')[0] + 'csseditor/index.php';
        settings.skip_container = true;
        settings.dom_target = 'csseditor_container_choix_class';
        settings.data = {
            'csseditor_action': 'csseditor_save_class',
            'csseditor-rules-id': CSS_EDITOR.currentRulesId,
            'csseditor-rules-properties': properties,
            'csseditor-rules-selector': CSS_EDITOR.currentSelector,
            'csseditor-rules-module': CSS_EDITOR.currentModule,
            'csseditor-rules-id_media': CSS_EDITOR.currentMediaId,
            'csseditor-theme-id': CSS_EDITOR.currentTheme
        };
        
        $_a.send(settings);
    }
};

CSS_EDITOR.changeIdClass = function(newId){
    for (let i = 0; i < this.domChoixClass.length; i++){
        let opt = this.domChoixClass[i];
        if (opt.innerHTML == this.currentSelector){
            opt.value = newId;
            this.currentRulesId = newId;
        }
    }
};

// ----------------------------------------------------------------------------------------------------------
// ----------------------------------------------------------------------------------------------------------

CSS_EDITOR.togglePreviewHighlight = function(evt){
    let targ = evt.target;
    if (evt.firstTime) return;
    if (DOM_Class.HasClass(targ, 'active')){
        this._preview.hideHighlight(this.currentSelector);
        DOM_Class.ToggleClass(targ, 'active', false);
    } else {
        this._preview.showHighlight(this.currentSelector);
        DOM_Class.ToggleClass(targ, 'active', true);
    }
};

CSS_EDITOR.enterOption = function(evt){
    let selector = evt.target.textContent;
    CSS_EDITOR._preview.showHighlight(selector);
};

CSS_EDITOR.leaveOption = function(evt){
    let selector = evt.target.innerHTML;
    CSS_EDITOR._preview.hideHighlight(selector);
};

// ----------------------------------------------------------------------------------------------------------
// ----------------------------------------------------------------------------------------------------------

CSS_EDITOR.initOutil = function(type){
    if (type){
        switch (type){
            case 'border':
                let borderAll = document.getElementById('border_inp_all');
                let borderLeft = document.getElementById('border_inp_gauche');
                let borderRight = document.getElementById('border_inp_right');
                let borderTop = document.getElementById('border_inp_top');
                let borderBot = document.getElementById('border_inp_bot');
                $_e.AddEvent(borderAll, 'change', function(){
                    if (borderLeft.style.display == 'none'){
                        borderRight.style.display = 'inline-block';
                        borderRight.previousElementSibling.style.display = 'inline-block';
                        borderLeft.style.display = 'inline-block';
                        borderLeft.previousElementSibling.style.display = 'inline-block';
                        borderTop.style.display = 'inline-block';
                        borderTop.previousElementSibling.style.display = 'inline-block';
                        borderBot.style.display = 'inline-block';
                        borderBot.previousElementSibling.style.display = 'inline-block';
                    } else {
                        borderRight.style.display = 'none';
                        borderRight.previousElementSibling.style.display = 'none';
                        borderLeft.style.display = 'none';
                        borderLeft.previousElementSibling.style.display = 'none';
                        borderTop.style.display = 'none';
                        borderTop.previousElementSibling.style.display = 'none';
                        borderBot.style.display = 'none';
                        borderBot.previousElementSibling.style.display = 'none';
                    }
                });
                
                let inpColorBorder = document.getElementById('inpColorBorder');
                this._variable.addToElem(inpColorBorder, 'color');
                $_e.AddEventClick(inpColorBorder, (evt)=>{
                    initColorPicker(inpColorBorder, CSS_EDITOR.colorPickerResult);
                });
                
                let inpWidth = document.getElementById('inpWidthBorder');
                this._variable.addToElem(inpWidth, 'other');

                let btnSaveBorder = document.getElementById('btnSaveBorder');
                $_e.AddEventClick(btnSaveBorder, function(evt){
                    let selectStyle = document.getElementById('BorderSelectStyle');
                    let res = '';
                    if (borderAll.checked == true) {
                        res += 'border: ' + CSS_EDITOR.sanitizeValue(inpWidth.value, 'px') + ' ' + selectStyle.value + ' ' + CSS_EDITOR.sanitizeValue(inpColorBorder.value, 'color') + ';';
                    } else {
                        if (borderLeft.checked) {
                            res += 'border-left: ' + CSS_EDITOR.sanitizeValue(inpWidth.value, 'px') + ' ' + selectStyle.value + ' ' + CSS_EDITOR.sanitizeValue(inpColorBorder.value, 'color') + ';';
                        }
                        if (borderTop.checked) {
                            res += 'border-top: ' + CSS_EDITOR.sanitizeValue(inpWidth.value, 'px') + ' ' + selectStyle.value + ' ' + CSS_EDITOR.sanitizeValue(inpColorBorder.value, 'color') + ';';
                        }
                        if (borderRight.checked) {
                            res += 'border-right: ' + CSS_EDITOR.sanitizeValue(inpWidth.value, 'px') + ' ' + selectStyle.value + ' ' + CSS_EDITOR.sanitizeValue(inpColorBorder.value, 'color') + ';';
                        }
                        if (borderBot.checked) {
                            res += 'border-bottom: ' + CSS_EDITOR.sanitizeValue(inpWidth.value, 'px') + ' ' + selectStyle.value + ' ' + CSS_EDITOR.sanitizeValue(inpColorBorder.value, 'color') + ';';
                        }
                        res = res.replace(/;b/g, ';\nb');
                    }
                    CSS_EDITOR._zoneText.insertRules(['border', 'border-left', 'border-top', 'border-right', 'border-bottom'], res);
                });
            break;
            
            case 'radius':
                let iframe = document.getElementById('outilsBorderRadius');
                iframe.addEventListener('load', function(){
                    let innerDoc = iframe.contentWindow.document;
                    let btnSaveRadius = innerDoc.getElementById('rules-save');
                    $_e.AddEventClick(btnSaveRadius, function(){
                        let res = innerDoc.getElementById('output').innerHTML;
                        CSS_EDITOR._zoneText.insertRules('border-radius', res);
                    });
                });
            break;
            
            case 'background':
                let selType = document.getElementById('selTypeBackground');
                let divColor = document.getElementById('backgroundSubColor');
                let divGradient = document.getElementById('backgroundSubGradient');
                let divImage = document.getElementById('backgroundSubImage');
                
                let currentType = 'color';
                
                $_e.AddEvent(selType, 'change', function(evt){
                    let selected = evt.target.selectedOptions[0].value;
                    switch (selected) {
                        case 'color':
                            divColor.style.display = 'block';
                            divGradient.style.display = 'none';
                            divImage.style.display = 'none';
                        break;
                        case 'gradient':
                            divGradient.style.display = 'block';
                            divColor.style.display = 'none';
                            divImage.style.display = 'none';
                        break;
                        case 'image':
                            divImage.style.display = 'grid';
                            divColor.style.display = 'none';
                            divGradient.style.display = 'none';
                        break;
                        default:
                        break;
                    }
                    currentType = selected;
                });
                
                let inpColorBack = document.getElementById('backgroundInpColor');
                this._variable.addToElem(inpColorBack, 'color');
                $_e.AddEventClick(inpColorBack, function(){
                    initColorPicker(inpColorBack, CSS_EDITOR.colorPickerResult);
                });
                
                let divCustomAngle = document.getElementById('backgroundGradientCustom');
                let divRadial = document.getElementById('backgroundGradientRadial');
                let divInverse = document.getElementById('backgroundInverseGradient');
                let selOrientation = document.getElementById('selOrientationBackground');
                $_e.AddEvent(selOrientation, 'change', function(e){
                    if (selOrientation.selectedOptions[0].value == 'custom') {
                        divCustomAngle.style.display = 'block';
                        divRadial.style.display = 'none';
                        divInverse.style.display = 'none';
                    } else if (selOrientation.selectedOptions[0].value == 'radial') {
                        divCustomAngle.style.display = 'none';
                        divRadial.style.display = 'block';
                        divInverse.style.display = 'none';
                    } else {
                        divInverse.style.display = 'inline-block';
                        divCustomAngle.style.display = 'none';
                        divRadial.style.display = 'none';
                    }
                });
                
                let btnAddGrad = document.getElementById('backgroundGradientAddColor');
                $_e.AddEventClick(btnAddGrad, this.addColorGradient.bind(this));
                
                let btnSaveBack = document.getElementById('btnSaveBackground');
                $_e.AddEventClick(btnSaveBack, function(evt){
                    let res = '';
                    switch (currentType){
                        case 'color':
                            res += 'background: ';
                            res += CSS_EDITOR.sanitizeValue(inpColorBack.value, 'color') + ';';
                            CSS_EDITOR._zoneText.insertRules(['background'], res);
                        break;
                        case 'gradient':
                            let inpInverse = document.getElementById('InpInverseBackgroundGrad');
                            res += 'background:linear-gradient(';
                            let angle = selOrientation.selectedOptions[0].value;
                            if (angle == 'custom') {
                                res += CSS_EDITOR.sanitizeValue(document.getElementById('backgroundGradientCustomAngle').value, 'deg');
                            } else if (angle == 'horizontal') {
                                if (inpInverse.checked) res += 'to left';
                                else res += 'to right';
                            } else if (angle == 'vertical') {
                                if (inpInverse.checked) res += 'to top';
                                else res += 'to bottom';
                            } else if (angle == 'radial') {
                                res = 'background:radial-gradient(' + document.getElementById('selShapeBackgroundRadial').selectedOptions[0].value + ' ' + document.getElementById('selStyleBackgroundRadial').selectedOptions[0].value;
                                let pos = document.getElementById('backgroundGradientRadialPosition');
                                if (pos.value != '') {
                                    res += ' at ' + pos.value;
                                }
                            }
                            let divColorGradient = document.getElementById('backgroundGradientColor');
                            let colors = divColorGradient.children;
                            for (j = 1; j < colors.length; j++) {
                                let childs = colors[j].childNodes;
                                if (childs[1].value != '') {
                                    res += ',' + CSS_EDITOR.sanitizeValue(childs[1].value, 'color');
                                }
                                if (childs[4].value != ''){
                                    res += ' ' + CSS_EDITOR.sanitizeValue(childs[4].value, '%');
                                }
                            }
                            res += ');';
                            CSS_EDITOR._zoneText.insertRules(['background'], res);
                            break;
                        break;
                        case 'image':
                            let inpUrl = document.getElementById('backgroundImageInpUrl');
                            let position = document.getElementById('backgroundImageInpPosition');
                            let size = document.getElementById('backgroundImageInpSize');
                            let repeat = document.getElementById('selRepeatBackground');
                            let attachment = document.getElementById('selAttachmentBackground');
                            
                            res += 'background: ';
                            if (inpUrl.value != ''){
                                res += 'url(' + inpUrl.value + ') ';
                            }
                            if (position.value != ''){
                                res += CSS_EDITOR.sanitizeValue(position.value, '%') + ' ';
                                if (size.value != ''){
                                    res += '/ ' + CSS_EDITOR.sanitizeValue(size.value, '%') + ' ';
                                }
                            }
                            res += repeat.selectedOptions[0].value + ' ';
                            res += attachment.selectedOptions[0].value;
                            res += ';';
                            CSS_EDITOR._zoneText.insertRules(['background'], res);
                        break;
                    }
                });
            break;
            
            case 'font':
                let selFamily = document.getElementById('fontSelFamily');
                this.addCustomFontToSelect();
                
                let btnManageFont = document.getElementById('btnManageFontFamily');
                $_e.AddEventClick(btnManageFont, function(){
                    CSS_EDITOR.manageFont.bind(CSS_EDITOR)();
                });
            
                let btnSaveFont = document.getElementById('btnAddFont');
                
                let inpSize = document.getElementById('fontInpSize');
                this._variable.addToElem(inpSize, 'other');
                
                $_e.AddEventClick(btnSaveFont, function(evt){
                    let selStyle = document.getElementById('fontSelStyle');
                    let selVariant = document.getElementById('fontSelVariant');
                    let selWeight = document.getElementById('fontSelWeight');
                    
                    if (selFamily.selectedOptions[0].value != ''){
                        CSS_EDITOR._zoneText.insertRules('font-family', 'font-family: '+selFamily.selectedOptions[0].value+';');
                    }
                    
                    //~ let res = 'font:';
                    if (selStyle.selectedOptions[0].value != 'normal'){
                        //~ res += selStyle.selectedOptions[0].value+' ';
                        CSS_EDITOR._zoneText.insertRules('font-style', 'font-style: '+selStyle.selectedOptions[0].value+';');
                    }
                    if (selVariant.selectedOptions[0].value != 'normal'){
                        //~ res += selVariant.selectedOptions[0].value+' ';
                        CSS_EDITOR._zoneText.insertRules('font-variant', 'font-variant: '+selVariant.selectedOptions[0].value+';');
                    }
                    if (selWeight.selectedOptions[0].value != 'normal'){
                        //~ res += selWeight.selectedOptions[0].value+' ';
                        CSS_EDITOR._zoneText.insertRules('font-weight', 'font-weight: '+selWeight.selectedOptions[0].value+';');
                    }
                    if (inpSize.value != ''){
                        //~ res += CSS_EDITOR.sanitizeValue(inpSize.value, 'px') +' ';
                        CSS_EDITOR._zoneText.insertRules('font-size', 'font-size: '+CSS_EDITOR.sanitizeValue(inpSize.value, 'px')+';');
                    }
                    //~ res += ';';
                    //~ CSS_EDITOR._zoneText.insertRules(['font'], res);
                });
                
                // text
                let inpTextColor = document.getElementById('textInpColor');
                this._variable.addToElem(inpTextColor, 'color');
                $_e.AddEventClick(inpTextColor, function(){
                    initColorPicker(inpTextColor, CSS_EDITOR.colorPickerResult);
                });
                
                let checkDeco = document.getElementById('textCheckDecoration');
                let divDeco = document.getElementById('textDivDecoration');
                $_e.AddEvent(checkDeco, 'change', function(e) {
                    if (checkDeco.checked) {
                        divDeco.style.display = 'flex';
                    } else {
                        divDeco.style.display = 'none';
                    }
                });
                let inpColorDeco = document.getElementById('textInpColorDecoration');
                this._variable.addToElem(inpColorDeco, 'color');
                $_e.AddEventClick(inpColorDeco, function(){
                    initColorPicker(inpColorDeco, CSS_EDITOR.colorPickerResult);
                });
                
                let inpLetter = document.getElementById('textInpLetter');
                this._variable.addToElem(inpLetter, 'other');
                
                let inpLineHeight = document.getElementById('textInpLine');
                this._variable.addToElem(inpLineHeight, 'other');
                
                let indent = document.getElementById('textInpIndent');
                this._variable.addToElem(indent, 'other');
                
                let wordSpace = document.getElementById('textSelWhiteSpace');
                this._variable.addToElem(wordSpace, 'other');
                
                let btnSaveText = document.getElementById('btnAddText');
                $_e.AddEventClick(btnSaveText, function(evt){
                    
                    if (inpLetter.value != 'normal') CSS_EDITOR._zoneText.insertRules('letter-spacing', 'letter-spacing: '+CSS_EDITOR.sanitizeValue(inpLetter.value, 'px')+';');
                    if (inpLineHeight.value != 'normal') CSS_EDITOR._zoneText.insertRules('line-height', 'line-height: '+CSS_EDITOR.sanitizeValue(inpLineHeight.value, 'px')+';');
                    if (indent.value != '') CSS_EDITOR._zoneText.insertRules('text-indent', 'text-indent: '+CSS_EDITOR.sanitizeValue(indent.value, 'px')+';');
                    if (wordSpace.value != 'normal') CSS_EDITOR._zoneText.insertRules('word-spacing', 'word-spacing: '+CSS_EDITOR.sanitizeValue(wordSpace.value, 'px')+';');
                    
                    let selAlign = document.getElementById('textSelAlign').selectedOptions[0];
                    CSS_EDITOR._zoneText.insertRules('text-align', 'text-align: '+selAlign.value+';');
                    
                    if (checkDeco.checked){
                        let res = 'text-decoration: ';
                        let selType = document.getElementById('textSelTypeDecoration').selectedOptions[0];
                        if (selType.value != 'none'){
                            let selStyle = document.getElementById('textSelStyleDecoration').selectedOptions[0];
                            res += selType.value + ' ' + selStyle.value + ' ' + CSS_EDITOR.sanitizeValue(inpColorDeco.value, 'color') + ';';
                        } else {
                            res += selType.value + ';';
                        }
                        CSS_EDITOR._zoneText.insertRules('text-decoration', res);
                    }
                    
                    let selTansform = document.getElementById('textSelTransform').selectedOptions[0];
                    if (selTansform.value != 'none') CSS_EDITOR._zoneText.insertRules('text-transform', 'text-transform: '+selTansform.value+';');
                    
                    let verticalAlign = document.getElementById('textSelVAlign').selectedOptions[0];
                    if (verticalAlign.value != 'baseline') CSS_EDITOR._zoneText.insertRules('vertical-align', 'vertical-align: '+verticalAlign.value+';');
                    
                    let whiteSpace = document.getElementById('textSelWhiteSpace').selectedOptions[0];
                    if (whiteSpace.value != 'normal') CSS_EDITOR._zoneText.insertRules('white-space', 'white-space: '+whiteSpace.value+';');
                });
            break;
            
            case 'shadow':
                let inpTextShadow = document.getElementById('shadowCheckText');
                let inpBoxShadow = document.getElementById('shadowCheckBox');
                let inpInset = document.getElementById('shadowCheckInset');
                let inpSpread = document.getElementById('shadowInpSpread');
                $_e.AddEvent(inpTextShadow, 'change', function(evt){
                    if (evt.target.checked) {
                        inpInset.style.display = 'none';
                        inpInset.previousElementSibling.style.display = 'none';
                        inpSpread.style.display = 'none';
                        inpSpread.previousElementSibling.style.display = 'none';
                    }
                });
                $_e.AddEvent(inpBoxShadow, 'change', function(evt){
                    if (evt.target.checked) {
                        inpInset.style.display = 'inline-block';
                        inpInset.previousElementSibling.style.display = 'inline-block';
                        inpSpread.style.display = 'inline-block';
                        inpSpread.previousElementSibling.style.display = 'inline-block';
                    }
                });
                
                let inpColorShadow = document.getElementById('inpColorShadow');
                this._variable.addToElem(inpColorShadow, 'color');
                $_e.AddEventClick(inpColorShadow, function(){
                    initColorPicker(inpColorShadow, CSS_EDITOR.colorPickerResult);
                });
                
                let inpHoriz = document.getElementById('shadowInpHorizontal');
                let inpVerti = document.getElementById('shadowInpVertical');
                let inpBlur = document.getElementById('shadowInpBlur');
                this._variable.addToElem(inpHoriz, 'other');
                this._variable.addToElem(inpVerti, 'other');
                this._variable.addToElem(inpBlur, 'other');
                this._variable.addToElem(inpSpread, 'other');
                
                let btnSaveShadow = document.getElementById('btnAddShadow');
                $_e.AddEventClick(btnSaveShadow, function(evt){
                    let res = '';
                    if (inpTextShadow.checked){
                        res += 'text-shadow: ' + CSS_EDITOR.sanitizeValue(inpHoriz.value, 'px') + ' ' + CSS_EDITOR.sanitizeValue(inpVerti.value, 'px') + ' ' + CSS_EDITOR.sanitizeValue(inpBlur.value, 'px') + ' ' + CSS_EDITOR.sanitizeValue(inpColorShadow.value, 'color') + ';';
                        CSS_EDITOR._zoneText.insertRules('text-shadow', res);
                    } else {
                        res += 'box-shadow: ';
                        if (inpInset.checked) res += 'inset ';
                        res += inpHoriz.value + ' ' + CSS_EDITOR.sanitizeValue(inpVerti.value, 'px') + ' ' + CSS_EDITOR.sanitizeValue(inpBlur.value, 'px') + ' ' + CSS_EDITOR.sanitizeValue(inpSpread.value, 'px') + ' ' + CSS_EDITOR.sanitizeValue(inpColorShadow.value, 'color') + ';';
                        CSS_EDITOR._zoneText.insertRules('box-shadow', res);
                    }
                });
            break;
        }
    }
};

CSS_EDITOR.addColorGradient = function(evt){
    let parent = evt.target.parentElement;
    let length = parent.children.length;
    
    let divUniqueColor = DOM_Class.CreateElement('DIV', {'id': 'gradientUniqueColor_'+length, 'class': 'csseditor_admin_background_gradient_color'});
        let labColorGrad = DOM_Class.CreateElement('LABEL', {'for': 'inpColorGradient'+length, 'class': 'csseditor_admin_outil_lab'}, 'color');
        let inpColorGrad = DOM_Class.CreateElement('INPUT', {'type': 'text', 'id': 'inpColorGradient'+length, 'class': 'csseditor_admin_outil_inp background gradient color'});
        inpColorGrad.style.backgroundColor = '#FFFFFF';
        inpColorGrad.value = '#FFFFFF';
    divUniqueColor.appendChild(labColorGrad);
    divUniqueColor.appendChild(inpColorGrad);
        let labLocationGrad = DOM_Class.CreateElement('LABEL', {'for': 'inpLocationGradient'+length, 'class': 'csseditor_admin_outil_lab'}, 'location');
        let inpLocationGrad = DOM_Class.CreateElement('INPUT', {'type': 'text', 'id': 'inpLocationGradient'+length, 'class': 'csseditor_admin_outil_inp background gradient location'});
    divUniqueColor.appendChild(labLocationGrad);
    divUniqueColor.appendChild(inpLocationGrad);
    parent.appendChild(divUniqueColor);
    
    this._variable.addToElem(inpLocationGrad, 'other');
    this._variable.addToElem(inpColorGrad, 'color');
    $_e.AddEventClick(inpColorGrad, function(evt){
        initColorPicker(inpColorGrad, CSS_EDITOR.colorPickerResult);
    });
};

CSS_EDITOR.sanitizeValue = function(val, type){
    if (val && type){
        if (type == 'color') {
            for (let selector in this._variable.rules){
                if (this._variable.rules[selector].properties == val){
                    return 'var('+selector+')';
                } else {
                    continue;
                }
            }
            return val;
        } else {
            let res = val.replace(/[0-9]/g, '');
            if (res == '') return val+type;
            else return val;
        }
    }
};
// ----------------------------------------------------------------------------------------------------------
// ----------------------------------------------------------------------------------------------------------

CSS_EDITOR.customSelect = function(domElem){

    let parentSelect = domElem;
    var selectElem = document.getElementById('css_choix_class');
    //~ var selectElem = domElem.lastElementChild.previousElementSibling;
    
    let a = DOM_Class.CreateElement('DIV', {'class': 'csseditor_admin_custom_select_selected'}, selectElem.options[selectElem.selectedIndex].innerHTML);
    DOM_Class.InsertAfter(a, selectElem);
    
    let b = DOM_Class.CreateElement('DIV', {'class': 'csseditor_admin_custom_select-items hide'});
    for (let i = 1; i < selectElem.length; i++) {
        this.addOptionToSelect(selectElem.options[i].innerHTML, selectElem.options[i].value, b);
    }
    DOM_Class.InsertAfter(b,a);
    $_e.AddEventClick(a, this.onClickCustomSelect);
    $_e.AddEvent(selectElem, EVENTS_Class.EVENT_MOUSEUP_OUTSIDE, this.closeAllCustomSelect);
    //$_e.AddEventClick(document, this.closeAllCustomSelect);
    //document.addEventListener("click", this.closeAllCustomSelect);
};

CSS_EDITOR.addOptionToSelect = function(val, id, domTarget){
    let c = DOM_Class.CreateElement('DIV', {'class': 'csseditor_admin_custom_select_options'}, val);
    
    // btn delete et edit
    let btn_delete = DOM_Class.CreateElement('SPAN', {'class': 'csseditor_admin_custom_select_options_delete'});
    let btn_edit = DOM_Class.CreateElement('SPAN', {'class': 'csseditor_admin_custom_select_options_edit'});
    c.appendChild(btn_edit);
    c.appendChild(btn_delete);
    $_e.AddEventClick(btn_delete, function(evt){
        $_e.StopEvent(evt);
        let t = confirm('T\'es sur ?');
        if (t){
            let data = {
                'csseditor_action': 'csseditor_delete_class',
                'csseditor-rules-id': id
            };
            let settings = {'url': document.baseURI.split('?')[0].split('#')[0] + 'csseditor/index.php', 'skip_container': true, 'dom_target': '', 'data': data};
            settings.success = function(res){
                if (res){
                    DOM_Class.RemoveElement(c);
                }
            };
            $_a.send(settings);
        }
    });
    $_e.AddEventClick(btn_edit, function(evt){
        $_e.StopEvent(evt);
        let data = {
            'csseditor-rules-id': id,
            'csseditor-rules-selector': val,
            'csseditor-rules-modules': CSS_EDITOR.currentModule
        };
        CSS_EDITOR.showModalForm.bind(CSS_EDITOR)('class', data);
    });
    $_e.AddEventClick(c, function(evt){
        $_e.StopEvent(evt);
        // When an item is clicked, update the original select box and the selected item:
        let targ = evt.target;
        var y, i, k, s, h;
        s = CSS_EDITOR.domChoixClass;
        h = targ.parentNode.previousSibling;
        for (i = 0; i < s.length; i++) {
            if (s.options[i].textContent == targ.textContent) {
                s.selectedIndex = i;
                $_e.SendEvent(s, 'change');
                h.innerHTML = targ.innerHTML;
                y = targ.parentNode.getElementsByClassName("same-as-selected");
                for (k = 0; k < y.length; k++) {
                    DOM_Class.ToggleClass(y[k], 'same-as-selected', false);
                }
                DOM_Class.ToggleClass(targ, 'same-as-selected', true);
                break;
            }
        }
        h.click();
    });
    //c.addEventListener('mouseenter', this.enterOption);
    //c.addEventListener('mouseleave', this.leaveOption);
    $_e.AddEvent(c, EVENTS_Class.EVENT_MOUSEENTER, this.enterOption);
    $_e.AddEvent(c, EVENTS_Class.EVENT_MOUSELEAVE, this.leaveOption);

    
    domTarget.appendChild(c);
    return c;
};

CSS_EDITOR.onClickCustomSelect = function(e){
    /* When the select box is clicked, close any other select boxes,
    and open/close the current select box: */
    $_e.StopEvent(e);
    let targ = e.target;
    CSS_EDITOR.closeAllCustomSelect(targ);
    DOM_Class.ToggleClass(targ.nextSibling, 'hide');
    DOM_Class.ToggleClass(targ, 'select-arrow-active');
    let btnHighlight = document.getElementById('csseditor_toolbar_elem_highlight');
    if (CSS_EDITOR._preview.isHighlighted && DOM_Class.HasClass(btnHighlight, 'active')) {
        $_e.SendEvent(btnHighlight, 'mousedown');
        //~ CSS_EDITOR._preview.hideHighlight();
    }
};

CSS_EDITOR.onClickOptionCustom = function(evt){
    $_e.StopEvent(evt);
    // When an item is clicked, update the original select box and the selected item:
    var y, i, k, s, h;
    s = selectElem;
    h = this.parentNode.previousSibling;
    for (i = 0; i < s.length; i++) {
        if (s.options[i].innerHTML == this.innerHTML) {
            s.selectedIndex = i;
            $_e.SendEvent(s, 'change');
            h.innerHTML = this.innerHTML;
            y = this.parentNode.getElementsByClassName("same-as-selected");
            for (k = 0; k < y.length; k++) {
                DOM_Class.ToggleClass(y[k], 'same-as-selected', false);
            }
            DOM_Class.ToggleClass(this, 'same-as-selected', true);
            break;
        }
    }
    h.click();
};

CSS_EDITOR.closeAllCustomSelect = function(elmnt){
    /* A function that will close all select boxes in the document,
    except the current select box: */
    var x, y, i, arrNo = [];
    x = document.getElementsByClassName("csseditor_admin_custom_select-items");
    y = document.getElementsByClassName("csseditor_admin_custom_select_selected");
    for (i = 0; i < y.length; i++) {
        if (elmnt == y[i]) {
            arrNo.push(i);
        } else {
            y[i].classList.remove("select-arrow-active");
        }
    }
    for (i = 0; i < x.length; i++) {
        if (arrNo.indexOf(i)) {
            x[i].classList.add("hide");
        }
    }
};
// ----------------------------------------------------------------------------------------------------------
// ----------------------------------------------------------------------------------------------------------
// ----------------------------------------------------------------------------------------------------------
// TEXTAREA

CSS_EDITOR.ZoneText = function(){
    var _self = this;
    
    // temps en ms avant d'update la preview après le dernier keypress
    this.updTime = 800;
    
    this.prevEventTime;
    //~ this.timeOut = false;
    //~ this.modified = false;
    
    
    this.domElement = document.getElementById('css_contenu_class');
    
    this.history = [];
    
    if (this.domElement){
        $_e.AddEvent(this.domElement, 'focus', this.onFocus.bind(this));
        $_e.AddEvent(this.domElement, 'blur', this.onBlur.bind(this));
        //$_e.AddEvent(this.domElement, 'paste', this.onPaste.bind(this));
    }
};
CSS_EDITOR.ZoneText.prototype.constructor = CSS_EDITOR.ZoneText;

CSS_EDITOR.ZoneText.prototype.reset = function(){
    this.value = '';
    this.prevEventTime = false;
};

Object.defineProperty(CSS_EDITOR.ZoneText.prototype, 'value', {
    get: function() {
        return this.domElement.value.replace(/\n/g, '');
    },
    set: function(val){
        if (val || val == '') {
            //~ this.history.push(val);
            this.domElement.value = val.replace(/;/g, ';\n');
        }
    }
});

CSS_EDITOR.ZoneText.prototype.onFocus = function(evt){
    $_e.AddEventKey(this.domElement, this.autoUpdatePreview.bind(this));
};

CSS_EDITOR.ZoneText.prototype.onBlur = function(evt){
    this.getCusorPos();
    $_e.RemoveEvent(this.domElement, 'keyup');
};

//~ CSS_EDITOR.ZoneText.prototype.onPaste = function(evt){
    //~ $_e.StopEvent(evt);
    //~ $_e.StopPropagation(evt);

    //~ // Get pasted data via clipboard API
    //~ let clipboardData = evt.clipboardData || window.clipboardData;
    //~ let pastedData = clipboardData.getData('Text');
    //~ if (evt.target != this.domElement){
        //~ modified = pastedData.replace(new RegExp('\r?\n','g'), '');
    //~ } else {
        //~ modified = pastedData;
    //~ }
    //~ evt.target.value += modified;
//~ };

CSS_EDITOR.ZoneText.prototype.getCusorPos = function(){
    if (this.domElement.selectionStart == this.domElement.selectionEnd) {
        cursor = parseInt(this.domElement.selectionStart);
    } else {
        cursor = {
            start: parseInt(this.domElement.selectionStart),
            end: parseInt(this.domElement.selectionEnd)
        };
    }
    this.currentCursorPos = cursor;
};

CSS_EDITOR.ZoneText.prototype.insertVar = function(evt){
    let targ = evt.target;
    if (targ.tagName == 'DIV') targ = targ.firstElementChild;
    
    // check si le textarea est focus, si pas ça, insertAtCursor est executé avant que le textarea perde le focus (et ça bug)
    if (document.activeElement == this.domElement) this.domElement.blur();
    
    let toInsert = 'var(' + targ.innerHTML + ')';
    
    this.insertAtCursor(toInsert);
};

CSS_EDITOR.ZoneText.prototype.insertRules = function(type, rules){
    if (type && rules){
        if (GENERICS_Class.IsArray(type)){
            for(let i = 0; i < type.length; i++){
                this.removeFromCss(type[i]);
            }
        } else { // string
            this.removeFromCss(type);
        }
        this.domElement.value += rules+'\n';
        this.updatePreview();
    }
};

CSS_EDITOR.ZoneText.prototype.insertAtCursor = function(str){
    if (this.currentCursorPos){
        if (GENERICS_Class.IsObject(this.currentCursorPos)){
            let newVal = this.domElement.value.substring(0, this.currentCursorPos.start) + str + this.domElement.value.substring(this.currentCursorPos.end);
            this.domElement.value = newVal;
        } else {
            let newVal = this.domElement.value.substring(0, this.currentCursorPos) + str + this.domElement.value.substring(this.currentCursorPos);
            this.domElement.value = newVal;
        }
        this.currentCursorPos = {
            start: (this.currentCursorPos.start) ? this.currentCursorPos.start : this.currentCursorPos,
            end: (this.currentCursorPos.start) ? parseInt(this.currentCursorPos.start + str.length) : parseInt(this.currentCursorPos + str.length)
        };
        this.updatePreview();
    }
};

CSS_EDITOR.ZoneText.prototype.autoUpdatePreview = function(){
    if (this.timeout) {
        clearTimeout(this.timeout);
        this.timeout = false;
    }
    this.timeout = setTimeout(this.updatePreview.bind(this), this.updTime);
};

CSS_EDITOR.ZoneText.prototype.updatePreview = function(){
    CSS_EDITOR._preview.changeClass(CSS_EDITOR.currentSelector, this.value);
};

CSS_EDITOR.ZoneText.prototype.removeFromCss = function(type){
    if (type){
        let res = '';
        let val = Array.from(this.value.split(';'));
        val.forEach((elem)=>{
            let t = elem.split(':');
            if (t[0].trim() == type){
                res = elem+';';
            }
        });
        if (res != '') {
            this.value = this.value.replace(res, '');
            return true;
        }
    }
    return false;
};
// ----------------------------------------------------------------------------------------------------------
// ----------------------------------------------------------------------------------------------------------
// ----------------------------------------------------------------------------------------------------------
// PREVIEW

CSS_EDITOR.Preview = function(rules){
    var _self = this;
    
    this.currentHighlightSelector = false;
    this.currentHighlight = false;
    
    this.prevPicker = false;
    
    this.full = false;
};
CSS_EDITOR.Preview.prototype.constructor = CSS_EDITOR.Preview;

Object.defineProperty(CSS_EDITOR.Preview.prototype, 'isHighlighted', {
    get: function() {
        if (this.currentHighlight) return true;
        else return false;
    }
});

Object.defineProperty(CSS_EDITOR.Preview.prototype, 'document', {
    get: function() {
        if (this.full) return top.fullPreview.document;
        else if (CSS_EDITOR.noob) {
            if (top.preview_admin) return top.preview_admin.preview_public.document;
            else return top.preview_public.document;
        }
        else return top.preview.document;
    }
});

Object.defineProperty(CSS_EDITOR.Preview.prototype, 'window', {
    get: function() {
        if (this.full) return top.fullPreview.window;
        else if (CSS_EDITOR.noob) {
            if (top.preview_admin) return top.preview_admin.preview_public.document;
            else return top.preview_public.document;
        }
        else return top.preview.window;
    }
});

Object.defineProperty(CSS_EDITOR.Preview.prototype, 'stylesheet', {
    get: function() {
        let doc = this.document;
        let stylesheet = doc.getElementById('media_'+CSS_EDITOR.currentMediaId);
        if (stylesheet) {
            return stylesheet.sheet;
        }
    }
});

Object.defineProperty(CSS_EDITOR.Preview.prototype, 'isActive', {
    get: function() {
        if (CSS_EDITOR.currentModule) return true;
        else if (this.domElement) return true;
        else return false;
    }
});

CSS_EDITOR.Preview.prototype.showOne = function(){
    var _self = this;
    
    let settings = {};
    settings.url = document.baseURI.split('?')[0].split('#')[0] + 'csseditor/index.php';
    settings.skip_container = true;
    settings.dom_target = 'css_contenu_preview';
    settings.data = {
        'csseditor_action': 'csseditor_preview',
        'csseditor-theme-id': CSS_EDITOR.currentTheme,
        'csseditor-rules-module': CSS_EDITOR.currentModule
    };
    
    settings.success = function(res){
        
        _self.domElement = document.getElementById('css_preview_iframe');
        if (_self.domElement){
            $_e.AddEvent(_self.domElement, 'load', function(){
                _self.ApplyCss(CSS_EDITOR.allRules);
            });
        }
        
    };
    
    $_a.send(settings);
};

CSS_EDITOR.Preview.prototype.ApplyCss = function(rules, mediaId = false){
    
    if (!mediaId) mediaId = CSS_EDITOR.currentMediaId;
    
    let themeCss = '';
    themeCss += ':root{' + CSS_EDITOR._variable.str + '}\n';
    for(let i = 0; i < CSS_EDITOR.cssFont.str.length; i++){
        themeCss += '@font-face{' + CSS_EDITOR.cssFont.str[i].replace(/\\/g, '') + '}\n';
    }
    let moduleCss = this.ObjToCss(rules);
    
    let doc = this.document;
    var styleSheet = false;
    for (var i=0; i < doc.styleSheets.length; i++){
        if (doc.styleSheets[i].title == 'media_'+mediaId) {
            styleSheet = doc.styleSheets[i];
        }
    }
    if (!styleSheet){
        let stylesheetElement = DOM_Class.CreateElement('STYLE', {
            'type': 'text/css',
            'rel': 'stylesheet',
        });
        
        stylesheetElement.setAttribute('id', 'media_'+mediaId);
        
        if (this.full && mediaId != CSS_EDITOR.normalMediaId){
            DOM_Class.AppendContent(stylesheetElement, CSS_EDITOR.currentMediaValue + '{\n' + themeCss + '\n' + moduleCss + '}');
        } else {
            DOM_Class.AppendContent(stylesheetElement, themeCss + '\n' + moduleCss);
        }
        
        this.document.head.appendChild(stylesheetElement);
        if (stylesheetElement.disabled) stylesheetElement.disabled = false;
    } else {
        if (this.full && mediaId != CSS_EDITOR.normalMediaId){
            styleSheet.innerHTML = CSS_EDITOR.currentMediaValue + '{\n' + themeCss + '\n' + moduleCss + '}';
            //~ DOM_Class.AppendContent(styleSheet, CSS_EDITOR.currentMediaValue + '{\n' + themeCss + '\n' + moduleCss + '}');
        } else {
            styleSheet.innerHTML = themeCss + '\n' + moduleCss;
            //~ DOM_Class.AppendContent(styleSheet, themeCss + '\n' + moduleCss);
        }
        styleSheet.disabled = false;
    }
    
    //~ if (!this.full && CSS_EDITOR.currentMediaId == CSS_EDITOR.normalMediaId){
        //~ let doc = this.document;
        //~ for (var i=0; i < doc.styleSheets.length; i++){
            //~ if (doc.styleSheets[i].title != 'media_'+CSS_EDITOR.currentMediaId) doc.styleSheets[i].disabled = true;
        //~ }
    //~ }
};

CSS_EDITOR.Preview.prototype.ObjToCss = function(objRules){
    let cssRules = '';
    
    for (let selector in objRules){
        cssRules += selector + '{' + objRules[selector] + '}\n';
    }
    
    return cssRules;
};

CSS_EDITOR.Preview.prototype.prepareForModification = function(){
    let styleSheetElement = DOM_Class.CreateElement('STYLE', {
        'type': 'text/css',
        'rel': 'stylesheet',
        'title': 'modified'
    }, document.createTextNode(''));
    this.document.head.appendChild(styleSheetElement);
    this.stylesheet = styleSheetElement;
};

CSS_EDITOR.Preview.prototype.changeClass = function(selector, style){
    
    var stylesheet = this.stylesheet;
    
    var styleSheetLength = (stylesheet.cssRules) ? stylesheet.cssRules.length : 0;
    if (styleSheetLength){
        for( let i = 0; i < styleSheetLength; i++) {
            if(stylesheet.cssRules[i].selectorText && stylesheet.cssRules[i].selectorText.toLowerCase() == selector.toLowerCase()) {
                stylesheet.cssRules[i].style.cssText = style;
                return;
            }
        }
    }
    
    stylesheet.insertRule(selector + "{" + style + "}", styleSheetLength);
    if (stylesheet.disabled) stylesheet.disabled = false;
};

CSS_EDITOR.Preview.prototype.changeVar = function(selector, value){
    // le selector :root est sur la balise html (ou documentElement), on peut donc simplement surclasser l'ancienne valeur avec setProperty
    this.document.documentElement.style.setProperty(selector, value);
};

CSS_EDITOR.Preview.prototype.showHighlight = function(selector){
    if (selector){
        selector = selector.replace(/&gt;/g, '>');
        this.currentHighlight = Array.from(this.document.querySelectorAll(selector));
        this.currentHighlightSelector = selector;
        
        //~ let sx = this.window.scrollX || (((t = this.document.documentElement) || (t = this.document.body.parentNode)) && typeof t.ScrollLeft == 'number' ? t : this.document.body).ScrollLeft || 0;
        //~ let sy = this.window.scrollY || (((t = this.document.documentElement) || (t = this.document.body.parentNode)) && typeof t.ScrollTop == 'number' ? t : this.document.body).ScrollTop || 0;
        
        this.currentHighlight.forEach((elem, index)=>{
            let overlay = DOM_Class.CreateElement('DIV', {'style': 'background: #87c4f080; position: absolute; z-index: 9999; pointer-events: none;'});
            this.document.body.appendChild(overlay);
            
            let rect = this.getRect(elem);
            overlay.style.left = rect.left + 'px';
            overlay.style.top = rect.top + 'px';
            overlay.style.width = rect.width + 'px';
            overlay.style.height = rect.height + 'px';
            this.currentHighlight[index] = overlay;
        });
    } else {
        console.error('NO SELECTOR');
    }
};

CSS_EDITOR.Preview.prototype.hideHighlight = function(){
    if (this.isHighlighted){
        this.currentHighlight.forEach((elem)=>{
            //~ DOM_Class.RemoveElement(elem.nextElementSibling);
            DOM_Class.RemoveElement(elem);
        });
        
        this.currentHighlight = false;
        this.currentHighlightSelector = false;
    }
};

CSS_EDITOR.Preview.prototype.addFont = function(fontName, fontUrl){
    var newStyle = document.createElement('style');
    newStyle.appendChild(document.createTextNode('@font-face {font-family: "' + fontName + '";src: url(' + fontUrl + ');}'));
    this.document.head.appendChild(newStyle);
};

CSS_EDITOR.Preview.prototype.getRect = function(domElement){
    if(!domElement){
        return null;
    }

    if(domElement === this.document){
        domElement = this.document.body;
    }

    if(!domElement.getBoundingClientRect){
        debugger;
    }

    let rect = domElement.getBoundingClientRect();

    if(domElement == this.document.body){
        rect = {left:rect.left , top:rect.top , right:rect.right , bottom:rect.bottom , width:rect.width , height:rect.height};
        if(rect.height === 0){
            rect.bottom = this.window.innerHeight;
            rect.height = this.window.innerHeight;
        }
        if(rect.width === 0){
            rect.right = this.window.innerWidth;
            rect.width = this.window.innerWidth;
        }
    }

    let sx = this.window.scrollX || (((t = this.document.documentElement) || (t = this.document.body.parentNode)) && typeof t.ScrollLeft == 'number' ? t : this.document.body).ScrollLeft || 0;
    let sy = this.window.scrollY || (((t = this.document.documentElement) || (t = this.document.body.parentNode)) && typeof t.ScrollTop == 'number' ? t : this.document.body).ScrollTop || 0;

    let temp = {};
    temp.left     = rect.left + sx;
    temp.top      = rect.top + sy;
    temp.right    = rect.right + sx;
    temp.bottom   = rect.bottom + sy;
    temp.width    = rect.right - rect.left;
    temp.height   = rect.bottom - rect.top;
    temp.x        = rect.left;
    temp.y        = rect.top;

    return temp;
};

CSS_EDITOR.Preview.prototype.reset = function(changeMode = true){
    
    if (this.isActive){
        let parent = document.getElementById('csseditor_admin_contenant_fullPreview');
        if (parent) DOM_Class.RemoveElement( parent );
        else DOM_Class.RemoveElement( this.domElement );
    }
    if (changeMode && this.full) this.full = false;
};

CSS_EDITOR.Preview.prototype.showFull = function(evt){
    var _self = this;
    if (!this.full){
        this.full = true;
    }
    let settings = {};
    settings.url = document.baseURI.split('?')[0].split('#')[0] + 'csseditor/index.php';
    settings.skip_container = true;
    //~ settings.dom_target = 'css_contenu_preview';
    settings.dom_target = '';
    settings.data = {
        'csseditor_action': 'csseditor_full_preview',
        'csseditor-theme-id': CSS_EDITOR.currentTheme,
        'csseditor-rules-id_media': CSS_EDITOR.currentMediaId,
        //~ 'csseditor-rules-module': CSS_EDITOR.currentModule
    };
    
    settings.success = function(res){
        if (res){
            res = JSON.parse(res);
            _self.reset(false);
            let contenant = DOM_Class.CreateElement('DIV', {'class': 'csseditor_admin_contenant_fullPreview', 'id': 'csseditor_admin_contenant_fullPreview'}, res.domElem);
            DOM_Class.AppendContent(document.getElementById('css_contenu_preview'), contenant);
            
            _self.rulesList = res.rules;
            
            _self.domElement = document.getElementById('css_full_preview_iframe');
            $_e.AddEvent(_self.domElement, 'load', function(evt){
                _self.RemoveCss();
                if (CSS_EDITOR.currentMediaId != CSS_EDITOR.normalMediaId){
                    let tempMediaId = CSS_EDITOR.currentMediaId;
                    let tempMediaValue = CSS_EDITOR.currentMediaValue;
                    CSS_EDITOR.currentMediaId = CSS_EDITOR.normalMediaId;
                    CSS_EDITOR.currentMediaValue = CSS_EDITOR.normalMediaValue;
                    CSS_EDITOR._variable.parse();
                    _self.ApplyCss(res.rules[CSS_EDITOR.currentMediaId]);
                    
                    CSS_EDITOR.currentMediaId = tempMediaId;
                    CSS_EDITOR.currentMediaValue = tempMediaValue;
                    CSS_EDITOR._variable.parse();
                    _self.changeMediaType();
                } else {
                    _self.ApplyCss(res.rules[CSS_EDITOR.currentMediaId]);
                }
                
                _self.oldLocation = _self.window.location;
                
                let config = {attributes: false, childList: true, subtree: false};
                var observer = new MutationObserver(function(mutationList, observer){
                    if (_self.oldLocation != _self.window.location){
                        _self.RemoveCss();
                        _self.ApplyCss(res.rules);
                        _self.oldLocation = _self.window.location;
                    }
                });
                observer.observe(_self.document.body, config);
            });
        }
    };
    
    $_a.send(settings);
};

CSS_EDITOR.Preview.prototype.RemoveCss = function(){
    let doc = this.document;
    if (doc){
        for (var i = 0; i < doc.styleSheets.length; i++) {
            if (!doc.styleSheets[i].href){
                doc.styleSheets[i].disabled = true;
                DOM_Class.RemoveElement(doc.styleSheets[i].ownerNode);
            }
        }
    }
};

CSS_EDITOR.Preview.prototype.changeMediaType = function(){
    if (this.isActive){
        if (this.full){
            if (this.stylesheet == undefined){
                this.ApplyCss(this.rulesList[CSS_EDITOR.currentMediaId]);
            }
            this.domElement.parentElement.setAttribute('class', 'csseditor_admin_contenant_fullPreview '+CSS_EDITOR.domChoixMediaType.selectedOptions[0].innerHTML);
        } else {
            if (CSS_EDITOR.allRules){
                this.ApplyCss(CSS_EDITOR.allRules);
            }
            this.domElement.setAttribute('class', 'csseditor_admin_preview_iframe '+CSS_EDITOR.domChoixMediaType.selectedOptions[0].innerHTML);
        }
    }
};

CSS_EDITOR.Preview.prototype.startPickerElem = function(evt){
    if (this.isActive){
        $_e.AddEventClick(this.document.body, this.pickElement.bind(this));
        //~ function(event){
            //~ _self.pickElement.bind(_self)(event);
            //~ return false;
        //~ });
        $_e.AddEvent(this.document.body, EVENTS_Class.EVENT_MOUSEOVER, this.hoverElemHighlight.bind(this));
    }
};

CSS_EDITOR.Preview.prototype.hoverElemHighlight = function(evt){
    $_e.StopEvent(evt);
    $_e.StopPropagation(evt);
    let elem = evt.target;
    if (elem){
        if (!this.prevPicker || this.prevPicker != elem){
            if (this.isHighlighted){
                this.hideHighlight();
            }
            this.showHighlight(this.getSelectorCss(elem));
        }
        this.prevPicker = elem;
    }
};

CSS_EDITOR.Preview.prototype.pickElement = function(evt){
    $_e.StopEvent(evt);
    $_e.StopPropagation(evt);
    $_e.PreventDefault(evt);
    $_e.RemoveEvent(this.document.body, 'mousedown');
    $_e.RemoveEvent(this.document.body, 'mouseover');
    this.prevPicker = false;
    this.hideHighlight();
    let elem = evt.target;
    let selector = this.getSelectorCss(elem);
    if (selector.startsWith('#')){
        selector  += ' OU ' + elem.tagName.toLowerCase();
    }
    let btnPickerElem = document.getElementById('csseditor_toolbar_elem_picker');
    if (btnPickerElem.nextElementSibling && btnPickerElem.nextElementSibling.className == 'csseditor_admin_picked_selector') DOM_Class.RemoveElement(btnPickerElem.nextElementSibling);
    DOM_Class.InsertAfter(DOM_Class.CreateElement('SPAN', {'class': 'csseditor_admin_picked_selector'}, selector), btnPickerElem);
};

CSS_EDITOR.Preview.prototype.getSelectorCss = function(elem){
    if (elem){
        let selector = '';
        if (elem.className != ''){
            selector = '.'+ elem.className.replace(new RegExp("\\s", "g"), '.');
        } else if (elem.id){
            selector = '#'+elem.id;
        } else {
            selector = elem.tagName.toLowerCase();
        }
        return selector;
    }
};
/*jshint esversion: 6 */
var UI_Burger = function(){};
UI_Burger.prototype.constructor = UI_Burger;

UI_Burger._prev = null;
UI_Burger._first = false;
UI_Burger._indicators = [];

UI_Burger.init = function(burgerID, menuID){
    if (!this._first){
        this.burger = document.getElementById(burgerID).firstElementChild;
        if (!this.burger) return false;
        $_e.AddEventClick(this.burger, this.Open.bind(this));

        this.overlay = DOM_Class.CreateElement('DIV', {'class': 'burger_admin_overlay', 'id': 'burger_admin_overlay'});
        DOM_Class.AppendContent(document.body, this.overlay);
        $_e.AddEventClick(this.overlay, this.Close.bind(this));

        this.menu = document.getElementById(menuID);
        if (!this.menu) return false;
        let childs = this.menu.children;
        for (let i = 0; i < childs.length; i++){
            UI_Burger.CreateIndicator(childs[i]);
        }
        this._first = true;
    }
};

UI_Burger.CreateIndicator = function(domElem){
    if (domElem.tagName == 'LI' && domElem.lastElementChild.tagName == 'UL' && domElem.lastElementChild.previousElementSibling.tagName != 'DIV'){
        let indic = DOM_Class.CreateElement('DIV', {'class': 'burger_admin_collapse_indicator'}, '+');
        DOM_Class.InsertBefore(indic, domElem.lastElementChild);
        $_e.AddEventClick(indic, this.CollapseIndicator.bind(this));
        this._indicators.push(indic);
    }
    if (domElem.tagName == 'LI'){
        let lien = domElem.firstElementChild;
        if (lien.tagName == 'A' && lien.href == '?'){    // cas du lien vide
            $_e.AddEventClick(domElem, this.CollapseIndicator.bind(this));
            if (domElem.lastElementChild.tagName == 'UL'){
                let ul = domElem.lastElementChild;
                for (let i = 0; i < ul.children.length; i++){
                    $_e.AddEventClick(ul.children[i], this.Close.bind(this));
                }
            }
        } else {
            $_e.AddEventClick(domElem, this.Close.bind(this));
        }
    }
    //~ if (domElem.lastElementChild.tagName == 'UL'){
        //~ let childs = domElem.lastElementChild.children;
        //~ for (let i = 0; i < childs.length; i++){
            //~ UI_Burger.CreateIndicator(childs[i]);
        //~ }
    //~ }
};

UI_Burger.CollapseIndicator = function(evt){
    $_e.StopEvent(evt);
    let target = evt.target;
    if (!target.classList.contains('burger_admin_collapse_indicator')){
        target = target.parentElement.nextElementSibling;
    }
    if (target){
        if (!this._prev) {
            this._prev = {};
            this._prev.dom = target;
            this._prev.childs = Array.from(target.parentElement.parentElement.children);
        }
        DOM_Class.ToggleClass(target.nextElementSibling, 'burger_admin_show');
        if (target.innerHTML == '-'){
            target.innerHTML = '+';
        }else{
            target.innerHTML = '-';
        }
        let parentChild =  Array.from(target.parentElement.parentElement.children);
        if (this._prev.dom != target) {
            if (this._prev.childs.length === parentChild.length && this._prev.childs.every(function(v,i) { return v === parentChild[i];})){
                DOM_Class.ToggleClass(this._prev.dom.nextElementSibling, 'burger_admin_show', false);
                if (this._prev.dom.innerHTML == '-'){
                    this._prev.dom.innerHTML = '+';
                }
            }
            this._prev.dom = target;
            this._prev.childs =  Array.from(target.parentElement.parentElement.children);
        }
    }
};

UI_Burger.Open = function(evt){
    DOM_Class.ToggleClass(this.menu, 'burger_admin_show');
    DOM_Class.ToggleClass(this.burger, 'burger_admin_croix');
    DOM_Class.ToggleClass(this.overlay, 'burger_admin_overlay_show');
    this._indicators.forEach(function(elem){
        DOM_Class.ToggleClass(elem, 'burger_admin_show_indic');
    });
    if (document.body.style.overflow != 'hidden'){
        document.body.style.overflow = 'hidden';
    }else{
        document.body.style.overflow = 'auto';
    }
    window.scrollTo(0, 0);
};

UI_Burger.Close = function(evt){
    if (this.burger && this.menu && this.overlay){
        DOM_Class.ToggleClass(this.menu, 'burger_admin_show', false);
        DOM_Class.ToggleClass(this.burger, 'burger_admin_croix', false);
        DOM_Class.ToggleClass(this.overlay, 'burger_admin_overlay_show', false);
        this._indicators.forEach(function(elem){
            DOM_Class.ToggleClass(elem, 'burger_admin_show_indic', false);
        });
        document.body.style.overflow = 'unset';
    }
};
var mediaModal = [];
var mediaSelected = [];
var mediaFromTiny = [];

// WIDGET -----------------------------------------------------------------------------------------
function mediaWidgetInit(widgetId){
    if (widgetId == undefined) widgetId='';
    var temp = false;
    if (widgetId) {
        let index = widgetId.lastIndexOf('-');
        var field_id = parseInt(widgetId.substr(index+1));
    }
    let droper = document.getElementById('media_droper_'+widgetId);
    let inputFile = document.getElementById('media_input_'+widgetId);
    inputFile.form._droper = droper;
    if (field_id > 0) {
        $_e.AddEvent(inputFile, 'change', function(){$_e.SendEvent(inputFile.form , 'submit');});
    } else {
        $_e.AddEvent(inputFile, 'change', function(){mediaChangeFile(inputFile, widgetId);});
        //inputFile.addEventListener('change', function(){mediaChangeFile(inputFile, widgetId);});
    }
    
    $_e.AddEventClick(droper, mediaInputFileClick.bind(inputFile) );
    $_e.EnableDrop(droper, mediaOnDropFile.bind({inputFile, 'toSubmit': (field_id > 0), widgetId}) );
    //droper.addEventListener('mousedown', mediaInputFileClick.bind(inputFile) );
    //droper.addEventListener('drop', mediaOnDropFile.bind({inputFile, 'toSubmit': (field_id > 0), widgetId}) );
    
    // toggle list
    let toggler = document.getElementById('media_toggler_'+widgetId);
    if (toggler) $_e.AddEventClick(toggler, mediaToggleList.bind(widgetId));
    
    // toggle edit
    let toggler_edit = document.getElementById('media_toggler_edit_'+widgetId);
    if (toggler_edit) $_e.AddEventClick(toggler_edit, mediaToggleEdit.bind(widgetId));
    
    // delete 
    let btn_delete = document.getElementById('media_delete_'+widgetId);
    if (btn_delete) $_e.AddEventClick(btn_delete, mediaDelete.bind(widgetId));
    
    // mklocal 
    let btn_mklocal = document.getElementById('media_mklocal_'+widgetId);
    if (btn_mklocal) $_e.AddEventClick(btn_mklocal, mediaMklocal.bind(widgetId));
    
    //big view
    let btn_big_view = document.getElementById('media_big_view_'+widgetId);
    if (btn_big_view) $_e.AddEventClick(btn_big_view, mediaToggleBigView.bind(widgetId));
}
function mediaInputFileClick(evt){
    $_e.StopEvent(evt);
    this.click();
}
function mediaOnDropFile(evt){
    $_e.StopEvent(evt);
    let inputFile = this.inputFile;
    let toSubmit = this.toSubmit;
    let widgetId = this.widgetId;
    if (evt.dataTransfer){
        inputFile.files = evt.dataTransfer.files;
        if (toSubmit){
            $_e.SendEvent(inputFile.form , 'submit');
        } else {
            mediaChangeFile(inputFile, widgetId);
        }
    }
}
function mediaChangeFile(inputFile, widgetId){
    let files = inputFile.files;
    let shtml = '';
    let length = files.length;
    if (length > 1) shtml += length+' files';
    else shtml += files[0].name;
    
    let droperTxt = document.getElementById('media_droper_txt_'+widgetId);
    droperTxt.innerHTML = shtml;
}
// ------------------------------------------------------------------------------------------------

// LIST -------------------------------------------------------------------------------------------
function mediaToggleList(evt){
    $_e.StopEvent(evt);

    let widgetId = this;
    let index = widgetId.lastIndexOf('-');
    let field_identifier = widgetId.substr(0, index);
    let field_id = widgetId.substr(index+1);
    
    let settings = {};
    settings.url = document.baseURI.split('?')[0].split('#')[0] + 'media/index.php';
    settings.skip_container = true;
    settings.dom_target = '';
    settings.data = {
        'media_action': 'media_list',
        'media-data-field_identifier': field_identifier,
        'media-data-field_id': field_id
    };
    settings.success = function(list){
        console.log('show list');
        console.log(mediaModal);
        if (mediaModal[widgetId]){
            mediaModal[widgetId].SetContent(list);
            if (!mediaModal[widgetId].visible) {
                mediaModal[widgetId].Show();
            }
            mediaResizeModal(widgetId);
        } else {
            let cur_lng = CONSTANTS.current_lang_iso;
            mediaModal[widgetId] = UI_Class.AddWindow(document.getElementById('lemain'), {'modal': true, 'class': 'media_admin_modal_list'});
            mediaModal[widgetId].domElement.setAttribute('id', 'media_admin_modal_list_'+widgetId);
            mediaModal[widgetId].SetContent(list);
            mediaResizeModal(widgetId);
        }
        if (mediaFromTiny[widgetId]){
            tinymce.activeEditor.plugins.spd2_media.modal.Hide();
        }
    };
    
    $_a.send(settings);
}
function mediaListInit(widgetId){
    let index = widgetId.lastIndexOf('-');
    var field_id = parseInt(widgetId.substr(index+1));
    var field_identifier = widgetId.substr(0, index);
    
    let inputFile = document.getElementById('media_input_'+widgetId);
    let list = document.getElementById('media_admin_list_images_'+widgetId);
    
    let btn_edit = document.getElementById('media_admin_list_btn_edit_'+widgetId);
    if (btn_edit) $_e.AddEventClick(btn_edit, mediaBtnEditClick.bind(widgetId));
    
    for (let i = 0; i < list.children.length; i++){
        if (field_identifier != 'manager'){
            $_e.AddEventDblClick(list.children[i], mediaSetForSubmit.bind({inputFile, widgetId}));
            let images = list.children[i].getElementsByClassName('media_admin_sub_img');
            for (let j = 0; j < images.length; j++){
                $_e.AddEventClick(images[j], mediaOnClickListElem.bind(widgetId));
                $_e.AddEventDblClick(images[j], mediaSetForSubmit.bind({inputFile, widgetId}));
                if (mediaSelected[widgetId] && mediaSelected[widgetId].id == images[j].dataset.id) {
                    DOM_Class.ToggleClass(images[j], 'selected', true);
                    DOM_Class.RemoveClass(btn_edit, 'hide');
                    DOM_Class.AppendContent(images[j].parentElement, btn_edit);
                    btn_edit.style.position = 'relative';
                    btn_edit.style.left = images[j].offsetLeft+'px';
                }
            }
        } else {
            $_e.AddEventClick(list.children[i], function(event){mediaManagerSelect(event, widgetId);});
        }
    }
    
    let btn_retour = document.getElementById('media_btn_return_'+widgetId);
    if (btn_retour) $_e.AddEventClick(btn_retour, mediaReturnToWidget.bind(widgetId));
}
function mediaReturnToWidget(evt){
    let widgetId = this;
    if (mediaModal[widgetId]){
        mediaModal[widgetId].Hide();
    }
    if (mediaFromTiny[widgetId]){
        tinymce.activeEditor.plugins.spd2_media.modal.Show();
    }
    DOM_Class.RemoveElement(mediaModal[widgetId]._modalMask);
    DOM_Class.RemoveElement(mediaModal[widgetId].domElement);
    mediaModal[widgetId] = false;
}
function mediaSetForSubmit(evt){
    $_e.StopEvent(evt);
    let target = evt.target;
    if (evt.target.dataset.id){
        target = evt.target.parentElement;
    }
    
    let inputFile = this.inputFile;
    let widgetId = this.widgetId;
    
    let field_identifier = target.dataset.field_identifier;
    let field_id = target.dataset.field_id;
    
    let container = document.getElementById('widget_container_'+widgetId);
    if (container.parentElement.id == ''){
        container.parentElement.id = 'parent_widget_'+widgetId;
    }
    let domTarget = container.parentElement.id;
    
    if (field_identifier && field_id){
        let settings = {};
        settings.url = document.baseURI.split('?')[0].split('#')[0] + 'media/index.php';
        settings.skip_container = true;
        settings.dom_target = domTarget;
        settings.data = {};
        for (let i = 0; i < inputFile.form.length; i++){
            let elem = inputFile.form[i];
            if (elem.type == 'hidden' && elem.name != 'posted_from_container'){
                settings.data[elem.name] = elem.value;
            }
        }
        settings.data.upd_field_identifier = field_identifier;
        settings.data.upd_field_id = field_id;
        settings.data.media_action = 'media_upload_apply';
        settings.success = function(res){
            mediaModal[widgetId].Hide();
        };
        $_a.send(settings);
    }
}
function mediaOnClickListElem(evt){
    //~ $_e.StopEvent(evt);
    let widgetId = this;
    
    let btn_edit = document.getElementById('media_admin_list_btn_edit_'+this);
    DOM_Class.RemoveClass(btn_edit, 'hide');
    if (!mediaSelected[widgetId]){
        mediaSelected[widgetId] = {};
        mediaSelected[widgetId].id = evt.target.dataset.id;
        mediaSelected[widgetId].dom = evt.target;
        mediaSelected[widgetId].field_identifier = evt.target.parentElement.dataset.field_identifier;
        mediaSelected[widgetId].field_id = evt.target.parentElement.dataset.field_id;
        DOM_Class.ToggleClass(mediaSelected[widgetId].dom, 'selected', true);
    }
    if (mediaSelected[widgetId].id != evt.target.dataset.id){
        DOM_Class.ToggleClass(mediaSelected[this].dom, 'selected', false);
        mediaSelected[widgetId].id = evt.target.dataset.id;
        mediaSelected[widgetId].dom = evt.target;
        mediaSelected[widgetId].field_identifier = evt.target.parentElement.dataset.field_identifier;
        mediaSelected[widgetId].field_id = evt.target.parentElement.dataset.field_id;
        DOM_Class.ToggleClass(mediaSelected[widgetId].dom, 'selected', true);
    }
    DOM_Class.AppendContent(evt.target.parentElement, btn_edit);
    let pos = DOM_Class.GetPosition(evt.target);
    btn_edit.style.position = 'relative';
    btn_edit.style.left = pos.x+'px';
}

// ------------------------------------------------------------------------------------------------

// EDIT -------------------------------------------------------------------------------------------
function mediaToggleEdit(evt){
    $_e.StopEvent(evt);
    let widgetId = this;
    let index = widgetId.lastIndexOf('-');
    let field_identifier = widgetId.substr(0, index);
    let field_id = widgetId.substr(index+1);
    
    let settings = {};
    settings.url = document.baseURI.split('?')[0].split('#')[0] + 'media/index.php';
    settings.skip_container = true;
    settings.dom_target = '';
    settings.data = {
        'media_action': 'media_edit',
        'media-data-field_identifier': field_identifier,
        'media-data-field_id': field_id,
        'fromList': false
    };
    settings.success = function(res){
        if (mediaModal[widgetId]){
            mediaModal[widgetId].SetContent(res);
            if (!mediaModal[widgetId].visible) {
                mediaModal[widgetId].Show();
            }
            mediaResizeModal(widgetId);
        } else {
            let cur_lng = CONSTANTS.current_lang_iso;
            mediaModal[widgetId] = UI_Class.AddWindow(null, {'modal': true, 'class': 'media_admin_modal_list'});
            mediaModal[widgetId].SetContent(res);
            mediaModal[widgetId].SetParent(document.getElementById('lemain'));
            mediaResizeModal(widgetId);
        }
        mediaEditorInit(widgetId);
        
        if (mediaFromTiny[widgetId]){
            tinymce.activeEditor.plugins.spd2_media.modal.Hide();
        }
    };
    
    $_a.send(settings);
}
function mediaBtnEditClick(evt){
    $_e.StopEvent(evt);
    let widgetId = this;
    let id = 0;
    let field_identifier = '';
    let field_id = 0;
    if (evt.target.dataset.id){
        id = evt.target.dataset.id;
        index = widgetId.lastIndexOf('-');
        field_identifier = widgetId.substr(0, index);
        field_id = widgetId.substr(index+1);
    } else {
        id = mediaSelected[widgetId].id;
        field_identifier = mediaSelected[widgetId].field_identifier;
        field_id = mediaSelected[widgetId].field_id;
    }

    let settings = {};
    settings.url = document.baseURI.split('?')[0].split('#')[0] + 'media/index.php';
    settings.skip_container = true;
    settings.dom_target = '';
    settings.data = {
        'media_action': 'media_edit',
        'media-data-id': id,
        'media-data-field_identifier': field_identifier,
        'media-data-field_id': field_id
    };
    settings.success = function(res){
        if (mediaModal[widgetId]){
            mediaModal[widgetId].SetContent(res);
            //~ mediaModal[widgetId].SetParent(document.body, 0.5, 0.2);
            if (!mediaModal[widgetId].visible) {
                mediaModal[widgetId].Show();
            }
            mediaResizeModal(widgetId);
        }
        let tempWidgetId = field_identifier+'-'+field_id;
        if (tempWidgetId != widgetId) mediaEditorInit(tempWidgetId, widgetId);
        else mediaEditorInit(widgetId);
    };
    
    $_a.send(settings);
}
function mediaEditorInit(widgetId, tempWidgetId = false){
    let list = document.getElementById('media_admin_editor_list_images_'+widgetId);
    if (list){
        for (let i = 0; i < list.children.length; i++){
            $_e.AddEventClick(list.children[i], mediaBtnEditClick.bind(widgetId));
        }
    } else {
        UI_Class.ToggleAccordion('media_admin_edition_title', 'hide');
        let resize_form = document.getElementById('media_admin_form_resize_'+widgetId);
        $_v.parseFields(resize_form);
        let rotate_form = document.getElementById('media_admin_form_rotate_'+widgetId);
        $_v.parseFields(rotate_form);
        
        let angle_inp = document.getElementById('media_input_angle_'+widgetId);
        if (angle_inp){
            $_e.AddEvent(angle_inp, 'change', mediaChangeAngle.bind(widgetId));
        }
        
        if (mediaFromTiny[widgetId]){
            let container = document.getElementById('media_admin_container_editor_process_'+widgetId);
            if (container){
                let observer = new MutationObserver(function(mutation){
                    let content = tinymce.activeEditor.plugins.spd2_media.reloadImg();
                    
                });
                let conf = {childList: true};
                observer.observe(container, conf);
            }
        }
        if (!tempWidgetId) tempWidgetId = widgetId;
        let btn_retour = document.getElementById('media_btn_return_'+widgetId);
        if (btn_retour) {
            $_e.AddEventClick(btn_retour, mediaReturnToWidget.bind(tempWidgetId));
        }
    }
}
function mediaDelete(evt){
    $_e.StopEvent(evt);
    
    console.log('tttt');
    let msg = evt.target.dataset.confirm;
    let t = confirm(msg);
    if (t){
        let widgetId = this;
        let index = widgetId.lastIndexOf('-');
        let field_identifier = widgetId.substr(0, index);
        let field_id = widgetId.substr(index+1);
        let container = document.getElementById('widget_container_'+widgetId);
        if (container.parentElement.id == ''){
            container.parentElement.id = 'parent_widget_'+widgetId;
        }
        let domTarget = container.parentElement.id;
        
        let settings = {};
        settings.url = document.baseURI.split('?')[0].split('#')[0] + 'media/index.php';
        settings.skip_container = true;
        settings.dom_target = 'widget_container_'+widgetId;
        settings.data = {
            'media_action': 'media_delete',
            'media-data-field_identifier': field_identifier,
            'media-data-field_id': field_id
        };
        let tt = document.getElementById('mediaChangeFieldIdentifier_'+widgetId);
        if (tt){
            settings.data[tt.name] = tt.value;
        }
        
        $_a.send(settings);
    }
}
function mediaResizeModal(widgetId){
    if (mediaModal[widgetId]){
        
        //let parent = mediaModal[widgetId].domElement.parentElement;
        let width = mediaModal[widgetId].domElement.offsetWidth;
        let height = mediaModal[widgetId].domElement.offsetHeight;
        
        //let x = parent.offsetLeft + (parent.offsetWidth - width) * 0.5;
        //let y = parent.offsetTop + (parent.offsetHeight - height) * 0.5;
        let x = Math.floor((self.innerWidth - width) * 0.5);
        let y = Math.floor((self.innerHeight - height) * 0.5);
        //console.log( parent.id +'--'+parent.offsetTop +'--'+ parent.offsetHeight +'--'+height);
        
        mediaModal[widgetId].domElement.style.left = x+'px';
        mediaModal[widgetId].domElement.style.top = y+'px';
    }
}
function mediaChangeAngle(evt){
    //~ console.log(evt);
    let widgetId = this;
    let target = evt.target;
    let value = target.value;
    
    let apercu = document.getElementById('media_admin_rotate_angle_'+widgetId);
    if (apercu){
        apercu.style.transform = 'rotate(-'+value+'deg)';
    }
}
function mediaToggleBigView(evt){
    $_e.StopEvent(evt);
    
    let widgetId = this;
    let index = widgetId.lastIndexOf('-');
    let field_identifier = widgetId.substr(0, index);
    let field_id = widgetId.substr(index+1);
    
    let big_view;
    if (evt.target.classList.contains('on')){
        big_view = 0;
    } else {
        big_view = 1;
    }
    
    let settings = {};
    settings.url = document.baseURI.split('?')[0].split('#')[0] + 'media/index.php';
    settings.skip_container = true;
    settings.dom_target = '';
    settings.data = {
        'media_action': 'media_change_big_view',
        'media-data-field_identifier': field_identifier,
        'media-data-field_id': field_id,
        'media-data-big_view': big_view
    };
    settings.success = function(res){
        let img = document.getElementById('media_current_img_'+widgetId);
        if (img) img.dataset.big_view = big_view;
        DOM_Class.ToggleClass(evt.target, 'on');
        if (mediaFromTiny[widgetId]){
            let node = document.getElementById('media_img_'+field_identifier+'-'+field_id);
            if (big_view){
                node.setAttribute('onmousedown', 'UI_Class.ShowBigImage(event);');
            } else {
                node.setAttribute('onmousedown', '');
            }
        }
    };
    
    $_a.send(settings);
}

function mediaMklocal(evt){
    $_e.StopEvent(evt);
    
    let widgetId = this;
    let index = widgetId.lastIndexOf('-');
    let field_identifier = widgetId.substr(0, index);
    let field_id = widgetId.substr(index+1);
        
    let settings = {};
    settings.url = document.baseURI.split('?')[0].split('#')[0] + 'media/index.php';
    settings.skip_container = true;
    settings.dom_target = 'widget_container_'+widgetId;
    settings.data = {
        'media_action': 'media_mklocal',
        'upd_field_identifier': field_identifier,
        'upd_field_id': field_id,
        'media-data-field_identifier': field_identifier,
        'media-data-field_id': field_id
    };
    settings.success = function(res){
        //~ console.log(res);
    };
    
    $_a.send(settings);
}
// ------------------------------------------------------------------------------------------------
// MANAGER ----------------------------------------------------------------------------------------
// ------------------------------------------------------------------------------------------------
function mediaManagerInit(widgetId){
    let manager = new MediaManager();
    manager.init(widgetId);
}
var MediaManager = function(){
    var self = this;
    var videoInSelected = false;
    this.init = function(widgetId){
        let index = widgetId.lastIndexOf('-');
        var field_id = parseInt(widgetId.substr(index+1));
        var field_identifier = widgetId.substr(0, index);
        
        let inputFile = document.getElementById('media_input_'+widgetId);
        let list = document.getElementById('media_admin_list_images_'+widgetId);
        
        //~ let btn_edit = document.getElementById('media_admin_list_btn_edit_'+widgetId);
        //~ if (btn_edit) $_e.AddEvent(btn_edit, 'mousedown', mediaManagerToggleEdit.bind(widgetId));
        
        for (let i = 0; i < list.children.length; i++){
            $_e.AddEventClick(list.children[i], function(event){select(event, widgetId);});
        }
        
        this.btnEdit = document.getElementById('btn_manager_edit');
        if (this.btnEdit) $_e.AddEventClick(this.btnEdit, toggleEdit.bind(widgetId));
        
        let btnDelete = document.getElementById('btn_manager_delete');
        if (btnDelete) $_e.AddEventClick(btnDelete, mediaDelete);
    };
    
    function select(evt, widgetId){
        let multiple = evt.shiftKey;
        let selectedContainer = document.getElementById('media_admin_manager_selected');
        let target = evt.target;
        if (!target.dataset.field_id){
            target = target.parentElement;
        }
        
        let is_video = false;
        if (target.firstElementChild.tagName == 'SPAN'){
            multiple = false;
            video_in_selected = true;
            is_video = true;
        }
        
        let t = {};
        t.domElem = target;
        t.field_id = target.dataset.field_id;
        t.field_identifier = target.dataset.field_identifier;
        t.copyElem = DOM_Class.CloneDomElement(target, true);
        let mediaId = t.field_id + '-' + t.field_identifier;
        let toInsert = false;
        
        if (!multiple || is_video || video_in_selected){
            for (let elem in mediaSelected){
                if (mediaId != elem){
                    DOM_Class.ToggleClass(mediaSelected[elem].domElem, 'selected', false);
                    DOM_Class.RemoveElement(mediaSelected[elem].copyElem);
                    delete mediaSelected[elem];
                }
            }
            if (!mediaSelected[mediaId]){
                mediaSelected[mediaId] = t;
                toInsert = true;
            } else {
                DOM_Class.ToggleClass(mediaSelected[mediaId].domElem, 'selected', false);
                DOM_Class.RemoveElement(mediaSelected[mediaId].copyElem);
                delete mediaSelected[mediaId];
            }
            if (!is_video){
                video_in_selected = false;
            }
        } else {
            if (!mediaSelected[mediaId]){
                mediaSelected[mediaId] = t;
                toInsert = true;
            } else{
                DOM_Class.ToggleClass(mediaSelected[mediaId].domElem, 'selected', false);
                DOM_Class.RemoveElement(mediaSelected[mediaId].copyElem);
                delete mediaSelected[mediaId];
            }
        }
        
        if (toInsert){
            DOM_Class.ToggleClass(t.domElem, 'selected', true);
            selectedContainer.appendChild(t.copyElem);
        }
        
        if (video_in_selected){
            self.btnEdit.style.display = 'none';
        } else {
            self.btnEdit.style.display = '';
        }
    }
    
    function toggleEdit(evt){
        $_e.StopEvent(evt);
        
        let widgetId = this;
        let index = widgetId.lastIndexOf('-');
        var field_id = parseInt(widgetId.substr(index+1));
        var field_identifier = widgetId.substr(0, index);
        
        let imgs = [];
        for (let elem in mediaSelected){
            imgs.push({'field_identifier': mediaSelected[elem].field_identifier, 'field_id': mediaSelected[elem].field_id});
        }
        
        let settings = {};
        settings.url = document.baseURI.split('?')[0].split('#')[0] + 'media/index.php';
        settings.skip_container = true;
        settings.dom_target = '';
        settings.data = {
            'media_action': 'media_edit',
            'media_list': imgs,
            'fromList': false,
            'media-data-field_identifier': field_identifier,
            'media-data-field_id': field_id
        };
        settings.success = function(res){
            if (mediaModal[widgetId]){
                mediaModal[widgetId].SetContent(res);
                if (!mediaModal[widgetId].visible) {
                    mediaModal[widgetId].Show();
                }
                mediaResizeModal(widgetId);
            } else {
                let cur_lng = CONSTANTS.current_lang_iso;
                mediaModal[widgetId] = UI_Class.AddWindow(null, {'modal': true, 'class': 'media_admin_modal_list'});
                mediaModal[widgetId].SetContent(res);
                mediaModal[widgetId].SetParent(document.getElementById('lemain'));
                mediaResizeModal(widgetId);
            }
            mediaEditorInit(widgetId);
            
            if (mediaFromTiny[widgetId]){
                tinymce.activeEditor.plugins.spd2_media.modal.Hide();
            }
        };
        
        $_a.send(settings);
    }

    function mediaDelete(evt){
        $_e.StopEvent(evt);
        
        let msg = evt.target.dataset.confirm;
        let t = confirm(msg);
        if (t){
            let imgs = [];
            for (let elem in mediaSelected){
                imgs.push({'field_identifier': mediaSelected[elem].field_identifier, 'field_id': mediaSelected[elem].field_id});
            }
            
            let settings = {};
            settings.url = document.baseURI.split('?')[0].split('#')[0] + 'media/index.php';
            settings.skip_container = true;
            settings.dom_target = 'media_admin_container_manager';
            settings.data = {
                'media_action': 'media_delete',
                'media_list': imgs
                //~ 'media-data-field_identifier': field_identifier,
                //~ 'media-data-field_id': field_id
            };
            
            $_a.send(settings);
        }
    }
};

// ------------------------------------------------------------------------------------------------
// ------------------------------------------------------------------------------------------------
// ------------------------------------------------------------------------------------------------

// penser à renommer cette fonction...
function mediaUploadProgress(settings){
    
    let droper = settings.data._droper;
    settings.success = media_success_func.bind(droper);
    settings.error = media_error_func;
    settings.up_progress = media_up_progress.bind(droper);
    settings.down_progress = media_down_progress.bind(droper);
    $_a.send(settings);
    
}
// transfert réussi
function media_success_func(result , ajaxSender){
    let widgetId = this.id.substr(this.id.lastIndexOf('_')+1);
    let data = ajaxSender._data;
    let tl = {
        'fr': {
            'process': 'Traitement en cours'
        },
        'en': {
            'Process': 'Processing'
        },
        'es': {
            'Process': 'Tratamiento'
        }
    };
    // création de l'overlay et du message d'attente lors du traitement
    let div_overlay = DOM_Class.CreateElement('DIV', {'id': 'media_admin_waiter_processing_overlay', 'class': 'media_admin_waiter_processing_overlay'});
    let div_container = DOM_Class.CreateElement('DIV', {'id': 'media_admin_waiter_processing_container', 'class': 'media_admin_waiter_processing_container'});
        let div_text = DOM_Class.CreateElement('DIV', {'id': 'media_admin_waiter_processing_text', 'class': 'media_admin_waiter_processing_text'}, tl[CONSTANTS.current_lang_iso]['process']);
        let div_anim = DOM_Class.CreateElement('DIV', {'id': 'media_admin_waiter_processing_text_anim', 'class': 'media_admin_waiter_processing_text'}, '.');
    DOM_Class.AppendContent(div_container, [div_text, div_anim]);
    DOM_Class.AppendContent(document.body, div_overlay);
    DOM_Class.AppendContent(document.body, div_container);
    mediaSendProcessApply(this, data);
    mediaFollowProcessVideo(this.id.substr(this.id.lastIndexOf('-')+1));
}
// error
function media_error_func(result , ajaxSender){
    console.log('ERROR',result);
}
// progression d'upload d'un widget
function media_up_progress(event , ajaxSender){
    //~ let uu = ajaxSender.files_up_progress;
    //console.log('UP '+ajaxSender._up_loaded_bytes , uu.completed+'/'+uu.total);
    this.innerHTML = Math.floor(ajaxSender.progress * 100)+"%";
    //~ if (uu.completed == uu.total){
        //~ followProcessVideo(this);
    //~ }
    //~ media_global_progress();
}
// progression de download d'un widget
function media_down_progress(event , ajaxSender){
    //console.log('DOWN '+ajaxSender.down_progress);
    media_global_progress();
}
// progression globale
function media_global_progress(){
    $_a.computeProgress();
    //console.log("GLOBAL" , $_a.progress , " | " , $_a.running_stream_count , "/" , $_a.busy_stream_count);

    // là y'a que la progression de l'upload qui est intéressante
    //console.log("GLOBAL" , $_a.up_progress , " | " , $_a.running_stream_count , "/" , $_a.busy_stream_count);

}
function mediaSendProcessApply(droper, postData){
    //~ console.log('2nd send');
    let widgetId = '';
    if (droper.id.includes('page_block_')){
        widgetId += 'page_block_' + droper.id.substr(droper.id.lastIndexOf('_')+1);
    } else if (droper.id.includes('preference_webstore')){
        widgetId += 'preference_webstore' + droper.id.substr(droper.id.indexOf('-'));
    } else {
        widgetId += droper.id.substr(droper.id.lastIndexOf('_')+1);
    }
    let index = widgetId.lastIndexOf('-');
    let field_identifier = widgetId.substr(0, index);
    let field_id = widgetId.substr(index+1);
    
    let domTarget = '';
    let container = document.getElementById('widget_container_'+widgetId);
    if (container){
        if (container.parentElement.id == ''){
            container.parentElement.id = 'parent_widget_'+widgetId;
        }
        domTarget = container.parentElement.id;
    }
    //~ console.log(domTarget);
    
    //~ let tt = document.getElementById('mediaChangeFieldIdentifier_'+widgetId);
    //~ if (tt){
        //~ field_identifier = tt.value;
    //~ }
    
    let settings = {};
    settings.url = document.baseURI.split('?')[0].split('#')[0] + 'media/index.php';
    settings.skip_container = true;
    settings.dom_target = domTarget;
    settings.data = {
        'media_action': 'media_upload_apply',
        'media-data-field_identifier': field_identifier,
        'media-data-field_id': field_id,
    };
    if (postData){
        if (postData.has('media_force_jpg')) settings.data['media_force_jpg'] = true;
        if (postData.has('lstFilePath[]')) settings.data['lstFilePath'] = postData.getAll('lstFilePath[]');
    }
    let tt = document.getElementById('mediaChangeFieldIdentifier_'+widgetId);
    if (tt){
        settings.data[tt.name] = tt.value;
    }
    let domID = document.getElementById('mediaCurrentId_'+widgetId);
    if (domID && domID.value > 0){
        settings.data[domID.name] = domID.value;
    }
    
    settings.success = function(res){
        //~ console.log(res);
        let targ = document.getElementById(domTarget);
        
        let overlay = document.getElementById('media_admin_waiter_processing_overlay');
        let container = document.getElementById('media_admin_waiter_processing_container');
        if (overlay) DOM_Class.RemoveElement(overlay);
        if (container) DOM_Class.RemoveElement(container);
    };
    
    $_a.send(settings);
}
function mediaFollowProcessVideo(field_id){
    let settings = {};
    settings.url = document.baseURI.split('?')[0].split('#')[0] + 'media/index.php';
    settings.skip_container = true;
    settings.dom_target = '';
    settings.data = {
        'media_action': 'media_get_video_process',
        'media-data-field_id': field_id
    };
    
    settings.success = function(res){
        res = res.replace(/\n/g, '').trim();
        //~ console.log(res);
        if (res == 'ok!' || res == '') {
            
            //~ let overlay = document.getElementById('media_admin_waiter_processing_overlay');
            //~ let container = document.getElementById('media_admin_waiter_processing_container');
            //~ if (overlay) DOM_Class.RemoveElement(overlay);
            //~ if (container) DOM_Class.RemoveElement(container);
            
        } else {
            
            let text = document.getElementById('media_admin_waiter_processing_text_anim');
            let content = text.textContent;
            if (content == '. . .'){
                content = '.';
            } else {
                content += ' .';
            }
            text.innerHTML = content;
            mediaFollowProcessVideo(field_id);
        }
    };
    
    $_a.send(settings, 1000);
}
// path -> chemin vers la vidéo
// secs -> seconde où prendre l'image
// domElem -> Balise HTML IMG qui recoit l'image final
function mediaGetVideoImage(path, secs, domElemId) {
    var me = this, video = document.createElement('video');
    video.onloadedmetadata = function() {
        if ('function' === typeof secs) {
            secs = secs(this.duration);
        }
        this.currentTime = Math.min(Math.max(0, (secs < 0 ? this.duration : 0) + secs), this.duration);
    };
    video.onseeked = function(e) {
        var canvas = document.createElement('canvas');
        canvas.height = video.videoHeight;
        canvas.width = video.videoWidth;
        var ctx = canvas.getContext('2d');
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        var img = new Image();
        img.src = canvas.toDataURL();
        document.getElementById(domElemId).src = img.src;
        //~ callback.call(me, img, this.currentTime, e);
    };
    video.onerror = function(e) {
        //~ callback.call(me, undefined, undefined, e);
    };
    video.src = CONSTANTS.base_url+path;
}
/*jshint esversion: 6 */
var pageEditor;

//console.log('Screen:',screen.width,',',screen.height);
//console.log(window.screen.orientation);

var PAGE_Editor_Class = function(domContainer , commands){

    if(GENERICS_Class.IsString(domContainer)){
        domContainer = DOM_Class.GetDomElement(domContainer);
    }

    this.domTarget = domContainer;
    DOM_Class.SetStyleValue(this.domTarget , 'position' , 'relative');
    
    this.mainContainer = document.getElementById('page_admin_container');

    this.overlay = new DOM_OVERLAY_Class(domContainer , 'page');

    this.commands = commands;

    this.overlay.toolpanel = new DOM_TOOLPANEL_Class(this.overlay , this.domTarget);

    this.infoID = document.getElementById('page_admin_info_id_page');

    this.currentPageData = {'id':0,'lang':{}};

    let btn;

    let settings = {};
    settings.url = document.baseURI.split('?')[0].split('#')[0] + 'page/index.php';
    settings.dom_target = '';
    settings.skip_container = true;
    settings.data = {
        'PageAction': 'page_load_tiny',
    };
    settings.success = function(res){
        this.tinyParams = JSON.parse(res);
    }.bind(this);
    $_a.send(settings);

    this.overlay.SelectOverlay(null);

    this.toolForm = null;
    this.pageSelector = null;
    this.groupeSelector = null;
    this.pageTitleField = null;
    this.pageNameField = null;
    this.pageLangIdField = null;

    this.admin_tools_container = document.getElementById('page_admin_tools');

    this.php_tools_container = document.getElementById('page_admin_container_tools');
    this.php_tools_placeholder = DOM_Class.CreateElement('div',{'id':'page_admin_container_tools_placeholder','style':'position:relative; height:0px; width:90%; display:block;'});

    this.php_tools_container.parentNode.insertBefore(this.php_tools_placeholder , this.php_tools_container);

    this.overlay.tools_container = this.php_tools_container;

    this.OnReceiveTools();
    this.InitBlocksTools();
    
    if (DOM_Class.GetStyleValue(this.mainContainer, 'position') == 'fixed' || DOM_Class.GetStyleValue(this.mainContainer, 'position') == 'absolute'){
        EVENTS_Class.AddEvent(this.mainContainer,'scroll',this.OnPageScroll.bind(this));
    } else {
        EVENTS_Class.AddEvent(window,'scroll',this.OnPageScroll.bind(this));
    }
    
    //~ let fakeLemain = document.getElementById('page_admin_fake_lemain');
    //~ if (fakeLemain){
        //~ EVENTS_Class.AddEvent(fakeLemain, 'mousedown', function(event){
            //~ if (pageEditor.overlay.currentSelection && pageEditor.overlay.currentSelection[0]){
                //~ console.log('hide');
                //~ pageEditor.overlay.currentSelection[0].Hide();
            //~ }
        //~ }, false);
    //~ }

    this.total_saved_page = 0;
    //~ DOM_Class.LoadCss('../public/page/page.css');
    // variable qui indique si les derniers blocks ajoutés sont des multiple (ajouter en meme temps)
    //~ this.lastAddedIsMultiple = false;

};
PAGE_Editor_Class.prototype.constructor = PAGE_Editor_Class;

//-------------------------
PAGE_Editor_Class.prototype.OnPageScroll = function(event){
    let py, limit;
    if (event.target == this.mainContainer){
        py = this.mainContainer.scrollTop;
        limit = 50;
    } else {
        py = event.pageY || document.body.scrollTop || window.pageYOffset;
        limit = 225;
    }
    
    if(py > limit && !this.tools_docked){
        this.tools_docked = true;
        let hh = DOM_Class.GetStyleValue(this.php_tools_container,'height');
        DOM_Class.SetStyleValue(this.php_tools_placeholder,'height',hh);
        this.php_tools_container.classList.toggle('fixed',true);
        this.overlay.UpdateHierarchy(true);

    }else if(this.tools_docked && py <= limit){
        this.tools_docked = false;
        DOM_Class.SetStyleValue(this.php_tools_placeholder,'height','0');
        this.php_tools_container.classList.toggle('fixed',false);
        this.overlay.UpdateHierarchy(true);
    }
};

PAGE_Editor_Class.prototype.InitBlocksTools = function(){
	let data = {};
    data[this.commands.action] = this.commands.blockstools;
    let settings = {'url':'page/index.php' , 'data':data , 'dom_target':this.overlay.toolpanel.domElement , 'skip_container':true , 'success':EVENTS_Class.BindCallback(this , this.OnInitBlocksToolsDone )};
    $_a.send(settings);
};

PAGE_Editor_Class.prototype.OnInitBlocksToolsDone = function(result,request){
    var self = this;
	let liste = [];
    for(let i=0 ; i<this.overlay.toolpanel.domElement.children.length ; i++){
        liste.push(this.overlay.toolpanel.domElement.children[i]);
    }
	let itemslist, btn;
    let show_min_width = false;

	for(let i=0 ; i<liste.length ; i++){
		let element = liste[i];
		switch(element.id){
			case 'btn_edit_block':
				btn = new UI_Button({'domElement':element,'label':element.innerHTML,'action':'edit','select_active':true , 'onclick':EVENTS_Class.BindCallback(this , this.OnEditItemContent)});
			    //btn.SetParent(this.overlay.toolpanel);
			    EVENTS_Class.ListenToEvent(btn.domElement , 'selectionChange' , EVENTS_Class.BindCallback(this , this.OnSelectionChange ) , this.overlay);
			break;

            case 'btn_koldron':
			    btn = new UI_Button({'domElement':element,'action':'koldron','onclick':EVENTS_Class.BindCallback(this , this.OnShowKoldron)});
    			//btn.SetParent(this.overlay.toolpanel);
			break;

            case 'btn_split':
			    btn = new UI_Button({'domElement':element,'action':'splitblock','select_active':true,'onclick':EVENTS_Class.BindCallback(this , this.OnSplitBlock)});
    			//btn.SetParent(this.overlay.toolpanel);
                EVENTS_Class.ListenToEvent(btn.domElement , 'selectionChange' , EVENTS_Class.BindCallback(this , this.OnSelectionChange ) , this.overlay);
			break;

            case 'btn_merge':
			    btn = new UI_Button({'domElement':element,'action':'mergeblocks','select_active':true,'onclick':EVENTS_Class.BindCallback(this , this.OnMergeBlocks)});
    			//btn.SetParent(this.overlay.toolpanel);
                EVENTS_Class.ListenToEvent(btn.domElement , 'selectionChange' , EVENTS_Class.BindCallback(this , this.OnSelectionChange ) , this.overlay);
			break;


			case 'btn_save_page':
			    btn = new UI_Button({'domElement':element,'icon':'save','action':'save','onclick':EVENTS_Class.BindCallback(this , this.OnSavePage)});
    			//btn.SetParent(this.overlay.toolpanel);
			break;

			case 'btn_add_block':
			    btn = new UI_Button({'domElement':element,'icon':'add','action':'add','onclick':EVENTS_Class.BindCallback(this , this.OnAddElement) });
    			//btn.SetParent(this.overlay.toolpanel);
			break;

			case 'btn_del_block':
			  	btn = new UI_Button({'domElement':element,'icon':'del','action':'del','select_active':true , 'onclick':EVENTS_Class.BindCallback(this.overlay , this.overlay.OnRemoveSelection)});
    			//btn.SetParent(this.overlay.toolpanel);
    			EVENTS_Class.ListenToEvent(btn.domElement , 'selectionChange' , EVENTS_Class.BindCallback(this , this.OnSelectionChange ) , this.overlay);

			break;

			case 'btn_clone_block':
			 	btn = new UI_Button({'domElement':element,'label':element.innerHTML,'action':'duplicate','select_active':true , 'onclick':EVENTS_Class.BindCallback(this , this.OnDuplicateSelection) });
    			//btn.SetParent(this.overlay.toolpanel);
    			EVENTS_Class.ListenToEvent(btn.domElement , 'selectionChange' , EVENTS_Class.BindCallback(this , this.OnSelectionChange ) , this.overlay);

			break;

			case 'inp_blockname':
			    let restrict = 'abcdefghijklmnopqrstuvwxyz0123456789_-';

			    btn = new UI_Input({'domElement':element,'label':element.innerHTML,'value':'','select_active':true ,'action':'blockname','restrict':restrict,'onchange':this.SetBlockProperty.bind(this)});
			    //btn.SetParent(this.overlay.toolpanel);
			    EVENTS_Class.ListenToEvent(btn.domElement , 'selectionChange' , EVENTS_Class.BindCallback(this , this.OnSelectionChange ) , this.overlay);
			break;
            
            case 'sel_stylename':
                let sel = document.getElementById('sel_stylename');
                //~ $_v.protectInput(sel);
                $_e.AddEvent(sel, 'change', function(){self.SetBlockProperty.bind(self)('blockname', sel.selectedOptions[0].value);});
                let params = {'domElement':sel, 'label':sel.previousElement, 'value':'','select_active':true ,'action':'blockname'};
                sel._ui_object = params;
                
                //~ sel = new UI_Input({'domElement':sel,'label':sel.previousElement,'value':'','select_active':true ,'action':'blockname','onchange':this.SetBlockProperty.bind(this)});
                EVENTS_Class.ListenToEvent(sel , 'selectionChange' , EVENTS_Class.BindCallback(this , this.OnSelectionChange ) , this.overlay);
            break;

            case 'inp_blocklink':
			    btn = new UI_Input({'domElement':element,'label':element.innerHTML,'value':'','select_active':true ,'action':'blocklink','onchange':this.SetBlockProperty.bind(this)});
			    //btn.SetParent(this.overlay.toolpanel);
			    EVENTS_Class.ListenToEvent(btn.domElement , 'selectionChange' , EVENTS_Class.BindCallback(this , this.OnSelectionChange ) , this.overlay);
			break;

            case 'inp_blockgroup':
			    btn = new UI_Input({'domElement':element,'label':element.innerHTML,'value':'','select_active':true ,'action':'blockgroup','onchange':this.SetBlockProperty.bind(this)});
			    //btn.SetParent(this.overlay.toolpanel);
			    EVENTS_Class.ListenToEvent(btn.domElement , 'selectionChange' , EVENTS_Class.BindCallback(this , this.OnSelectionChange ) , this.overlay);
			break;

			case 'tgl_display':
				itemslist = element.dataset.items?JSON.parse(element.dataset.items):{};
                
			    let display_toggle = new DOM_MULTITOGGLE_Class({'domElement':element,'attributeName':'css:display' , 'items':itemslist , 'title':element.innerHTML});
                //display_toggle.ExtractChildrenTo();


			    // cet overlay manager est à l'écoute des changements de valeur du selecteur display_toggle
			    EVENTS_Class.ListenToEvent(this.overlay.domElement , display_toggle.changeEventName , EVENTS_Class.BindCallback(this.overlay , this.overlay.OnChangeAttribute ) , display_toggle);
			    // le selecteur display_toggle est à l'écoute des changements de sélection des overlays
			    EVENTS_Class.ListenToEvent(display_toggle.domElement , 'selectionChange' , EVENTS_Class.BindCallback(display_toggle , display_toggle.OnReceiveValue ) , this.overlay);
                
			break;

			case 'tgl_align':
				itemslist = element.dataset.items?JSON.parse(element.dataset.items):{};


			    let align_toggle = new DOM_MULTITOGGLE_Class({'domElement':element,'attributeName':'var:align' , 'items':itemslist , 'title':element.innerHTML});
                //align_toggle.ExtractChildrenTo();

			    // cet overlay manager est à l'écoute des changements de valeur du selecteur display_toggle
			    EVENTS_Class.ListenToEvent(this.overlay.domElement , align_toggle.changeEventName , EVENTS_Class.BindCallback(this.overlay , this.overlay.OnChangeAttribute ) , align_toggle);
			    // le selecteur display_toggle est à l'écoute des changements de sélection des overlays
			    EVENTS_Class.ListenToEvent(align_toggle.domElement , 'selectionChange' , EVENTS_Class.BindCallback(align_toggle , align_toggle.OnReceiveValue ) , this.overlay);

			    EVENTS_Class.ListenToEvent(align_toggle.domElement , 'displayChange' , EVENTS_Class.BindCallback(align_toggle , align_toggle.OnReceiveValue ) , this.overlay);
    		break;

    		case 'tgl_position':
    			itemslist = element.dataset.items?JSON.parse(element.dataset.items):{};
			    let position_toggle = new DOM_MULTITOGGLE_Class({'domElement':element,'attributeName':'css:position' , 'items':itemslist , 'title':element.innerHTML});
                //position_toggle.ExtractChildrenTo();


			    // cet overlay manager est à l'écoute des changements de valeur du selecteur display_toggle
			    EVENTS_Class.ListenToEvent(this.overlay.domElement , position_toggle.changeEventName , EVENTS_Class.BindCallback(this.overlay , this.overlay.OnChangeAttribute ) , position_toggle);
			    // le selecteur display_toggle est à l'écoute des changements de sélection des overlays
			    EVENTS_Class.ListenToEvent(position_toggle.domElement , 'selectionChange' , EVENTS_Class.BindCallback(position_toggle , position_toggle.OnReceiveValue ) , this.overlay);
				//this.overlay.toolpanel.appendChild(position_toggle);

			break;

			case 'inp_width':
                //let input = DOM_Class.CreateElement('INPUT',{'class':'hidden'});

				itemslist = element.dataset.items?JSON.parse(element.dataset.items):{};


				let width_unit_toggle = new DOM_MULTITOGGLE_Class({'domElement':element,'attributeName':'var:width_unit' , 'items':itemslist , 'title':element.innerHTML });
                //width_unit_toggle.ExtractChildrenTo();


			    // cet overlay manager est à l'écoute des changements de valeur du selecteur display_toggle
			    EVENTS_Class.ListenToEvent(this.overlay.domElement , width_unit_toggle.changeEventName , EVENTS_Class.BindCallback(this.overlay , this.overlay.OnChangeAttribute ) , width_unit_toggle);
			    // le selecteur display_toggle est à l'écoute des changements de sélection des overlays
			    EVENTS_Class.ListenToEvent(width_unit_toggle.domElement , 'selectionChange' , EVENTS_Class.BindCallback(width_unit_toggle , width_unit_toggle.OnReceiveValue ) , this.overlay);
			    EVENTS_Class.ListenToEvent(width_unit_toggle.domElement , 'widthChange' , EVENTS_Class.BindCallback(width_unit_toggle , width_unit_toggle.OnReceiveValue ) , this.overlay);
			break;

			case 'inp_minwidth':
				itemslist = element.dataset.items?JSON.parse(element.dataset.items):{};
				let minwidth_unit_toggle = new DOM_MULTITOGGLE_Class({'domElement':element,'attributeName':'var:minwidth_unit' , 'items':itemslist , 'title':element.innerHTML});
                //minwidth_unit_toggle.ExtractChildrenTo();

			    // cet overlay manager est à l'écoute des changements de valeur du selecteur display_toggle
			    EVENTS_Class.ListenToEvent(this.overlay.domElement , minwidth_unit_toggle.changeEventName , EVENTS_Class.BindCallback(this.overlay , this.overlay.OnChangeAttribute ) , minwidth_unit_toggle);
			    // le selecteur display_toggle est à l'écoute des changements de sélection des overlays
			    EVENTS_Class.ListenToEvent(minwidth_unit_toggle.domElement , 'selectionChange' , EVENTS_Class.BindCallback(minwidth_unit_toggle , minwidth_unit_toggle.OnReceiveValue ) , this.overlay);
			    EVENTS_Class.ListenToEvent(minwidth_unit_toggle.domElement , 'minwidthChange' , EVENTS_Class.BindCallback(minwidth_unit_toggle , minwidth_unit_toggle.OnReceiveValue ) , this.overlay);

                show_min_width = true;
			break;

			case 'mce_container':
			    this.overlay.mceToolbarContainer = element; //DOM_Class.CreateElement('DIV');
			    this.overlay.mceToolbarContainer.id = 'mce_tool'+GENERICS_Class.GetUniqueId();
			    this.overlay.toolpanel.domElement.appendChild(this.overlay.mceToolbarContainer);
			break;
            
            case 'bloc_preset':
                for(let i = 0 ; i < element.children.length ; i++){
                    let elem = element.children[i];
                    switch(elem.id){
                        case 'bloc_preset_split_middle':
                            $_e.AddEventClick(elem, EVENTS_Class.BindCallback(this , this.OnAddPreset));
                            //~ btn = new UI_Button({'domElement':element,'icon':'add','action':'add_multiple_1','onclick': });
                        break;
                        
                        case 'bloc_preset_three_middle':
                            $_e.AddEventClick(elem, EVENTS_Class.BindCallback(this , this.OnAddPreset));
                            //~ btn = new UI_Button({'domElement':element,'icon':'add','action':'add_multiple_1','onclick': });
                        break;
                        
                        case 'bloc_preset_two_middle':
                            $_e.AddEventClick(elem, EVENTS_Class.BindCallback(this , this.OnAddPreset));
                            //~ btn = new UI_Button({'domElement':element,'icon':'add','action':'add_multiple_1','onclick': });
                        break;
                        
                        case 'bloc_preset_four_middle':
                            $_e.AddEventClick(elem, EVENTS_Class.BindCallback(this , this.OnAddPreset));
                            //~ btn = new UI_Button({'domElement':element,'icon':'add','action':'add_multiple_1','onclick': });
                        break;
                        
                        case 'bloc_preset_big_left':
                            $_e.AddEventClick(elem, EVENTS_Class.BindCallback(this , this.OnAddPreset));
                            //~ btn = new UI_Button({'domElement':element,'icon':'add','action':'add_multiple_1','onclick': });
                        break;
                        
                        case 'bloc_preset_big_right':
                            $_e.AddEventClick(elem, EVENTS_Class.BindCallback(this , this.OnAddPreset));
                            //~ btn = new UI_Button({'domElement':element,'icon':'add','action':'add_multiple_1','onclick': });
                        break;
                        
                        case 'bloc_preset_medium_middle':
                            $_e.AddEventClick(elem, EVENTS_Class.BindCallback(this , this.OnAddPreset));
                            //~ btn = new UI_Button({'domElement':element,'icon':'add','action':'add_multiple_1','onclick': });
                        break;
            
                        default:
                        break;
                    }
                }
            break;
            
            default:
            break;
		}

	}

    if(show_min_width){
        this.overlay.ShowMinWidth();
    }else{
        this.overlay.HideMinWidth();
    }

    /*
    btn = new UI_Button({'tooltip':'Test','label':'Test'});
    btn.SetParent(this.toolbar);
    EVENTS_Class.AddEvent(btn.domElement , EVENTS_Class.EVENT_MOUSEDOWN , EVENTS_Class.BindCallback(this , this.OnTest) );
*/

	DOM_Class.SetAlignment(this.overlay.toolpanel.domElement , 0.5 , 0.25 , this.overlay.domTarget);

    this.toolpanel_dock = document.getElementById('page_admin_toolpanel_dock');
    this.overlay.toolpanel.dock(this.toolpanel_dock);

	EVENTS_Class.BroadcastEvent('selectionChange' , this.overlay.currentSelection , this.overlay);

};

PAGE_Editor_Class.prototype.InitLang = function(){
	if(this.langok){
		return;
	}
	this.langok = true;

    let lng = {};
    for(let i in CONSTANTS.languages){
        lng[i] = CONSTANTS.languages[i].iso;
    }
    let container_lang_toggle = document.getElementById('page_admin_container_lng');
    this.lang_toggle = new DOM_MULTITOGGLE_Class({'attributeName':'var:lang_id_data' , 'items':lng , 'title':'Lang :' , 'eventName':'changeLangValue'});
    container_lang_toggle.appendChild(this.lang_toggle.domElement);
    this.lang_toggle.SetValue(CONSTANTS.current_lang_id);

    let lang_count = Object.keys(CONSTANTS.languages).length;
    if(lang_count < 2){
        let btn_copy = document.getElementById('page_admin_btn_copy_lng');
        btn_copy.style.display = 'none';
        container_lang_toggle.style.display = 'none';
    }

    EVENTS_Class.ListenToEvent(this.overlay.domElement , this.lang_toggle.changeEventName , EVENTS_Class.BindCallback(this , this.OnChangeLang ) , this.lang_toggle);
    EVENTS_Class.ListenToEvent(this.lang_toggle.domElement , 'langChange' , EVENTS_Class.BindCallback(this.lang_toggle , this.lang_toggle.OnReceiveValue ) , this);
};


PAGE_Editor_Class.prototype.OnShowKoldron = function(){
    if(!this.koldron){
        this.koldron = new KOLDRON_EDITOR_Class();
    }

    this.koldron.Show();
};

PAGE_Editor_Class.prototype.OnSplitBlock = function(){
    if(this.overlay.currentSelection.length > 0){

        let currentOverlay = this.overlay.currentSelection[this.overlay.currentSelection.length-1];

        let currentElement = currentOverlay.sourceElement;


        var target = document.createTextNode("\u0001");
        document.getSelection().getRangeAt(0).insertNode(target);
        var startPos = currentElement.innerHTML.indexOf("\u0001");
        target.parentNode.removeChild(target);

        if(!startPos){
            return;
        }

        let content = currentElement.innerHTML;

        let content_A = content.substr(0,startPos).trim();
        let content_B = content.substr(startPos , content.length - startPos).trim();

        if(!content_A || !content_B){
            return;
        }

        let domElement = DOM_Class.DuplicateDomElement(currentElement , true);
        domElement.setAttribute('id','');

        currentElement.parentNode.insertBefore(domElement,currentElement.nextSibling);
        currentOverlay = this.overlay.AddElement(domElement);

        domElement.innerHTML = content_B;

        currentElement.innerHTML = content_A;

        this.overlay.UpdateHierarchy(true);

        this.overlay.SetTextEditor(null);

        this.overlay.SelectOverlay(null);

        this.overlay.SelectOverlay(currentOverlay);
    }
};

PAGE_Editor_Class.prototype.OnMergeBlocks = function(){
    if(this.overlay.currentSelection.length > 0){

        let currentOverlay = this.overlay.currentSelection[this.overlay.currentSelection.length-1];

        let currentElement = currentOverlay.sourceElement;

        let nextElement = currentOverlay.sourceElement.nextSibling;

        if(nextElement && nextElement._overlay){
            currentElement.innerHTML += nextElement.innerHTML;

            this.overlay.RemoveElement(nextElement._overlay);

            this.overlay.UpdateHierarchy(true);
        }
    }
};

PAGE_Editor_Class.prototype.OnDeletePage = function(){
    if(this.selectedPageIndex > 0){

        let settings = {};

        settings.content = 'Confirmation de la suppression de la page en cours d\'édition ?';

        settings.buttons = [];
        settings.buttons.push({'label':'Supprimer','handler':this.DeletePage.bind(this) , 'css':'warning'});
        settings.buttons.push({'label':'Annuler'});

        let w = new UI_PromptWindow(settings);
        w.SetParent(document.body,0.5,0.3);
    }
};

PAGE_Editor_Class.prototype.DeletePage = function(){
    let data = {};
    data[this.commands.action] = this.commands.delete;
    data['id'] = this.selectedPageIndex;
    this.ResetPage();
    let settings = {'url':'page/index.php' , 'data':data , 'dom_target0':this.php_tools_container.id , 'skip_container':true , 'success':EVENTS_Class.BindCallback(this , this.OnDeletePageDone )};
    $_a.send(settings);
};

PAGE_Editor_Class.prototype.OnDeletePageDone = function(result,sender){

    let data = JSON.parse(result);
    if(this.pageSelector.value == data.id){
        this.pageSelector.value = '';

        for(let i=0; i<this.pageSelector.childNodes.length;i++){
            let child = this.pageSelector.childNodes[i];
            if(child.value == data.id){
                child.remove();
                break;
            }
        }

    }

    this.GetToolsForm();
    this.LoadPage();
};


//-------------------------

PAGE_Editor_Class.prototype.OnTest = function(event){
    let w = new UI_PromptWindow({});
    w.SetParent(document.body);
};


PAGE_Editor_Class.prototype.SetBlockProperty = function(propertyName , newValue){
    if(this.overlay.currentSelection.length > 0){
        let lst = this.overlay.currentSelection;
        for(let i = 0 ; i < lst.length ; i++){
            lst[i].sourceElement.dataset[propertyName] = newValue;
            lst[i].UpdateSourceRect();
        }
    }
};

PAGE_Editor_Class.prototype.OnDuplicatePage = function(event){

    if(this.selectedPageIndex > 0){
        let settings = {};

        settings.content = 'Confirmation de la duplication ?';

        settings.buttons = [];
        settings.buttons.push({'label':'OK','handler':this.DuplicatePage.bind(this)});
        settings.buttons.push({'label':'Annuler'});

        let w = new UI_PromptWindow(settings);
        w.SetParent(document.body,0.5,0.3);
    }

};

Object.defineProperty(PAGE_Editor_Class.prototype, 'selectedPageIndex', {
    get: function() {
        return parseInt(this.pageSelector.value);
    }
});

PAGE_Editor_Class.prototype.DuplicatePage = function(){
    let data = {};
    data[this.commands.action] = this.commands.duplicate;
    data['id'] = this.selectedPageIndex;
    data['pagename'] = this.pageTitleField.value;
    data['name'] = this.pageNameField.value;
    data['id_groupe']=this.groupeSelector.value;
    data['lang_id_data'] = this.lang_toggle.currentValue;
    this.ResetPage();
    let settings = {'url':'page/index.php' , 'data':data , 'dom_target0':this.php_tools_container.id , 'skip_container':true , 'success':EVENTS_Class.BindCallback(this , this.OnDuplicatePageDone )};
    $_a.send(settings);
};


PAGE_Editor_Class.prototype.OnDuplicatePageDone = function(result,sender){
    let data = JSON.parse(result);
    if(this.pageSelector.value != data.id){

        let opt = DOM_Class.CreateElement('option',{'value':data.id},data.name);
        this.pageSelector.appendChild(opt);
        this.pageSelector.value = data.id;

    }

    this.GetToolsForm();
    this.LoadPage();
};


PAGE_Editor_Class.prototype.OnDuplicateSelection = function(event){
    this.DuplicateSelection();
};


PAGE_Editor_Class.prototype.DuplicateSelection = function(){

    if(this.overlay.currentSelection.length > 0){

        let currentOverlay = this.overlay.currentSelection[this.overlay.currentSelection.length-1];

        let currentElement = currentOverlay.sourceElement;

        for(let i = 0 ; i < this.overlay.currentSelection.length ; i++){
            let overlay = this.overlay.currentSelection[i];
            let src = overlay.sourceElement;

            let domElement = DOM_Class.DuplicateDomElement(src , true);

            domElement.setAttribute('id','');

            currentElement.parentNode.insertBefore(domElement,currentElement.nextSibling);

            currentElement = domElement;

            currentOverlay = this.overlay.AddElement(domElement);
        }

        this.overlay.SelectOverlay(currentOverlay);
    }
};


PAGE_Editor_Class.prototype.OnEditItemContent = function(event){
    EVENTS_Class.StopEvent(event);
    if(this.overlay.currentSelection && this.overlay.currentSelection.length){
        this.overlay.SetTextEditor(this.overlay.currentSelection[0]);
    }else{
        this.overlay.SetTextEditor(null);
    }
};

PAGE_Editor_Class.prototype.ShowIndexation = function(){
    if(this.selectedPageIndex === 0){

        UI_Class.MessagePopup('Vous devez d\'abord sauver cette page pour accéder à ses paramètres d\'indexation');

    }else if(this._indexationWindow){
        this._indexationWindow.Toggle();
        DOM_Class.SetAlignment(this._indexationWindow.domElement , 0.5 , 0.4 , document.body);
    }else{
        UI_Class.MessagePopup('Rechargez la page pour activer les options d\'indexation');
    }
};

PAGE_Editor_Class.prototype.LoadIndexationData = function(page_id){
    let data = {};
    data[this.commands.action] = this.commands.indexation;
    data.id = page_id ? page_id : 0;


    if(!this.indexation_tools_container){
        this.indexation_tools_container = DOM_Class.CreateElement('DIV',{'class':'ui_overlay_tool_block'});
        this.indexation_tools_container.id = 'indexation_tool'+GENERICS_Class.GetUniqueId();
    }

    if(!this._indexationWindow){
        this._indexationWindow = UI_Class.AddWindow(document.body,{'modal':true,'hidden':true, 'close': CONSTANTS.texts['close'], 'class': 'ui_window page_modal_indexation'});
    }

    this._indexationWindow.SetContent(this.indexation_tools_container);


    //let settings = {'url':'page/index.php' , 'data':data , 'dom_target':this.indexation_tools_container.id , 'skip_container':true , 'success':EVENTS_Class.BindCallback(this , this.OnReceiveTools )};
    let settings = {'url':'page/index.php' , 'data':data , 'dom_target':this.indexation_tools_container.id , 'skip_container':true };
    $_a.send(settings);
};

PAGE_Editor_Class.prototype.OnReceiveTools = function(result,sender){
    this.GetToolsForm();
};

PAGE_Editor_Class.prototype.OnSelectionChange = function(event){

    let target = event.target;
    let ui_object = target._ui_object;
    
    //~ console.log(target);

    // désactivation de l'élément d'interface si aucune sélection n'est active dans le document en cours d'édition
    if(ui_object.select_active){
    	// event.detail contient la liste des éléments en cours d'édition
    	let state = GENERICS_Class.IsFilledArray(event.detail) === false;
        target.classList.toggle('disabled' , state);
    }

    switch(ui_object.action){
        case 'blockname':
        case 'blocklink':
        case 'blockgroup':
            if(this.overlay.currentSelection.length > 0){
                let lbl = this.overlay.currentSelection[0].sourceElement.dataset[ui_object.action];
                if(lbl !== undefined){
                    if (target.tagName == 'SELECT'){
                        for(let i = 0; i < target.length; i++){
                            if (target[i].value == lbl) {
                                target.selectedIndex = i;
                                break;
                            }
                        }
                    } else {
                        ui_object.value = lbl;
                    }
                }else{
                    if (target.tagName == 'SELECT'){
                        target.selectedIndex = 0;
                    } else {
                        ui_object.value = '';
                    }
                }
            }else{
                ui_object.value = '';
            }
        break;
    }

    this.overlay.UpdateHierarchy(true);

};

PAGE_Editor_Class.prototype.OnAddPreset = function(event){
    //~ console.log(event);
    let targ = event.target;
    let br = DOM_Class.CreateElement('BR', {'class': 'ui_dom_'});
    //~ console.log(targ);
    let id = targ.id;
    let items = [];
    let parent_style=false;
    switch(targ.id){
        case 'bloc_preset_two_middle':
            items[0] = {
                'style': {'display': 'inline-block', 'position': 'relative', 'width': '46%'}
            };
            items[1] = {
                'style': {'display': 'inline-block', 'position': 'relative', 'width': '46%'}
            };
        break;
        
        case 'bloc_preset_three_middle':
            items[0] = {
                'style': {'display': 'inline-block', 'position': 'relative', 'width': '29.33%'}
            };
            items[1] = {
                'style': {'display': 'inline-block', 'position': 'relative', 'width': '29.33%'}
            };
            items[2] = {
                'style': {'display': 'inline-block', 'position': 'relative', 'width': '29.33%'}
            };
        break;
        
        case 'bloc_preset_four_middle':
            items[0] = {
                'style': {'display': 'inline-block', 'position': 'relative', 'width': '21%'}
            };
            items[1] = {
                'style': {'display': 'inline-block', 'position': 'relative', 'width': '21%'}
            };
            items[2] = {
                'style': {'display': 'inline-block', 'position': 'relative', 'width': '21%'}
            };
            items[3] = {
                'style': {'display': 'inline-block', 'position': 'relative', 'width': '21%'}
            };
        break;
        
        case 'bloc_preset_big_left':
            items[0] = {
                'style': {'display': 'inline-block', 'position': 'relative', 'width': '66%'}
            };
            items[1] = {
                'style': {'display': 'inline-block', 'position': 'relative', 'width': '26%'}
            };
        break;
        
        case 'bloc_preset_big_right':
            items[0] = {
                'style': {'display': 'inline-block', 'position': 'relative', 'width': '26%'}
            };
            items[1] = {
                'style': {'display': 'inline-block', 'position': 'relative', 'width': '66%'}
            };
        break;
        
        case 'bloc_preset_medium_middle':
            items[0] = {
                'style': {'display': 'inline-block', 'position': 'relative', 'width': '16%'}
            };
            items[1] = {
                'style': {'display': 'inline-block', 'position': 'relative', 'width': '56%'}
            };
            items[2] = {
                'style': {'display': 'inline-block', 'position': 'relative', 'width': '16%'}
            };
        break;
        
        default:
        break;
    }
    
    if (items){
        let o;
        items.forEach((obj)=>{
            o = this.AddElement(obj.style);
            o.preformat = true;
            //~ if (obj.data){
                //~ for (let attr in obj.data){
                    //~ o.sourceElement.dataset[attr] = obj.data[attr];
                //~ }
            //~ }
            o.MatchSourceRect();
        });
    }
};

PAGE_Editor_Class.prototype.OnAddElement = function(event){
    this.AddElement();
    //~ this.lastAddedIsMultiple = false;
};


PAGE_Editor_Class.prototype.AddElement = function(style = false){

    let domElement = DOM_Class.CreateElement('DIV',{'className':'page_element'});
    //~ if (type == 1){ // container preformat
        //~ domElement.dataset.container_preformat = '1';
    //~ } else if (type == 2){ // preformat
        //~ domElement.dataset.preformat = '1';
    //~ }
    if (style){
        for (let attr in style){
            domElement.style[attr] = style[attr];
        }
    }

    if(this.overlay.currentSelection.length === 0){

        this.overlay.domTarget.appendChild(domElement);

    }else{
        let currentElement = this.overlay.currentSelection[this.overlay.currentSelection.length-1].sourceElement;
        //~ console.log(currentElement);
        //~ let preformat = false;
        //~ if (currentElement.dataset.preformat && !currentElement.dataset.temp) {
            //~ currentElement = currentElement.parentElement;
            //~ currentElement = currentElement.nextElementSibling;
            //~ currentElement.classList.remove('container_preformat');
            //~ preformat = true;
        //~ } else {
            //~ delete currentElement.dataset.temp;
        //~ }
        let style = DOM_Class.GetStyle(currentElement);
        //~ console.log('selection for add :',currentElement);
        //~ if(style.POS == 'relative' && !currentElement.classList.contains('container_preformat')){
        if(style.POS == 'relative'){
            currentElement.parentNode.insertBefore(domElement,currentElement.nextSibling);
        } else {
            this.overlay.currentSelection[0].sourceElement.appendChild(domElement);
        }
        
        //~ if (preformat) currentElement.classList.add('container_preformat');
    }

    let newOverlay = this.overlay.AddElement(domElement);

    this.overlay.SelectOverlay(newOverlay);

    return newOverlay;
};

PAGE_Editor_Class.prototype.OnChangeLang = function(event){
    //this.pageLangIdField.value = event.detail['var:lang_id_data'];

    this.GenerateCurrentSaveData(true);

    this.pageLangIdField.value = this.lang_toggle.currentValue;

    if(this.currentPageData.lang[this.pageLangIdField.value]){
        this.ApplyJsonData(this.currentPageData.lang[this.pageLangIdField.value]);
        this.LoadSCode();
        return true;
    }else{
        this.LoadPage();
        return false;
    }
};


PAGE_Editor_Class.prototype.OnCopyLanguage = function(event){
    let settings = {};

    settings.content = [DOM_Class.CreateElement('SPAN',{},'Copier les données actuelles vers la langue :')];

    settings.fields = {};
    let lng = {};
    let currentLang = this.lang_toggle.currentValue;
    let otherLang = 0;
    for(let i in CONSTANTS.languages){
        if(i != currentLang){
            lng[i] = CONSTANTS.languages[i].iso;
            if(!otherLang) otherLang = i;
        }
    }

    settings.fields.destination = new DOM_MULTITOGGLE_Class({'attributeName':'var:lang_id_data' , 'items':lng , 'eventName':'changeLangDestinationValue'});

    settings.fields.destination.SetValue(otherLang);

    settings.content.push(settings.fields.destination.domElement);

    settings.buttons = [];
    settings.buttons.push({'label':'Effectuer la copie','handler':this.ConfirmCopyLanguage.bind(this),'css':'warning'});
    settings.buttons.push({'label':'Annuler'});


    let w = new UI_PromptWindow(settings);
    w.SetParent(document.body , 0.5 , 0.3);
};

PAGE_Editor_Class.prototype.ConfirmCopyLanguage = function(fields , domSource){
    let src_lang = this.lang_toggle.currentValue;
    let dst_lang = fields.destination.currentValue;

    if(src_lang != dst_lang){
        this.lang_toggle.SetValue(dst_lang);

        if(this.OnChangeLang()){
            // la changement de langue s'est effectué sans avoir besoin de charger les nouvelles données à afficher
            // on peut donc effectuer la copie des blocs directement
            //~ console.log(this.media);
            if (this.media){
                let settings = {};
                settings.url = document.baseURI.split('?')[0].split('#')[0] + 'media/index.php';
                settings.dom_target = '';
                settings.skip_container = true;
                settings.data = {
                    'media_action': 'media_copy_tinymce',
                    'src_field_identifier': 'page-'+src_lang+'-'+pageEditor.currentPageData.id,
                    'dst_field_identifier': 'page-'+dst_lang+'-'+pageEditor.currentPageData.id
                };
                var self = this;
                settings.success = function(){
                    self.AppendJsonData(self.currentPageData.lang[src_lang] , true);
                };
                $_a.send(settings);
            } else {
                this.AppendJsonData(this.currentPageData.lang[src_lang] , true);
            }
        }else{
            // le changement de langue a entrainé le chargement des données en asynchrone
            // il faut donc faire l'action de copie après que ce chargement ait été effectué
            this._after_load_handler = function(){
                let settings = {};
                settings.url = document.baseURI.split('?')[0].split('#')[0] + 'media/index.php';
                settings.dom_target = '';
                settings.skip_container = true;
                settings.data = {
                    'media_action': 'media_copy_tinymce',
                    'src_field_identifier': 'page-'+src_lang+'-'+pageEditor.currentPageData.id,
                    'dst_field_identifier': 'page-'+dst_lang+'-'+pageEditor.currentPageData.id
                };
                var self = this;
                settings.success = function(){
                    self.AppendJsonData(self.currentPageData.lang[src_lang] , true);
                };
                $_a.send(settings);
            };
        }
    }
};


PAGE_Editor_Class.prototype.SetLang = function(id_data){
    EVENTS_Class.BroadcastEvent('langChange' , id_data ,this);
};

PAGE_Editor_Class.prototype.GetToolsForm = function(){
    let domTarget = this.php_tools_container.firstElementChild;

    if(domTarget){
        for(let i = 0 ; i < domTarget.children.length ; i++){
            let child = domTarget.children[i];
            if(child.tagName == 'FORM'){
                this.toolForm = child;

                for(let i = 0 ; i < child.elements.length; i++){
                	let element = child.elements[i];

                	switch(element.name){
                		case 'id':
                			this.pageSelector = element;
                        	this.pageSelector.onchange = this.OnLoadPage.bind(this);
                		break;

                		case 'pagename':
                			this.pageTitleField = element;
                		break;

                		case 'name':
                			this.pageNameField = element;
                		break;
                        case 'id_groupe':
                            this.groupeSelector = element;
                        break;
                		case 'lang_id_data':
                			this.pageLangIdField = element;
                		break;
                	}
                }
                break;
            }
        }
    }
};

PAGE_Editor_Class.prototype.NewPage = function(){
    this.pageSelector.value = 0;
    this.ResetPage();
};

PAGE_Editor_Class.prototype.ResetPage = function(){
    this.overlay.Clear();
    this.pageTitleField.value = '';
    this.pageNameField.value = '';
    this.currentPageData.lang = {};
    this.pageLangIdField.value = this.lang_toggle.currentValue;
    this.currentPageData.id = 0;
    this.domTarget.dataset.pagename = '';
    this.admin_tools_container.removeAttribute('disabled');
};

PAGE_Editor_Class.prototype.GenerateCurrentSaveData = function(skipSCode){
    let data = {};
    data.json = this.overlay.ExportJSON();
    data.blocks = this.overlay.GetBlocksContents(skipSCode);
    //~ console.log(this);
    data.name = this.pageNameField.value;
    //data.pagename =

    this.currentPageData.lang[this.pageLangIdField.value] = data;
    //this.currentPageData.pagename = this.pageTitleField.value;

    //~ console.log(data);
    return data;
};

PAGE_Editor_Class.prototype.OnSavePage = function(event){
    this.overlay.SetTextEditor(null);
    this.overlay.SelectOverlay(this.overlay.currentSelection[0]);
    this.SavePage();
};


PAGE_Editor_Class.prototype.SavePage = function(){

    // sauvegarde de toutes les versions de la page
    let data = {};
    data[this.commands.action] = this.commands.save;

    data.id = this.selectedPageIndex;
    
    // on sauve d'abord la version de la langue actuelle,
    // pour que le premier nom sauvé soit celui de la d'affichage du site langue en cours,
    // qui sera réaffiché de suite dans le select après le chargement du formulaire
    data.lang_id_data = CONSTANTS.current_lang_id;

    // génération des données à sauver pour la langue en cours d'édition
    let current_data = this.GenerateCurrentSaveData();


    // récupération des données à sauver
    //~ let first_data = this.currentPageData.lang[CONSTANTS.current_lang_id];

    //~ if(!first_data){
        //~ // cas où on a édité uniquement le texte dans une autre langue que la langue actuelle d'affichage du site
        //~ first_data = current_data;
        //~ // là il faut forcer le title pour qu'il prenne la valeur du nom définit
        //~ first_data.title = first_data.name;
        //~ data.lang_id_data = parseInt(this.pageLangIdField.value);
    //~ }

    //~ first_data.pagename = this.pageTitleField.value;

    //~ // on spécifie que cette version a été sauvée pour qu'elle ne le soit pas une seconde fois dans la seconde partie du processus de sauvegarde
    //~ first_data.saved = true;
    //~ this.total_saved_page++;
    
    //~ console.log(data);
    //~ console.log(first_data);

    //~ let settings = {'url':'page/index.php' , 'data':data , 'extra_data':first_data , 'dom_target0':this.php_tools_container.id , 'skip_container':true, 'error':this.OnSaveError.bind(this) , 'success':this.OnPageSaved.bind(this)};

    settings = {};
    settings.content = [pageEditor.texts['saving']];
    settings.buttons = [];
    let w = new UI_PromptWindow(settings);
    w.SetParent(document.body , 0.5 , 0.3);

    this._savePrompt = w;
    
    //~ $_a.send(settings);
    //~ console.log('début sauvegarde');
    this.OnSaveOtherLanguages.bind(this)();
};


PAGE_Editor_Class.prototype.UpProgress = function(){
    //~ console.log(arguments);
};

PAGE_Editor_Class.prototype.OnPageSaved = function(result,sender){
    //~ let data = JSON.parse(result);
    //~ let data = result;
    //~ if(this.pageSelector.value != data.id){
        //~ if(!this.pageSelector.value){
            //~ let opt = DOM_Class.CreateElement('option',{'value':data.id},data.title);
            //~ this.pageSelector.appendChild(opt);
            //~ this.pageSelector.value = data.id;
        //~ }
    //~ }

    //~ let opt = this.pageSelector.options[this.pageSelector.selectedIndex];
    //~ if(opt){
        //~ opt.innerHTML = this.pageNameField.value;
    //~ }
    //~ this.OnSaveOtherLanguages(result,sender);
};

PAGE_Editor_Class.prototype.OnSaveOtherLanguages = function(count = 0,sender){
    var self = this;
    let size = Object.keys(this.currentPageData.lang).length;
    console.log(this.lang_toggle);
    for (let i = 0; i < this.lang_toggle.allowed_values.length; i++){
        let lng = this.lang_toggle.allowed_values[i];
        let data = this.currentPageData.lang[lng];
        if(data && !data.saved){
            data[this.commands.action] = this.commands.save;
            data.id = this.selectedPageIndex;
            data.lang_id_data = parseInt(lng);
            data.id_groupe=this.groupeSelector.value;
            data.pagename = this.pageTitleField.value;
            let settings = {'url':'page/index.php' , 'data':data , 'skip_container':true};
            settings.success = function(res){
                count++;
                let t = JSON.parse(res);
                if (t.id && t.id != self.selectedPageIndex){
                    if(self.pageSelector.value != t.id){
                        if(!self.pageSelector.value){
                            let opt = DOM_Class.CreateElement('option',{'value':t.id},t.title);
                            self.pageSelector.appendChild(opt);
                            self.pageSelector.value = t.id;
                            self.selectedPageIndex = t.id;
                            self.currentPageData['id'] = self.selectedPageIndex;
                        }
                    }
                }
                data.saved=true;
                if (count == size){
                    self.OnSaveDone();
                } else {
                    self.OnSaveOtherLanguages.bind(self)(count);
                }
            };
            $_a.send(settings);
            break;
        }
    }
};

PAGE_Editor_Class.prototype.OnSaveError = function(result,sender){
    console.log('Erreur sauvegarde');
    debugger;
    this._savePrompt.Remove();

    this.LoadIndexationData(this.selectedPageIndex);
    this.lang_toggle.SetValue(this.pageLangIdField.value);
};

PAGE_Editor_Class.prototype.OnSaveDone = function(result,sender){
    //~ console.log('Sauvegarde terminée');
    this._savePrompt.Remove();
    
    this.currentPageData['id'] = this.selectedPageIndex;
    this.LoadIndexationData(this.selectedPageIndex);
    this.lang_toggle.SetValue(this.pageLangIdField.value);
    this.LoadPage();
    
    if (window.spd2_koldron) spd2_koldron.reloadPreview();
};

PAGE_Editor_Class.prototype.OnLoadPage = function(event){

    if(this.currentPageData.id != this.selectedPageIndex){
        this.ResetPage();
    }
//~ console.log(this.selectedPageIndex);
    if (this.selectedPageIndex > 0){
        this.infoID.innerHTML = '#page=' + this.selectedPageIndex;
        this.LoadPage();
        
        // ajout koldron, bloquer la suppresion de la page avec id 1, la page d'acceuil
        if (this.selectedPageIndex == 1){
            this.pageSelector.parentElement.nextElementSibling.nextElementSibling.firstElementChild.disabled = true;
        } else {
            this.pageSelector.parentElement.nextElementSibling.nextElementSibling.firstElementChild.disabled = false;
        }
    }else{
        this.infoID.innerHTML = '';
        this.GetToolsForm();

	    this.overlay.Clear();
	    this.pageTitleField.value = '';
	    this.pageNameField.value = '';
        this.pageSelector.parentElement.nextElementSibling.nextElementSibling.firstElementChild.disabled = false;
    }
   
};

PAGE_Editor_Class.prototype.LoadPage = function(){
	this.loadingPage = true;
	
	this.php_tools_container.classList.toggle('disabled',true);

    let data = {};
    data[this.commands.action] = this.commands.load;
    data['lang_id_data'] = this.lang_toggle.currentValue;

    let settings = {'url':'page/index.php' , 'data':this.toolForm , 'extra_data':data , 'dom_target':this.php_tools_container.id , 'skip_container':true, 'disableTargetUpdate':true, 'success':EVENTS_Class.BindCallback(this , this.OnLoadDone )};

    $_a.send(settings);
};

PAGE_Editor_Class.prototype.OnLoadDone = function(result,sender){
    this.GetToolsForm();

    this.overlay.Clear();
    this.pageTitleField.value = '';
    this.pageNameField.value = '';
    if (this.domTarget.firstChild){
        while(this.domTarget.firstChild){
            this.domTarget.removeChild(this.domTarget.firstChild);
        }
    }

    this.loadingPage = false;
	
	this.php_tools_container.classList.toggle('disabled',false);

    if(!result){
        console.log('no json data');
        return false;
    }

    let data = null;

    try {
        data = JSON.parse(result);
    } catch (e) {
        console.log('bad json data');
        return false;
    }

    this.ApplyJsonData(data);

    this.LoadIndexationData(this.selectedPageIndex);

    this.LoadSCode();

    if(this.currentPageData.id != this.selectedPageIndex){
        this.currentPageData.lang = {};
    }
    this.currentPageData.id = this.selectedPageIndex;
    this.currentPageData.lang[this.lang_toggle.currentValue] = data;

    if(this._after_load_handler){
        this._after_load_handler();
        this._after_load_handler = undefined;
    }

};


PAGE_Editor_Class.prototype.LoadSCode = function(scode){
    let scode_tags = document.getElementsByClassName('scode');
    let scodes = [];
    let tags = [];
    for(let i=0; i<scode_tags.length; i++){
        let scode = scode_tags[i].dataset.scode;
        if(GENERICS_Class.IsString(scode)){
            scodes.push( scode );
            tags.push( scode_tags[i] );
        }
    }
    
    this.php_tools_container.classList.toggle('disabled',true);

    let data = {};
    data[this.commands.action] = this.commands.getscode;
    data['scode'] = scodes;

    let settings = {'url':'page/index.php' , 'data':data , 'localdata':tags , 'skip_container':true, 'disableTargetUpdate':true, 'success':EVENTS_Class.BindCallback(this , this.OnLoadSCodeDone )};

    $_a.send(settings);
};

PAGE_Editor_Class.prototype.OnLoadSCodeDone = function(result,sender){

    if(GENERICS_Class.IsFilledObject(result)){
        if(GENERICS_Class.IsFilledArray(result)){
            let tags = sender._localdata;
            for(let i=0; i<result.length; i++){
                //tags[i].outerHTML = '<div class="mceNonEditable scode" data-scode="'+tags[i].innerHTML+'">'+result[i]+'</div>';
                tags[i].outerHTML = result[i];
            }
        }
    }
    
    this.LoadScodeCss();
    this.php_tools_container.classList.toggle('disabled',false);
};

PAGE_Editor_Class.prototype.LoadScodeCss = function(){
    let scode_tags = document.getElementsByClassName('scode');
    let modules = [];
    for(let i=0; i<scode_tags.length; i++){
        let scode = scode_tags[i].dataset.scode;
        if(GENERICS_Class.IsString(scode)){
            let m = scode.split('|').shift();
            if(modules.indexOf(m) == -1){
                modules.push( m );
            }
        }
    }

    let data = {};
    data[this.commands.action] = this.commands.getcss;
    data['modules'] = modules;

    let settings = {'url':'page/index.php' , 'data':data , 'skip_container':true, 'disableTargetUpdate':true, 'success':EVENTS_Class.BindCallback(this , this.OnLoadCssDone )};

    $_a.send(settings);
};

PAGE_Editor_Class.prototype.OnLoadCssDone = function(result,sender){
    if(GENERICS_Class.IsFilledObject(result)){
        content = [];
        for (let media in result){
            if (media != 'general'){
                content+=media+'{';
            }
            for (let i = 0; i < result[media].length; i++){
                let rules = result[media][i];
                content+=rules[0]+'{'+rules[1]+'}';
            }
            if (media != 'general'){
                content+='}';
            }
        }
        
        let styleSheet = document.querySelector('[title="insertedFromDB"]');
        //~ console.log(styleSheet);
        if (!styleSheet) styleSheet = document.querySelector('[title="variableFromPublic"]');
        if (styleSheet){
            styleSheet.innerHTML += content;
        }
        //~ if (!this.stylesheetScode){
            //~ this.stylesheetScode = DOM_Class.CreateElement('style', {'rel':'stylesheet', 'type': 'text/css', 'title':'cssScode'});
            //~ document.body.appendChild(this.stylesheetScode);
        //~ }
        //~ this.stylesheetScode.innerHTML = content;
        //~ if (this.stylesheetScode.sheet.disabled) this.stylesheetScode.sheet.disabled=false;
        //~ console.log(this.stylesheetScode.sheet);
    }
};

PAGE_Editor_Class.prototype.ApplyJsonData = function(data){
    if(GENERICS_Class.IsFilledObject(data)){
        this.overlay.ImportJSON(data.json , data.blocks);
/*
        if(GENERICS_Class.IsFilledObject(data.blocks)){
            for(let id in data.blocks){
                let domElement = DOM_Class.GetDomElement(id);
                if(domElement){
                    domElement.innerHTML = data.blocks[id];
                }else{
                    debugger;
                }
            }
        }
*/
        if(data.pagename !== undefined) {
            this.pageTitleField.value = data.pagename;
            this.domTarget.dataset.pagename = data.pagename;
        }
        if (data.id_groupe !==undefined){
            //~ console.log(data.id_groupe);
            this.groupeSelector.value=data.id_groupe;
        }
        this.pageNameField.value = data.name;

        //~ console.log(data);

    }
};


PAGE_Editor_Class.prototype.AppendJsonData = function(data,regenerateIds){

    if(GENERICS_Class.IsFilledObject(data)){
        this.overlay.AppendJSON(data.json , data.blocks , regenerateIds);
    }
};

//----------------------------------------------------------------------------------------------------


var DOM_OVERLAY_Class = function(domTarget , moduleName){

    if(GENERICS_Class.IsString(domTarget)){
        domTarget = DOM_Class.GetDomElement(domTarget);
    }

    if(!domTarget){
        debugger;
        return false;
    }

    this.domTarget = domTarget || document.body;

    this.domElement = DOM_Class.CreateElement('DIV');
    this.domElement.className = 'ui_overlay_container';

    this.overlays = [];
    this.currentSelection = [];

    // insertion de l'overlay juste au dessus de l'élément édité
    DOM_Class.InsertAfter(this.domElement , this.domTarget);

    $_e.AddResizeHandler(this.OnUpdateHierarchy.bind(this));
    //EVENTS_Class.AddEvent(window,'resize',this.OnUpdateHierarchy.bind(this));
    $_e.AddEventKey(document, this.OnKeyDown.bind(this) );
    //EVENTS_Class.AddEvent(document , 'keydown' , this.OnKeyDown.bind(this) );

    //EVENTS_Class.AddEvent(this.domTarget , EVENTS_Class.EVENT_TOUCHSTART , EVENTS_Class.BindCallback(this , this.OnTouchDown ) );

    EVENTS_Class.AddEventClick(this.domTarget, EVENTS_Class.BindCallback(this , this.OnMouseDown ) );
    EVENTS_Class.AddEventClick(document.body, EVENTS_Class.BindCallback(this , this.OnMouseDown ));

    //EVENTS_Class.AddEvent(domTarget , EVENTS_Class.EVENT_DOUBLECLICK , EVENTS_Class.BindCallback(this , this.OnDoubleClick ) );
    //EVENTS_Class.AddEvent(document.body , EVENTS_Class.EVENT_DOUBLECLICK , EVENTS_Class.BindCallback(this , this.OnDoubleClick ) );

    this.moduleName = moduleName || 'auto';

    // TODO : remplacer par
    // https://developer.mozilla.org/en-US/docs/Web/API/MutationObserver
    EVENTS_Class.AddEvent(document , 'DOMNodeRemoved' , EVENTS_Class.BindCallback(this , this.OnRemoveFromDom ) );

    this.mceEditing = false;

    this.visibility = {};
    this.visibility['min-width'] = true;
};
DOM_OVERLAY_Class.prototype.constructor = DOM_OVERLAY_Class;

DOM_OVERLAY_Class.prototype.GetUniqueId = function(){
    return Date.now()+''+Math.round(111+Math.random()*888);
};

DOM_OVERLAY_Class.prototype.OnRemoveFromDom = function(event){
    if(event.target == this.domTarget){
        // TODO : remplacer par
        // https://developer.mozilla.org/en-US/docs/Web/API/MutationObserver
        EVENTS_Class.RemoveEvent(document , 'DOMNodeRemoved' , EVENTS_Class.BindCallback(this , this.OnRemoveFromDom ) );
        this.domElement.remove();
    }
};

DOM_OVERLAY_Class.prototype.OnChangeAttribute = function(event){

    let data = event.detail;

    let lst = this.currentSelection;
    for(let i = 0 ; i < lst.length ; i++){
        for(let key in data){
            let tmp = key.split(':');
            let type = tmp[0];
            let attrName = tmp[1];
            let value = data[key];
            
            switch(type){
                case 'css':

                    switch(attrName){
                        case 'position':
                            DOM_Class.StoreCssRect(lst[i].sourceElement);
                            DOM_Class._SetRectDirty(lst[i].sourceElement);
                        break;
                    }

                    DOM_Class.SetStyleValue(lst[i].sourceElement , attrName , value);

                    switch(attrName){
                        case 'position':
                            DOM_Class.RestoreCssRect(lst[i].sourceElement);
                            DOM_Class._SetRectDirty(lst[i].sourceElement);

                            lst[i].MatchSourceRect();
                            lst[i].UpdateControls();
                            lst[i].UpdateUI();

                        break;

                        case 'display':
                            EVENTS_Class.BroadcastEvent('displayChange' , [lst[i]] , this);
                            
                            let style = DOM_Class.GetStyle(lst[i].sourceElement);
                            this.UpdateAlignment(lst[i] , style._align , style);

                        break;
                    }
                break;

                case 'var':
                    let style = DOM_Class.GetStyle(lst[i].sourceElement);

                    switch(attrName){
                        case 'width_unit':

                            style._width_unit = value;

                            if(style.POS == 'relative'){

                                DOM_Class.SetGlobalWidth(lst[i].sourceElement , style.rect.width);

                                lst[i].MatchSourceRect();
                                lst[i].UpdateControls();
                                lst[i].UpdateUI();

                                EVENTS_Class.BroadcastEvent('widthChange' , [lst[i]] , this);

                                this.UpdateAlignment(lst[i] , style._align , style);
                            }

                        break;

                        case 'minwidth_unit':

                            let mw = DOM_Class.GetStyleValue(lst[i].sourceElement , 'min-width');

                            if(value != style._minwidth_unit){
                                mw = DOM_CSS_MANAGER_Class.ToPx(mw , lst[i].sourceElement.parentNode);
                                style._minwidth_unit = value;
                                DOM_Class.SetGlobalMinWidth(lst[i].sourceElement , mw );
                            }

                            style._minwidth_unit = value;

                            lst[i].MatchSourceRect();
                            lst[i].UpdateControls();
                            lst[i].UpdateUI();

                            EVENTS_Class.BroadcastEvent('minwidthChange' , [lst[i]] , this);

                        break;

                        case 'align':
                            //~ console.log(value);
                            //~ console.log(lst[i]);
                            //~ console.log(style);
                            if (value == 'sans'){
                                //~ EVENTS_Class.BroadcastEvent('displayChange' , [lst[i]] , this);
                                
                                
                                //~ this.UpdateAlignment(lst[i], 'block', style);
                                //~ let style = DOM_Class.GetStyle(lst[i].sourceElement);
                                lst[i].sourceElement.style.display = 'inline-block';
                                style = DOM_Class.GetStyle(lst[i].sourceElement);
                                //~ style.all.display = 'block';
                                style._align = '';
                                this.UpdateAlignment(lst[i] , style._align , style);
                                //~ let style = DOM_Class.GetStyle(lst[i].sourceElement);
                                //~ this.UpdateAlignment(lst[i] , style._align , style);
                            } else {
                                lst[i].sourceElement.style.display = 'block';
                                style = DOM_Class.GetStyle(lst[i].sourceElement);
                                //~ style.all.display = 'inline-block';
                                //~ EVENTS_Class.BroadcastEvent('displayChange' , [lst[i]] , this);
                                
                                //~ let style = DOM_Class.GetStyle(lst[i].sourceElement);
                                //~ this.UpdateAlignment(lst[i] , style._align , style);
                                
                                style._align = value;
                                this.UpdateAlignment(lst[i] , value , style);
                            }

                        break;
                    }
                break;

                default:
                    //debugger;
                break;
            }

        }
    }

    this.UpdateHierarchy(true);
};

DOM_OVERLAY_Class.prototype.UpdateAlignment = function(overlayElement,value,style){
    if(!style){
        style = DOM_Class.GetStyle(overlayElement.sourceElement);
    }

    if(style.POS == 'relative'){

        //if(style._width_unit == 'auto' && style.all.display == 'inline-block' ){
        if(style._width_unit == 'auto' || style.all.display == 'inline-block'){
            DOM_Class.SetStyleValue(overlayElement.sourceElement , 'margin-left' , '');
            DOM_Class.SetStyleValue(overlayElement.sourceElement , 'margin-right' , '');
        }else{

            switch(value){
                case 'center':
                    DOM_Class.SetStyleValue(overlayElement.sourceElement , 'margin-left' , 'auto');
                    DOM_Class.SetStyleValue(overlayElement.sourceElement , 'margin-right' , 'auto');
                break;

                case 'right':
                    DOM_Class.SetStyleValue(overlayElement.sourceElement , 'margin-left' , 'auto');
                    DOM_Class.SetStyleValue(overlayElement.sourceElement , 'margin-right' , 'unset');
                break;

                default:
                    DOM_Class.SetStyleValue(overlayElement.sourceElement , 'margin-left' , '');
                    DOM_Class.SetStyleValue(overlayElement.sourceElement , 'margin-right' , '');
                break;
            }
        }
        overlayElement.MatchSourceRect();
        overlayElement.UpdateControls();
        overlayElement.UpdateUI();
    }
};

DOM_OVERLAY_Class.prototype.OnKeyDown = function(e){
    if(e.shiftKey && e.ctrlKey){
        this.domTarget.classList.toggle('ui_preview');
        if(this.domTarget.classList.contains('ui_preview')){
            this.domElement.style.opacity = 0;
        }else{
            this.domElement.style.opacity = 1;
        }
        EVENTS_Class.StopEvent(e);
    }
    if(e.ctrlKey && e.keyCode == 83){
        EVENTS_Class.StopEvent(e);
        //~ console.log('CTRL + S');
        pageEditor.OnSavePage();
    }
};

DOM_OVERLAY_Class.prototype.GetBlocksContents = function(skipSCode){

    let result = {};
    for(let i = 0 ; i < this.overlays.length ; i++){
        let o = this.overlays[i];
        //~ if (o.preformat) return;
        //~ console.log(o);
        //~ if (o.container_preformat) continue;
//~ console.log(o);    

        for(let j = o.sourceElement.children.length-1 ; j >=0 ; j--){
            let e = o.sourceElement.children[j];

            if(e.className.indexOf('mce-')>-1){
                if(e.className.indexOf('mce-resizeHandle')>-1 || e.className.indexOf('mce-offscreen-selection')>-1){
                    //~ console.log('remove mce',e);
                    e.remove();
                }else{
                    let tmp = e.className.split(' ');
                    for(let c = 0 ; c<tmp.length; c++){
                        if(tmp[c].indexOf('mce-'===0)){
                            e.classList.toggle(tmp[c],false);
                            //~ console.log('remove css:',tmp[c]);
                        }
                    }
                }
            }

            if (e.tagName == 'DETAILS'){
                e.removeAttribute('open');
            }
        }

        let tmp = [];
        if(o.sourceElement.dataset.module){
            while(o.sourceElement.children.length > 0){
                tmp.push(o.sourceElement.children[0]);
                o.sourceElement.children[0].remove();
            }
        }

        this.CheckForSaveImgUrl(o.sourceElement);
        
        //scode
//~ console.log(skipSCode);
        if(skipSCode){
            let original_html = o.sourceElement.innerHTML;
            let scode_tags = o.sourceElement.getElementsByClassName('scode');
            if(scode_tags && scode_tags.length){
        
                for(let i=0 ; i<scode_tags.length; i++){
                    let scode = scode_tags[i].dataset.scode;
                    scode_tags[i].outerHTML = '<div class="mceNonEditable scode" data-scode="'+scode+'">['+scode+']</div>';
                }
            }

            result[o.sourceElement.id] = o.sourceElement.innerHTML;

            o.sourceElement.innerHTML = original_html;
        }else{
            let original_html = o.sourceElement.innerHTML;
            let scode_tags = o.sourceElement.getElementsByClassName('scode');
            if(scode_tags && scode_tags.length){
                while (scode_tags.length){
                    let scode = scode_tags[0].dataset.scode;
                    scode_tags[0].outerHTML = '['+scode+']';
                }
                //~ for(let i=0 ; i<scode_tags.length; i++){
                    
                //~ }
            }

            result[o.sourceElement.id] = o.sourceElement.innerHTML;

            o.sourceElement.innerHTML = original_html;
        }
        


        if(tmp.length > 0){
            while(tmp.length > 0){
                o.sourceElement.appendChild(tmp.shift());
            }
        }
        tmp.length = 0;
    }

    return result;
};

// fonction pour gérer les urls des images
DOM_OVERLAY_Class.prototype.SanitizeImgUrl = function(elem){
    if (elem){
        if (elem.tagName == 'IMG'){
            elem.src = '../' + elem.src.slice(elem.src.indexOf('public'));
            if (this._resetId || pageEditor.pageNameField.value.startsWith('[CP]') || elem.dataset.field_identifier == 'page-'+pageEditor.pageLangIdField.value+'-0'){
                let field_identifier = elem.dataset.field_identifier;
                let real_field_identifier = 'page-'+pageEditor.pageLangIdField.value+'-'+pageEditor.currentPageData.id;
                if (field_identifier != real_field_identifier){
                    let field_id = elem.dataset.field_id;
                    let oldMediaId = field_identifier+'-'+field_id;
                    let realMediaId = real_field_identifier+'-'+field_id;
                    elem.dataset.field_identifier = real_field_identifier;
                    elem.id = elem.id.replace(oldMediaId, realMediaId);
                    elem.src = elem.src.replace(field_identifier, real_field_identifier);
                }
            }
        }
        var children = elem.children;
        for (let i = 0; i < children.length; i++){
            this.SanitizeImgUrl(children[i]);
        }
    }
};

DOM_OVERLAY_Class.prototype.CheckForSaveImgUrl = function(elem){
    if (elem){
        if (elem.tagName == 'IMG'){
            elem.src = elem.src.slice(elem.src.indexOf('public'));
        }
        var children = elem.children;
        for (let i = 0; i < children.length; i++){
            this.CheckForSaveImgUrl(children[i]);
        }
    }
};

DOM_OVERLAY_Class.prototype.ExportJSON = function(){
    let data = this.RecurseExportJSON(this.domElement);
    this.saved = data;
    //~ console.log(data);
    return data;
};

DOM_OVERLAY_Class.prototype.RecurseExportJSON = function(parentNode){
    let sourceElement;

    if(!parentNode){
        parentNode = this.domElement;
        sourceElement = this.domTarget; //document.body;
    }else{
        sourceElement = parentNode._sourceElement?parentNode._sourceElement:parentNode;
    }
    
    //~ if (sourceElement.dataset.container_preformat) return;

    let class_exclude_list = ['ui_dom_' , 'mce-','hideTinymce'];

    let class_list = sourceElement.className.split(' ');
    for(let i = class_list.length-1; i >= 0 ; i--){
        for(let j=0; j < class_exclude_list.length;j++){
            if(class_list[i].indexOf(class_exclude_list[j])===0){
                class_list.splice(i,1);
                break;
            }
        }
    }

    let result = {'dom_id':sourceElement.id , 'className':class_list.join(' ') , 'tagName':sourceElement.tagName, 'style':{} , 'children':[] , 'data':{} , 'styleData':{} };

    let style = DOM_Class.GetStyle(sourceElement);

    let attributes;

    if(style.POS == 'relative'){
        attributes = ['display','position','min-width'];
        if(sourceElement.style.width){
            attributes.push('width');
        }
        if(style._align){
            attributes.push('margin-left');
            attributes.push('margin-right');
        }
    } else {
        attributes = ['display','position','left','top','right','bottom','width','height','min-width'];
    }
    
    //~ if (sourceElement.dataset.container_preformat){
        //~ attributes.push('display', 'grid-template-columns', 'justify-content', 'grid-gap');
    //~ }
    
    //~ if (sourceElement.dataset.preformat){
        //~ attributes.push('justify-self', 'display', 'max-width', 'position', 'right', 'float', 'left');
        //~ let preformat = sourceElement.dataset.preformat;
        //~ switch (preformat){
            //~ case '1':
                //~ attributes.push('right');
                //~ attributes.push('float');
            //~ break;
            //~ case '2':
                //~ attributes.push('left');
            //~ break;
            
            //~ default:
            //~ break;
        //~ }
    //~ }

    for(let i = 0 ; i < attributes.length ; i++){
        result.style[attributes[i]] = DOM_Class.GetStyleValue(sourceElement , attributes[i]);
    }

    result.styleData._storedRect = style._storedRect;
    result.styleData._snapEdge = style._snapEdge;
    result.styleData._snapCenter = style._snapCenter;
    result.styleData._width_unit = style._width_unit;
    result.styleData._minwidth_unit = style._minwidth_unit;
    result.styleData._align = style._align;

    result.blockdata = {};
    for(let i in sourceElement.dataset){
        if(sourceElement.dataset[i] !== ''){
            result.blockdata[i] = sourceElement.dataset[i];
        }
    }

    let lst = parentNode.children;

    for(let i = 0 ; i < lst.length ; i++){
        if(lst[i].classList.contains('ui_overlay_item')){
            let obj = lst[i];
            let index = DOM_Class.GetDomElementIndex(obj._sourceElement);
            result.children[index] = this.RecurseExportJSON(lst[i]);
        }
    }
    
    //~ console.log('-----------');
    //~ console.log(parentNode);
    //~ console.log(sourceElement);
    //~ console.log(result);

    return result;
};

DOM_OVERLAY_Class.prototype.Clear = function(){
    this.SelectOverlay(null);

    while(this.overlays.length > 0){
        this.RemoveElement(this.overlays[0]);
    }
    
    this.UpdateMaxHeight();

    EVENTS_Class.BroadcastEvent('selectionChange' , this.currentSelection ,this);
};

DOM_OVERLAY_Class.prototype.UpdateMaxHeight = function(newHeight){
    return;
    /*
    if(!newHeight){
        DOM_Class.SetGlobalHeight(this.domTarget , '');
    }else{
        let myRect = DOM_Class.GetGlobalRect(this.domTarget);
        let parentRect = DOM_Class.GetGlobalRect(this.domTarget.parentNode);
        if(newHeight < parentRect.bottom){
            newHeight = parentRect.bottom;
        }
        //if(newHeight > myRect.bottom && newHeight > parentRect.bottom){
            DOM_Class.SetGlobalBottom(this.domTarget , newHeight);
        //}
    }
    */
};

DOM_OVERLAY_Class.prototype.LoadTest = function(){
    if(this.saved){
        this.ImportJSON(this.saved);
    }
};

DOM_OVERLAY_Class.prototype.ImportJSON = function(jsonData , contentData , resetId){

    this.Clear();
    this.AppendJSON(jsonData , contentData , resetId);
};

DOM_OVERLAY_Class.prototype.AppendJSON = function(jsonData , contentData , resetId){

    this._resetId = resetId;
    this._contentData = contentData;
    //~ console.log(jsonData);
    this.RecurseImportJSON(jsonData);
    this._contentData = undefined;
    this.resetId = undefined;

    setTimeout(this.UpdateHierarchy.bind(this) , 500 , true);
    setTimeout(this.UpdateHierarchy.bind(this) , 1000 , true);
    setTimeout(this.UpdateHierarchy.bind(this) , 2000 , true);

    this.SelectOverlay(null);
};


DOM_OVERLAY_Class.prototype.RecurseImportJSON = function(jsonData , parentNode){

    if(GENERICS_Class.IsString(jsonData)){
        jsonData = JSON.parse(jsonData);
    }

    if(!GENERICS_Class.IsObject(jsonData)){
        return false;
    }

    let domElement = null;

    if(!parentNode){
        domElement = this.domTarget;
    }else{
        domElement = DOM_Class.CreateElement(jsonData.tagName);

        if(!this._resetId) domElement.id = jsonData.dom_id;

        domElement.className = jsonData.className;

        if(this._contentData){
            if(this._contentData[jsonData.dom_id]){
                DOM_Class.AppendContent( domElement, this._contentData[jsonData.dom_id]);
            }
        }else if(jsonData.content){
            DOM_Class.AppendContent( domElement , jsonData.content);
        }
        parentNode.appendChild(domElement);

        for(let i in jsonData.style){
            DOM_Class.SetStyleValue( domElement , i , jsonData.style[i]);
        }

        let style = DOM_Class.GetStyle(domElement);

        for(let i in jsonData.styleData){
            style[i] = jsonData.styleData[i];
        }

        if(jsonData.blockdata){
            for(let i in jsonData.blockdata){
                domElement.dataset[i] = jsonData.blockdata[i];
            }
        }

        if (domElement.tagName == 'IMG'){
            let field_identifier = domElement.dataset.field_identifier;
            //~ console.log(field_identifier);
            //~ console.log(this);
            //~ let realField_identifier = 'page_'.
        }

        this.SanitizeImgUrl(domElement);
        this.AddElement(domElement);
    }

    if(domElement){



        for(let i in jsonData.children){
            let childData = jsonData.children[i];
            this.RecurseImportJSON(childData , domElement);
        }

        if (domElement.dataset.module && domElement.children.length == 0) {
            let settings = {};
            settings.url = CONSTANTS.base_url + '/public/' + domElement.dataset.module + '/index.php';
            settings.dom_target = domElement.id;
            settings.data = JSON.parse(domElement.dataset.module_params);
            $_a.send(settings);
            //~ UI_Class.RefreshContainer(domElement.id, JSON.parse(domElement.dataset.module_params), false);
        }
        
        //~ if (domElement.dataset.preformat && domElement.dataset.preformat == '2'){
            //~ console.log('add br after');
            //~ let br = DOM_Class.CreateElement('BR', {'class': 'ui_dom_'});
            //~ DOM_Class.InsertAfter(br, domElement);
        //~ }

        //~ console.log(domElement);
    }else{
        debugger;
    }
};

DOM_OVERLAY_Class.prototype.OnSelectionChange = function(event){

    EVENTS_Class.BroadcastEvent('selectionChange' , this.currentSelection , this);
};

DOM_OVERLAY_Class.prototype.AddElement = function(domElement){

    let o = new DOM_OVERLAY_ITEM_Class(domElement , this);
    
    this.overlays.push(o);

    this.UpdateHierarchy();
    
    o.Hide();
    //this.SelectOverlay(o);

    return o;
};

DOM_OVERLAY_Class.prototype.RemoveElement = function(overlayItem){

    if(this.mceEditing === overlayItem){
        this.SetTextEditor(null);
    }

    let pos = this.overlays.indexOf(overlayItem);
    if(pos > -1){
        this.overlays.splice(pos,1);
        tinymce.remove('#'+overlayItem.sourceElement.id);
        overlayItem.domElement.remove();
        overlayItem.sourceElement.remove();
    }
};

DOM_OVERLAY_Class.prototype.OnRemoveSelection = function(event){

    let lst = this.currentSelection.concat();
    for(let i = 0 ; i < lst.length ; i++){
        this.RemoveElement(lst[i]);
    }

    this.UpdateHierarchy(true);

    this.SelectOverlay(null);
};


DOM_OVERLAY_Class.prototype.OnDoubleClick = function(event){
debugger;
/*
    if(this.mceEditing){
        EVENTS_Class.StopEvent(event);
        this.SetTextEditor(null);
    }
*/
};


DOM_OVERLAY_Class.prototype.OnMouseDown = function(event){
    // clic sur une zone vide

    if(event.target._sourceElement){
        // clic sur un overlay
        return true;
    }

    let p = event.target;
    while(p){
        p = p.parentNode;
        if(p == this.tools_container){
            return true;
        }
    }

    //console.log('DOM_OVERLAY_Class.prototype.OnMouseDown',event);

    if(!this.mceEditing){

        this.SelectOverlay(null);
        EVENTS_Class.BroadcastEvent('selectionChange' , this.currentSelection ,this);

    }else{
        // si un div est en cours d'édition, désactivation du mode édition

        EVENTS_Class.StopEvent(event);
        this.SetTextEditor(null);

        let count = this.currentSelection.length;

        for(let i = 0 ; i < count ; i++){
            this.currentSelection[i].Enable();
            this.currentSelection[i].Show();
            this.currentSelection[i].Select();
        }


    }

};

DOM_OVERLAY_Class.prototype.OnTouchDown = function(event){
    // clic sur une zone vide

//console.log('DOM_OVERLAY_Class.prototype.OnTouchDown',event);

    let lst = event.touches;

    if(lst.length > 0){
        let touched = lst[0].target;

        if(this.mceEditing){
            let loop = 0;
            while(touched != this.mceEditing.domElement && touched != this.mceEditing.sourceElement && loop < 100){
                touched = touched.parentNode;

                if(touched == this.mceEditing.domElement || touched == this.mceEditing.sourceElement){
                    //EVENTS_Class.StopEvent(event);
                    return true;
                }
                if(!touched){
                    break;
                }
                loop++;
            }
        }
    }

    if(!this.mceEditing){

        this.SelectOverlay(null);
        EVENTS_Class.BroadcastEvent('selectionChange' , this.currentSelection ,this);

    }else{
        // si un div est en cours d'édition, désactivation du mode édition

        EVENTS_Class.StopEvent(event);
        //FORCE LA DESELECTION !
        this.mceEditing.Selection.collapse();
        
        this.SetTextEditor(null);

        let count = this.currentSelection.length;

        for(let i = 0 ; i < count ; i++){
            this.currentSelection[i].Enable();
            this.currentSelection[i].Show();
            this.currentSelection[i].Select();
        }


    }

};

DOM_OVERLAY_Class.prototype.OnUpdateHierarchy = function(event){
    this.UpdateHierarchy(true);
};

DOM_OVERLAY_Class.prototype.UpdateHierarchy = function(forceRefresh){
    let count = this.overlays.length;

    let maxHeight = 0;
    if(count > 0){
        for(let i = 0 ; i < count ; i++){
            this.overlays[i].Update(forceRefresh);
            maxHeight = Math.max(this.overlays[i].style.rect.bottom , maxHeight);
        }
    }

    this.UpdateMaxHeight(maxHeight);
};

DOM_OVERLAY_Class.prototype.SelectOverlay = function(o){
    let count = this.overlays.length;

    let result = false;

    if(this.currentSelection.indexOf(o) > -1){
        result = 'present';
    }else{
        result = 'added';
    }

    this.currentSelection.length = 0;

    for(let i = 0 ; i < count ; i++){

        if(this.overlays[i].selected && this.overlays[i] !== o){
            this.overlays[i].Unselect();

        }else if(this.overlays[i] === o){
            this.overlays[i].Select();
            this.currentSelection.push(this.overlays[i]);
        }
    }

    EVENTS_Class.BroadcastEvent('selectionChange' , this.currentSelection ,this);

    return result;
};

DOM_OVERLAY_Class.prototype.SetTextEditor = function(o){
    let count = this.overlays.length;

    if(GENERICS_Class.IsObject(this.mceEditing)){
        this.mceEditing.StoreTextSelection();
    }

    this.mceEditing = false;

    let lang = CONSTANTS.current_lang_iso=='fr'?'fr_FR':'';

    pageEditor.admin_tools_container.classList.toggle('disabled',false);

    for(let i = 0 ; i < count ; i++){

        let id = this.overlays[i].sourceElement.id;
//~ console.log(this.overlays[i]);
        //~ if (!this.overlays[i].container_preformat){
            this.overlays[i].sourceElement.classList.toggle('editingOther',false);
            this.overlays[i].sourceElement.classList.toggle('ui_dom_hideTinymceCss',true);

            this.overlays[i].sourceElement.classList.toggle('mce-content-body',false);
            this.overlays[i].sourceElement.classList.toggle('mce-edit-focus',false);
            this.overlays[i].ClearTextSelection();
        //~ }

        if(this.overlays[i] === o){
            let e = tinymce.get(id);

            if(!e){
                let params = pageEditor.tinyParams;
                //~ if (params.toolbar != undefined) {
                    //~ let index = params.toolbar.indexOf('fontsizeselect');
                    //~ let length = 'fontsizeselect'.length;
                    //~ index = index + length;
                    //~ let toolbar1 = params.toolbar.slice(1, index);
                    //~ let toolbar2 = params.toolbar.slice(index+3);

                    //~ delete params.toolbar;
                    //~ params.toolbar1 = toolbar1;
                    //~ params.toolbar2 = toolbar2;
                //~ }

                params.selector = '#'+id;
                params.inline = true;
                params.extended_valid_elements += ' script[src|type|defer]';
                console.log(params.extended_valid_elements);
                params.auto_focus = id;
                params.hidden_input = false;
                params.fixed_toolbar_container = '#'+this.mceToolbarContainer.id;
                params.importcss_append = true;
                params.importcss_selector_filter = '.pppppp';
                params.media_live_embeds = false;
                params.forced_root_block = 'p';
                params.images_reuse_filename = false;
                //~ params.relative_urls = true;
                //~ params.convert_urls = true;
                params.images_upload_handler = AJAX_Class.tinymce_image_upload_handler.bind({action:"tinymceupload",url:params.images_upload_url});

                if (this.overlays[i].sourceElement.dataset.module){
                    var css = CONSTANTS.base_url + 'public/'+ this.overlays[i].sourceElement.dataset.module + '/' + this.overlays[i].sourceElement.dataset.module + '.css';
                    if (params.content_css) params.content_css.push(css);
                    else {
                        params.content_css = [];
                        params.content_css.push(css);
                    }
                }

                params.setup = function(ed){
                    ed.on('init', function(){
                        //this.execCommand("fontSize", false, "1em");
                    });

                    ed.on("blur", function() { return false; });
                };

                tinymce.init(params);


                // TODO :
                // voir ici pour définir des presets de formats customisés
                // https://www.tinymce.com/docs/demo/format-custom/
            }

            this.mceEditing = o;

            o.sourceElement.style.pointerEvents = 'auto';
            // pour contourner les modifs de la class css mce-body-content
            o.sourceElement.style.lineHeight = 'inherit';

            o.sourceElement.classList.toggle('ui_dom_hideTinymceCss',false);
            o.sourceElement.classList.toggle('mce-content-body',true);
            o.sourceElement.classList.toggle('mce-edit-focus',true);

            setTimeout(this.FocusCurrentTextEditor.bind(this),100);
            //this.FocusCurrentTextEditor();

            pageEditor.admin_tools_container.classList.toggle('disabled',true);
        }else{

            let e = tinymce.get(id);
            if(e){
                this.overlays[i].sourceElement.blur();
                if(e.initialized){
                    e.hide();
                }
            }
        }

        if(!o){
            this.overlays[i].Enable();
        }else{
            this.overlays[i].Disable();
        }
    }


    let lst = document.querySelectorAll(".mce-offscreen-selection"); 
    for(let i=0; i<lst.length;i++){
    	lst[i].remove();
    }

    if(GENERICS_Class.IsObject(this.mceEditing)){
        for(let i = 0 ; i < count ; i++){
            //~ if(this.overlays[i] != this.mceEditing && !this.overlays[i].container_preformat){
            if(this.overlays[i] != this.mceEditing){
                this.overlays[i].sourceElement.classList.toggle('editingOther',true);
            }
        }
    }

    setTimeout(this.UpdateHierarchy.bind(this),1000,true);
};

DOM_OVERLAY_Class.prototype.ShowMinWidth = function(){
    this.visibility['min-width'] = true;
    this.UpdateUI();
};
DOM_OVERLAY_Class.prototype.HideMinWidth = function(){
    this.visibility['min-width'] = false;
    this.UpdateUI();
};


DOM_OVERLAY_Class.prototype.UpdateUI = function(){
    let count = this.overlays.length;
    for(let i = 0 ; i < count ; i++){
        this.overlays[i].UpdateUI();
    }
};

function PAGE_Editor_Class_fixUrl(url, node, on_save){
    return url;
}

DOM_OVERLAY_Class.prototype.FocusCurrentTextEditor = function(){
    if(this.mceEditing){
		
        if(!this.mceEditing.mceEditor){
            let id = this.mceEditing.sourceElement.id;
            let e = tinymce.get(id);
            if(e){
                this.mceEditing.mceEditor = e;
            }else{
                debugger;
            }
            //tinymce.execCommand('mceFocus',false,id);
            //tinymce.execCommand("fontSize", false, "1em");
        }

        //~ console.log('FocusCurrentTextEditor initialized=',this.mceEditing.mceEditor.initialized);
        if(this.mceEditing.mceEditor){
        	//~ let main_container = document.getElementById('page_admin_container');
    		//~ pageEditor.mainContainer.classList.toggle('disabled',true);

            if(this.mceEditing.mceEditor.initialized){
                this.mceEditing.sourceElement.style.pointerEvents = 'auto';

                this.mceEditing.mceEditor.show();
                this.mceEditing.sourceElement.focus();
                this.mceEditing.mceEditor.focus();

                this.mceEditing.RestoreTextSelection();

                if(!this.mceEditing.mceEditor._extracted){
                    this.mceEditing.mceEditor._extracted = this.ExtractMceButton();
                }
                //~ pageEditor.mainContainer.classList.toggle('disabled',false);
            }else{
                setTimeout(this.FocusCurrentTextEditor.bind(this),100);
            }
        }else{
            debugger;
        }
    }

    setTimeout(this.UpdateHierarchy.bind(this),1000,true);
};

// Extraction des boutons de tinymce, pour les placer sur une seule ligne
DOM_OVERLAY_Class.prototype.ExtractMceButton = function(){

    let container = this.toolpanel.domElement;

    if(container){
    	//~ let main_container = document.getElementById('page_admin_container');
    	//~ pageEditor.mainContainer.classList.toggle('disabled',true);

        let data = this.RecurseExtractMceButton(container);
        if(data.root && data.btn.length){
            for(let i=0; i<data.btn.length; i++){
                data.body.appendChild(data.btn[i]);
            }

            DOM_Class.SetStyleValue(data.body , 'height' , '');
            DOM_Class.SetStyleValue(data.body , 'width' , '');
            DOM_Class.SetStyleValue(data.body , 'display' , 'inline-block');
            DOM_Class.SetStyleValue(data.body , 'white-space' , 'unset');

            DOM_Class.SetStyleValue(data.root , 'height' , '');
            DOM_Class.SetStyleValue(data.root , 'width' , '');
            DOM_Class.SetStyleValue(data.root , 'display' , 'inline-block');
            DOM_Class.SetStyleValue(data.root , 'white-space' , 'unset');

            setTimeout(function(){pageEditor.mainContainer.classList.toggle('disabled',false);},100);
            return true;
        }
        //~ pageEditor.mainContainer.classList.toggle('disabled',false);
    }

    return false;
};

DOM_OVERLAY_Class.prototype.RecurseExtractMceButton = function(parent){
    let children = parent.childNodes;
    let result = {'root':null , 'body':null , 'btn':[]};

    for(let i=0; i<children.length;i++){
        let child = children[i];
        if(child.nodeType == Node.ELEMENT_NODE){

            if(DOM_Class.GetStyleValue(child,'display') == 'none'){
                continue;
            }

            if(child.classList.contains('mce-panel')){
                result.root = child;
            }

            if(child.classList.contains('mce-container-body')){
                result.body = child;
            }

            if(child.classList.contains('mce-btn') || child.classList.contains('mce-menubtn')){
                result.btn.push(child);
            }else{
                let sub = this.RecurseExtractMceButton(child);
                if(sub.btn.length){
                    result.btn = result.btn.concat(sub.btn);
                }
                if(!result.root && sub.root){
                    result.root = sub.root;
                }

                if(!result.body && sub.body){
                    result.body = sub.body;
                }
            }
        }
    }

    return result;
};

//-----------------------------------------------------------------------------

var DOM_OVERLAY_ITEM_Class = function(domElement , overlayObject){

    this.overlayContainer = overlayObject;
    let parentNode = this.overlayContainer.domElement;

    this.sourceElement = domElement;
    this.sourceElement.style.pointerEvents = 'auto';

    this.sourceElement._overlay = this;
    this.sourceElement.classList.toggle('ui_dom_element',true);
    this.sourceElement.classList.toggle('ui_dom_hideTinymceCss',true);

    this.sourceElement.classList.toggle('editingOther',false);


    let style = DOM_Class.GetStyle(this.sourceElement);

    //min-width par défaut
    if(!this.sourceElement.style.minWidth) DOM_Class.SetStyleValue(this.sourceElement , 'min-width','50px');
    DOM_Class.SetStyleValue(this.sourceElement , 'line-height','unset');


    if(!this.sourceElement.id){
        this.sourceElement.id = this.overlayContainer.moduleName+'_block_'+this.overlayContainer.GetUniqueId();
    }
    
    //~ if (this.sourceElement.dataset.preformat){
        //~ this.preformat = true;
    //~ } else {
        //~ this.preformat = false;
    //~ }
    
    //~ if (this.sourceElement.dataset.container_preformat){
        //~ this.container_preformat = true;
    //~ } else {
        //~ this.container_preformat = false;
    //~ }

    this.domElement = DOM_Class.CreateElement('DIV');
    this.domElement.classList.toggle('ui_overlay_item',true);

    this.domElement.id = 'OVERLAY__'+this.sourceElement.id;

    this.minSizeElement = DOM_Class.CreateElement('DIV');
    this.minSizeElement.classList.toggle('ui_overlay_minsize',true);
    this.domElement.appendChild(this.minSizeElement);


    this.domElement._sourceElement = domElement;

    parentNode.appendChild(this.domElement);

    if(domElement._dragArea){
        this.domElement._dragArea = domElement._dragArea;
    }
    
    //~ if (!this.container_preformat){
        this.texteditor_data = {};
        this.texteditor_data.selection = null;

        this.MatchSourceRect();

        this.Enable();
        this.UpdateControls();
        this.UpdateUI();
        
        if (!this.preformat){
            EVENTS_Class.EnableDrag(this.domElement, this.OnStartDrag.bind(this) , this.OnDrag.bind(this) , this.OnEndDrag.bind(this) );
            EVENTS_Class.EnableResize(this.domElement,null , this.OnResize.bind(this) , this.overlayContainer.OnUpdateHierarchy.bind(this.overlayContainer));
        }

    
        EVENTS_Class.AddEvent(this.domElement , EVENTS_Class.EVENT_MOUSEOVER , this.OnMouseOver.bind(this));
        EVENTS_Class.AddEvent(this.domElement , EVENTS_Class.EVENT_MOUSEOUT , this.OnMouseOut.bind(this));
        EVENTS_Class.AddEventClick(this.domElement, this.OnMouseDown.bind(this));
        EVENTS_Class.AddEventDblClick(this.domElement, this.OnDoubleClick.bind(this));

        this.tools = [];

        let btn = DOM_Class.CreateElement('DIV',{'class':'btn move_left'});
        this.domElement.appendChild(btn);
        EVENTS_Class.AddEventClick(btn, this.MovePrevious.bind(this));

        btn = DOM_Class.CreateElement('DIV',{'class':'btn move_right'});
        this.domElement.appendChild(btn);
        EVENTS_Class.AddEventClick(btn, this.MoveNext.bind(this));

        btn = DOM_Class.CreateElement('DIV',{'class':'btn edit'});
        this.domElement.appendChild(btn);
        EVENTS_Class.AddEventClick(btn, this.EnableTextEditor.bind(this));

        btn = DOM_Class.CreateElement('DIV',{'class':'btn config'});
        this.domElement.appendChild(btn);
        EVENTS_Class.AddEventClick(btn, this.ShowConfiguration.bind(this));
    //~ } else {
        //~ EVENTS_Class.EnableDrag(this.domElement, this.OnStartDrag.bind(this) , this.OnDrag.bind(this) , this.OnEndDrag.bind(this));
        //~ EVENTS_Class.AddEvent(this.domElement , EVENTS_Class.EVENT_MOUSEDOWN , this.OnMouseDown.bind(this));
    //~ }

};
DOM_OVERLAY_ITEM_Class.prototype.constructor = DOM_OVERLAY_ITEM_Class;

DOM_OVERLAY_ITEM_Class.prototype.ShowConfiguration = function(event){
    var self = this;
    
    let data = {};
    data['genanime_action'] = 'genanime_load_prepared';
    
    console.log(this.sourceElement);
    if (this.sourceElement.dataset.animate && this.sourceElement.dataset.animate == 'spanim'){
        data['anim_name'] = this.sourceElement.dataset.anim_name;
    }
    
    if (pageEditor.modalAnimation){
        pageEditor.modalAnimation.Remove();
    }
    
    //~ if (!pageEditor.modalAnimation){
        pageEditor.modalAnimation = UI_Class.AddWindow(pageEditor.mainContainer, {'modal': true, 'close': CONSTANTS.texts['close'], 'hidden': true});
        //~ pageEditor.modalAnimation.domElement.id = 'page_admin_modal_animation';
        let container = DOM_Class.CreateElement('DIV', {'class': 'pageBlock_config_container'});
        // title 
        let title = DOM_Class.CreateElement('DIV', {'class': 'pageBlock_config_title'}, pageEditor.texts['blockConf']);
        container.appendChild(title);
        // lien
        let label = DOM_Class.CreateElement('LABEL', {'for': 'pageBlock_inp_link', 'class':'pageBlock_label_link'}, pageEditor.texts['tools_block_link']);
        let inp = DOM_Class.CreateElement('INPUT', {'id': 'pageBlock_inp_link', 'class': 'pageBlock_input_link'});
        if (this.sourceElement.dataset.blocklink){
			inp.value = this.sourceElement.dataset.blocklink;
		}
        let add = DOM_Class.CreateElement('BUTTON', {'class': 'pageBlock_add_link'}, pageEditor.texts['add']);
        container.appendChild(label);
        container.appendChild(inp);
        container.appendChild(add);
        $_e.AddEventClick(add, function(event){pageEditor.SetBlockProperty('blocklink', event.target.previousElementSibling.value);});
        // background
        //~ let div = DOM_Class.CreateElement('DIV', {'id':'pageBlock_div_background', 'class':'pageBlock_div_background'});
            //~ label = DOM_Class.CreateElement('LABEL', {'for': 'pageBlock_inp_background', 'class':'pageBlock_label_background'}, pageEditor.texts['tools_block_back']);
            //~ inp = DOM_Class.CreateElement('INPUT', {'id': 'pageBlock_inp_background', 'class': 'pageBlock_input_background'});
            //~ add = DOM_Class.CreateElement('BUTTON', {'class': 'pageBlock_add_background'}, pageEditor.texts['add']);
            //~ div.appendChild(label);
            //~ div.appendChild(inp);
            //~ div.appendChild(add);
            //~ $_e.AddEvent(add, 'mousedown', function(event){pageEditor.SetBlockProperty('blockback', event.target.previousElementSibling.value);});
        //~ container.appendChild(div);
        // animation
        let tanim = document.getElementById('genanime_admin_container');
        if (tanim) tanim.parentElement.removeChild(tanim);
        let anim = DOM_Class.CreateElement('DIV', {'id':'genanime_admin_container', 'class':'genanime_admin_container'});
        container.appendChild(anim);
        pageEditor.modalAnimation.SetContent( container );
    //~ }
    
    let settings = {};
    settings.url = document.baseURI.split('?')[0].split('#')[0] + 'genanime/index.php';
    settings.dom_target = 'genanime_admin_container';
    settings.skip_container=true;
    settings.data = data;
    settings.success = function(){
        pageEditor.modalAnimation.Show();
        let sel = document.getElementById('genanime_select_preset');
        if (sel){
            $_e.AddEvent(sel, 'change', self.AddAnimation.bind(self));
        }
    };
    $_a.send(settings);
};

DOM_OVERLAY_ITEM_Class.prototype.AddAnimation = function(event){
    let sel = event.target;
    if (sel.selectedOptions[0].value != ''){
        let name = sel.selectedOptions[0].textContent;
        let opts = JSON.parse(sel.selectedOptions[0].value);
        opts.elements = '#'+this.sourceElement.id;
        opts.preset = true;
        
        this.sourceElement.dataset.animate = 'spanim';
        this.sourceElement.dataset.anim_name = name;
        this.sourceElement.dataset.anim_opts = JSON.stringify(opts);
    } else {
        delete this.sourceElement.dataset.animate;
        delete this.sourceElement.dataset.anim_name;
        delete this.sourceElement.dataset.anim_opts;
    }
};

DOM_OVERLAY_ITEM_Class.prototype.MovePrevious = function(event){
    if(this.sourceElement.previousSibling){
        DOM_Class.InsertBefore(this.sourceElement , this.sourceElement.previousSibling);

        this.overlayContainer.UpdateHierarchy(true);

        this.overlayContainer.SetTextEditor(null);

        this.overlayContainer.SelectOverlay(this);
    }
};

DOM_OVERLAY_ITEM_Class.prototype.MoveNext = function(event){

    if(this.sourceElement.nextSibling){
        DOM_Class.InsertAfter(this.sourceElement , this.sourceElement.nextSibling);

        this.overlayContainer.UpdateHierarchy(true);

        this.overlayContainer.SetTextEditor(null);

        this.overlayContainer.SelectOverlay(this);
    }
};

DOM_OVERLAY_ITEM_Class.prototype.StoreTextSelection = function(){
    // TODO : à revoir plus tard, window.getSelection(); est encore une fonction expérimentale

    /*
    var currSelection = window.getSelection();
    this.texteditor_data.selection = currSelection.rangeCount > 0 ? currSelection.getRangeAt(0):null;

    this.texteditor_data.selection_start = this.texteditor_data.selection.startOffset;
    this.texteditor_data.selection_end = this.texteditor_data.selection.endOffset;

    this.texteditor_data.selection_start_container = this.texteditor_data.selection.startContainer;
    this.texteditor_data.selection_end_container = this.texteditor_data.selection.endContainer;
    */
};

DOM_OVERLAY_ITEM_Class.prototype.RestoreTextSelection = function(){
    /*
    if (window.getSelection) {
        if(GENERICS_Class.IsObject(this.texteditor_data.selection)){
            var currSelection = window.getSelection ();
            currSelection.removeAllRanges ();
            this.texteditor_data.selection.setStart(this.texteditor_data.selection_start_container,this.texteditor_data.selection_start);
            this.texteditor_data.selection.setEnd(this.texteditor_data.selection_end_container,this.texteditor_data.selection_end);
            currSelection.addRange(this.texteditor_data.selection);
        }
    }
    */
};

DOM_OVERLAY_ITEM_Class.prototype.ClearTextSelection = function(){
    /*
    if (window.getSelection){
        window.getSelection().removeAllRanges();
    }
    */
};


DOM_OVERLAY_ITEM_Class.prototype.UpdateControls = function(){
    let style = DOM_Class.GetStyle(this.sourceElement);

    if(style.POS == 'absolute' || style.POS == 'fixed'){
        if(!this._buttonsAdded){
            this._buttonsAdded = true;
            let buttons = ['left','top','right','bottom','center_h','center_v','center'];

            for(let i = 0 ; i < buttons.length ; i++){
                let type = buttons[i];
                let btn = null;
                switch(type){
                    case 'center':
                        btn = new DOM_ICON_Class('center','ui_overlay_btn_center absoluteControl',this);
                        $_e.AddEventClick(btn.domElement, this.Center.bind(this));
                    break;

                    default:
                        btn = new DOM_ICON_Class('edge','ui_overlay_btn_edge absoluteControl',this);
                        btn.domElement.classList.toggle(type,true);
                        $_e.AddEventClick(btn.domElement, this.OnCycleEdgeLock.bind(this));
                    break;
                }
            }
        }
        this.domElement.classList.toggle('relativeControls',false);
        this.domElement.classList.toggle('absoluteControls',true);

    }else if(style.POS == 'relative'){
        this.domElement.classList.toggle('relativeControls',true);
        this.domElement.classList.toggle('absoluteControls',false);
    }
};

DOM_OVERLAY_ITEM_Class.prototype.ProcessCss = function(){
    // force refresh on element styles
    this.style = DOM_Class.GetStyle(this.sourceElement);
};


DOM_OVERLAY_ITEM_Class.prototype.OnDoubleClick = function(event){
//    console.log('DOM_OVERLAY_ITEM_Class.prototype.OnDoubleClick',event);

    if(this.visible && this.enabled && !this.sourceElement.dataset.module){
        EVENTS_Class.StopEvent(event);
        this.EnableTextEditor();
    }

};


DOM_OVERLAY_ITEM_Class.prototype.EnableTextEditor = function(){

    let style = DOM_Class.GetStyle(this.sourceElement);

    if(style.POS == 'relative'){
        this.overlayContainer.SetTextEditor(this);
        this.Hide();
    }

};

DOM_OVERLAY_ITEM_Class.prototype.OnMouseDown = function(event){
//    console.log('DOM_OVERLAY_ITEM_Class.prototype.OnMouseDown',event);

    EVENTS_Class.StopEvent(event);
    
    //~ if (this.container_preformat){
        //~ this.overlayContainer.SetTextEditor(null);

        //~ let count = this.overlayContainer.currentSelection.length;

        //~ for(let i = 0 ; i < count ; i++){
            //~ this.overlayContainer.currentSelection[i].Enable();
            //~ this.overlayContainer.currentSelection[i].Show();
            //~ this.overlayContainer.currentSelection[i].Select();
        //~ }
    //~ } else {
    if(this.overlayContainer.SelectOverlay(this) === 'added'){
        this.overlayContainer.OnSelectionChange();
    }
    //~ }
};

DOM_OVERLAY_ITEM_Class.prototype.OnMouseOver = function(event){
    if(EVENTS_Class.MouseInteracting()){
        return;
    }
    EVENTS_Class.StopEvent(event);

    this.Show();
};

DOM_OVERLAY_ITEM_Class.prototype.OnMouseOut = function(event){
    if(EVENTS_Class.MouseInteracting()){
        return;
    }
    EVENTS_Class.StopEvent(event);

    if(!this.selected){
        this.Hide();
    }
};

DOM_OVERLAY_ITEM_Class.prototype.Select = function(){

    this.Enable();
    this.Show();

    this.domElement.classList.toggle('selected',true);
    this.selected = true;
};

DOM_OVERLAY_ITEM_Class.prototype.Unselect = function(){
    this.domElement.classList.toggle('selected',false);
    this.selected = false;
    this.Hide();
};


DOM_OVERLAY_ITEM_Class.prototype.UpdateUI = function(){
    let style = DOM_Class.GetStyle(this.sourceElement);
    //~ console.log('update UI');
    
    for(let edge in style._snapEdge){
        this.domElement.classList.toggle('lock_'+edge , style._snapEdge[edge] != false);

        for(let u in DOM_CSS_MANAGER_Class.standardUnits){

            let unit = DOM_CSS_MANAGER_Class.standardUnits[u];
            if(unit=='%'){
                unit = 'prct';
            }
            let classname = 'unit_'+edge+'_'+unit;
            let state = style._snapEdge[edge] == DOM_CSS_MANAGER_Class.standardUnits[u];
            this.domElement.classList.toggle(classname,state );
        }

    }

    this.domElement.classList.toggle('lock_center_h' , style._snapCenter.horizontal === true);
    this.domElement.classList.toggle('lock_center_v' , style._snapCenter.vertical === true);

    this.minSizeElement.classList.toggle('hidden',!this.overlayContainer.visibility['min-width']);

};

DOM_OVERLAY_ITEM_Class.prototype.Center = function(event){
    EVENTS_Class.StopEvent(event);

    DOM_Class.SetAlignment(this.sourceElement , 0.5 , 0.5);

    this.MatchSourceRect();
};

DOM_OVERLAY_ITEM_Class.prototype.OnToggleEdgeLock = function(event){
    let btn = event.target;
    let type = null;
    if(btn.classList.contains('left')){
        type = 'left';
    }
    if(btn.classList.contains('top')){
        type = 'top';
    }
    if(btn.classList.contains('right')){
        type = 'right';
    }
    if(btn.classList.contains('bottom')){
        type = 'bottom';
    }

    if(btn.classList.contains('center_h')){
        type = 'center_h';
    }
    if(btn.classList.contains('center_v')){
        type = 'center_v';
    }

    if(type == 'center_h' || type == 'center_v'){

        this.ToggleCentering(type);

    }else if(type){

        this.ToggleEdgeLock(type);
    }
};


DOM_OVERLAY_ITEM_Class.prototype.OnCycleEdgeLock = function(event){
    let btn = event.target;
    let type = null;
    if(btn.classList.contains('left')){
        type = 'left';
    }
    if(btn.classList.contains('top')){
        type = 'top';
    }
    if(btn.classList.contains('right')){
        type = 'right';
    }
    if(btn.classList.contains('bottom')){
        type = 'bottom';
    }

    if(btn.classList.contains('center_h')){
        type = 'center_h';
    }
    if(btn.classList.contains('center_v')){
        type = 'center_v';
    }

    if(type == 'center_h' || type == 'center_v'){

        this.ToggleCentering(type);

    }else if(type){

        this.CycleEdgeLock(type);
    }
};



DOM_OVERLAY_ITEM_Class.prototype.ToggleCentering = function(type){
    let style = DOM_Class.GetStyle(this.sourceElement);

    let state = null;

    switch(type){
        case 'center_h':
            state = !style._snapCenter.horizontal;
            if(!state){
                DOM_Class.UnsetHorizontalPercentagePosition(this.sourceElement);
            }else{
                DOM_Class.SetHorizontalPercentagePosition(this.sourceElement);
            }
        break;

        case 'center_v':
            state = !style._snapCenter.vertical;
            if(!state){
                DOM_Class.UnsetVerticalPercentagePosition(this.sourceElement);
            }else{
                DOM_Class.SetVerticalPercentagePosition(this.sourceElement);
            }
        break;
    }

    this.UpdateUI();

    return state;
};

DOM_OVERLAY_ITEM_Class.prototype.CycleEdgeLock = function(edgeName){
    let state = DOM_Class.CycleSnapAbsolute(this.sourceElement , edgeName);

    this.UpdateUI();

    return state;
};

DOM_OVERLAY_ITEM_Class.prototype.ToggleEdgeLock = function(edgeName){
    let state = DOM_Class.ToggleSnapAbsolute(this.sourceElement , edgeName);

    this.UpdateUI();

    return state;
};


DOM_OVERLAY_ITEM_Class.prototype.Update = function(forceRefresh){

    this.ProcessCss();

    if(this.UpdateParent() || forceRefresh){
        this.MatchSourceRect(forceRefresh);
    }
    this.UpdateControls();
};

DOM_OVERLAY_ITEM_Class.prototype.MatchSourceRect = function(forceRefresh){
    let r = this.sourceElement.getBoundingClientRect();
    //~ let temp = window.getComputedStyle(this.sourceElement);
    //~ console.log(this.sourceElement);
    //~ let r = {
        //~ x: parseFloat(temp.left) + parseFloat(temp.marginLeft),
        //~ y: parseFloat(temp.top) + parseFloat(temp.marginTop)
    //~ };
    //~ console.log(r);
    let t = '';
    let sx = window.scrollX || (((t = document.documentElement) || (t = document.body.parentNode)) && typeof t.ScrollLeft == 'number' ? t : document.body).ScrollLeft || 0;
    let sy = window.scrollY || (((t = document.documentElement) || (t = document.body.parentNode)) && typeof t.ScrollTop == 'number' ? t : document.body).ScrollTop || 0;
    //~ if (pageEditor.mainContainer.scrollTop > 0){
        //~ r.y += pageEditor.mainContainer.scrollTop;
    //~ }
    if (pageEditor.mainContainer._ComputedStyle.POS != 'fixed'){
        r.y += sy;
        r.x += sx;
    } else {
        r.y -= sy;
        r.x -= sx;
    }
    //~ console.log(r);
    
    //~ let parent = this.domElement.parentElement;
    //~ console.log(parent);
    //~ let pr = window.getComputedStyle(parent);
    //~ console.log(pr);
    
    this.domElement.style.position = 'absolute';
    //~ this.domElement.style.left = r.x + 'px';
    //~ this.domElement.style.top = r.y + 'px';
    DOM_Class.SetGlobalLeft(this.domElement , r.x);
    DOM_Class.SetGlobalTop(this.domElement , r.y);
    this.domElement.style.width = (r.width-2) + 'px';
    this.domElement.style.height = (r.height-2) + 'px';

    //~ let r = DOM_Class.GetGlobalRect(this.sourceElement , forceRefresh);
    //~ DOM_Class.SetGlobalRect(this.domElement , r);

    let style = DOM_Class.GetStyle(this.sourceElement);
    
    //~ if(style.POS == 'relative' && !this.preformat){
    if(style.POS == 'relative'){
        DOM_Class.SetStyleValue(this.sourceElement , 'left','');
        DOM_Class.SetStyleValue(this.sourceElement , 'top','');
        DOM_Class.SetStyleValue(this.sourceElement , 'right','');
        DOM_Class.SetStyleValue(this.sourceElement , 'bottom','');
        DOM_Class.SetStyleValue(this.sourceElement , 'height','');
        DOM_Class.SetStyleValue(this.sourceElement , 'word-wrap','break-word');
    }

    let ww = DOM_CSS_MANAGER_Class.ToPx(style.all.getPropertyValue('min-width'),this.sourceElement.parentNode);
    let hh = DOM_CSS_MANAGER_Class.ToPx(style.all.getPropertyValue('min-height'),this.sourceElement.parentNode);

    if(ww > 20 && hh > 20){
        ww += style.PH;
        hh += style.PV;
        this.minSizeElement.classList.toggle('width',true);
        this.minSizeElement.classList.toggle('height',true);
        DOM_Class.SetStyleValue(this.minSizeElement , 'width' , ww+'px');
        DOM_Class.SetStyleValue(this.minSizeElement , 'height' , hh+'px');
    }else{
        if(ww > 20){
            ww += style.PH;
            this.minSizeElement.classList.toggle('width',true);
            this.minSizeElement.classList.toggle('height',false);
            DOM_Class.SetStyleValue(this.minSizeElement , 'width' , ww+'px');
        }

        if(hh > 20){
            hh += style.PV;
            this.minSizeElement.classList.toggle('width',false);
            this.minSizeElement.classList.toggle('height',true);
            DOM_Class.SetStyleValue(this.minSizeElement , 'height' , hh+'px');
        }
    }
};

DOM_OVERLAY_ITEM_Class.prototype.UpdateSourceRect = function(){

    let r = DOM_Class.GetGlobalRect(this.domElement);
    let style = DOM_Class.GetStyle(this.sourceElement);

    if(style.POS == 'relative'){
        DOM_Class.SetStyleValue(this.sourceElement , 'left','');
        DOM_Class.SetStyleValue(this.sourceElement , 'top','');
        DOM_Class.SetStyleValue(this.sourceElement , 'right','');
        DOM_Class.SetStyleValue(this.sourceElement , 'bottom','');
        DOM_Class.SetStyleValue(this.sourceElement , 'height','');
        DOM_Class.SetStyleValue(this.sourceElement , 'word-wrap','break-word');

        DOM_Class.SetGlobalWidth(this.sourceElement , r.width);

        //~ DOM_Class.SetGlobalRect(this.domElement , DOM_Class.GetGlobalRect(this.sourceElement) );
        this.MatchSourceRect(true);
    }else{
        DOM_Class.SetGlobalRect(this.sourceElement , r);
    }

};

DOM_OVERLAY_ITEM_Class.prototype.UpdateParent = function(){
    if(this.sourceElement.parentNode._overlay){
        this.sourceElement.parentNode._overlay.domElement.appendChild(this.domElement);
        return true;
    }
    return false;
};

DOM_OVERLAY_ITEM_Class.prototype.OnShow = function(event){
    if(EVENTS_Class.MouseInteracting()){
        return;
    }
    EVENTS_Class.StopEvent(event);

    this.Show();
};

DOM_OVERLAY_ITEM_Class.prototype.OnHide = function(event){
    if(EVENTS_Class.MouseInteracting()){
        return;
    }
    EVENTS_Class.StopEvent(event);

    this.Hide();
};

DOM_OVERLAY_ITEM_Class.prototype.Show = function(){
    //~ let r = DOM_Class.GetGlobalRect(this.sourceElement);
    //~ DOM_Class.SetGlobalRect(this.domElement , r);

    this.domElement.classList.toggle('ui_outline_pulse',true);
    this._visible = true;
};

DOM_OVERLAY_ITEM_Class.prototype.Hide = function(){
    this.domElement.classList.toggle('ui_outline_pulse',false);
    this._visible = false;
};

Object.defineProperty(DOM_OVERLAY_ITEM_Class.prototype, 'parent', {
    get: function() {
        return this.domElement.parentNode._overlay;
    }
});


Object.defineProperty(DOM_OVERLAY_ITEM_Class.prototype, 'visible', {
    get: function() {
        let o = this;
        let v = o._visible;
        while(!v){
            o = o.parent;
            if(o){
                v = o.visible;
            }else{
                break;
            }
        }
        return v;
    },
    set: function(v){
        if(v){
            this.Show();
        }else{
            this.Hide();
        }
    }
});

Object.defineProperty(DOM_OVERLAY_ITEM_Class.prototype, 'enabled', {
    get: function() {
        let o = this;
        let v = o._enabled;
        while(!v){
            o = o.parent;
            if(o){
                v = o.enabled;
            }else{
                break;
            }
        }
        return v;
    },
    set: function(v){
        if(v){
            this.Enable();
        }else{
            this.Disable();
        }
    }
});


DOM_OVERLAY_ITEM_Class.prototype.Disable = function(){
    //~ if (!this.container_preformat){
        this._enabled = false;
        this.domElement.style.display = 'none';
        this.sourceElement.style.pointerEvents = 'none';
    //~ }
};

DOM_OVERLAY_ITEM_Class.prototype.Enable = function(){
    //~ if (!this.container_preformat){
        this._enabled = true;

        this.domElement.style.display = 'block';
        this.sourceElement.style.pointerEvents = 'auto';
        this.MatchSourceRect(true);
    //~ }
};


DOM_OVERLAY_ITEM_Class.prototype.OnResize = function(event){
    this.UpdateSourceRect();

    EVENTS_Class.BroadcastEvent('widthChange' , [this] , this.overlayContainer);
};

DOM_OVERLAY_ITEM_Class.prototype.OnDrag = function(event){

    if(!this._dragRelativeItem){
        // dragging absolute item
        this.UpdateSourceRect();

    }else{
        // dragging relative item
        let target = DOM_Class.PickElementAt(event.pageX , event.pageY);

        // si on survole un élément qui n'est pas controllé par un overlay, on recherche le parent le plus proche qui en a un
        while(target && !target._overlay){
            target = target.parentNode;
        }

        if(target && target._overlay){

            let style = DOM_Class.GetStyle(target);

            if(target === this.sourceElement.parentNode){
                // over parent node

            }else if(target.parentNode === this.sourceElement.parentNode && this.sourceElement !== target && style.POS == 'relative') {

                let localPos = DOM_Class.GetGlobalToLocal(target , event.pageX , event.pageY , true);

                if(localPos.ratiox > 0.5){
                    DOM_Class.InsertAfter(this.sourceElement , target);
                    DOM_Class.InsertAfter(this.domElement , target._overlay.domElement);
                    //console.log('R',target.id,localPos.ratiox);
                }else{
                    DOM_Class.InsertBefore(this.sourceElement , target);
                    DOM_Class.InsertBefore(this.domElement , target._overlay.domElement);
                    //console.log('L',target.id,localPos.ratiox);
                }


            }else{
                //over same source
            }
        }
    }

};

DOM_OVERLAY_ITEM_Class.prototype.OnStartDrag = function(event){
    let count = this.overlayContainer.overlays.length;
    
    let style = DOM_Class.GetStyle(this.sourceElement);
    this._dragRelativeItem = style.POS !== 'absolute' && style.POS !== 'fixed';

    if(count > 1){
        for(let i = 0; i<count;i++){
            let o = this.overlayContainer.overlays[i];
            if(o !== this){
                o.domElement.style.pointerEvents = 'none';
            }else{ //if(o.sourceElement.style.position=='absolute'){
                //o.sourceElement.style.pointerEvents = 'none';
            }
        }
    }
};

DOM_OVERLAY_ITEM_Class.prototype.OnEndDrag = function(event){
    let count = this.overlayContainer.overlays.length;

    if(!this.selected){
        this.Hide();
    }

    if(count > 1){
        for(let i = 0; i<count;i++){
            let o = this.overlayContainer.overlays[i];
            o.domElement.style.pointerEvents = 'auto';
        }
    }

    this.overlayContainer.UpdateHierarchy(true);

};

//------------------------------

var DOM_ICON_Class = function(action , className , parentObject){

    this.domElement = DOM_Class.CreateElement('DIV');
    this.domElement.className = className;

    this.action = action;

    this.domElement._ui_object = this;

    this.parentObject = null;
    if(parentObject){
        if(parentObject.domElement){
            this.parentObject = parentObject;
            this.parentObject.domElement.appendChild(this.domElement);
        }else{
            parentObject.appendChild(this.domElement);
        }
    }
};
DOM_ICON_Class.prototype.constructor = DOM_ICON_Class;


//------------------------------

var DOM_MULTITOGGLE_Class = function(settings){

	let attributeName = settings.attributeName;
	let items = settings.items;
	let title = settings.title;
	let eventName = settings.eventName;


    let tmp = attributeName.split(':');

    this.changeEventName = eventName || 'changeValue_'+attributeName;

    this.attributeType = tmp[0];
    this.attribute = tmp[1];
    this.attributeName = attributeName;

    let domElement = settings.domElement;

    if(GENERICS_Class.IsString(domElement)){
        domElement = DOM_Class.GetDomElement(domElement);
    }
    if(GENERICS_Class.IsDomObject(domElement)){
        this.domElement = domElement;
        this.domElement.classList.toggle('ui_multitoggle',true);
        this.domElement.innerHTML = '';
    }else{
    	this.domElement = DOM_Class.CreateElement('DIV');
    	this.domElement.className = 'ui_multitoggle';
    }

    this.items = [];

    this.currentItem = null;
    this.currentValue = null;
    this.currentSubValue = null;

    if(title){
        this.domElement.appendChild(DOM_Class.CreateElement('DIV',{'class':'title'},title));
    }

    this.allowed_values = [];

    for(let value in items){
        let label = items[value];

        let item = DOM_Class.CreateElement('DIV',{'class':'ui_singletoggle'});

        item._value = value;
        item.innerHTML = label;

        this.allowed_values.push(value);
        if(value=='percent'){
            this.allowed_values.push('%');
        }
        
        item._multi_toggle = this;

        this.items.push(item);

        this.domElement.appendChild(item);

        EVENTS_Class.AddEventClick(item, this.OnClickSetValue.bind(this));
    }

    this.input = DOM_Class.CreateElement('INPUT',{'class':'ui_multitoggle_input hidden'});
    this.input._multi_toggle = this;

    EVENTS_Class.AddEvent(this.input , 'change' , this.OnInputChange.bind(this));
    EVENTS_Class.AddEventKey(this.input, this.OnInputChange.bind(this));

    this.domElement.appendChild(this.input);

};
DOM_MULTITOGGLE_Class.prototype.constructor = DOM_MULTITOGGLE_Class;

DOM_MULTITOGGLE_Class.prototype.ExtractChildrenTo = function(targetElement){

    let lst = [];
    for(let i = 0 ; i < this.domElement.children.length ; i++){
        if(this.domElement.children[i]._multi_toggle === this){
            lst.push(this.domElement.children[i]);
        }
    }
    for(let i = 0 ; i < lst.length ; i++){
        if(!targetElement){
            DOM_Class.InsertBefore(lst[i] , this.domElement);
        }else{
            targetElement.appendChild(lst[i]);
        }
    }

    this.domElement.remove();
};

DOM_MULTITOGGLE_Class.prototype.OnInputChange = function(event){
    EVENTS_Class.StopEvent(event);

    let input = event.target;
    let newValue = parseFloat(input.value);
    let data = null;

    if(input.value != ''){
        if(isNaN(newValue)) newValue = input._storedValue;
    }else{
        newValue = '';
    }

    switch(this.attributeType){
        case 'var':
            switch(this.attribute){
                case 'width_unit':
                    if(newValue == ''){
                        data = {'css:width':''};
                    }else{
                        switch(this.currentValue){
                            case 'percent':
                                if(newValue > 100) newValue = 100;
                                if(newValue < 0) newValue = 0;
                                
                                // CALC ICI
                                //~ let style = pageEditor.overlay.currentSelection[0].sourceElement;
                                //~ console.log(overlay);
                                //~ let style = window.getComputedStyle(overlay.sourceElement);
                                //~ console.log(style);
                                //~ let padd = overlay.sourceElement.style.paddingLeft;
                                //~ let style = DOM_Class.GetStyle(overlay.sourceElement);
                                //~ let realPad = style.all.paddingLeft;
                                //~ console.log(padd);
                                //~ let t = style.ML + style.MR + style.PL + style.PR;
                                //~ if (t > 0){
                                    //~ newValue = 'calc('+newValue+'% - '+px+'
                                //~ }
                                //~ console.log(style);
                                
                                data = {'css:width':newValue+'%'};
                            break;

                            case 'rem':
                                if(newValue < 0) newValue = 0;
                                data = {'css:width':newValue+'rem'};
                            break;

                            case 'em':
                                if(newValue < 0) newValue = 0;
                                data = {'css:width':newValue+'em'};
                            break;

                            case 'px':
                                if(newValue < 0) newValue = 0;
                                data = {'css:width':newValue+'px'};
                            break;
                        }
                    }
                break;

                case 'minwidth_unit':
                    if(newValue == ''){
                        data = {'css:min-width':''};
                    }else{
                        switch(this.currentValue){
                            case 'percent':
                                if(newValue > 100) newValue = 100;
                                if(newValue < 0) newValue = 0;

                                data = {'css:min-width':newValue+'%'};
                            break;

                            case 'rem':
                                if(newValue < 0) newValue = 0;
                                data = {'css:min-width':newValue+'rem'};
                            break;

                            case 'em':
                                if(newValue < 0) newValue = 0;
                                data = {'css:min-width':newValue+'em'};
                            break;

                            case 'px':
                                if(newValue < 0) newValue = 0;
                                data = {'css:min-width':newValue+'px'};
                            break;
                        }
                    }
                break;
            }
        break;
    }

    input.value = newValue;

    if(data){
        EVENTS_Class.BroadcastEvent(this.changeEventName , data , this);
    }
};

DOM_MULTITOGGLE_Class.prototype.OnClickSetValue = function(event){
    if(EVENTS_Class.MouseInteracting()){
        return;
    }
    EVENTS_Class.StopEvent(event);

    if(this.currentValue === undefined){
        return;
    }else{
        let item = event.target;
        if(item._value !== undefined){
            if(this.SetValue(item._value , this.currentSubValue)){

                let data = {};
                data[this.attributeName] = this.currentValue;
//~ console.log(this.changeEventName);
                EVENTS_Class.BroadcastEvent(this.changeEventName , data , this);
            }
        }
    }
};

DOM_MULTITOGGLE_Class.prototype.SetValue = function(newValue){
    let lst = this.items; //this.domElement.children;

    let changed = this.currentValue != newValue;

    if(changed){
        this.previousValue = this.currentValue;
    }

    this.currentItem = null;
    this.currentValue = undefined;
    this.currentSubValue = undefined;
    
    //~ console.log(newValue);

    for(let i = 0 ; i < lst.length ; i++){
        let item = lst[i];

        if(item._value == newValue){
            this.currentItem = item;
            this.currentValue = item._value;
            this.currentItem.classList.toggle('selected',true);
        }else{
            item.classList.toggle('selected',false);
        }
    }

    //~ this.domElement.classList.toggle('disabled' , this.currentValue === undefined);
    //~ if(this.input.value !== 'undefined'){
    if (newValue == 'percent' || newValue == 'px') this.input.classList.toggle('disabled' , false);
    else this.input.classList.toggle('disabled' , true);
        //~ this.input.classList.toggle('disabled' , newValue != 'px');
    //~ }
    
    //if(this.currentValue === undefined){
    //~ console.log(this);
        for(let i = 0 ; i < lst.length ; i++){
            let item = lst[i];
            //~ console.log(item);
            item.classList.toggle('disabled',this.currentValue === undefined);
        }
    //}

    return changed;
};

DOM_MULTITOGGLE_Class.prototype.OnReceiveValue = function(event){
    if(EVENTS_Class.MouseInteracting()){
        this.UpdateSubValue(event.detail);
        return;
    }
    EVENTS_Class.StopEvent(event);

    let value = undefined;
    let subValue = undefined;

    let source = event.detail;
    let overlay_item = null;

    //~ console.log(event);

    if(GENERICS_Class.IsFilledArray(source)){

        switch(this.attributeType){
            case 'css':
                overlay_item = source[0];
                value = DOM_CSS_MANAGER_Class.ExtractValue(source , this.attributeName);
            break;

            case 'var':
                overlay_item = source[0];
                let style = DOM_Class.GetStyle(overlay_item.sourceElement);

                switch(this.attribute){
                    case 'width_unit':
                    
                        //~ console.log(overlay_item.sourceElement);
                        //~ console.log(style);
                    

                        if(style._width_unit == 'em' || style._width_unit == 'rem'){
                            if(this.allowed_values.indexOf(style._width_unit) > -1){
                                DOM_Class.SetGlobalWidth(overlay_item.sourceElement , style.rect.width);
                            }else{
                                style._width_unit = 'px';
                            }
                        }
                        value = style._width_unit;

                    break;

                    case 'minwidth_unit':

                        if(style._minwidth_unit == 'em' || style._minwidth_unit == 'rem'){

                            if(this.allowed_values.indexOf(style._width_unit) > -1){
                                let mw = DOM_Class.GetStyleValue(overlay_item.sourceElement,'min-width');
                                mw = DOM_CSS_MANAGER_Class.ToPx(mw , overlay_item.sourceElement.parentNode);

                                DOM_Class.SetGlobalMinWidth(overlay_item.sourceElement , mw );
                            }else{

                                style._minwidth_unit = 'px';
                            }
                        }
                        value = style._minwidth_unit;

                    break;

                    case 'align':
                        //~ console.log(style._align);
                        if(style.all.display == 'block'){
                            value = style._align;
                        } else {
                            value = 'sans';
                        }

                    break;
                }
            break;
        }
    }

    let changed = this.SetValue(value);

    if(overlay_item){
        this.UpdateSubValue(overlay_item);
    }
};

DOM_MULTITOGGLE_Class.prototype.UpdateSubValue = function(overlay_item){


    if(GENERICS_Class.IsFilledArray(overlay_item)){
        overlay_item = overlay_item[0];
    }

    if(GENERICS_Class.IsObject(overlay_item)){
        let subValue = undefined;

        switch(this.attributeType){
            case 'css':
            break;

            case 'var':
                let unit;

                switch(this.attribute){
                    case 'width_unit':
                        let val = overlay_item.sourceElement.style.width;
                        //~ console.log(val);
                        if(val && GENERICS_Class.IsCssMeasure(val)){ //} != 'auto' && val != 'max-content' && val){
                            if (val.startsWith('calc(')){
                                val = val.replace('calc(', '').split('%')[0];
                            }
                            subValue = parseFloat(val);
                        }
                        unit = DOM_CSS_MANAGER_Class.ExtractUnit(overlay_item.sourceElement , 'width');
                        if (unit.startsWith('calc(')){
                            unit = unit.replace('calc(', '').split(' ')[0];
                        }
                        //~ console.log(subValue);
                        if(this.allowed_values.indexOf(unit) == -1){
                            subValue = DOM_CSS_MANAGER_Class.ToPx(DOM_Class.GetStyleValue(overlay_item.sourceElement,'width') , overlay_item.sourceElement.parentNode );
                        }
                        //~ console.log(subValue);
                    break;

                    case 'minwidth_unit':
                        subValue = parseFloat(overlay_item.sourceElement.style.minWidth);
                        unit = DOM_CSS_MANAGER_Class.ExtractUnit(overlay_item.sourceElement , 'minWidth');
                        if(this.allowed_values.indexOf(unit) == -1){
                            subValue = DOM_CSS_MANAGER_Class.ToPx(DOM_Class.GetStyleValue(overlay_item.sourceElement,'minWidth') , overlay_item.sourceElement.parentNode );
                        }
                        if(isNaN(subValue)) subValue = 0;
                    break;

                }
            break;
        }

        this.currentSubValue = subValue;
        this.input.value = this.currentSubValue;
        this.input._storedValue = this.currentSubValue;

        this.input.classList.toggle('hidden' , this.currentSubValue === undefined);
    }
};

//------------------------------


var DOM_TOOLPANEL_Class = function(targetOverlay , dragArea){

    this.overlayContainer = targetOverlay;

    this.domElement = DOM_Class.CreateElement('DIV');
    this.domElement.className = 'ui_toolpanel';

    this.overlayContainer.domElement.appendChild(this.domElement);

    this.titleElement = DOM_Class.CreateElement('DIV');
    this.titleElement.className = 'ui_title';
    this.domElement.appendChild(this.titleElement);

    EVENTS_Class.EnableDrag(this.domElement);
    if(dragArea){
        EVENTS_Class.SetDragArea(this.domElement , dragArea , 200);
    }
};
DOM_TOOLPANEL_Class.prototype.constructor = DOM_TOOLPANEL_Class;


DOM_TOOLPANEL_Class.prototype.appendChild = function(child){
    if(child.domElement){
        this.domElement.appendChild(child.domElement);
    }else{
        this.domElement.appendChild(child);
    }
};

DOM_TOOLPANEL_Class.prototype.dock = function(domElement){

    if(!this.free_parent && domElement){
        this.free_parent = this.domElement.parentNode;
        this.free_rect = DOM_Class.GetGlobalRect(this.domElement);
        this.dock = domElement;
        EVENTS_Class.DisableDrag(this.domElement);

    DOM_Class.SetStyleValue(this.domElement , 'left' , '');
    DOM_Class.SetStyleValue(this.domElement , 'top' , '');
    DOM_Class.SetStyleValue(this.domElement , 'width' , '100%');

        domElement.appendChild(this.domElement);
    }

};

DOM_TOOLPANEL_Class.prototype.undock = function(){
    if(this.free_parent){
        this.dock = null;

        //DOM_Class.SetStyleValue(this.domElement , 'position' , 'absolute');
        this.free_parent.appendChild(this.domElement);
        if(this.free_rect){
            DOM_Class.SetGlobalRect(this.domElement,this.free_rect);
        }
        EVENTS_Class.EnableDrag(this.domElement);
    }
};

//------------------------------


var KOLDRON_EDITOR_Class = function(){
    this.totalfilesize = 0;
    this.fileslist = [];

    this.GetWindow();
};
KOLDRON_EDITOR_Class.prototype.constructor = KOLDRON_EDITOR_Class;

KOLDRON_EDITOR_Class.prototype.Show = function(){
    this.window.SetParent(document.body,0.5,0.3);
    this.window.Show();
    this.window.ShowButtons();
    this.progressWindow.Hide();
    this.ClearText();
    
    document.getElementById('koldron_text').focus();
};

KOLDRON_EDITOR_Class.prototype.Hide = function(){
    this.window.Hide();
};

KOLDRON_EDITOR_Class.prototype.FindText = function(){
    let list = this.window.contentDiv.children;

    for(let i=0; i<list.length; i++){
        if(list[i].id == 'koldron_text'){
            this.textarea = list[i];
        }

        if(list[i].id == 'koldron_files_area'){
            this.filesarea = list[i];
        }

        if(list[i].id == 'koldron_messagearea'){
            this.messagearea = list[i];
        }
    }

    list = this.progressWindow.contentDiv.children;
    for(let i=0; i<list.length; i++){
        if(list[i].id == 'koldron_progress'){
            this.progressarea = list[i];
            this.progressbar = DOM_Class.CreateElement('div',{'class':'progressbar'},'',this.progressarea);
            this.progresstext = DOM_Class.CreateElement('div',{'class':'progresstext'},'',this.progressarea);
        }
    }
    
    $_e.AddEvent(this.textarea, 'paste', this.PasteHandler.bind(this));
    //this.textarea.addEventListener("paste", this.PasteHandler.bind(this));
    //window.addEventListener("paste", this.PasteHandler);

    $_e.EnableDrop(this.window.contentDiv.parentNode , this.OnDropFile.bind(this));

};

KOLDRON_EDITOR_Class.prototype.OnDropFile = function(evt) {

    $_e.StopEvent(evt);

    if (evt.dataTransfer){
        let files = evt.dataTransfer.files;

        //~ console.log('file count :',files.length);

        for(let i=0; i<files.length;i++){
            switch(files[i].type){
                case 'text/plain':
                case 'application/rtf':
                case 'application/vnd.oasis.opendocument.text':
                case 'application/vnd.openxmlformats-officedocument.wordprocessingml.document':

                    if(this.fileslist.indexOf(files[i].name) == -1){
                        let txt = document.createElement("div");
                        txt.className = '';
                        txt.innerHTML = files[i].name.split('/').pop();
                        txt._filedata = files[i];

                        this.filesarea.appendChild(txt);

                        this.fileslist.push(files[i].name);
                        this.totalfilesize += files[i].size;
                    }else{
                        console.log('already present');
                    }
                break;

                case 'image/png':
                case 'image/gif':
                case 'image/jpeg':
                case 'image/svg+xml':

                    if(this.fileslist.indexOf(files[i].name) == -1){
                        let img = document.createElement("img");
                        img.src = window.URL.createObjectURL(files[i]);
                        img.width = 80;
                        img.onload = function() {
                            window.URL.revokeObjectURL(this.src);
                        };
                        this.filesarea.appendChild(img);
                        img._filedata = files[i];
                        //~ EVENTS_Class.AddEvent(img , 'click' , this.OnToggleImageGallery.bind(this));

                        this.fileslist.push(files[i].name);
                        this.totalfilesize += files[i].size;
                    }else{
                        console.log('already present');
                    }
                break;

                default:
                    alert('unsupported file');
                break;
            }

        }
    }else{
        console.log('nothing detected');
    }

    this.messagearea.innerHTML = this.fileslist.length + '/' + AJAX_Class.max_file_uploads;
    this.messagearea.innerHTML += ' | '+this.totalfilesize + '/' + AJAX_Class.max_upload_size;
    this.error = false;

    if(this.fileslist.length > AJAX_Class.max_file_uploads){
        this.messagearea.innerHTML += 'too many files';
        this.error = true;
    }

};


KOLDRON_EDITOR_Class.prototype.PasteHandler = function(e) {
    let data =  e.clipboardData || window.clipboardData;
    let txt = data.getData('Text');

    if(!this.textarea){
        this.FindText();
    }

    this.textarea.rawtext = txt;

    setTimeout(this.ParsePastedContent.bind(this) , 100);
};

KOLDRON_EDITOR_Class.prototype.ParsePastedContent = function(){
    if(!this.textarea){
        this.FindText();
    }

    let images = document.querySelectorAll(".koldron_text img");

    for(let i=0; i<images.length; i++){
        let ext = images[i].src.split('/')[images[i].src.split('/').length-1].split('?')[0].split('.')[1];
        //~ console.log(images[i]);
        //~ console.log(images[i].getAttribute('src'));
        console.log(ext);
        if (ext == 'jpg' || ext == 'jpeg' || ext == 'gif' || ext == 'png' || ext == 'svg'){
            images[i].width = 80;
            images[i].removeAttribute('height');
            this.filesarea.appendChild(images[i]);
        }
        
        //~ EVENTS_Class.AddEvent(images[i] , 'click' , this.OnToggleImageGallery.bind(this));
    }

    this.textarea.innerHTML = this.textarea.rawtext;

};

function dataURLtoBlob(dataurl) {
    var arr = dataurl.split(',') , mime = arr[0].match(/:(.*?);/)[1] , bstr = atob(arr[1]) , n = bstr.length , u8arr = new Uint8Array(n);
    while(n--){
        u8arr[n] = bstr.charCodeAt(n);
    }
    return new Blob([u8arr], {type:mime});
}

KOLDRON_EDITOR_Class.prototype.OnToggleImageGallery = function(event){
    event.target.classList.toggle('gallery');
};

KOLDRON_EDITOR_Class.prototype.OnUploadError = function(result,sender){
    debugger;
};


KOLDRON_EDITOR_Class.prototype.GetText = function(){
    if(!this.textarea){
        this.FindText();
    }

    return this.textarea.innerHTML.trim();
};

KOLDRON_EDITOR_Class.prototype.ClearText = function(){
    if(!this.textarea){
        this.FindText();
    }

    this.textarea.innerHTML = '';
    this.filesarea.innerHTML = '';
    this.pasted_images_data = null;
    this.fileslist = [];


    this.progressbar.style.width = 0;
    this.progresstext.innerHTML = '';

    this.messagearea.innerHTML = '';
};

KOLDRON_EDITOR_Class.prototype.GetWindow = function(){
    if(!this.window){
        let settings = {};
        settings.contentClass = 'editable';
        settings.modal = true;
        settings.content ='<div id="koldron_title" class="page_koldron_title">'+pageEditor.texts['koldron_title']+'</div>';
        settings.content+='<div id="koldron_info" class="page_koldron_info">'+pageEditor.texts['koldron_explication']+'</div>';
        settings.content+='<div contenteditable="true" id="koldron_text" name="koldron_text" class="koldron_text" ></div>';
        settings.content+='<div id="koldron_files_area" name="koldron_files_area" class="koldron_files_area" ></div>';
        settings.content+='<div id="koldron_messagearea" name="koldron_files_area" class="koldron_messagearea" ></div>';
        settings.buttons = [];
        settings.buttons.push({'label': pageEditor.texts['ok'], 'handler':this.OnSendData.bind(this) });
        settings.buttons.push({'label': pageEditor.texts['annuler'],'handler':this.OnClose.bind(this)});

        this.window = new UI_PromptWindow(settings);
        this.window.SetParent(document.body,0.5,0.3);

        settings = {};
        settings.modal = true;
        settings.content ='<div id="koldron_progress" name="koldron_progress" class="koldron_progress" ></div>';
        settings.buttons = [];
        settings.buttons.push({'label':pageEditor.texts['annuler'],'handler':this.OnCancelUpload.bind(this)});

        this.progressWindow = new UI_PromptWindow(settings);
        this.progressWindow.SetParent(document.body,0.5,0.3);
    }

    return this.window;
};

KOLDRON_EDITOR_Class.prototype.OnSendData = function(event){
    //~ console.log('Send Koldron');

    let texts = document.querySelectorAll(".koldron_files_area div");

    let data = new FormData();
    data.append('PageAction', 'page_upload_kldimages');

    let textcount = 0;
    let imagecount = 0;

    if(texts.length){
        for(let i = 0; i < texts.length ; i++){
            if(texts[i]._filedata){
                data.append('texts['+i+']', texts[i]._filedata );
                textcount++;
            }
        }
    }

    let images = document.querySelectorAll(".koldron_files_area img");

    if(images.length > 0){

        let index_blob = 0;
        let index_distant = 0;

        let gallery_index = 0;

        for(let i=0; i<images.length; i++){

            let filename = '';

            if(images[i]._filedata){
                filename = images[i]._filedata.name;

                data.append('images['+index_blob+']', images[i]._filedata );
                index_blob++;

            }else if(images[i].src.substr(0,5)=='data:'){
                let p = images[i].src.indexOf('image/')+6;
                let p2 = images[i].src.indexOf(';');
                let ext = images[i].src.substr(p,p2-p);
                filename = 'blobimage'+index_blob+'.'+ext;
                data.append('images['+index_blob+']', dataURLtoBlob(images[i].src) , filename );
                index_blob++;
            }else{
                filename = images[i].src;
                data.append('distantimages['+index_distant+']', filename );
                index_distant++;
            }

            if(images[i].classList.contains('gallery')){
                data.append('gallery['+gallery_index+']',filename);
                gallery_index++;
            }
        }

        imagecount = index_blob+index_distant;
    }

    if(textcount + imagecount > 0 && !this.error){
        //~ console.log(data);
        let settings = {'url':'page/index.php' , 'data':data , 'skip_container':true, 'error':this.OnUploadError.bind(this) , 'success':this.OnContentUploaded.bind(this)};

        settings.up_progress = this.OnUploadProgress.bind(this);
        settings.down_progress = this.OnDownloadProgress.bind(this);

        this.sender = $_a.send(settings);

        this.progressWindow.Show();

    }else{

        if(this.error){
            alert('Files limits reached !');
        }
        this.sender = null;
        this.GenerateBlocs(this.ProcessText(this.GetText()));
    }
};

KOLDRON_EDITOR_Class.prototype.GenerateBlocs = function(texts, images){
    if(!texts){
        texts = [];
    }

    if(!images){
        images = [];
    }

    let big_list = null;
    let small_list = null;

    if(images.length > texts.length){
        big_list = images;
        small_list = texts;
    }else{
        big_list = texts;
        small_list = images;
    }

    let step = Math.round(big_list.length / (small_list.length+1) );

    let step_counter = 0;
    for(let i = 0; i < big_list.length ; i++){
        let o = pageEditor.AddElement();
        o.sourceElement.innerHTML = big_list[i];
        step_counter++;
        if(step_counter == step && small_list.length > 0){
            let o = pageEditor.AddElement();
            o.sourceElement.innerHTML = small_list.shift();
            step_counter = 0;
        }
    }

    while(small_list.length > 0){
        let o = pageEditor.AddElement();
        o.sourceElement.innerHTML = small_list.shift();
    }

    setTimeout(pageEditor.overlay.UpdateHierarchy.bind(pageEditor.overlay),500,true);
};

KOLDRON_EDITOR_Class.prototype.ProcessText = function(txt){

    txt = txt.trim();

    let result = [];

    if(txt){
        txt = STRINGS_Class.EscapeHtml(txt).replace(/\t/g,'');

        let lines = txt.split('\n\n');
        let blocs = [];

        for(let i = 0 ; i < lines.length ; i++){
            let str = lines[i].trim();

            if(str != ''){
                let obj = {'string':str};
                obj.multiline = str.includes('\n');
                blocs.push(obj);
            }
        }

        for(let i = 0 , last_index = blocs.length-1 ; i <= last_index ; i++){
            let obj = blocs[i];
            let next_obj = null;
            let str = '';

            if(i < last_index){
                next_obj = blocs[i+1];
            }

            if(next_obj && !obj.multiline && next_obj.multiline){
                str = obj.string+'\n\n'+next_obj.string;
                i++;
            }else{
                str = obj.string;
            }

            result.push(str.replace(/\n/g,'<br>'));

            /*
            let o = pageEditor.AddElement();
            let bloc = o.sourceElement;
            //bloc.innerText = STRINGS_Class.EscapeHtml(str).replace(/\n/g,'<br>');
            bloc.innerHTML = str.replace(/\n/g,'<br>');
            */

        }
    }

    return result;
};

KOLDRON_EDITOR_Class.prototype.OnContentUploaded = function(result,sender){


    var images = [];
    if(result != ''){
        console.log(result);
        result = JSON.parse(result);
        images = result.images;
    }else{
        return;
    }

    let gallery = [];

    let html_images = [];

    if(GENERICS_Class.IsFilledArray(images)){
        for(let i=0; i < images.length; i++){
            let data = images[i];
            if(data.gallery){
                gallery.push(data.url);
            }else{
                let mediaID = data.identifier+'-'+data.id;
                
                id = 'media_img_'+mediaID;
                src = data.url;

                //let o = pageEditor.AddElement();
                //let bloc = o.sourceElement;
                //bloc.innerHTML = '<img src="../' + data.url + '" id="media_img_'+mediaID+'" border="0" width="100%" data-field_id="'+data.id+'" />';

                html_images.push('<img src="../' + data.url + '" id="media_img_'+mediaID+'" border="0" width="100%" data-field_id="'+data.id+'" data-field_identifier="'+data.identifier+'"/>');
            }
        }
    }

    if(gallery.length > 0){
        for(let i=0; i<gallery.length; i++){
            gallery[i] = '"'+i+'":"'+gallery[i]+'"';
        }

        //let o = pageEditor.AddElement();
        //let bloc = o.sourceElement;
        //bloc.innerHTML = '[galerie|galerie_images={'+gallery.join(',')+'}]';

        html_images.push('[galerie|galerie_images={'+gallery.join(',')+'}]');

    }

    this.GenerateBlocs(this.ProcessText(this.GetText()+'\n\n'+result.text.trim()) , html_images);

    this.progressWindow.Hide();
};

KOLDRON_EDITOR_Class.prototype.OnCancelUpload = function(event , sender){
    //~ console.log('cancel');
    this.sender.Abort();
};

KOLDRON_EDITOR_Class.prototype.OnUploadProgress = function(event , sender){
    //~ console.log(sender.progress , sender.up_progress , sender.files_up_progress );

    p = Math.round(sender.up_progress * 100);

    this.progressbar.style.width = (sender.up_progress*100)+'%';
    this.progresstext.innerHTML = p+'%';

};

KOLDRON_EDITOR_Class.prototype.OnDownloadProgress = function(event , sender){
    //~ console.log(sender.progress , sender.down_progress);

    p = Math.round(sender.down_progress * 100);

    this.progressbar.style.width = (sender.up_progress*100)+'%';
    this.progresstext.innerHTML = p+'%';
};


KOLDRON_EDITOR_Class.prototype.OnClose = function(event){
    //~ console.log('Close Koldron');
};

var Settings = function(){
    var self = this;
    
    this.id_ensemble = false;
    
    var multiple;
    
    this.init = function(types_multiple){
        multiple = types_multiple;
        
        var btn_new = document.getElementById('settings_admin_btn_new');
        $_e.AddEventClick(btn_new,onClickItem);
        
        var lst = Array.from(document.getElementsByClassName('settings_admin_item'));
        
        //~ console.log(lst);
        
        lst.forEach((item)=>{
            $_e.AddEventClick(item, onClickItem);
        });
    };
    
    function onClickItem(evt){
        if (!self.id_ensemble){
            console.error('no ensemble set');
            return false;
        }
        
        let targ = evt.target;
        
        let params = {
            'settings_action':'settings_edit',
            'id_ensemble': self.id_ensemble,
            'id': targ.dataset.id
        };
        UI_Class.openPopupModal(evt,'settings',params);
    }
    
    this.initFormEdit = function(){
        
    };
    
    this.onChangeType = function(evt){
        console.log('change type');
        
        let val = evt.target.selectedOptions[0].value;
        if (val == 'boolean'){
            DOM_Class.AddClass(document.getElementById('settings_admin_block_values'), 'hidden');
            DOM_Class.AddClass(document.getElementById('settings_admin_block_default'), 'hidden');
        } else if (multiple.indexOf(val) > -1){
            DOM_Class.RemoveClass(document.getElementById('settings_admin_block_values'), 'hidden');
            DOM_Class.AddClass(document.getElementById('settings_admin_block_default'), 'hidden');
        } else {
            DOM_Class.AddClass(document.getElementById('settings_admin_block_values'), 'hidden');
            DOM_Class.RemoveClass(document.getElementById('settings_admin_block_default'), 'hidden');
        }
    };
    
    this.onClickAddValue = function(evt){
        
        let parent = document.getElementById('settings_admin_block_values');
        
        // clone seconde elem (first is the head)
        let clone = DOM_Class.CloneDomElement(parent.firstElementChild.nextElementSibling, true);
        console.log(clone);
        let inps = Array.from(clone.getElementsByClassName('settings_admin_inp'));
        inps.forEach((inp)=>{
            if (inp.type == 'checkbox') inp.removeAttribute('checked');
            if (inp.type == 'text') inp.value = '';
        });
        
        DOM_Class.InsertBefore(clone, parent.lastElementChild);
        
    };
    this.onClickDelValue = function(evt){
        
        let parent = document.getElementById('settings_admin_block_values');
        
        let line = evt.target.parentElement;
        if (parent.firstElementChild.nextElementSibling == line && parent.lastElementChild.previousElementSibling == line){
            // do not delete if it's the last element
            console.log('LAST !!! CAN\'T DELETE');
            return false;
        }
        
        DOM_Class.RemoveElement(line);
    };
};

var spd_sett = new Settings();
/*jshint esversion: 6 */
var FieldExtender = function(){
    var self = this;
    
    this.lastKey = 0;
    this.module = '';
    
    var fieldsHided = [];
    
    this.onAddField = function(evt){
        let targetId = 'fieldextender_admin_field_new';
        let domTarget = document.getElementById(targetId);
        if (domTarget.children.length == 0){
            let settings = {};
            settings.url = document.baseURI.split('?')[0].split('#')[0] + 'fieldextender/index.php';
            settings.dom_target = targetId;
            settings.skip_container = true;
            settings.data = {
                'fieldextender_action': 'fieldextender_add',
                'key': this.lastKey,
                'fieldextender-data-module': this.module
            };
            settings.success = function(res){
                let div = DOM_Class.CreateElement('DIV', {'id': 'fieldextender_admin_line_'+self.lastKey, 'class': 'fieldextender_admin_line'});
                DOM_Class.InsertBefore(div, domTarget);
            };
            $_a.send(settings);
        } else console.log(domTarget);
    };
    
    this.onClickDelete = function(evt, id){
        $_e.StopEvent(evt);
        let target = document.getElementById('fieldextender_fieldset_'+id);
        if (!target) target = document.getElementById('fieldextender_sub_value_'+id);
        if (target){
            let settings = {};
            settings.url = document.baseURI.split('?')[0].split('#')[0] + 'fieldextender/index.php';
            settings.dom_target = '';
            settings.skip_container = true;
            settings.data = {
                'fieldextender_action': 'fieldextender_delete',
                'fieldextender-data-id': id
            };
            settings.success = function(res){
                console.log(res);
                DOM_Class.RemoveElement(target.nextElementSibling);
                DOM_Class.RemoveElement(target);
            };
            $_a.send(settings);
        }
    };
    
    this.onChangeType = function(evt, id){
        $_e.StopEvent(evt);
        let targ = document.getElementById('fieldextender_select_type_'+id);
        let selected = targ.selectedOptions[0].value;
        let multiple = document.getElementById('fieldextender_input_multiple_'+id);
        console.log(selected);
        console.log(selected.trim());
        if (selected == 'select' && !multiple.checked){
            console.log('1');
            multiple.checked = true;
        }
        if (selected.trim() != 'select' && selected.trim() != 'radio' && selected.trim() != 'checkbox'){
            console.log('2');
            if (multiple.checked){
                multiple.checked = false;
                //~ $_e.SendEvent(multiple, 'change');
            }
            let labMultiple = multiple.previousElementSibling;
            DOM_Class.ToggleClass(multiple, 'hide', true);
            DOM_Class.ToggleClass(labMultiple, 'hide', true);
        } else {
            console.log('3');
            console.log(selected);
            let labMultiple = multiple.previousElementSibling;
            DOM_Class.ToggleClass(multiple, 'hide', false);
            DOM_Class.ToggleClass(labMultiple, 'hide', false);
            $_e.SendEvent(multiple, 'change');
        }
        if (selected == 'picto'){
            let div_media = document.getElementById('fieldextender_admin_container_imgs_'+id);
            if (div_media){
                DOM_Class.ToggleClass(div_media, 'hide', false);
            }
        } else {
            let div_media = document.getElementById('fieldextender_admin_container_imgs_'+id);
            if (div_media){
                DOM_Class.ToggleClass(div_media, 'hide', true);
            }
        }
    };
    
    this.toggleFields = function(evt, id){
        let targ = evt.target;
        let parent = targ.parentElement;
        if (parent){
            hideFields(parent);
            let id_parent = parent.id;
            if (fieldsHided.indexOf(id_parent) === -1){
                fieldsHided.push(id_parent);
            } else {
                fieldsHided.splice(fieldsHided.indexOf(id_parent), 1);
            }
        }
    };
    
    function hideFields(parent){
        let notHided = Array.from(parent.getElementsByClassName('nothided'));
        for (let i = 0; i < parent.children.length; i++){
            let elem = parent.children[i];
            if (notHided.indexOf(elem) == -1){
                if (elem.tagName != 'LEGEND'){
                    DOM_Class.ToggleClass(elem, 'fieldextender_field_hide');
                }
            }
        }
    }
    
    this.restoreHidedFields = function(){
        if (fieldsHided.length){
            fieldsHided.forEach((id)=>{
                let elem = document.getElementById(id);
                hideFields(elem);
            });
        } else {
            let list = document.getElementsByClassName('fieldextender_admin_fieldset');
            for (let i = 0; i < list.length; i++){
                fieldsHided.push(list[i].id);
                hideFields(list[i]);
            }
        }
    };
    
    this.onChangePicto = function(evt, id){
        let targ = evt.target;
        let next = evt.target.nextElementSibling;
        if (targ.checked){
            console.log('checked!');
            next.checked = false;
            console.log(targ);
            console.log(next);
        } else {
            console.log('not checked!');
            next.checked = true;
            console.log(targ);
            console.log(next);
        }
    };
    
    this.afterSave = function(){
        let divNew = document.getElementById('fieldextender_admin_field_new');
        while(divNew.firstChild){
            divNew.removeChild(divNew.firstChild);
        }
        this.lastKey++;
    };
    
    this.removeField = function(key){
        if (key){
            let elem = document.getElementById('fieldextender_admin_line_'+key);
            console.log(elem.nextElementSibling);
            DOM_Class.RemoveElement(elem.nextElementSibling);
            DOM_Class.RemoveElement(elem);
            
            checkKeyValue();
        }
    };
    
    function checkKeyValue(){
        let parent = document.getElementById('fieldextender_admin_subcontainer_form');
        let list = parent.getElementsByClassName('fieldextender_admin_line');
        if (list){
            this.lastKey = list.length - 1;
        } else {
            this.lastKey = 0;
        }
    }
    
    this.showPreview = function(){
        this.prev = document.getElementById('fieldextender_admin_preview');
        if (this.prev){
            DOM_Class.ToggleClass(this.prev, 'hide', false);
            $_e.AddEvent(window, 'scroll', followScroll);
        }
    };
    function followScroll(evt){
        if (self.prev){
            let sy = evt.pageY;
            if (sy >= 274) {
                DOM_Class.ToggleClass(self.prev, 'fixed', true);
            } else {
                DOM_Class.ToggleClass(self.prev, 'fixed', false);
            }
        }
    }
    
    this.showHelp = function(evt){
        
    };
    
    this.addValue = function(evt, id_parent){
        $_e.StopEvent(evt);
        let targ = evt.target;
        
        if (id_parent){
            console.log(id_parent);
            let settings = {};
            settings.url = document.baseURI.split('?')[0].split('#')[0] + 'fieldextender/index.php';
            settings.dom_target = 'fieldextender_container_multiple_value';
            settings.skip_container = true;
            settings.data = {
                'fieldextender_action': 'fieldextender_add',
                'fieldextender-data-id_parent': id_parent,
                'fieldextender-data-module': self.module
            };
            settings.success = function(res){
                $_v.parseFields(targ.form);
            };
            $_a.send(settings);
        }
    };
    
    this.onChangeMultiple = function(evt){
        let targ;
        if (GENERICS_Class.IsString(evt)){
            targ = document.getElementById(evt).nextElementSibling;
        } else {
            targ = evt.target;
        }
        //~ console.log(targ);
        let id = targ.dataset.id;
        let lab_value = targ.parentElement.nextElementSibling;
        let inp_value = lab_value.nextElementSibling.firstElementChild;
        let btn_add = document.getElementById('fieldextender_admin_btn_add_value_'+id);
        let container_values = document.getElementById('fieldextender_container_multiple_value_'+id);
        console.log(targ);
        console.log(btn_add);
        console.log(container_values);
        if (lab_value && inp_value && btn_add) {
            DOM_Class.ToggleClass(lab_value, 'hide');
            DOM_Class.ToggleClass(inp_value, 'hide');
            DOM_Class.ToggleClass(btn_add, 'hide');
            DOM_Class.ToggleClass(container_values, 'hide');
        }
    };
    
    this.onSaveField = function(evt){
        let form = evt.target.form;
        console.log(form);
        let data = {};
        for (let i = 0; i < form.length; i++){
            
        }
    };
};
var spd2_fdExtend = new FieldExtender();
/*jshint esversion: 6 */
function alert(){
  var interval = false;
  this.initWidget = function(){
        if (!interval){
            interval = setInterval(()=>{
                RefreshAlert();
            }, 60000);
        }
    };
    
   function RefreshAlert(){
        
        let settings = {};
        settings.url = document.baseURI.split('?')[0].split('#')[0] + 'alert/index.php';
        settings.dom_target = 'alert_widget';
        settings.skip_container = true;
        settings.notimer = true;
        settings.data = {
            'alert_action': 'alert_widget'
        };
        
        $_a.send(settings);
    }
    
}
var spd3_alert = new alert();
var spatimeout = function(call,time,timed=0){
    try{
        eval(call);
    } catch(e){
        timed++;
        if (timed<3){
            setTimeout(spatimeout , time , call, time, timed);
        }
    }
};
//ajax.js
//------------------------------
var $_a = new AJAX_Class();

//events.js
//------------------------------
var $_e = EVENTS_Class;
$_e.Init(); 

//validator.js
//------------------------------
$_v = new VALIDATOR_Class();

//detect_hash in history.js
//------------------------------
$_e.AddLoadHandler(detect_hash); 
//~ $_e.AddEvent(window,'hashchange',detect_hash);
window.onhashchange = function(evt){
    //~ console.log(evt);
    detect_hash();
};
//~ window.onpopstate = function(evt){
    //~ console.log(evt);
    //~ console.log('popstate');
    //~ return false;
    //~ detect_hash();
//~ }

//initialvar for VerticalRatio based on FHD size
var fhdVR=1;
//update root css var on load, detect_screen_infos is in ui.js
$_e.AddLoadHandler(detect_screen_infos); 
//should update fhdVR and some root css vars on resize , still in ui.js
$_e.AddResizeHandler(updateCssfhdvr); 
