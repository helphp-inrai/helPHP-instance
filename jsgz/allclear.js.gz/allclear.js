﻿/**
 * COPYRIGHT M666 2009-2022 LEFT-ANGLE 2022
 * ALL RIGHTS RESERVED
 */
 /*jshint esversion: 6 */
var GENERICS_Class = function(){
    this._eventHandlers = {};
};
GENERICS_Class.prototype.constructor = GENERICS_Class;
//~ class GENERICS_Class{
    //~ constructor() {
        //~ this._eventHandlers = {};
    //~ }
//~ }

GENERICS_Class.debug = false;
GENERICS_Class.uniqueId = 0;

GENERICS_Class.CopyObject = function(a,b){
    let keys = Object.keys(a);
    for(let k = 0 ; k < keys.length ; k++){
        b[keys[k]] = a[keys[k]];
    }
};

GENERICS_Class.GetUniqueId = function(){
    return GENERICS_Class.uniqueId++;
};

GENERICS_Class.IsObject = function(a){
    if(!a){
        return false;
    }
    return typeof(a) == 'object';
};

GENERICS_Class.IsEmpty = function(a){
    if(!a) return true;
    if(GENERICS_Class.IsArray(a) && a.length == 0) return true;
    if(GENERICS_Class.IsObject(a) && !GENERICS_Class.IsFilledObject(a) ) return true;

    return false;
};

GENERICS_Class.IsDomObject = function(a){
    if(!a){
        return false;
    }
    if(typeof(a) == 'object'){
        return a.nodeType?true:false;
    }

    return false;
};

GENERICS_Class.IsFormdata = function(a){
    return Object.prototype.toString.apply(a) === '[object FormData]';
};

GENERICS_Class.IsString = function(a){
    return typeof(a) == 'string';
};

GENERICS_Class.IsFunction = function(a){
    let t = typeof(a);
    return t == 'function';
};

GENERICS_Class.IsProperty = function(a){
    return (typeof(a) != "function" && a !== null && a !== undefined);
};

GENERICS_Class.IsArray = function(a){
    return Object.prototype.toString.apply(a) === '[object Array]';
};

GENERICS_Class.IsEvent = function(a){
    return Object.prototype.toString.apply(a).indexOf('Event]') > 0;
};

GENERICS_Class.IsFilledArray = function(a){
    if(Object.prototype.toString.apply(a) === '[object Array]'){
        return a.length;
    }
    return false;
};

GENERICS_Class.IsFilledObject = function(a){
    if(GENERICS_Class.IsObject(a)){
        return Object.keys(a).length;
    }
    return false;
};

GENERICS_Class.IsUndefined = function(a){
    return a === undefined;
};

GENERICS_Class.IsNumeric = function(a){
    return !isNaN(a);
};
//only for page.js
GENERICS_Class.IsCssMeasure = function(str){
    let f = parseFloat(str);
    if(isNaN(f)){
        for(let i = 0 ; i < str.length ; i++){
            let o = str.charCodeAt(i);
            if(o >= 48 && o <= 57 || o == 46){
                str = str.substr(i,str.len);
                break;
            }
        }
        if(str==''){
            return false;
        }
        f = parseFloat(str);
        if(isNaN(f)){
            return false;
        }
    }
    return true;
};

GENERICS_Class.GetType = function(a){
    let str = Object.prototype.toString.apply(a).split(' ');
    return str[1].substr(0,str[1].length-1);
};

GENERICS_Class.MergeObjects = function(a,b){
    let result = {};
    if(!a){
        a = {};
    }

    if(!b){
        b = {};
    }
    let keys = Object.keys(a);

    for(let i = 0 ; i < keys.length ; i++){
        result[keys[i]] = a[keys[i]];
    }

    keys = Object.keys(b);

    for(let i = 0 ; i < keys.length ; i++){
        result[keys[i]] = b[keys[i]];
    }

    return result;
};

//----------------------------------------------------------------------------------
// STRINGS
var STRINGS_Class = function(){
    this._eventHandlers = {};
};
STRINGS_Class.prototype.constructor = STRINGS_Class;
//~ class STRINGS_Class{
    //~ constructor() {
        //~ this._eventHandlers = {};
    //~ }
//~ }
STRINGS_Class.dom_parser = null;
STRINGS_Class.xml_http = null;

STRINGS_Class.CompleteString = function(str , replace_array){
    if(replace_array){
        if(!GENERICS_Class.IsArray(replace_array)){
            replace_array = [replace_array];
        }
        if(GENERICS_Class.IsFilledArray(replace_array)){
            for(let i=0; i<replace_array.length; i++){
                str = str.replace('$'+i,replace_array[i]);
            }
        }
    }

    return str;
};

STRINGS_Class.EscapeHtml = function(text){
  var map = {
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#039;'
  };

  return text.replace(/[<>"']/g, function(m) { return map[m]; });
};

String.prototype.hashCode = function() {
    var hash = 0, i, chr;
    if (this.length === 0) return hash;
    for (i = 0; i < this.length; i++) {
      chr = this.charCodeAt(i);
      hash = ((hash << 5) - hash) + chr;
      hash |= 0; // Convert to 32bit integer
    }
    return hash;
  };
//--------------------------------------------------------------------------
// MATH
//CLASSE TOTALEMENT INUTILSEE NUL PART POUR LE MOMENT !!! Wtf ?
var MATH_Class = function(){
    this._eventHandlers = {};
};
MATH_Class.prototype.constructor = MATH_Class;
//~ class MATH_Class{
    //~ constructor() {
        //~ this._eventHandlers = {};
    //~ }
//~ }

MATH_Class.ExtractFloat = function(str){
    let f = parseFloat(str);
    if(isNaN(f)){
        for(let i = 0 ; i < str.length ; i++){
            let o = str.charCodeAt(i);
            if(o >= 48 && o <= 57 || o == 46){
                str = str.substr(i,str.len);
                break;
            }
        }
        f = parseFloat(str);
        if(isNaN(f)){
            return 0.0;
        }
    }
    return f;
};

MATH_Class.ExtractInt = function(str){
    let f = parseInt(str);
    if(isNaN(f)){
        for(let i = 0 ; i < str.length ; i++){
            let o = str.charCodeAt(i);
            if(o >= 48 && o <= 57){
                str = str.substr(i,str.len);
                break;
            }
        }
        f = parseInt(str);
        if(isNaN(f)){
            return 0;
        }
    }
    return f;
};

MATH_Class.IsRound = function(a){
    if(isNaN(a)){
        return false;
    }else{
        return Math.round(a) == a;
    }
    return false;
};

// nombre impair
MATH_Class.IsOdd = function(a){
    if(isNaN(a)){
        return NaN;
    }else{
        return a%2>0;
    }
};

// nombre pair
MATH_Class.IsEven = function(a){
    if(isNaN(a)){
        return NaN;
    }else{
        return a%2 === 0;
    }
};

MATH_Class.RoundFloat = function(fl,rn){
    if(!rn){
        rn = 8;
    }
    rn = Math.pow(10,rn);
    return Math.round(fl*rn)/rn;
};
/*
function Storage_access_check(){
    // if (!!document.hasStorageAccess) {
        
    //     // setTimeout(function(){
    //         document.hasStorageAccess().then(result => {
    //             if (!result) {
    //                 console.log("nostaorageaccess");
    //                 // Show the button and tie to the click.
    //                 var requestStorageAccessButton = document.getElementById('requestStorageAccessButton');
    //                 if(requestStorageAccessButton==undefined || requestStorageAccessButton==null){
    //                     requestStorageAccessButton = DOM_Class.CreateElement('BUTTON',{'class':'artiviewer_markerdel', 'id':'artrequestStorageAccessButton'},'Allow local storage access');
    //                     let artihome_exist=document.getElementById('artihome_container');
    //                     if (artihome_exist!=undefined) {
    //                         artihome_exist.appendChild(requestStorageAccessButton);
    //                     }else{
    //                         document.getElementById('lemain').appendChild(requestStorageAccessButton);
    //                     }
    //                 }
    //                 requestStorageAccessButton.style.display = "block";
    //                 requestStorageAccessButton.addEventListener("click", event => {
        
    //                     // On UI event, consume the event by requesting access.
    //                     document.requestStorageAccess().then(result => {
        
    //                         // Finally, we are allowed! Reload to get the cookie.
    //                         window.location.reload();
    //                     }).catch(err => {
        
    //                         // notgood
    //                     });
    //                 });
    //             }else{
    //                 console.log('storageaccessok');
    //             }
    //         }).catch(err => console.error(err));
        // },500);
    // }
    var is_safari = navigator.userAgent.indexOf("Safari") > -1;
    var is_chrome = navigator.userAgent.indexOf("Chrome") > -1;
    if ((!is_chrome) && (is_safari)){
        // if (document.hasStorageAccess()){
        //     console.log('hasStorageAccess', "granted");
        // } else {
        //     var storageModal = new UI_Window({'modal': true, 'disableBackgroundClick': true, 'nodrag': true, 'disableKeydownClose': true});
        //     var btn = DOM_Class.CreateElement('BUTTON',{ 'id':'artrequestStorageAccessButton'},'Storage Access Request');
        //     storageModal.SetContent(btn);
        //     storageModal.SetParent(document.body, 0.5, 0.5);
        //     $_e.AddEventClick(btn, function(){
        //         document.requestStorageAccess().then(
        //             function() {
        //                 console.log("requestStorageAccess", "granted");
        //                 storageModal.Remove();
        //             },
        //             function() {
        //                 console.log("requestStorageAccess", "rejected");
        //                 top.window.location.reload();
        //             }
        //         );
        //     });

            
            // var butnewtab = document.getElementById('artihome_safari_open');
            // if(butnewtab==undefined || butnewtab==null){
            //     butnewtab = DOM_Class.CreateElement('BUTTON',{ 'id':'artrequestStorageAccessButton'},'Open in new tab');
            //     let artihome_exist=document.getElementById('artihome_container');
            //     if (artihome_exist!=undefined) {
            //         artihome_exist.appendChild(requestStorageAccessButton);
            //     }else{
            //         document.getElementById('lemain').appendChild(butnewtab);
            //     }
            // }
            // document.getElementById('artihome_safari_msg').style.display = "block";
            // butnewtab.style.display = "block";
            // butnewtab.addEventListener("click", event => {
            //     window.open(document.location,'_blank');
            // });
            // console.log('hasStorageAccess', "rejected");
            // document.requestStorageAccess().then(
                // function() {
                    // console.log("requestStorageAccess", "granted");
                // },
                // function() {
                    // console.log("requestStorageAccess", "rejected");
                // }
            // );
        // }
        var butnewtab = document.getElementById('artihome_safari_open');
        if(butnewtab==undefined || butnewtab==null){
            butnewtab = DOM_Class.CreateElement('BUTTON',{ 'id':'artrequestStorageAccessButton'},'Open in new tab');
            let artihome_exist=document.getElementById('artihome_container');
            if (artihome_exist!=undefined) {
                artihome_exist.appendChild(requestStorageAccessButton);
            }else{
                document.getElementById('lemain').appendChild(butnewtab);
            }
        }
        document.getElementById('artihome_safari_msg').style.display = "block";
        butnewtab.style.display = "block";
        butnewtab.addEventListener("click", event => {
            window.open(document.location,'_blank');
        });
    }
}
*/
//AUTOGRAPH SECTION
var qTw='nope';
var qTwA='nope';
var qtwAl=[];
var qtwAlc=[];

function dlLinkScrambler (mode){
    links = document.querySelectorAll('[data-scram]');
    if (mode=="kill"){
        for (let i = 0; i < links.length; i++){
            let link = links[i];
            link.href="#connection=true";
            link.classList.add("pleaseconnect");
            link.innerHTML="Please sign in to access this link.";
        }
    }else{
        for (let i = 0; i < links.length; i++){
            let link = links[i];
            let command=link.dataset.scram;
            let hash=link.href.hashCode();
            if (qtwAl[hash]==undefined){
                qtwAl[hash]=link.href;
            }
            link.href=hash;
            link.addEventListener('click', function (e) {e.preventDefault();});
            if (mode=="auto"){
                if (qtwAlc[hash]==undefined){
                    qtwAlc[hash]=command;
                }
                $_e.AddEventClick(link,qtSender);
            }else{
                $_e.AddEventClick(link,extOpener);
            }
            
        }
    }
}

function qtSender(event){
    let hash=event.target.href;
    hash=hash.split('/').pop();
    if (qtwAlc[hash]!=undefined && qtwAl[hash]!=undefined){
        let json='{\"command\":\"'+qtwAlc[hash]+'\",\"params\":{\"url\":\"'+qtwAl[hash]+'\"}}';
        if (qTwA!=undefined && qTwA!='nope'){
            qTwA.entryPoint(json,false);
        }else{
            console.log('qTwA not connected'); 
        }
    }else{
        console.log('hash part not found');
    }
   
}

function extOpener(event){
    let hash=event.target.href;
    hash=hash.split('/').pop();
    if (qtwAl[hash]!=undefined){
        window.open(qtwAl[hash],'_blank').focus();
    }else{
        console.log('hash part not found');
    }
    
}

function desactiveContextMenu(elem){
    elem.oncontextmenu = function(){return false;};
    if (elem.children.length > 0){
        for (let index = 0; index < elem.children.length; index++) {
            desactiveContextMenu(elem.children[index]);
        }
    }

}
// memo on file upload : https://developer.mozilla.org/en-US/docs/Using_files_from_web_applications

// AJAX Class declaration
var AJAX_Class = function(){
    this.xhr_list = [];
    this._up_loaded_bytes = 0;
    this._up_total_bytes = 0;

    this._down_loaded_bytes = 0;
    this._down_total_bytes = 0;

    // if the total size is unknow, these values will contains the upload/download bytes values
    this._up_overload = 0;
    this._down_overload = 0;

    this._up_speed = 0;
    this._down_speed = 0;

    this._consecutive_streams = 10; // how many simultaneous ajax streams are allowed at the same time
    this._busy_stream_count = 0;
    this._running_stream_count = 0;

    this._stream_queue = [];
    // different queue for sending chunk faster
    //~ this._files_queue = [];

    this._last_data_time = 0;

    this._debug = false;
    
    this.timer_modal = false;
    this.timer_modal_is_hide = true;
};
AJAX_Class.prototype.constructor = AJAX_Class;

// these two variables have to be update by PHP script to reflect server the configuration
AJAX_Class.max_upload_size = CONSTANTS.max_upload_size; // max file upload size
AJAX_Class.max_file_uploads = CONSTANTS.max_file_uploads; // max number of simultaneous file uploads

// variable used in conjunction with the PHP AJAX_Class to identify json variables
AJAX_Class.json_list_identifier = CONSTANTS.json_list_identifier; //'_AJAX_json_decode_list';

AJAX_Class.JSON_OFF = 0; // json data stay as strings
AJAX_Class.JSON_ON = 1; // json data are converted to objetcs and arrays
AJAX_Class.JSON_ARRAY = 2; // json data are converted, and objects are converted to associative arrays

//~ AJAX_Class.setFormSubmitter = function(submitDomElement){

    //~ if(submitDomElement.form){
        //~ submitDomElement.form._submitter = submitDomElement;
    //~ }else{
        //~ return false;
    //~ }
    //~ return true;
//~ };
//convert a form as json string...
AJAX_Class.formToObj = function( form ) {
    var obj = {};
    var elements = form.querySelectorAll( "input, select, textarea" );
    for( var i = 0; i < elements.length; ++i ) {
        let element = elements[i];
        let name = element.name;
        let value = element.value;
        let tag_type = element.type.toLowerCase();
        if( name ) {
            if( tag_type == "checkbox" || tag_type == "radio"){
                if(element.checked){
                    obj[ name ] = value;
                }

            }else {
                obj[ name ] = value;
            }
        }
    }

    return obj;
};

AJAX_Class.submitOnChange = function(selectDomElement){

    if(selectDomElement.form){
        selectDomElement.form._submitter = selectDomElement;
        EVENTS_Class.SendEvent(selectDomElement.form , 'submit');
    }else{
        return false;
    }
    return true;
};

// convert a raw bytes length into a human readable string
AJAX_Class.readableFileSize = function(size){
    let cnt = 0;
    let units = ['bytes','KB','MB','GB','TB'];
    while(size > 1024 && cnt < units.length-1){
        size /= 1024;
        cnt ++;
    }
    return size.toFixed(2)+' '+units[cnt];
};

// check if the FILE inputs respect the server limitations
AJAX_Class.checkFileData = function(domElement){
    var lst = [];
    
    if(GENERICS_Class.IsFormdata(domElement)){
        if(domElement.entries){
            let data = domElement.entries();
            let obj = data.next();
            while(undefined !== obj.value) {
                let t = Object.prototype.toString.apply(obj.value[1]);
                if(t == '[object File]'){
                    lst.push(obj.value[1]);
                }
                obj = data.next();
            }
        }else{
            console.log('Formdata.entries not supported !');
        }

    }else if(GENERICS_Class.IsDomObject(domElement)){
        
        if (domElement.tagName == 'INPUT' && domElement.type == 'file' && domElement.files){
            // if the given dom element is a FILE input, get its files
            lst = domElement.files;

        }else if(domElement.tagName == 'FORM'){
            // if the given dom element is a FORM, get all the files from the FILE inputs inside this form
            let elements = domElement.elements;

            for(let i = 0; i < elements.length ; i++){
                if(elements[i].type == 'file'){
                    for(let f = 0; f < elements[i].files.length ; f++){
                        lst.push(elements[i].files[f]);
                    }
                }
            }
        }
    }

    let count = lst.length;
    let size = 0;
    for(let i = 0 ; i < count ;i++){
        size += lst[i].size;
    }
    let message = '';
    if(count > AJAX_Class.max_file_uploads){
        message += CONSTANTS.GetText('too_many_files' , [count,AJAX_Class.max_file_uploads]); //'Too many files ('+count+')! Max = '+AJAX_Class.max_file_uploads;
    }
    if(size > AJAX_Class.max_upload_size){
        message += CONSTANTS.GetText('too_heavy_files' , [AJAX_Class.readableFileSize(size),AJAX_Class.readableFileSize(AJAX_Class.max_upload_size)] ); //'Files are too heavy ('+AJAX_Class.readableFileSize(size)+')! Max = '+AJAX_Class.readableFileSize(AJAX_Class.max_upload_size);
    }

    if(message !== ''){
        UI_Class.MessagePopup(message);
        return false;
    }else{
        return true;
    }
};

//~ AJAX_Class.cancelUpload = function(jsonData){
    //~ let obj = JSON.parse(jsonData);
    //~ obj.cancelFile();
//~ };

AJAX_Class.quick_edit_check = function(event){

    if(event.keyCode == 13){
        EVENTS_Class.StopEvent(event);

        AJAX_Class.quick_edit_send({'target':event.target,'action':'save'});
    }

    if(event.keyCode == 27){
        EVENTS_Class.StopEvent(event);

        AJAX_Class.quick_edit_send({'target':event.target,'action':'cancel'});
    }
};

AJAX_Class.quick_edit_send = function(event){

    let action = '';
    let targetTag = null;
    let field_ID = '';
    let id_lang_data = null;

    if(!GENERICS_Class.IsEvent(event)){
        targetTag = event.target.parentNode;
        action = event.action;
        field_ID = event.target.getAttribute('id');
    }else{
        EVENTS_Class.StopEvent(event);
        let buttonTag = event.target;
        action = buttonTag.getAttribute('value');
        targetTag = buttonTag.parentNode;
        field_ID = buttonTag.getAttribute('data-'+CONSTANTS.quick_edit_field);
    }

    let value_field = document.getElementById(field_ID);

    if(action == 'cancel'){
        if(targetTag._quick_edit_initial_value !== undefined){
            targetTag.innerHTML = targetTag._quick_edit_initial_value;
            delete(targetTag._quick_edit_initial_value);
            return;
        }
    }

    if(!$_v.checkField(value_field)){
        alert(CONSTANTS.GetText('error')+' : '+value_field._validatorIcon.getAttribute('title'));
        value_field.focus();
        return false;
    }

    let data = value_field.getAttribute('data-'+CONSTANTS.quick_edit_data);
    id_lang_data = value_field.getAttribute('data-id_lang_data');

    let dataTag = null;
    if(!data){
        dataTag = value_field.parentNode;
        let loops = 0;
        while(!data && dataTag && loops < 1000){
            data = dataTag.getAttribute('data-'+CONSTANTS.quick_edit_data);
            if(!data){
                dataTag = dataTag.parentNode;
            }
            loops++;
        }
    }

    if(!data){
        return false;
    }

    let id = value_field.getAttribute('data-'+CONSTANTS.quick_edit_id);
    let type = value_field.getAttribute('data-'+CONSTANTS.quick_edit_type);

    let sender = $_a.getSender();
    let settings = {};
    settings.url = dataTag.getAttribute('action');

    settings.data = {'quick_edit':action , 'id':id , 'type':type , 'data':data , 'value':value_field.value , 'id_lang_data':id_lang_data};

    settings.success = function(responseText , ajaxSender){

        if(responseText == 'ERROR!'){
            if(targetTag._quick_edit_initial_value !== undefined){
                targetTag.innerHTML = targetTag._quick_edit_initial_value;
            }
            console.warn('Error in quick edit !');
        }else{
            targetTag.innerHTML = responseText;
        }

        delete(targetTag._quick_edit_initial_value);
    };

    settings.error = function(event){
        debugger;
    };
    sender.setData(settings);
    sender.send();

};

AJAX_Class.quick_edit = function(targetTag){

    if(targetTag._quick_edit_initial_value !== undefined){
        return false;
    }


    let data = targetTag.getAttribute('data-'+CONSTANTS.quick_edit_data);
    let dataTag = null;
    if(!data){
        dataTag = targetTag.parentNode;
        let loops = 0;
        while(!data && dataTag && loops < 1000){
            data = dataTag.getAttribute('data-'+CONSTANTS.quick_edit_data);
            if(!data){
                dataTag = dataTag.parentNode;
            }
            loops++;
        }
    }

    if(!data){
        return false;
    }

    let id = targetTag.getAttribute('data-'+CONSTANTS.quick_edit_id);
    let type = targetTag.getAttribute('data-'+CONSTANTS.quick_edit_type_index);
    let id_lang_data = targetTag.getAttribute('data-id_lang_data');

    targetTag._quick_edit_initial_value = targetTag.innerHTML;

    let sender = $_a.getSender();
    let settings = {};
    settings.url = dataTag.getAttribute('action');
    settings.dom_target = targetTag;
    settings.data = {'quick_edit':true , 'id':id , 'type':type , 'data':data , 'value':targetTag.innerHTML , 'id_lang_data':id_lang_data };

    sender.setData(settings);
    sender.send();
};

AJAX_Class.tinymce_image_upload_handler = function(blobInfo, success, failure) {
    var xhr, formData;

    xhr = new XMLHttpRequest();
    xhr.withCredentials = false;
    xhr.open('POST', this.url);

    xhr.onload = function() {
        let json;

        if (xhr.status != 200) {
            failure('HTTP Error: ' + xhr.status);
            return;
        }

        try{
            json = JSON.parse(xhr.responseText);
        }catch(e){
            json = false;
            console.log(e);
        }

        if (!json || typeof json.location != 'string') {
            failure('Invalid JSON: ' + xhr.responseText);
            return;
        }

        success(json.location);
    };

    formData = new FormData();
    formData.append('file', blobInfo.blob(), blobInfo.filename());
    formData.set('action', this.action);

    console.log(blobInfo.filename());

    xhr.send(formData);
};

// get the first available XHR, if none is found a new one is created
AJAX_Class.prototype.getSender = function(){

    let sender = null;

    for(let i = 0 , c = this.xhr_list.length ; i < c ; i++){
        if(!this.xhr_list[i].busy){
            if(this._debug){
                console.log('reuse sender ',i);
            }
            sender = this.xhr_list[i];
            break;
        }
    }

    if(sender === null){
        if(this._debug){
            console.log('create sender');
        }
        sender = new AJAX_SENDER();
        this.xhr_list.push(sender);
    }

    sender._debug = this._debug;

    return sender;
};

// send data according to the settings
AJAX_Class.prototype.send = function(settings , delay , queue){

    let sender = this.getSender();

    sender._debug = this._debug;

    if(this.running_stream_count <= this._consecutive_streams && !delay && !queue){
        sender.send(settings);
        return sender;
    }else{
        // if too many ajax stream are running, put the current in a waiting queue and run it later
        if(sender.setData(settings)){
            if(delay){
                sender._delayedSendTime = Date.now() + delay;
            }
            //~ if (sender._file) {
                //~ this._files_queue.push(sender);
                //~ return sender;
            //~ }
            this.queue(sender);
        }
        return false;
    }
};

AJAX_Class.prototype.queue = function(sender){

    this._stream_queue.push(sender);

    if(!GENERICS_Class.IsFunction(sender)){
        sender._state = AJAX_SENDER.STATE_QUEUED;
    }

    // try again to run the ajax call in 200ms
    if(this._queue_timer){
        clearTimeout(this._queue_timer);
    }

    this._queue_timer = setTimeout(this._process_queue.bind(this),200);
};

AJAX_Class.prototype._process_queue = function(){

    if(this._queue_timer){
        clearTimeout(this._queue_timer);
    }

    // try to run the next ajax stream
    if(this._stream_queue.length){

        if(GENERICS_Class.IsFunction (this._stream_queue[0])){
            let f = this._stream_queue.shift();
            f();
        }else{

            if(this.running_stream_count <= this._consecutive_streams){

                    let sender = this._stream_queue[0];
                    let send = false;
                    if(sender._delayedSendTime){
                        if(Date.now() >= sender._delayedSendTime){
                            send = true;
                        }
                    }else{
                        send = true;
                    }
                    // test for the big file upload pause
                    if (sender._file && sender.pause_on_next_chunk){
                        send = false;
                    }
                    if(send){
                        sender = this._stream_queue.shift();
                        sender.send();
                    }

            }
        }
        this._queue_timer = setTimeout(this._process_queue.bind(this),200);
    }
};

// compute the global progress for all the ajax streams running
AJAX_Class.prototype.computeProgress = function() {
    let up_bytes_loaded = 0;
    let up_bytes_total = 0;

    let down_bytes_loaded = 0;
    let down_bytes_total = 0;

    let up_unknown_loaded = 0;
    let down_unknown_loaded = 0;

    this._up_overload = 0;
    this._up_speed = 0;
    this._down_speed = 0;
    this._speed = 0;

    this._down_zero_loaded = 0;
    this._down_zero_total = 0;

    for(let i = 0 , c = this.xhr_list.length ; i < c ; i++){
        let x = this.xhr_list[i];
        if(x.busy){
            this._up_speed += x.up_speed;
            this._down_speed += x.down_speed;

            if(x._state == AJAX_SENDER.STATE_UPLOADING){
                this._speed += x.up_speed;
            }

            if(x._state == AJAX_SENDER.STATE_DOWNLOADING){
                this._speed += x.down_speed;
            }

            if(x.up_progress === null){
                up_unknown_loaded += x.up_loaded_bytes;
            }else{
                up_bytes_loaded += x.up_loaded_bytes;
                up_bytes_total += x.up_total_bytes;
            }

            if(x.down_progress === null){
                down_unknown_loaded += x.down_loaded_bytes;
            }else{
                down_bytes_loaded += x.down_loaded_bytes;
                down_bytes_total += x.down_total_bytes;

                if(x._download_done && x.down_total_bytes === 0){
                    this._down_zero_loaded ++;
                    this._down_zero_total ++;
                }
            }


        }
    }

    if(up_unknown_loaded + up_bytes_loaded > up_bytes_total){
        up_bytes_total = up_unknown_loaded + up_bytes_loaded;
        this._up_overload = up_unknown_loaded;
    }

    if(down_unknown_loaded + down_bytes_loaded > down_bytes_total){
        down_bytes_total = down_unknown_loaded + down_bytes_loaded;
        down_bytes_loaded += down_unknown_loaded;
        this._down_overload = down_unknown_loaded;
    }

    this._down_loaded_bytes = down_bytes_loaded;
    this._down_total_bytes = down_bytes_total;

    this._up_loaded_bytes = up_bytes_loaded;
    this._up_total_bytes = up_bytes_total;

    this._last_data_time = Date.now();
};

// indicates a temporary upload info until we had a correct update from the browser
Object.defineProperty(AJAX_Class.prototype, 'up_overload', {
    get: function() {
        return this._up_overload;
    }
});

// indicates a temporary dowload info until we had an answer from the server
Object.defineProperty(AJAX_Class.prototype, 'down_overload', {
    get: function() {
        return this._down_overload;
    }
});

// current overall upload speed
Object.defineProperty(AJAX_Class.prototype, 'up_speed', {
    get: function() {
        return this._up_speed;
    }
});

// current overall download speed
Object.defineProperty(AJAX_Class.prototype, 'down_speed', {
    get: function() {
        return this._down_speed;
    }
});

// number of XHR doing something (initialization, upload, download, finalization ...)
Object.defineProperty(AJAX_Class.prototype, 'busy_stream_count', {
    get: function() {
        this._busy_stream_count = 0;
        for(let i = 0 , c = this.xhr_list.length ; i < c ; i++){
            if(this.xhr_list[i].busy){
                this._busy_stream_count++;
            }
        }
        return this._busy_stream_count;
    }
});

// number of transfer in progress
Object.defineProperty(AJAX_Class.prototype, 'running_stream_count', {
    get: function() {
        this._running_stream_count = 0;
        for(let i = 0 , c = this.xhr_list.length ; i < c ; i++){
            if(this.xhr_list[i].running){
                this._running_stream_count++;
            }
        }
        return this._running_stream_count;
    }
});

// overall upload progress (value between 0 and 1)
Object.defineProperty(AJAX_Class.prototype, 'up_progress', {
    get: function() {
        if(this._last_data_time === 0 || (Date.now() - this._last_data_time) > 100){
            this.computeProgress();
        }
        return this._up_total_bytes > 0 ? this._up_loaded_bytes / this._up_total_bytes : 0;
    }
});

// overall download progress (value between 0 and 1)
Object.defineProperty(AJAX_Class.prototype, 'down_progress', {
    get: function() {
        if(this._last_data_time === 0 || (Date.now() - this._last_data_time) > 100){
            this.computeProgress();
        }
        return this._down_total_bytes > 0 ? this._down_loaded_bytes / this._down_total_bytes : this._down_zero_total > 0 ? this._down_zero_loaded / this._down_zero_total : 0;
    }
});

// overall progression average
Object.defineProperty(AJAX_Class.prototype, 'progress', {
    get: function() {
        return (this.up_progress + this.down_progress) * 0.5;
    }
});

// overall speed average
Object.defineProperty(AJAX_Class.prototype, 'speed', {
    get: function() {
        return this._speed;
    }
});


//****************************************************************************************
// AJAX_SENDER Class declaration
var AJAX_SENDER = function(){
    var _self = this;

    this._xhr = new XMLHttpRequest();

    this._xhr._AJAX_SENDER = this;
    this._xhr.upload._AJAX_SENDER = this;

    this._xhr.addEventListener('loadend',this._onDownLoadend.bind(this));
    this._xhr.addEventListener('progress',this._downProgress.bind(this));

    this._xhr.addEventListener('load' , this.processResponse.bind(this));
    this._xhr.addEventListener('error' , this.processResponse.bind(this));

    this._xhr.upload.addEventListener('loadend',this._onUpLoadend.bind(this));
    this._xhr.upload.addEventListener('progress',this._upProgress.bind(this));
    //~ this._xhr.upload.onerror = (...err) => {
        //~ console.log('Upload failed.', err);
    //~ }
    //~ this._xhr.upload.ontimeout  = (...err) => {
        //~ console.log('Upload timeout.', err);
    //~ }

    this._xhr.addEventListener('readystatechange' , this._readyStateChange.bind(this));

    this._state = AJAX_SENDER.STATE_NOTHING;

    //~ this._files = [];
    //~ this.pause_on_next_chunk = false;

    this._reset();
};
AJAX_SENDER.prototype.constructor = AJAX_SENDER;
//~ class AJAX_SENDER {
    //~ constructor() {
        //~ var _self = this;

        //~ this._xhr = new XMLHttpRequest();

        //~ this._xhr._AJAX_SENDER = this;
        //~ this._xhr.upload._AJAX_SENDER = this;

        //~ this._xhr.addEventListener('loadend',this._onDownLoadend.bind(this));
        //~ this._xhr.addEventListener('progress',this._downProgress.bind(this));

        //~ this._xhr.addEventListener('load' , this.processResponse.bind(this));
        //~ this._xhr.addEventListener('error' , this.processResponse.bind(this));

        //~ this._xhr.upload.addEventListener('loadend',this._onUpLoadend.bind(this));
        //~ this._xhr.upload.addEventListener('progress',this._upProgress.bind(this));

        //~ this._xhr.addEventListener('readystatechange' , this._readyStateChange.bind(this));

        //~ this._state = AJAX_SENDER.STATE_NOTHING;

        //~ this._files = [];

        //~ this._reset();
    //~ }
//~ }

AJAX_SENDER.STATE_NOTHING = 0;
AJAX_SENDER.STATE_QUEUED = 1;
AJAX_SENDER.STATE_UPLOADING = 2;
AJAX_SENDER.STATE_DOWNLOADING = 3;

AJAX_SENDER.prototype._readyStateChange = function(event){

    switch(this.readyState){
        case this.UNSENT:
            if(this._debug){ console.log('init',event); }
        break;

        case this.OPENED:
            if(this._debug){ console.log('connexion open',event); }
        break;

        case this.HEADERS_RECEIVED:
            if(this._debug){
                console.log('header received',event);
                console.log(this.getAllResponseHeaders());
            }
        break;

        case this.LOADING:
            if(this._debug){ console.log('loading ...',event); }
        break;

        case this.DONE:
            if(this._debug){ console.log('all done',event); }
            
        break;

    }

};

AJAX_SENDER.prototype._reset = function(){

    this._data = null;
    this._localdata = null;

    this._busy = false;
    this._action = '';
    this._method = 'POST';

    this._state = AJAX_SENDER.STATE_NOTHING;

    this._up_progress = 0;
    this._down_progress = 0;

    this._up_total_bytes = 0;
    this._down_total_bytes = 0;

    this._up_loaded_bytes = 0;
    this._down_loaded_bytes = 0;

    this._current_success_callback = null;
    this._current_error_callback = null;
    this._current_down_progress_callback = null;
    this._current_up_progress_callback = null;

    this._last_up_time = 0;
    this._last_down_time = 0;

    this._up_speed = 0;
    this._down_speed = 0;

    this._download_done = false;

    //~ this._files.length = 0;
    //~ this.pause_on_next_chunk = false;
};

// compute the current upload progression of this sender
AJAX_SENDER.prototype._upProgress = function(event){

    //let target = this._AJAX_SENDER || this;
    let target = this;

    target._state = AJAX_SENDER.STATE_UPLOADING;

    if(target._last_up_time > 0 && event.loaded != event.total){
        let time_offset = Date.now() - target._last_up_time;
        let bytes_offset = event.loaded - target._up_loaded_bytes;

        target._up_speed = bytes_offset * (1000 / time_offset);
    }
    target._last_up_time = Date.now();

    if(target._send_time <= 0){
        target._send_time = target._last_up_time;
    }

    target._up_loaded_bytes = event.loaded;

    if (event.lengthComputable) {
        target._up_progress = event.loaded / event.total;
        target._up_total_bytes = event.total;

        //~ this._files_count = 0;
        //~ this._files_completed = 0;
        //~ if(this._files){
            //~ this._files_count = this._files.length;

            //~ for(let i = 0 ; i < this._files_count ; i++){
                //~ if(this._files[i].end <= event.loaded){
                    //~ this._files[i].progress = 1;
                    //~ this._files_completed++;

                //~ }else if(this._files[i].start > event.loaded){
                    //~ this._files[i].progress = 0;
                //~ }else{
                    //~ this._files[i].progress = (event.loaded - this._files[i].start) / (this._files[i].file.size);
                //~ }
            //~ }
        //~ }
    }else{
        target._up_progress = null;
        target._up_total_bytes = null;
    }


    if(this._current_up_progress_callback){
        this._current_up_progress_callback(event,this);
    }
};

// compute the current download progression of this sender
AJAX_SENDER.prototype._downProgress = function(event){

    let target = this;
    target._state = AJAX_SENDER.STATE_DOWNLOADING;

    if(target._last_down_time > 0 && event.loaded != event.total){
        let time_offset = Date.now() - target._last_down_time;
        let bytes_offset = event.loaded - target._down_loaded_bytes;
        target._down_speed = bytes_offset * (1000 / time_offset);
    }
    target._last_down_time = Date.now();

    if(target._send_time <= 0){
        target._send_time = target._last_down_time;
    }

    target._down_loaded_bytes = event.loaded;

    if (event.lengthComputable) {

        target._down_progress = event.loaded / event.total;
        target._down_total_bytes = event.total;
    }else{
        target._down_progress = null;
        target._down_total_bytes = null;
    }

    if(this._current_down_progress_callback){
        this._current_down_progress_callback(event,this);
    }
};

// action = url php script
// data = form dom object, formdata object, or and object with variables to send
// extra_data = object with additional variables to send
// down_progress : progress callback for download
// up_progress : progress callback for upload
// error : error callback
// success : success callback
// json_mode:
// AJAX_Class.JSON_OFF = 0 = the json string untouched server side
// AJAX_Class.JSON_ON = 1 = basic json decode server side : js objects are converted to PHP objects and js arrays to PHP arrays
// AJAX_Class.JSON_ARRAY = 2 = (default) automatically convert json strings to PHP associative arrays when an object or an array is sent
AJAX_SENDER.prototype.setData = function(settings){
    settings = settings || {};

    if(settings['skip_container']){
        delete(settings['skip_container']);
        if(!settings.extra_data) settings.extra_data = {};
        settings.extra_data[CONSTANTS.posted_varname] = 1;
    }
    if(settings['container_name']){
        
        if(!settings.extra_data) settings.extra_data = {};
        settings.extra_data[CONSTANTS.posted_varname_container] = settings['container_name'];
        delete(settings['container_name']);
    }

    this._reset();
    
    this._timer_needed = (settings.notimer == undefined);

    let formAction = null;

    if(GENERICS_Class.IsObject(settings) && settings.tagName == 'FORM'){
        formAction = settings.getAttribute('action');
    }

    if(!settings.action && settings.url){
        settings.action = settings.url;
    }

    settings.action = settings.action || this._action;
    settings.method = settings.method || this._method;

    if(settings.json_mode === undefined){
        settings.json_mode = AJAX_Class.JSON_ARRAY;
    }

    // local data retrievable on receipt of the query result, in the sender object
    if(settings.localdata !== undefined){
        this._localdata = settings.localdata;
    }

    let json_decode_list = [];
    let json_list_identifier = AJAX_Class.json_list_identifier;
    
    // Si file présent est a true, on envoie un chunk seulement
    //~ if (settings.file){
        //~ this._file = true;
        //~ this._fileData = settings.fileData;
    //~ } else {
        //~ this._file = false;
        //~ this._fileData = {};
    //~ }
    //~ this._bigFileLst = [];
    this._fileLst = [];
    
    if(GENERICS_Class.IsObject(settings.data)){

        if(GENERICS_Class.IsFormdata(settings.data)){
            //~ console.log('is formData');
            // ok !
            //~ let keys = ;
            //~ console.log(keys);
            //~ for (let key in settings.data.keys()){
                //~ console.log(key);
                //~ let vals = settings.data.getAll(key);
                //~ console.log(vals);
                //~ for (let val in vals){
                    //~ console.log(val);
                //~ }
            //~ }
            let already_parsed = [];
            let toReplace = [];
            for (var pair of settings.data.entries()){
                if (already_parsed.indexOf(pair[0]) == -1){
                    let vals = settings.data.getAll(pair[0]);
                    let is_file = false;
                    let newVal = [];
                    //~ console.log(pair);
                    
                    vals.forEach((val,key)=>{
                        if (!GENERICS_Class.IsString(val)){
                            // a value in formData can be a string or a file
                            this._fileLst.push(val);
                            newVal.push(val.name);
                            is_file = true;
                        }
                    });
                    if (is_file){
                        already_parsed.push(pair[0]);
                        toReplace.push({'key': pair[0], 'val':newVal});
                    }
                    already_parsed.push(pair[0]);
                }
            }
            // toReplace.forEach((obj)=>{settings.data.set(obj.key, obj.val);});
            toReplace.forEach((obj)=>{settings.data.delete(obj.key);});

        }else if(settings.data.tagName === 'FORM'){
            // add form inputs
            settings.action = settings.action || settings.data.getAttribute('action');
            settings.method = settings.method || settings.data.getAttribute('method');

            let only_submitter = false;
            if(settings.data._submitter){
                if(!settings.extra_data){
                    settings.extra_data = {};
                }
                settings.extra_data[settings.data._submitter.name] = settings.data._submitter.value;
                if(settings.data._submitter.getAttribute('data-only')){
                    only_submitter = true;
                }
            }

            let formData;
            if(only_submitter){
                formData = new FormData();
            }else{

                formData = new FormData();

                let el = settings.data.elements;
                for(let i = 0; i < el.length ; i++){
                    let input = el[i];
                    let tag_name = input.tagName.toLowerCase();
                    let tag_type = input.type.toLowerCase();

                    if(tag_name == "button" && tag_type == "submit" && settings.data._submitter && settings.data._submitter !== input){
                        // we exclude submits that are not used
                        continue;
                    }
                    //~ console.log(tag_name);
                    //~ if(tag_name == "textarea"){
                        //~ console.log(input.value);
                        //~ input.value= input.value.replace(/(?:\r\n|\r(?=\n)|\n(?=\r))/g, '\r\n');
                        //~ input.value= input.value.replace(/\n/g, "\r\n").replace(/\r\r/g, "\r");
                        //~ console.log(input.value);
                    //~ }
                    
                    if(tag_name == "input" && tag_type == "file"){
                        if (settings.ignore_file){
                            continue;
                        }
                        for(let f=0 ; f < input.files.length ; f++){
                            //~ if (input.files[f].size < CONSTANTS.file_upload_size){
                                // petit fichier, on l'envoie avec le form
                                //~ formData.append( input.name , input.files[f]);
                            //~ } else {
                                // gros fichier, on l'envoie par chunk
                                this._fileLst.push(input.files[f]);
                                formData.append( input.name , input.files[f].name);
                            //~ }
                            
                        }
                    }else{
                        if(tag_name == "input" && tag_type == "checkbox"){
                            if(input.checked){
                                formData.append( input.name , input.value);
                            }

                        }else if(tag_name == "input" && tag_type == "radio"){
                            if(input.checked){
                                formData.append( input.name , input.value);
                            }
                        }else{
                            formData.append( input.name , input.value);
                        }
                    }

                }


            }

            settings.data = formData;

        }else{
            // add object data
            let formData = new FormData();

            let keys = Object.keys(settings.data);

            for(let i = 0 , c = keys.length ; i < c ; i++){

                let name = keys[i];
                let value = settings.data[name];

                if(value === true){
                    value = 1;
                }

                if(value === false){
                    value = 0;
                }

                if(GENERICS_Class.IsObject(value)){

                    if(GENERICS_Class.IsObject(value)){
                        formData.append( name , JSON.stringify(value));
                        if(settings.json_mode){
                            json_decode_list.push(name);
                        }
                    }else{
                        formData.append( name , value );
                    }

                }else{
                    formData.append( name, value );
                }
            }

            settings.data = formData;
        }

        if(!AJAX_Class.checkFileData(settings.data)){
            return;
        }

        // add extra data
        if(GENERICS_Class.IsObject(settings.extra_data)){

            let keys = Object.keys(settings.extra_data);

            for(let i = 0 , c = keys.length ; i < c ; i++){

                let name = keys[i];
                let value = settings.extra_data[name];

                if(GENERICS_Class.IsObject(value) ){
                    settings.data.append( name , JSON.stringify(value) );
                    if(settings.json_mode){
                        json_decode_list.push( name );
                    }
                }else{
                    settings.data.append( name , value );
                }
            }
        }

        //~ this._files.length = 0;
        //~ let entries = settings.data.entries();
        //~ let obj = entries.next();
        //~ let start = 0;
        //~ while(undefined !== obj.value) {
            //~ let t = Object.prototype.toString.apply(obj.value[1]);
            //~ if(t == '[object File]'){
                //~ this._files.push({'file':obj.value[1] , 'start':start , 'end':start+obj.value[1].size-1 , 'progress':0});
                //~ start += obj.value[1].size;
            //~ }
            //~ obj = entries.next();
        //~ }


        if(settings.json_mode){
            settings.data.append(json_list_identifier , JSON.stringify(json_decode_list));
            settings.data.append(json_list_identifier+'_mode' , settings.json_mode);
        }
    }
//~ console.log(settings);
    if(settings.debug){
        console.log(this);
        for(var pair of settings.data.entries()) {
           console.log(pair[0] ,'=', pair[1]);
        }
    }

    if(GENERICS_Class.IsFunction(settings.success)){
        this._current_success_callback = settings.success;
    }else{
        this._current_success_callback = null;
    }

    if(GENERICS_Class.IsFunction(settings.error)){
        this._current_error_callback = settings.error;
    }else{
        this._current_error_callback = null;
    }

    if(GENERICS_Class.IsFunction(settings.up_progress)){
        this._current_up_progress_callback = settings.up_progress;
    }else{
        this._current_up_progress_callback = null;
    }

    if(GENERICS_Class.IsFunction(settings.down_progress)){
        this._current_down_progress_callback = settings.down_progress;
    }else{
        this._current_down_progress_callback = null;
    }

    this.busy = true;

    this._method = settings.method;

    this._action = formAction || settings.action;

    this._dom_target = DOM_Class.GetDomElement(settings.dom_target);

    this._replace_dom_target = settings.replace_dom_target;

    this._allow_target_update = settings.disableTargetUpdate?false:true;

    this._data = settings.data;

    return true;
};

Object.defineProperty(AJAX_SENDER.prototype, 'dom_target', {
    get: function() {
        return this._dom_target;
    }
});

Object.defineProperty(AJAX_SENDER.prototype, 'data', {
    get: function() {
        return this._data;
    }
});

Object.defineProperty(AJAX_SENDER.prototype, 'method', {
    get: function() {
        return this._method;
    }
});

Object.defineProperty(AJAX_SENDER.prototype, 'action', {
    get: function() {
        return this._action;
    }
});

AJAX_SENDER.prototype.updateResponseData = function(event){
    this._down_total_bytes = event.total;
    this._down_loaded_bytes = event.loaded;

    this._download_done = true;

    // compute the average download speed
    if(this._send_time > 0){
        this._down_speed = event.loaded * (1000 / (Date.now() - this._send_time));
    }

    if(this._current_down_progress_callback !== null){

        // execute the progress call back for a last update
        this._current_down_progress_callback(event , this);

    }
};

AJAX_SENDER.ProcessJson = function(result){
    if(GENERICS_Class.IsObject(result)){

        if(result.reload_after_message){
            result.url = result.reload_after_message;
        }

        if(result.messages){
            UI_Class.MessagePopup(result.messages , result.reload_after_message ? DOM_Class.reload_page.bind(result) : undefined );
        }

        if(result.url === CONSTANTS.reload_noparams){
            DOM_Class.reload_page(result.url);
        }else{
            if(result.errors){
                UI_Class.MessagePopup(result.errors , result.reload_after_message ? DOM_Class.reload_page.bind(result) : undefined );
            }
        }
    }
};

AJAX_SENDER.prototype.processResponse = function(event){

    let type = this._xhr.getResponseHeader('Content-Type');

    //hide waiting modal
    if (!this.timer_modal_is_hide && this.timer_modal){
        this.timer_modal.Hide();
        this.timer_modal_is_hide = true;
    }


    let result = this._xhr.responseText;
    if(type == 'application/json'){
        try{
            result = JSON.parse(result);
        }catch(e){
            result = this._xhr.responseText;
        }
    }

    this.updateResponseData(event);

    if(this._xhr.status >= 400){
        console.error('Ajax Error',this._xhr);
        if(this._current_error_callback){
            this._current_error_callback(result , this);
        }

    }else{

        AJAX_SENDER.ProcessJson(result);

        if(this._dom_target && this._allow_target_update){

            if(GENERICS_Class.IsObject(result)){

                if(result.html !== undefined){
                    if(this._replace_dom_target){
                        DOM_Class.ReplaceElement(this._dom_target , result.html);
                    }else{
                        DOM_Class.WriteHtml(this._dom_target , result.html );
                    }

                }

            }else if(GENERICS_Class.IsString(result)){
                if(this._replace_dom_target){
                    DOM_Class.ReplaceElement(this._dom_target , result);
                }else{
                    DOM_Class.WriteHtml(this._dom_target , result );
                }
            }else{
                console.warn('Wrong ajax result type',result);
            }
        }

        if(this._current_success_callback){
            this._current_success_callback(result , this);
        }
    }
};

AJAX_SENDER.prototype.processError = function(event,...args){
    console.log(event);
    console.log(this._xhr);
    console.log(args);

    let type = this._xhr.getResponseHeader('Content-Type');
    
    //hide waiting modal
     if (!this.timer_modal_is_hide && this.timer_modal){
        this.timer_modal.Hide();
        this.timer_modal_is_hide = true;
    }

    let result = this._xhr.responseText;
    if(type=='application/json'){
        result = JSON.parse(result);
    }

    this.updateResponseData(event);

    if(this._current_error_callback){
        this._current_error_callback(result , this);
    }

    if(this._dom_target && this._allow_target_update){

        if(GENERICS_Class.IsObject(result)){

            if(result.html !== undefined){
                DOM_Class.WriteHtml(this._dom_target , result.html );
            }

        }else if(GENERICS_Class.IsString(result)){
            DOM_Class.WriteHtml(this._dom_target , result );

        }else{
            console.warn('Wrong ajax result type',result);
        }
    }

};

AJAX_SENDER.prototype.send = function(settings){
    // when sending a file, need to save the settings object before the processing
    let originalSettings = settings;
    
    if(settings){
        if(!this.setData(settings)){
            return false;
        }
    }
    
    if (this._fileLst.length > 0){
        originalSettings.ignore_file = true;
        // console.log(this._fileLst);
        let fileSender = new AJAX_FILE(this._fileLst,originalSettings);
        return;
    }

    this._xhr.open(this._method, this._action , true);
    
    this._xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
    this._xhr.setRequestHeader('Cache-Control', 'no-cache');
    
    if (this._xhr.readyState != 1) {
        console.warn("Cannot send this request because the XMLHttpRequest.readyState is not OPENED.");
        console.log(this);
        return;
    }
    if (!this.timer_modal && this._timer_needed ){
        this.timer_modal =  UI_Class.AddWindow(null, {'modal': true, 'nodrag': true, 'class':'timer_requete', 'disableBackgroundClick': true});
        this.timer_modal.SetParent(document.body, 0.5, 0.5);
        this.timer_modal_is_hide = false;
        this.timer_modal._modalMask.classList.add('load_timer');
    } else {
        if (this.timer_modal_is_hide && this._timer_needed) {
            this.timer_modal.Show();
            this.timer_modal_is_hide = false;
        }
    }
    this._xhr.send(this._data);
    this.running = true;

    this._state = AJAX_SENDER.STATE_UPLOADING;

    this._send_time = Date.now();
};


AJAX_SENDER.prototype.Abort = function(event){
    this._current_success_callback = null;
    this._current_error_callback = null;
    this._current_down_progress_callback = null;

    this.busy = false;
    this.running = false;

    this._xhr.abort();
};

AJAX_SENDER.prototype._onDownLoadend = function(event){

    let ajax_sender = this;
    let xhr = ajax_sender._xhr;

    if(ajax_sender._debug){
        console.log('DOWN end',event);
    }

    // compute the average download speed
    if(ajax_sender._send_time > 0){
        ajax_sender._down_speed = event.loaded * (1000 / (Date.now() - ajax_sender._send_time));
    }

    if(ajax_sender._current_down_progress_callback){

        // execute the progress call back for a last update
        ajax_sender._current_down_progress_callback(event , this);

    }

    ajax_sender._current_success_callback = null;
    ajax_sender._current_error_callback = null;
    ajax_sender._current_down_progress_callback = null;

    ajax_sender.busy = false;
    ajax_sender.running = false;

    xhr.abort();

};


AJAX_SENDER.prototype._onUpLoadend = function(event){

    let ajax_sender = this;
    let xhr = ajax_sender._xhr;

    if(this._debug){
        console.log('UP end',event);
    }

    ajax_sender._up_total_bytes = event.total;
    ajax_sender._up_loaded_bytes = event.loaded;

    // compute the average upload speed
    if(ajax_sender._send_time > 0){
        ajax_sender._up_speed = event.loaded * (1000 / (Date.now() - ajax_sender._send_time));
    }

    if(ajax_sender._current_up_progress_callback){

        // execute the progress call back for a last update
        ajax_sender._current_up_progress_callback(event,this);

    }

    ajax_sender._current_up_progress_callback = null;

    // reset time counter for the download step coming after this
    ajax_sender._send_time = Date.now();
};

Object.defineProperty(AJAX_SENDER.prototype, 'busy', {
    get: function() {
        return this._busy;
    },
    set: function(value) {
        this._busy = value === true;
    }
});

Object.defineProperty(AJAX_SENDER.prototype, 'progress', {
    get: function() {
        if(this._up_progress === null || this._down_progress === null){
            return null;
        }
        return (this._up_progress + this._down_progress) * 0.5;
    }
});

//~ Object.defineProperty(AJAX_SENDER.prototype, 'files_up_progress', {
    //~ get: function() {
        //~ return {'completed':this._files_completed , 'total':this._files_count , 'files':this._files };
    //~ }
//~ });

Object.defineProperty(AJAX_SENDER.prototype, 'up_progress', {
    get: function() {
        return this._up_progress;
    }
});

Object.defineProperty(AJAX_SENDER.prototype, 'down_progress', {
    get: function() {
        return this._down_progress;
    }
});

Object.defineProperty(AJAX_SENDER.prototype, 'up_loaded_bytes', {
    get: function() {
        return this._up_loaded_bytes;
    }
});

Object.defineProperty(AJAX_SENDER.prototype, 'up_total_bytes', {
    get: function() {
        return this._up_total_bytes;
    }
});

Object.defineProperty(AJAX_SENDER.prototype, 'down_loaded_bytes', {
    get: function() {
        return this._down_loaded_bytes;
    }
});


Object.defineProperty(AJAX_SENDER.prototype, 'down_total_bytes', {
    get: function() {
        return this._down_total_bytes;
    }
});

Object.defineProperty(AJAX_SENDER.prototype, 'up_speed', {
    get: function() {
        return this._up_speed;
    }
});

Object.defineProperty(AJAX_SENDER.prototype, 'down_speed', {
    get: function() {
        return this._down_speed;
    }
});

var AJAX_FILE = function(fileLst,originalRequest){
    var self = this;
    
    var debug = false;
    
    if (debug){
        console.log('new AJAX_FILE','fileLst',fileLst,'originalRequest',originalRequest);
    }
    
    var slicesTotal = 0; // count the total amount of slice sent
    
    // current start and end byte
    var chunkStart = 0;
    var chunkEnd;
    // index of current chunk 
    var chunkIndex = 0;
    // adaptative size of chunk, depending the upload speed
    var chunkSize = CONSTANTS.slice_upload_size;
    
    // when there is a file in a form or in a request,
    // the request stop and send the file
    // once is done, re-send the original request
    var originalRequest = originalRequest;
    var original_time = (originalRequest.data.has('time')) ? originalRequest.data.get('time') : false;
    
    var queue;
    var file;
    
    var Dom_ID = GENERICS_Class.GetUniqueId();
    
    // handle stop of an upload
    var aborted = false;
    // handle pause of an upload
    var paused = false;
    
    // calculate the number of slices (chunk)
    var startTime = Date.now();
    var lastChunkSendingTime = 0; // enregistre le dernier temps passé à envoyer un chunk
    var chunkStartTime = Date.now();
    
    var xhr = new XMLHttpRequest();
    
    // progress bytes by chunk
    var last_progress_time = 0;
    
    // progress for each chunk
    var chunkTotalBytes = 0;        // chunk size
    var chunkUploadedBytes = 0;     // already loaded 
    var chunkProgress = 0;          // progress, 0 to 1
    
    var errors = [];
    
    this.speed,this.fileCount,this.fileSended;
    
    this.all = {
        'progress': 0,
        'total': 0,
        'loaded': 0
    };
    this.current = {
        'name': '',
        'progress': 0,
        'total': 0,
        'loaded': 0,
        'small': false,
    };
    
    // for tracking time, used for debug
    var startTime,endTime;
    
    var uniqueid = Date.now();
    
    function sendChunk(){
        if (xhr.readyState > 0){
            console.log('not sending next chunk, xhr not ready');
            return false;
        }
        if (paused){
            console.log('not sending next chunk, upload paused');
            return false;
        }
        if (aborted){
            console.log('not sending next chunk, upload aborted');
            return false;
        }
        
        if (!self.current.small){
            
            slicesTotal++; // count total slice for merge
            
            chunkEnd = chunkStart + chunkSize;
            if(chunkEnd > file.size) {
                // Pour que le dernier chunk soit correct
                chunkEnd = file.size;
                chunkSize = chunkEnd - chunkStart;
            }
        
            chunk = file.slice(chunkStart, chunkEnd);
        }
        
        xhr.open('POST', CONSTANTS.base_url + 'public/upload.php' , true);
        
        xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
        xhr.setRequestHeader('Cache-Control', 'no-cache');
        
        let formData = new FormData();
        formData.append('filename', file.name);
        formData.append('uniqueid', uniqueid);
        if (self.current.small){
            formData.append('filesize', file.size);
            formData.append('file', file, file.name + '!s!p!a!d!e!' + uniqueid);
            // formData.append('file', file, file.name);
            formData.append('full', 1);
        } else {
            formData.append('filesize', chunk.size);
            formData.append('chunkIndex', chunkIndex);
            formData.append('file', chunk, file.name);
        }
        if (original_time) formData.append('time', original_time);
        
        xhr.onload = onLoadChunk;
        xhr.onerror = function(evt){
            self.cancelFile(originalRequest.error);
            //~ xhr.abort();
            //~ console.log('error', evt);
        };
        xhr.upload.onprogress = onProgressChunk;
        
        xhr.send(formData);
    }
    
    function onLoadChunk(evt){
        let result = xhr.responseText;
        let sendNextChunk = true;
        // console.log(result);
        if (result != 'ok'){
            /* TODO
             * retry sending current chunk ?
             * display error message ?
             */
            //~ console.log('error sending chunk');
            if (!self.current.small){
                errors.push({'path': file.name,'chunk': chunkIndex});
            } else {
                errors.push({'path': file.name,'chunk': false});
            }

            UI_Class.MessagePopup('An error occured with your upload.');

            self.cancelFile(originalRequest.error);
            return;
        }
        
        xhr.abort();
        
        // add this chunk to loaded
        if (!self.current.small){
            self.current.loaded += chunkSize;
            self.all.loaded += chunkSize;
        } else {
            self.current.loaded = file.size;
            self.all.loaded += file.size;
        }
        
        chunkUploadedBytes = 0;
        
        // what to do next, sending next chunk or sending merge request ?
        if (self.current.small){
            self.fileSended++;
            processQueue();
            return;
        }
        
        if (sendNextChunk){
            if (chunkEnd < file.size){
                // there is still some byte to send, prepare next chunk
                
                // ADAPTATIVE CHUNK
                // calcul le temps passé à envoyer le chunk
                let currentTime = Date.now();
                let chunkSendingTime = currentTime - chunkStartTime;
                // c'est le premier chunk que l'on envoie
                // Taille courante du chunk * le temps que l'on veut pour envoyer un chunk (ici 5s) / le temps passé a envoyé
                chunkSize = Math.round(chunkSize * ( 5000 / chunkSendingTime)); 
                // enregistre le dernier temps pour le prochain passage
                lastChunkSendingTime = chunkSendingTime;
                chunkStartTime = currentTime;
                
                chunkIndex++;
                chunkStart = chunkEnd;
                
                if (debug){
                    console.log('time sending chunk (s)', (lastChunkSendingTime/1000));
                }
                
                sendChunk();
            } else {
                // every byte have been sent, send merge request to the server
                
                // display the real time for uploading the file
                //~ let endChunkTime = Date.now();
                //~ let diff = (endChunkTime - startTime) / 1000;
                //~ console.log('time passed sending all chunk (s)', diff);
                
                mergeFile();
            }
        } else {
            self.fileSended++;
            processQueue();
        }
    }
    
    function onProgressChunk(evt){
        //~ console.log(evt);
        //~ if(last_progress_time > 0 && evt.loaded != evt.total){
        if(last_progress_time > 0){
            let time_offset = Date.now() - last_progress_time;
            let bytes_offset = evt.loaded - chunkUploadedBytes;

            self.speed = Math.round(bytes_offset * (1000 / time_offset)); // byte par seconde
        }
        last_progress_time = Date.now();
        chunkUploadedBytes = evt.loaded;

        if (evt.lengthComputable) {
            chunkProgress = evt.loaded / evt.total;
            chunkTotalBytes = evt.total;
            
            //~ console.log('speed byte/s',up_speed);
            
            computeProgress();
            
            if(GENERICS_Class.IsFunction(originalRequest.up_progress)){
                originalRequest.up_progress(evt,self);
            }
        }else{
            chunkProgress = null;
            chunkTotalBytes = null;
        }
    }
    function computeProgress(){
        let currentLoaded = self.current.loaded + chunkUploadedBytes;
        self.current.progress = currentLoaded / self.current.total;
        self.current.progress = self.current.progress > 1 ? 1 : self.current.progress;
        
        //~ console.log('current', self.current.progress);
        
        let allLoaded = self.all.loaded + chunkUploadedBytes;
        self.all.progress = allLoaded / self.all.total;
        self.all.progress = self.all.progress > 1 ? 1 : self.all.progress;
        //~ console.log('total', self.all.progress);
    }
    function mergeFile(){
        let settings = {};
        settings.url = CONSTANTS.base_url + 'public/upload.php';
        settings.notimer = true;
        settings.data = {
            'merge': 1,
            'name': file.name,
            'type': file.type,
            'size': file.size,
            'index': slicesTotal,
            'uniqueid': uniqueid
            //~ 'relativePath': file.webkitRelativePath
        };
        if (original_time) settings.data.time = original_time;
        // if (file.webkitRelativePath != ''){
        //     settings.data.relativePath = file.webkitRelativePath;
        // }
        settings.up_progress = false;
        settings.success = function(res){
            // file send successfully
            self.fileSended++;
            processQueue();
        };
        if (debug){
            console.log('AJAX_FILE sending merge request');
        }
        $_a.send(settings);
    }
    
    this.cancelFile = function(callback){
        aborted = true;
        // stop current xhr sending
        xhr.abort();
        
        // send a request to delete sent chunk
        let settings = {};
        settings.url = CONSTANTS.base_url + 'public/upload.php';
        settings.notimer = true;
        settings.data = {
            'cancel': 1,
            'name': file.name,
            'uniqueid': uniqueid
        };
        if (original_time) settings.data.time = original_time;
        settings.success = callback;
        $_a.send(settings);
    };
    
    this.pauseFile = function(){
        //~ console.log('PAUSE');
        paused = true;
        
        //~ let btn_pause = document.getElementById(Dom_ID+'_pause');
        //~ let btn_reprendre = document.getElementById(Dom_ID+'_reprendre');
        //~ btn_pause.style.display = 'none';
        //~ btn_reprendre.style.display = 'block';
    };
    
    this.reprendreFile = function(){
        //~ console.log('REPRENDRE');
        paused = false;
        
        sendChunk();
    };

    function processQueue(){
        // check the "file" variable, if not empty, mean that a file have been uploaded, add it to the quota used/remain CONSTANTS variable
        if (file){
            CONSTANTS.left -= file.size;
            CONSTANTS.usage += file.size;
            CONSTANTS.percentage = (CONSTANTS.usage / CONSTANTS.quota) * 100;
        }
        if (queue.length > 0){
            
            //~ console.log(queue);
            // begin by the first element of the list to preserve the index with the file_path list (when uploading a folder in filemanager)
            file = queue.shift();
            
            self.current.total = file.size;
            self.current.small = (file.size <= CONSTANTS.file_upload_size);
            
            self.current.loaded = 0;
            slicesTotal = 0;
            chunkStart = 0;
            chunkIndex = 0;
            
            // can't use webkitRelativePath because it's not supported everywhere
            let filename = file.name;
            if (originalRequest.data.has('file_path[]')){
                let paths = originalRequest.data.getAll('file_path[]');
                filename = paths[self.fileSended] + file.name;
            }
            
            self.current.name = filename;
            originalRequest.data.append('lstFilePath[]', filename + '!s!p!a!d!e!' + uniqueid);
            // originalRequest.data.append('lstFilePath[]', filename);
            
            // send the first chunk
            sendChunk();
            
        } else {
            if (errors) originalRequest.data.append('upload_errors', errors);
            if (originalRequest.data.has('file_path[]')) originalRequest.data.delete('file_path[]');
            $_a.send(originalRequest,10);
        }
    }
    
    function init(fileLst){
        queue = fileLst;
        
        self.fileCount = queue.length;
        self.fileSended = 0;
        
        queue.forEach( (file) => {
            self.all.total += file.size;
        });
        
        if (CONSTANTS.left <= self.all.total) {
            UI_Class.MessagePopup(CONSTANTS.texts.too_heavy_files.replace(['$1','$2'],[self.all.total,CONSTANTS.left]));
            return false;
        }
        
        processQueue();
    }
    init(fileLst);
};
/*jshint esversion: 6 */
//-------------------------------------------------------------
// all manipulation around ONE dom element
var DOM_Class = function(){};
DOM_Class.prototype.constructor = DOM_Class;
//~ class DOM_Class{
    //~ constructor() {
        
    //~ }
//~ }

DOM_Class.debug = false;
DOM_Class.elementsPool = {};
DOM_Class.focusedElement = null;
DOM_Class.dom_parser = new DOMParser();

DOM_Class._currentGlobalCursor = '';

DOM_Class.RELATIVE = 'relative';
DOM_Class.ABSOLUTE = 'absolute';

// write html code inside a div and make sure scripts are executed
DOM_Class.WriteHtml = function(domTarget , htmlData, append=false, before=false){

    let target = DOM_Class.GetDomElement(domTarget);

    if(target){
        if (append){
            target.innerHTML += htmlData;
        } else if (before){
            target.innerHTML = htmlData + target.innerHTML;
        } else {
            target.innerHTML = htmlData;
        }
        

        // when append, detect script that was present before and trig them again
        let scripts = target.querySelectorAll("script");
        for(let i=0; i < scripts.length; i++){

            DOM_Class.AddScriptTag(scripts[i] , i);

        }

    }else{
        console.warn('Cannot find dom target ',domTarget);
    }
};

DOM_Class.AddScriptTag = function(scriptTag , delay){
    if(scriptTag.hasAttribute('defer')){
        if(!delay) {
            delay = 1;
        }
        setTimeout(function(){ DOM_Class.InsertScriptTag(scriptTag); } , 50 + delay);
    }else{
        DOM_Class.InsertScriptTag(scriptTag);
    }
};

DOM_Class.InsertScriptTag = function(scriptTag){

    if(scriptTag.hasAttribute('src')){
        let src = scriptTag.getAttribute('src');
        setTimeout(function(){ scriptTag.remove(); } , 100);

        return DOM_Class.LoadScript(src);

    }else{
        // console.log(scriptTag, scriptTag.innerHTML);
        if(!scriptTag.evaldone){
            eval(scriptTag.innerHTML || scriptTag.text);
            scriptTag.evaldone = true;

            DOM_Class.RemoveElement(scriptTag);
        }
    }

    return true;
};

DOM_Class.reload_page = function(url){

    if(GENERICS_Class.IsEmpty(url) && GENERICS_Class.IsString(this.url)) url = this.url;

    if(GENERICS_Class.IsString(url)){
        if(url === CONSTANTS.reload_noparams){
            document.location = document.location.origin + document.location.pathname;
        }else{
            document.location = url;
        }
    }else{
        document.location.reload();
    }
};

DOM_Class.MoveToHeader = function(id){

    let obj = document.getElementById(id);

    if(obj){
        let type = obj.tagName.toLowerCase();
        let attr_name = '';
        let ref_val = '';

        switch(type){
            case 'script':
                attr_name = 'src';
            break;

            case 'link':
                attr_name = 'href';
            break;

            default:
                console.warn('!!!');
                return false;
        }

        ref_val = obj.getAttribute(attr_name);

        let elements = document.head.getElementsByTagName(type);

        for(let i = 0 ; i < elements.length ; i++){
            let s = elements[i];
            if(s.getAttribute(attr_name) == ref_val){
                if(DOM_Class.debug){
                    console.log('script ',url,' already in header');
                }
                obj.remove();
                return false;
            }
        }
        document.head.appendChild(obj);
    }
};

DOM_Class.LoadScript = function(url){
    let scripts = document.head.getElementsByTagName("script");

    for(let i = 0 ; i < scripts.length ; i++){
        let s = scripts[i];
        if(s.getAttribute('src') == url){
            if(DOM_Class.debug){
                console.log('script ',url,' already in header');
            }
            return false;
        }
    }

    let scriptTag = DOM_Class.CreateElement('SCRIPT');
    scriptTag.onload = function(){
        if(DOM_Class.debug){
            console.log(url , 'loaded');
        }
    };
    scriptTag.src = url;
    document.head.appendChild(scriptTag);
    return true;
};

// 'multiple' allow to retrieve all the elements and not just the first one
DOM_Class.StringToDom = function(str, multiple=false, activScript=false){
    let res = DOM_Class.dom_parser.parseFromString(str,'text/html');
    if (activScript) {
        let newDoc = document.createDocumentFragment();
        while(res.body.firstChild){
            newDoc.appendChild(res.body.firstChild);
        }

        let scripts = newDoc.querySelectorAll('script');
        for (let i = 0; i < scripts.length; i++){
            let parent = scripts[i].parentElement || newDoc;
            let newScript = document.createElement('script');
            if (scripts[i].src) {
                newScript.src = scripts[i].src;
            } else {
                newScript.textContent = scripts[i].textContent;
            }
            parent.replaceChild(newScript, scripts[i]);
        }
        res = newDoc;
        if (!multiple) return res.firstChild;
        else return res.childNodes;
    } else {
        if (!multiple) return res.firstChild.lastChild.firstChild;
        else return res.firstChild.lastChild.childNodes;
    }
};

DOM_Class.HideElement = function(element){
    if(!element._hidden){
        if(element.style.display != 'none'){
            element._originalVisibility = element.style.display;
        }else{
            element._originalVisibility = '';
        }

    }

    element.style.display = 'none';
    element._hidden = true;
};

DOM_Class.ShowElement = function(element , forceVisibilityValue){

    if(element._hidden){
        if(forceVisibilityValue){
            element.style.display = forceVisibilityValue;
        }else{
            element.style.display = element._originalVisibility;
        }

    }else{
        //Get the value of style attribute
        var originalStyle = element.getAttribute('style') || '';

        //var regex = new RegExp(/(width:|height:).+?(;[\s]?|$)/g);
        var regex = new RegExp(/(display:).+?(;[\s]?|$)/g);

        //Replace matches with null
        var modStyle = originalStyle.replace(regex, '');

        element.setAttribute('style', modStyle);

    }
    element._hidden = false;

};

DOM_Class.IsSameElement = function(a,b){

    //~ if(a && b && a._classID === b._classID){
        //~ return true;
    //~ }

    return Object.is(a,b);
};

DOM_Class.FindChildByClassName = function(parentElement,className){

    for(let i = 0; i < parentElement.childNodes.length; i++) {
        let child = parentElement.childNodes[i];
        if(child.classList.contains(className)){
            return child;
        }
    }

    return null;
};

DOM_Class.FindAllChildrenByClassName = function(parentElement,className){
    let result = [];
    for(let i = 0; i < parentElement.childNodes.length; i++) {
        let child = parentElement.childNodes[i];
        if(child.classList && child.classList.contains(className)){
            result.push(child);
        }
    }

    return result;
};

DOM_Class.FindChildIndex = function(parentElement,childElement){
    let result = [];
    for(let i = 0; i < parentElement.childNodes.length; i++) {
        if(parentElement.childNodes[i] === childElement) return i;
    }

    return -1;
};

DOM_Class.GetDomElement = function(domIdOrObject){
    if(GENERICS_Class.IsObject(domIdOrObject)){
        if(GENERICS_Class.IsDomObject(domIdOrObject)){
            return domIdOrObject;
        }else if(GENERICS_Class.IsDomObject(domIdOrObject.domElement)){
            return domIdOrObject.domElement;
        }else{
            return null;
        }

    }else if(GENERICS_Class.IsString(domIdOrObject)){
        if(!domIdOrObject){
            return null;
        }
        return document.getElementById(domIdOrObject);
    }

    return null;
};

DOM_Class.GetDomElementByName = function(domNameOrObject){
    if(GENERICS_Class.IsObject(domNameOrObject)){
        return domNameOrObject;
    }else if(GENERICS_Class.IsString(domNameOrObject)){
        if(!domNameOrObject){
            return null;
        }
        return document.getElementByName(domNameOrObject);
    }

    return null;
};

DOM_Class.GetDomElementIndex = function(node) {
    let index = 0;
    while ( (node = node.previousElementSibling) ) {
        index++;
    }
    return index;
};

DOM_Class.CreateElement = function(tagName,params,content,parent){

    var element;
    params = params || {};
    tagName = tagName.toUpperCase();

    var svg_element = tagName.indexOf('SVG_')===0;

    if(!DOM_Class.elementsPool[tagName]){
        DOM_Class.elementsPool[tagName] = [];
    }
    let xmlns = 'http:/'+'/www.w3.org/2000/svg';
    if(DOM_Class.elementsPool[tagName].length){
        element = DOM_Class.elementsPool[tagName].pop();

    }else if(tagName == 'SVG'){

        element = document.createElementNS(xmlns, 'svg');
        element.setAttribute('xmlns', xmlns);
        element.setAttribute('version', '1.2');

    }else if(svg_element){
        tagName = tagName.substring(4,tagName.length).toLowerCase();

        element = document.createElementNS(xmlns, tagName);

    }else{
        element = document.createElement(tagName);
    }

    var attr_list = element.attributes;
    for(let attr in attr_list){
        if(attr!='xmlns' && attr!='version'){
            element.removeAttribute(attr);
        }
    }

    if(svg_element){
        for(let attr in params){
            element.setAttributeNS(null,attr,params[attr]);
        }

    }else{
        for(let attr in params){
            if (tagName == 'SVG') {
                element.setAttribute(attr,params[attr]);
            } else if(element[attr] !== undefined){
                element[attr] = params[attr];
            }else{
                element.setAttribute(attr,params[attr]);
            }
        }
    }

    element._customClasses = {};
    element._eventListeners = [];

    if(content){
        if(GENERICS_Class.IsDomObject(content)){
            element.appendChild(content);
        }else if (GENERICS_Class.IsString(content)){
            element.innerHTML = content;
        } else {
            element.append(content);
        }
    }

    if(GENERICS_Class.IsDomObject(parent)){
        parent.appendChild(element);
    }

    return element;
};

// add content to a dom element
// it can be an other dom element, a string or an array of those elements
// or an object/class who got an attribute domElement that point to a dom element
DOM_Class.AppendContent = function(domElement , content){

    if(GENERICS_Class.IsDomObject(content)){
        domElement.appendChild(content);

    }else if( GENERICS_Class.IsFilledArray(content) ){
        for(let i in content){
            DOM_Class.AppendContent(domElement , content[i]);
        }

    }else if(GENERICS_Class.IsFilledObject(content)){
        for(let i in content){
            if(content[i].domElement){
                DOM_Class.AppendContent(domElement , content[i].domElement);
            }
        }
    }else{
        DOM_Class.WriteHtml(domElement,content,true);
        //~ domElement.innerHTML += content;
    }

};

DOM_Class.RemoveElement = function(element){
    if(!DOM_Class.elementsPool[element.tagname]){
        DOM_Class.elementsPool[element.tagname] = [];
    }

    // reset all CSS properties
    element.className = '';

    let s = element.style;
    for (let prop in s ) {
        s[prop] = '';
    }

    let cc = element._customClasses;
    for (let prop in cc ) {
        delete(cc[prop]);
    }

    // remove all events
    EVENTS_Class.RemoveAllEvents(element);

    // put in pool list
    DOM_Class.elementsPool[element.tagname].push(element);

    // recursive cleaning
    let ttt = 0;
    if (element.childNodes){
        while(element.childNodes.length > 0 && ttt < 1000){
            DOM_Class.RemoveElement(element.childNodes[0]);
            ttt++;
        }
        if(ttt >=1000){
            debugger;
        }
    }

    element.innerHTML = '';

    // remove from DOM
    if(element.parentNode){
        element.parentNode.removeChild(element);
    }
};

// link a class instance to a dom element
// to eventually redirect all mouse events to that class
DOM_Class.AddClassObject = function(element, type, object){
    if(!element._customClasses){
        element._customClasses = {};
    }
    element._customClasses[type] = object;
};

DOM_Class.GetClassObject = function(element, type){
    if(!element._customClasses){
        element._customClasses = {};
    }

    if(!type){
        let keys = Object.keys(element._customClasses);
        let list = [];
        if(keys.length > 0){
            for(let k in keys){
                list.push(element._customClasses[keys[k]]);
            }
        }
        return list;
    }
    return element._customClasses[type];
};

DOM_Class.CloneDomElement = function(domElement , recursive){

    let newElement = domElement.cloneNode();

    if(recursive){
        for(let i = 0 ; i < domElement.childNodes.length ; i++){
            let child = DOM_Class.CloneDomElement(domElement.childNodes[i] , recursive);
            newElement.appendChild(child);
        }
    }

    if(GENERICS_Class.IsFilledArray(domElement._eventListeners)){
        let lst = domElement._eventListeners;

        if(!GENERICS_Class.IsArray(newElement._eventListeners)){
            newElement._eventListeners = [];
        }

        for(let i = 0 ; i < lst.length ; i++){
            EVENTS_Class.AddEvent(newElement , lst[i].event , lst[i].callback);
        }
    }

    if(GENERICS_Class.IsFilledArray(domElement._customClasses)){
        // TODO
        // add a Clong() function in classes

        let lst = domElement._customClasses;

        if(!GENERICS_Class.IsArray(newElement._customClasses)){
            newElement._customClasses = [];
        }

        for(let i = 0 ; i < lst.length ; i++){
            if(GENERICS_Class.IsFunction(lst[i].clone)){
                lst[i].Clone(newElement); // specify the new dom element to the Clone function
            }else{
                console.log('no clone method found on ',lst[i]);
                debugger;
            }
        }
    }
    
    if (domElement._validator) newElement._validator = domElement._validator;

    return newElement;
};

//---------------------------------------------------------------------

DOM_Class.CanHaveCSS = function(domElement){
    if(GENERICS_Class.IsDomObject(domElement)){
        return domElement.classList != undefined;
    }
    return false;
};

DOM_Class.HasClass = function (domElement , className){
    if(DOM_Class.CanHaveCSS(domElement)){
        return domElement.classList.contains(className);
    }
    return false;
};

DOM_Class.AddClass = function (domElement , className){
    if(DOM_Class.CanHaveCSS(domElement)){
        domElement.classList.add(className);
    }
};

DOM_Class.RemoveClass = function (domElement , className){
    if(DOM_Class.CanHaveCSS(domElement)){
        domElement.classList.remove(className);
    }
};

DOM_Class.ReplaceClass = function (domElement , classNameToReplace, NewClassName){
    if(DOM_Class.CanHaveCSS(domElement)){
        domElement.classList.replace(classNameToReplace,NewClassName);
    }
};

DOM_Class.ToggleClass = function (domElement , className , forceState){
    if(DOM_Class.CanHaveCSS(domElement)){
        domElement.classList.toggle(className , forceState);
    }
};

DOM_Class.ReplaceElement = function(originalElement , newElement){
    // Be careful, do not recreate the old events!
    if(GENERICS_Class.IsString(newElement)){
        originalElement.outerHTML = newElement;
        
    }else if(GENERICS_Class.IsDomObject(newElement)){
        DOM_Class.InsertAfter( newElement , originalElement);
        DOM_Class.RemoveElement(originalElement);
    }

};

DOM_Class.InsertBefore = function(domElement , berforeMe){
    berforeMe.insertAdjacentElement('beforebegin',domElement);
    DOM_Class._SetRectDirty(domElement);
    DOM_Class._SetRectDirty(berforeMe);
};

DOM_Class.InsertAfter = function(domElement , afterMe){
    afterMe.insertAdjacentElement('afterend',domElement);
    DOM_Class._SetRectDirty(domElement);
    DOM_Class._SetRectDirty(afterMe);
};

// give the absolute rect of the element, in page coordinates
DOM_Class.GetGlobalRect = function(domElement , forceRefresh){
    if(!domElement){
        return null;
    }

    if(domElement._RectReady && !forceRefresh){
        return domElement._ComputedStyle.rect;
    }

    if(domElement === document){
        domElement = document.body;
    }


    if(!domElement.getBoundingClientRect){
        debugger;
    }

    let rect = domElement.getBoundingClientRect();

    if(domElement == document.body){
        rect = {left:rect.left , top:rect.top , right:rect.right , bottom:rect.bottom , width:rect.width , height:rect.height};
        if(rect.height === 0){
            rect.bottom = window.innerHeight;
            rect.height = window.innerHeight;
        }

        if(rect.width === 0){
            rect.right = window.innerWidth;
            rect.width = window.innerWidth;
        }
    }
    
    let t = '';
    let sx = window.scrollX || (((t = document.documentElement) || (t = document.body.parentNode)) && typeof t.ScrollLeft == 'number' ? t : document.body).ScrollLeft || 0;
    let sy = window.scrollY || (((t = document.documentElement) || (t = document.body.parentNode)) && typeof t.ScrollTop == 'number' ? t : document.body).ScrollTop || 0;
    if(!domElement._ComputedStyle){
        domElement._ComputedStyle = {};
    }
    if(!domElement._ComputedStyle.rect){
        domElement._ComputedStyle.rect = {};
    }

    domElement._ComputedStyle.rect.left     = rect.left + sx;
    domElement._ComputedStyle.rect.top      = rect.top + sy;
    domElement._ComputedStyle.rect.right    = rect.right + sx;
    domElement._ComputedStyle.rect.bottom   = rect.bottom + sy;
    domElement._ComputedStyle.rect.width    = rect.right - rect.left;
    domElement._ComputedStyle.rect.height   = rect.bottom - rect.top;
    domElement._ComputedStyle.rect.x        = domElement._ComputedStyle.rect.left;
    domElement._ComputedStyle.rect.y        = domElement._ComputedStyle.rect.top;

    domElement._RectReady = true;

    return domElement._ComputedStyle.rect;
};

// convert page coordinates to the element inside local coordinates
DOM_Class.GetGlobalToLocal = function(domElement , x , y , advanced){
    let style = DOM_Class.GetStyle(domElement);

    x = x - style.rect.left - style.BL;
    y = y - style.rect.top - style.BT;

    if(advanced){
        return {'x':x , 'y':y, 'ratiox':x/style.rect.width , 'ratioy':y/style.rect.height};
    }else{
        return {'x':x , 'y':y};
    }
};

DOM_Class.GetPosition = function(domElement){
    return {'x':domElement.offsetLeft , 'y':domElement.offsetTop};
};

DOM_Class.GetRelativePosition = function(domElement){
    return {'x':domElement.left , 'y':domElement.top};
};


DOM_Class.GetGlobalPosition = function(domElement){
    let rect = DOM_Class.GetGlobalRect(domElement);
    return {'x' : rect.x , 'y' : rect.y};
};


// test if the givent global x,y coordinates are inside the element global rect
DOM_Class.PointInsideElement = function( x , y , domElement){
    let rect = DOM_Class.GetGlobalRect(domElement,true);
    return (x >= rect.left && x <= rect.right && y >= rect.top && y <= rect.bottom);
};

// return data about the given point an the specified dom element
DOM_Class.PointInsideElementData = function( x , y , domElement){
    let rect = DOM_Class.GetGlobalRect(domElement);
    let inside = (x >= rect.left && x <= rect.right && y >= rect.top && y <= rect.bottom);
    let localX = x - rect.left;
    let localY = y - rect.top;

    return {'inside':inside , 'rect':rect , 'localX':localX , 'localY':localY};
};

// set the position of the element in page coordinates
DOM_Class.SetGlobalPosition = function(domElement , x , y){
    let parentElement = domElement.parentNode;

    let parentStyle = DOM_Class.GetStyle(parentElement);
    let style = DOM_Class.GetStyle(domElement);
    
    if(style.POS != 'fixed'){
        if (parentStyle.POS == 'relative'){
            x -= parentStyle.rect.left + parentStyle.BL + style.ML;
            y -= parentStyle.rect.top + parentStyle.BT + style.MT;
        }else{
            let t = '';
            let sx = window.scrollX || (((t = document.documentElement) || (t = document.body.parentNode)) && typeof t.ScrollLeft == 'number' ? t : document.body).ScrollLeft || 0;
            let sy = window.scrollY || (((t = document.documentElement) || (t = document.body.parentNode)) && typeof t.ScrollTop == 'number' ? t : document.body).ScrollTop || 0;
            x -= sx;
            y -= sy;
        }
    }

    if(style.POS == 'relative'){

        DOM_Class.SetPosition(domElement ,0 , 0);
        let newStyle = DOM_Class.GetStyle(domElement);

        x -= newStyle.rect.x - (parentStyle.rect.left + parentStyle.BL);
        y -= newStyle.rect.y - (parentStyle.rect.top + parentStyle.BT);
    }
    
    while(parentElement.tagName != 'BODY'){
        if (parentElement.scrollTop > 0){
            y += parentElement.scrollTop;
        }
        if (parentElement.scrollLeft > 0){
            x += parentElement.scrollLeft;
        }
        parentElement = parentElement.parentElement;
    }
    //for page.js
    let snapLeft = style._snapEdge.left;
    let snapTop = style._snapEdge.top;
    let snapRight = style._snapEdge.right;
    let snapBottom = style._snapEdge.bottom;

    if(snapLeft){
        DOM_Class.UnsnapAbsoluteLeft(domElement);
    }
    if(snapTop){
        DOM_Class.UnsnapAbsoluteTop(domElement);
    }
    if(snapRight){
        DOM_Class.UnsnapAbsoluteRight(domElement);
    }
    if(snapBottom){
        DOM_Class.UnsnapAbsoluteBottom(domElement);
    }

    DOM_Class.SetPosition(domElement ,x , y);

    if(snapLeft){
        DOM_Class.SnapAbsoluteLeft(domElement , snapLeft);
    }
    if(snapTop){
        DOM_Class.SnapAbsoluteTop(domElement , snapTop);
    }

    if(snapRight){
        DOM_Class.SnapAbsoluteRight(domElement , snapRight);
    }
    if(snapBottom){
        DOM_Class.SnapAbsoluteBottom(domElement , snapBottom);
    }
    //...
};

// set the rect left position, in page coordinates
DOM_Class.SetGlobalLeft = function(domElement , newLeft){
    let style = DOM_Class.GetStyle(domElement);
    let offset = newLeft - style.rect.left;

    let parentElement = domElement.parentNode;
    
    parentElement._RectReady = false;
    let parentStyle = DOM_Class.GetStyle(parentElement);

    if(style.POS != 'fixed'){
        newLeft -= parentStyle.rect.left + parentStyle.BL + style.ML;
    }else{
        let t = '';
        let sx = window.scrollX || (((t = document.documentElement) || (t = document.body.parentNode)) && typeof t.ScrollLeft == 'number' ? t : document.body).ScrollLeft || 0;
        newLeft -= sx;
        console.log(newLeft);
    }

    if(style.POS == 'relative'){

        DOM_Class.SetPosition(domElement ,0 , parseInt(domElement.style.top));
        let newStyle = DOM_Class.GetStyle(domElement);

        newLeft -= newStyle.rect.x - (parentStyle.rect.left + parentStyle.BL) - style.ML;
        console.log(newLeft);

    }

    switch(style._snapEdge.left){
        case 'rem':
            domElement.style.left = DOM_Class.PxToEm(newLeft , domElement.parentNode , true);
        break;

        case 'em':
            domElement.style.left = DOM_Class.PxToEm(newLeft , domElement.parentNode , true);
        break;

        case '%':
            if(newLeft < 0){
                // overstep the border
                DOM_Class.SetLeft(domElement , newLeft);
            }else{
                let parent_innerwidth = parentStyle.rect.width - parentStyle.BH;
                let leftPercent = ((newLeft / parent_innerwidth)*100).toFixed(3);
                domElement.style.left = leftPercent+'%';
            }

        break;

        default:
            DOM_Class.SetLeft(domElement , newLeft);

            if(style._snapCenter.horizontal){
                DOM_Class.SetHorizontalPercentagePosition(domElement);
            }
        break;
    }

    let newWidth = style.rect.width - offset;

    if(style._snapEdge.right){

        if(style._snapEdge.left){
            domElement.style.width = 'auto';
        }else{
            DOM_Class.SetGlobalWidth(domElement , newWidth);
            domElement.style.left = 'auto';
        }

    }else if(style.POS != 'fixed'){

        DOM_Class.SetGlobalWidth(domElement , newWidth);
    }

    DOM_Class._SetRectDirty(domElement);
};

// set the rect top position, in page coordinates
DOM_Class.SetGlobalTop = function(domElement , newTop){

    let style = DOM_Class.GetStyle(domElement);
    let offset = newTop - style.rect.top;

    let parentElement = domElement.parentNode;

    let parentStyle = DOM_Class.GetStyle(parentElement);

    if(style.POS != 'fixed'){
        newTop -= parentStyle.rect.top + parentStyle.BT + style.MT;
    }else{
        let t = '';
        let sy = window.scrollY || (((t = document.documentElement) || (t = document.body.parentNode)) && typeof t.ScrollTop == 'number' ? t : document.body).ScrollTop || 0;
        newTop -= sy;
    }

    if(style.POS == 'relative'){
        DOM_Class.SetPosition(domElement , parseInt(domElement.style.left) , 0);
        let newStyle = DOM_Class.GetStyle(domElement);

        newTop -= newStyle.rect.y - (parentStyle.rect.top + parentStyle.BT) - style.MT;
    }

    switch(style._snapEdge.top){
        case 'rem':
            domElement.style.top = DOM_Class.PxToEm(newTop , domElement.parentNode , true);
        break;

        case 'em':
            domElement.style.top = DOM_Class.PxToEm(newTop , domElement.parentNode , true);
        break;

        case '%':
            if(newTop < 0){
                // overstep border
                DOM_Class.SetTop(domElement , newTop);
            }else{
                let parent_innerheight = parentStyle.rect.height - parentStyle.BV;
                let topPercent = ((newTop / parent_innerheight)*100).toFixed(3);
                domElement.style.top = topPercent+'%';
            }

        break;

        default:

            DOM_Class.SetTop(domElement , newTop);

            if(style._snapCenter.vertical){
                DOM_Class.SetVerticalPercentagePosition(domElement);
            }

        break;
    }

    let newHeight = style.rect.height - offset;

    if(style._snapEdge.bottom){

        if(style._snapEdge.top){
            domElement.style.height = 'auto';
        }else{
            DOM_Class.SetGlobalHeight(domElement , newHeight);
            domElement.style.top = 'auto';
        }

    }else if(style.POS != 'fixed'){
        DOM_Class.SetGlobalHeight(domElement , newHeight);
    }


    DOM_Class._SetRectDirty(domElement);
};

// set the rect right position, in page coordinates
DOM_Class.SetGlobalRight = function(domElement , newRight){
    let style = DOM_Class.GetStyle(domElement);
    let offset = newRight - style.rect.right;

    let newWidth = style.rect.width + offset;

    if(style._snapEdge.right && style.POS != 'relative'){
        let parentStyle = DOM_Class.GetStyle(domElement.parentNode);

        let pxValue = (parentStyle.rect.right - (style.rect.left + style.rect.width + offset + parentStyle.BR + style.MR));

        switch(style._snapEdge.right){
            case 'rem':
                domElement.style.right = DOM_Class.PxToEm(pxValue , domElement.parentNode , true);
            break;

            case 'em':
                domElement.style.right = DOM_Class.PxToEm(pxValue , domElement.parentNode , true);
            break;

            case '%':
                if(pxValue < 0){
                    // overstep border
                    domElement.style.right = pxValue+'px';
                }else{
                    let parent_innerwidth = parentStyle.rect.width - parentStyle.BH;
                    let rightPercent = ((1 - (style.rect.right - (parentStyle.rect.left + parentStyle.BL) + offset) / parent_innerwidth)*100).toFixed(3);
                    domElement.style.right = rightPercent+'%';
                }

            break;

            default:
                domElement.style.right = pxValue + 'px';
            break;
        }

        if(style._snapEdge.left){
            domElement.style.width = 'auto';
        }else{
            DOM_Class.SetGlobalWidth(domElement , newWidth);
        }


    }else{

        DOM_Class.SetGlobalWidth(domElement , newWidth);
    }

    DOM_Class._SetRectDirty(domElement);
};

// set the rect bottom position, in page coordinates
DOM_Class.SetGlobalBottom = function(domElement , newBottom){
    let style = DOM_Class.GetStyle(domElement);
    let offset = newBottom - style.rect.bottom;

    let newHeight = style.rect.height + offset;

    if(style._snapEdge.bottom && style.POS != 'relative'){
        let parentStyle = DOM_Class.GetStyle(domElement.parentNode);

        let pxValue = (parentStyle.rect.bottom - (style.rect.top + style.rect.height + offset + parentStyle.BB + style.MB));

        switch(style._snapEdge.bottom){
            case 'rem':
                domElement.style.bottom = DOM_Class.PxToEm(pxValue , domElement.parentNode , true);
            break;

            case 'em':
                domElement.style.bottom = DOM_Class.PxToEm(pxValue , domElement.parentNode , true);
            break;

            case '%':

                if(pxValue < 0){
                    // overstep border
                    domElement.style.bottom = pxValue+'px';
                }else{
                    let parent_innerheight = parentStyle.rect.height - parentStyle.BV;
                    let bottomPercent = ((1 - (style.rect.bottom - (parentStyle.rect.top + parentStyle.BT) + offset) / parent_innerheight)*100).toFixed(3);
                    domElement.style.bottom = bottomPercent+'%';
                }
            break;

            default:
                domElement.style.bottom = pxValue + 'px';
            break;
        }


        if(style._snapEdge.top){
            domElement.style.height = 'auto';
        }else{
            DOM_Class.SetGlobalHeight(domElement , newHeight);
        }

    }else{

        DOM_Class.SetGlobalHeight(domElement , newHeight);
    }

    DOM_Class._SetRectDirty(domElement);
};

// set the outside width of the element, taking the border and padding in account
DOM_Class.SetGlobalWidth = function(domElement , newWidth){
    let style = DOM_Class.GetStyle(domElement);

    newWidth -= style.BH + style.PH;

    if(style.POS == 'relative'){
        switch(style._width_unit){
            case 'percent':
                let parentStyle = DOM_Class.GetStyle(domElement.parentNode);
                let percent = (newWidth / parseFloat(parentStyle.all.width)) * 100;
                // correction of rounding errors
                if(percent % 1 < 0.08){
                    percent = Math.round(percent*10)/10;
                }
                    domElement.style.setProperty('width' , Math.min(100,percent) + '%');
            break;

            case 'rem':
                let remWidth = DOM_Class.PxToEm(newWidth);
                domElement.style.setProperty('width' , remWidth + 'rem');
            break;

            case 'em':
                let emWidth = DOM_Class.PxToEm(newWidth);
                domElement.style.setProperty('width' , emWidth + 'em');
            break;

            case '':
            case 'auto':
            case 'max-content':
            case 'min-content':
            case 'fit-content':
            case 'stretch':
            case 'unset':
            case 'inherit':
                domElement.style.setProperty('width' , style._width_unit);
            break;

            case 'px':
                domElement.style.setProperty('width' , newWidth + 'px');
            break;

            default:
                domElement.style.setProperty('width' , newWidth + 'px');
            break;
        }
    }else{
        domElement.style.setProperty('width' ,newWidth + 'px');
    }

    DOM_Class._SetRectDirty(domElement);
};

// set the outside width of the element, taking the border and padding in account
DOM_Class.SetGlobalMinWidth = function(domElement , newWidth){
    let style = DOM_Class.GetStyle(domElement);

    switch(style._minwidth_unit){
        case 'percent':
            let parentStyle = DOM_Class.GetStyle(domElement.parentNode);
            let percent = (newWidth / parseFloat(parentStyle.all.width)) * 100;
            domElement.style.setProperty('min-width' , Math.min(100,percent) + '%');
        break;

        case 'rem':
            let remWidth = DOM_Class.PxToEm(newWidth);
            domElement.style.setProperty('min-width' , remWidth + 'rem');
        break;

        case 'em':
            let emWidth = DOM_Class.PxToEm(newWidth);
            domElement.style.setProperty('min-width' ,emWidth + 'em');
        break;

        case 'auto':
            domElement.style.setProperty('min-width' , 'auto');
        break;

        case 'px':
            domElement.style.setProperty('min-width' , newWidth + 'px');
        break;

        default:
            domElement.style.setProperty('min-width' , newWidth + 'px');
        break;
    }


    DOM_Class._SetRectDirty(domElement);
};


// set the outside height of the element, taking the border and padding in account
DOM_Class.SetGlobalHeight = function(domElement , newHeight){

    let style = DOM_Class.GetStyle(domElement);

    if(newHeight !== undefined && newHeight != ''){
        newHeight -= style.BV + style.PV;
        domElement.style.setProperty('height' , newHeight + 'px');
    }else{
        domElement.style.setProperty('height' , '');
    }

    DOM_Class._SetRectDirty(domElement);
};

// set the outside rect of the element, in page coordinates
DOM_Class.SetGlobalRect = function(domElement , left , top , right , bottom){

    if(GENERICS_Class.IsObject(left)){
        top = left.top;
        right = left.right;
        bottom = left.bottom;
        left = left.left;
    }

    DOM_Class.SetGlobalLeft(domElement , left);
    DOM_Class.SetGlobalTop(domElement , top);

    DOM_Class.SetGlobalRight(domElement , right);
    DOM_Class.SetGlobalBottom(domElement , bottom);

    DOM_Class._SetRectDirty(domElement);
};

// set the width, in local coordinates
DOM_Class.SetWidth = function(domElement , w){
    domElement.style.setProperty('width' , w + 'px');
    DOM_Class._SetRectDirty(domElement);
};

// set the height, in local coordinates
DOM_Class.SetHeight = function(domElement , h){
    domElement.style.setProperty('height' , h + 'px');
    DOM_Class._SetRectDirty(domElement);
};


// set the left/x position, in local coordinates
DOM_Class.SetLeft = function(domElement , x){
    domElement.style.setProperty('left' , x + 'px');
    DOM_Class._SetRectDirty(domElement);
};

// set the top/x position, in local coordinates
DOM_Class.SetTop = function(domElement , y){
    domElement.style.setProperty('top' , y + 'px');
    DOM_Class._SetRectDirty(domElement);
};

// set the width and height, in local coordinates
DOM_Class.SetSize = function(domElement , w , h){
    domElement.style.setProperty('width' , w + 'px');
    domElement.style.setProperty('height' , h + 'px');

    DOM_Class._SetRectDirty(domElement);
};

DOM_Class.GetGlobalWidth = function(domElement){
    if(!domElement._RectReady){
        domElement._ComputedStyle.rect = DOM_Class.GetGlobalRect(domElement);
    }

    return domElement._ComputedStyle.rect.width;
};

DOM_Class.GetGlobalHeight = function(domElement){
    if(!domElement._RectReady){
        domElement._ComputedStyle.rect = DOM_Class.GetGlobalRect(domElement);
    }

    return domElement._ComputedStyle.rect.height;
};

// set the position, in local coordinates
// use DOM_Class.RELATIVE or DOM_Class.ABSOLUTE for specify the cssPosition parameters
DOM_Class.SetPosition = function(domElement , x , y , cssPosition){
    if( cssPosition !== undefined){
        domElement.style.position = cssPosition; // relative or absolute
    }

    if(GENERICS_Class.IsObject(x) && x.x){
        y = x.y;
        x = x.x;
    }

    if(x!==undefined){
        domElement.style.left = Math.round(x)+'px';

        if(domElement._ComputedStyle && domElement._ComputedStyle._snapCenter && domElement._ComputedStyle._snapCenter.horizontal){
            DOM_Class._SetRectDirty(domElement);
            DOM_Class.SetHorizontalPercentagePosition(domElement);
        }
    }
    if(y!==undefined){
        domElement.style.top = Math.round(y)+'px';

        if(domElement._ComputedStyle && domElement._ComputedStyle._snapCenter && domElement._ComputedStyle._snapCenter.vertical){
            DOM_Class._SetRectDirty(domElement);
            DOM_Class.SetVerticalPercentagePosition(domElement);
        }
    }

    DOM_Class._SetRectDirty(domElement);
};

// alignment factor from 0 (left) to 1(right)
DOM_Class.SetAlignment = function(domElement , horizontal , vertical , parentNode , fromWindow = false){
    let parentRect;
    if (fromWindow){
        parentRect = {'left': 0, 'top': 0, 'right': 0, 'bottom': 0, 'width': window.innerWidth, 'height': window.innerHeight};
    } else {
        if(!GENERICS_Class.IsObject(parentNode)) parentNode = domElement.parentNode;
        parentRect = DOM_Class.GetGlobalRect(parentNode, true);
    }
    let rect = DOM_Class.GetGlobalRect(domElement, true);
    let pos = DOM_Class.GetStyleValue(domElement, 'position');
    if (parentNode.tagName == 'BODY' && pos == 'fixed') parentRect = {'left': 0, 'top': 0, 'right': 0, 'bottom': 0, 'width': window.innerWidth, 'height': window.innerHeight};

    let left = parentRect.left + (parentRect.width - rect.width) * horizontal;
    let top = parentRect.top + (parentRect.height - rect.height) * vertical;

    DOM_Class.SetGlobalPosition(domElement, left, top);

    let style = DOM_Class.GetStyle(domElement);

    DOM_Class._SetRectDirty(domElement);

    if(style._snapCenter.horizontal){
        DOM_Class.SetHorizontalPercentagePosition(domElement);
    }

    if(style._snapCenter.vertical){
        DOM_Class.SetVerticalPercentagePosition(domElement);
    }
};

DOM_Class.GetStyleValue = function(domElement , attributeName){
    if(domElement.style[attributeName]){
        return domElement.style[attributeName];
    }
    let style = DOM_Class.GetStyle(domElement);
    let value = style.all.getPropertyValue(attributeName) || undefined;
    return value;
};

// returns the precomputed styles for this element
DOM_Class.GetStyle = function(domElement){

    if(!domElement){
        debugger;
    }

    if(domElement === document){
        domElement = domElement.body;
    }

    if(!domElement._ComputedStyleReady){
        if(DOM_Class.debug){
            console.log('recompute style for ',domElement);
        }

        if(!domElement._ComputedStyle){
            domElement._ComputedStyle = {};
        }

        if(!domElement._RectReady){
            domElement._ComputedStyle.rect = DOM_Class.GetGlobalRect(domElement,true);
        }

        let style = window.getComputedStyle(domElement, '');

        domElement._ComputedStyle.all = style;

        domElement._ComputedStyle.BL = parseInt(style.getPropertyValue('border-left-width')) || 0;
        domElement._ComputedStyle.BT = parseInt(style.getPropertyValue('border-top-width')) || 0;
        domElement._ComputedStyle.BR = parseInt(style.getPropertyValue('border-right-width')) || 0;
        domElement._ComputedStyle.BB = parseInt(style.getPropertyValue('border-bottom-width')) || 0;

        domElement._ComputedStyle.BH = domElement._ComputedStyle.BL + domElement._ComputedStyle.BR;
        domElement._ComputedStyle.BV = domElement._ComputedStyle.BB + domElement._ComputedStyle.BT;

        domElement._ComputedStyle.PL = parseInt(style.getPropertyValue('padding-left')) || 0;
        domElement._ComputedStyle.PT = parseInt(style.getPropertyValue('padding-top')) || 0;
        domElement._ComputedStyle.PR = parseInt(style.getPropertyValue('padding-right')) || 0;
        domElement._ComputedStyle.PB = parseInt(style.getPropertyValue('padding-bottom')) || 0;

        domElement._ComputedStyle.PH = domElement._ComputedStyle.PL + domElement._ComputedStyle.PR;
        domElement._ComputedStyle.PV = domElement._ComputedStyle.PB + domElement._ComputedStyle.PT;

        domElement._ComputedStyle.ML = parseInt(style.getPropertyValue('margin-left')) || 0;
        domElement._ComputedStyle.MT = parseInt(style.getPropertyValue('margin-top')) || 0;
        domElement._ComputedStyle.MR = parseInt(style.getPropertyValue('margin-right')) || 0;
        domElement._ComputedStyle.MB = parseInt(style.getPropertyValue('margin-bottom')) || 0;

        domElement._ComputedStyle.MH = domElement._ComputedStyle.ML + domElement._ComputedStyle.MR;
        domElement._ComputedStyle.MV = domElement._ComputedStyle.MB + domElement._ComputedStyle.MT;

        domElement._ComputedStyle.POS = style.getPropertyValue('position') || 'relative';

        domElement._ComputedStyleReady = true;
        domElement._RectReady = true;
    }

    if(!domElement._RectReady){
        domElement._ComputedStyle.rect = DOM_Class.GetGlobalRect(domElement);
    }
    //page.js 
    if(!domElement._ComputedStyle._snapEdge){
        domElement._ComputedStyle._snapEdge = {};
        domElement._ComputedStyle._snapEdge.top = false;
        domElement._ComputedStyle._snapEdge.left = false;
        domElement._ComputedStyle._snapEdge.right = false;
        domElement._ComputedStyle._snapEdge.bottom = false;
    }

    if(!domElement._ComputedStyle._snapCenter){
        domElement._ComputedStyle._snapCenter = {};
        domElement._ComputedStyle._snapCenter.horizontal = false;
        domElement._ComputedStyle._snapCenter.vertical = false;
    }
    //....

    if(!domElement._ComputedStyle._width_unit){
        let ww = domElement.style.width;
        if(ww.indexOf('px') > 0){
            domElement._ComputedStyle._width_unit = 'px';
        }else if(ww.indexOf('%') > 0){
            domElement._ComputedStyle._width_unit = 'percent';

        }else if(ww.indexOf('rem') > 0){
            domElement._ComputedStyle._width_unit = 'rem';

        }else if(ww.indexOf('em') > 0){
            domElement._ComputedStyle._width_unit = 'em';

        }else{
            domElement._ComputedStyle._width_unit = 'auto';
        }
    }

    if(!domElement._ComputedStyle._minwidth_unit){

        let ww = domElement.style.minWidth;

        if(ww.indexOf('px') > 0){
            domElement._ComputedStyle._minwidth_unit = 'px';
        }else if(ww.indexOf('%') > 0){
            domElement._ComputedStyle._minwidth_unit = 'percent';

        }else if(ww.indexOf('rem') > 0){
            domElement._ComputedStyle._minwidth_unit = 'rem';

        }else if(ww.indexOf('em') > 0){
            domElement._ComputedStyle._minwidth_unit = 'em';

        }else{
            domElement._ComputedStyle._minwidth_unit = 'rem';
        }
    }


    if(!domElement._ComputedStyle._align){
        domElement._ComputedStyle._align = '';
    }

    return domElement._ComputedStyle;
};

// indicates that the styles of the element must be recomputed the next time they are accessed
DOM_Class._SetStyleDirty = function(domElement){
    domElement._ComputedStyleReady = false;
};

// indicates that the rect of the element has to be recomputed
DOM_Class._SetRectDirty = function(domElement){
    domElement._RectReady = false;
    for(let i = 0 ; i < domElement.children.length ; i++){
        DOM_Class._SetRectDirty(domElement.children[i]);
    }
};

DOM_Class.StoreCssRect = function(domElement){

    let style = DOM_Class.GetStyle(domElement);

    if(!style._storedRect) style._storedRect = {};

    if(!style._storedRect[style.POS]){
        if(style.POS == 'relative'){
            style._storedRect[style.POS] = {'left':'' , 'top':'' , 'right':'','bottom':'','width':domElement.style.width , 'height':domElement.style.height};
            return;
        }else{
            style._storedRect[style.POS] = {};
        }
    }

    style._storedRect[style.POS].left  = domElement.style.left;
    style._storedRect[style.POS].top  = domElement.style.top;
    style._storedRect[style.POS].right  = domElement.style.right;
    style._storedRect[style.POS].bottom  = domElement.style.bottom;
    style._storedRect[style.POS].width  = domElement.style.width;
    style._storedRect[style.POS].height  = domElement.style.height;

};

DOM_Class.RestoreCssRect = function(domElement){

    let style = DOM_Class.GetStyle(domElement);

    if(!style._storedRect) style._absRect = {};

    if(style._storedRect[style.POS]){
        domElement.style.left  = style._storedRect[style.POS].left;
        domElement.style.top  = style._storedRect[style.POS].top;
        domElement.style.right  = style._storedRect[style.POS].right;
        domElement.style.bottom  = style._storedRect[style.POS].bottom;
        domElement.style.width  = style._storedRect[style.POS].width;
        domElement.style.height  = style._storedRect[style.POS].height;

    }else if(style.POS == 'relative'){
        domElement.style.left  = '';
        domElement.style.top  = '';
        domElement.style.right  = '';
        domElement.style.bottom  = '';
        domElement.style.width  = domElement.style.width;
        domElement.style.height  = domElement.style.height;
    }
};

DOM_Class.SetStyleValue = function(domElement , attributeName , value){

    let style = DOM_Class.GetStyle(domElement);

    let originalValue = style.all.getPropertyValue(attributeName);

    if(originalValue != value || domElement.style[attributeName] != value){

        domElement.style.setProperty(attributeName , value);
        DOM_Class._SetStyleDirty(domElement);

        if(attributeName == 'display'){
            DOM_Class._SetRectDirty(domElement);
        }
        return true;
    }
    return false;
};

//---------------------------------------------------------------------------------------------------

DOM_Class.LoadCss = function(url){
    let styles = document.head.getElementsByTagName("link");

    for(let i = 0 ; i < styles.length ; i++){
        let s = styles[i];
        if(s.getAttribute('href') == url){
            if(DOM_Class.debug){
                console.log('style ',url,' already in header');
            }
            return false;
        }
    }

    let styleSheetElement = DOM_Class.CreateElement('LINK');

    styleSheetElement.onload = function(){
        if(DOM_Class.debug){
            console.log(url , 'loaded');
        }
    };

    styleSheetElement.setAttribute('type','text/css');
    styleSheetElement.setAttribute('rel','stylesheet');
    styleSheetElement.setAttribute('href',url);

    document.head.appendChild(styleSheetElement);

    return true;
};

DOM_Class.GetStylesheet = function(sheetTitle , sheetMedia, create){
    if(!document.styleSheets) {
        return;
    }

    if(document.getElementsByTagName("head").length === 0) {
        return;
    }

    let styleSheet;
    let mediaType;

    if(document.styleSheets.length > 0) {
        for( let i = 0; i < document.styleSheets.length; i++) {

            if(sheetTitle && document.styleSheets[i].title != sheetTitle) {
                continue;
            }

            let media = document.styleSheets[i].media;
            mediaType = typeof media;

            if(mediaType === "string") {
                if(media === sheetMedia){
                    styleSheet = document.styleSheets[i];
                    break;

                }else if(media === "" || (media.indexOf("screen") != -1)) {
                    styleSheet = document.styleSheets[i];
                }
            } else if(mediaType == "object") {
                if(media === sheetMedia){
                    styleSheet = document.styleSheets[i];
                    break;
                }else if(media.mediaText === "" || (media.mediaText.indexOf("screen") != -1)) {
                    styleSheet = document.styleSheets[i];
                }
            }
        }
    }

    if( styleSheet === undefined && create) {
        // create styleSheet
        let styleSheetElement = DOM_Class.CreateElement('STYLE');
        styleSheetElement.setAttribute('type','text/css');
        styleSheetElement.setAttribute('rel','stylesheet');

        if(sheetMedia){
            styleSheetElement.setAttribute('media',sheetMedia);
        }

        if(sheetTitle){
            styleSheetElement.setAttribute('title',sheetTitle);
        }

        document.head.appendChild(styleSheetElement);

        styleSheet = styleSheetElement.sheet;
    }


    return styleSheet;
};

//create a new css class
DOM_Class.AddCssRule = function(sheetTitle , selector, style, sheetMedia) {
    if(!document.styleSheets) {
        return;
    }

    if(document.getElementsByTagName("head").length === 0) {
        return;
    }

    let styleSheet = null;

    if(GENERICS_Class.IsObject(sheetTitle)){
        styleSheet = sheetTitle;
    }else{
        styleSheet = DOM_Class.GetStylesheet(sheetTitle , sheetMedia);
    }
    

    if( styleSheet === undefined) {

        // create styleSheet
        let styleSheetElement = DOM_Class.CreateElement('STYLE');
        styleSheetElement.setAttribute('type','text/css');
        styleSheetElement.setAttribute('rel','stylesheet');

        if(sheetMedia){
            styleSheetElement.setAttribute('media',sheetMedia);
        }

        if(sheetTitle){
            styleSheetElement.setAttribute('title',sheetTitle);
        }

        document.head.appendChild(styleSheetElement);

        styleSheet = styleSheetElement.sheet;
    }

    let mediaType = typeof styleSheet.media;

    if(mediaType == "string") {
        for( let i = 0; i < styleSheet.rules.length; i++) {
            if(styleSheet.rules[i].selectorText && styleSheet.rules[i].selectorText.toLowerCase() == selector.toLowerCase()) {
                styleSheet.rules[i].style.cssText = style;
                return;
            }
        }

        styleSheet.addRule(selector, style);

    } else if(mediaType == "object") {

        var styleSheetLength = (styleSheet.cssRules) ? styleSheet.cssRules.length : 0;
        for( let i = 0; i < styleSheetLength; i++) {
            if(styleSheet.cssRules[i].selectorText && styleSheet.cssRules[i].selectorText.toLowerCase() == selector.toLowerCase()) {
                styleSheet.cssRules[i].style.cssText = style;
                return;
            }
        }

        styleSheet.insertRule(selector + "{" + style + "}", styleSheetLength);
    }
};

//get a css class for modification
DOM_Class.GetCssRule = function(sheetTitle , ruleName) {
    ruleName = ruleName.toLowerCase();

    if (document.styleSheets) {
        for (let i = 0 ; i < document.styleSheets.length ; i++) {
            let styleSheet = document.styleSheets[i];

            if(sheetTitle && styleSheet.title != sheetTitle){
                continue;
            }

            let j = 0;
            let cssRule = false;
            do {
                if (styleSheet.cssRules) {
                    cssRule = styleSheet.cssRules[j];
                } else {
                    cssRule = styleSheet.rules[j];
                }
                if (cssRule)  {
                    if (cssRule.selectorText.toLowerCase() == ruleName) {
                        return cssRule;
                    }
                }
                j++;
            } while (cssRule);
        }
    }
   return false;
};

DOM_Class.RemoveCssRule = function(sheetTitle , ruleName) {
    ruleName = ruleName.toLowerCase();

    if (document.styleSheets) {
        for (let i = 0 ; i < document.styleSheets.length ; i++) {
            let styleSheet = document.styleSheets[i];

            if(sheetTitle && styleSheet.title != sheetTitle){
                continue;
            }

            let j = 0;
            let cssRule = false;
            do {
                if (styleSheet.cssRules) {
                    cssRule = styleSheet.cssRules[j];
                } else {
                    cssRule = styleSheet.rules[j];
                }
                if (cssRule)  {
                    if (cssRule.selectorText.toLowerCase() == ruleName) {
                        if (styleSheet.cssRules) {
                            styleSheet.deleteRule(j);
                        } else {
                            styleSheet.removeRule(j);
                        }
                        return true;
                    }
                }
                j++;
            } while (cssRule);
        }
    }
   return false;
};


DOM_Class.DisableCssSheet = function(sheetTitle) {
    if(!sheetTitle){
        return false;
    }

    if (document.styleSheets) {
        for (let i = 0 ; i < document.styleSheets.length ; i++) {
            let styleSheet = document.styleSheets[i];

            if(styleSheet.title == sheetTitle){
                styleSheet.disabled = true;
                styleSheet.ownerNode.setAttribute('disabled','disabled');
                return true;
            }
        }
    }
   return false;
};


//activate a css class for modification or delete it
DOM_Class.EnableCssSheet = function(sheetTitle) {

    if(!sheetTitle){
        return false;
    }

    if (document.styleSheets) {
        for (let i = 0 ; i < document.styleSheets.length ; i++) {
            let styleSheet = document.styleSheets[i];

            if(styleSheet.title == sheetTitle){
                styleSheet.disabled = false;
                styleSheet.ownerNode.removeAttribute('disabled');
                return true;
            }
        }
    }
   return false;
};

DOM_Class.SetGlobalCursor = function(cursorValue){
    if(DOM_Class._currentGlobalCursor == cursorValue){
        return false;
    }
    DOM_Class._currentGlobalCursor = cursorValue;
    DOM_Class.AddCssRule('temp_cursor' , '*' , 'cursor:'+cursorValue+' !important;');
    DOM_Class.EnableCssSheet('temp_cursor');
};

DOM_Class.UnsetGlobalCursor = function(){
    DOM_Class._currentGlobalCursor = '';
    DOM_Class.DisableCssSheet('temp_cursor');
};


DOM_Class.DisableMouseEvents = function(domElement){

    //if(!domElement) debugger;

    if(domElement && !domElement._firstPointerEvents){
        domElement._originalPointerEvents = domElement.style.pointerEvents;
        domElement._firstPointerEvents = true;
    }

    domElement.style.pointerEvents = 'none';
};

DOM_Class.EnableMouseEvents = function(domElement){

    //if(!domElement) debugger;

    if(domElement && !domElement._firstPointerEvents){
        domElement._originalPointerEvents = domElement.style.pointerEvents;
        domElement._firstPointerEvents = true;
    }

    domElement.style.pointerEvents = 'auto';
};

DOM_Class.RestoreMouseEvents = function(domElement){

    //if(!domElement) debugger;

    if(domElement && domElement._firstPointerEvents){
        domElement._firstPointerEvents = false;
        domElement.style.pointerEvents = domElement._originalPointerEvents;
    }

};

DOM_Class.MoveToFront = function(domElement){

    if(domElement && !domElement._firstZindex){
        domElement._originalZindex = domElement.style.zIndex;
        domElement._firstZindex = true;
    }

    domElement.style.zIndex = 99999;
};

DOM_Class.RestoreZindex = function(domElement){

    if(domElement && domElement._firstZindex){
        domElement._firstZindex = false;
        domElement.style.zIndex = domElement._originalZindex;
    }
};

DOM_Class.GetCssPrefix = function prefixed () {
    if(this._prefix !== undefined) return this._prefix;

    var prefixes = ["","-webkit-","-moz-","-o-"], el;
    for (var i = 0; i < prefixes.length; i++) {
        el = document.createElement('div');
        el.style.cssText = "width:" + prefixes[i] + "calc(9px)";
        if (el.style.length){
            this._prefix = prefixes[i];
            console.log('prefix =',this._prefix);
            return prefixes[i];
        }
    }
};

//ex dom_css_manager_class_part
DOM_Class.GetEmUnitValue = function(parentNode){
    if (!parentNode) {
        parentNode = document.body;
    }

    if(!DOM_Class._EMscopeTester){
        DOM_Class._EMscopeTester = document.createElement('DIV');
        DOM_Class._EMscopeTester.style = 'display: block; font-size: 1em; margin: 0; padding:0; height: auto; line-height: 1; border:0;';
        DOM_Class._EMscopeTester.innerHTML = '&nbsp;';
    }

    parentNode.appendChild(DOM_Class._EMscopeTester);

    let scopeVal = DOM_Class._EMscopeTester.offsetHeight;
    DOM_Class._EMscopeTester.remove();

    return parseFloat(scopeVal);
};

DOM_Class.PxToEm = function(pxValue , parentNode , addEmSuffix){

    if (!parentNode || (pxValue+'').toLowerCase().indexOf("rem") >= 0) {
      parentNode = document.body;
    }

    let emScale = DOM_Class.GetEmUnitValue(parentNode);

    return (parseFloat(pxValue) / emScale) + (addEmSuffix?'rem':0);
};
/*jshint esversion: 6 */
//-------------------------------------------------------------
//extension dom class juste pour le module page.js
DOM_Class.CycleSnapAbsolute = function(domElement , edge , state){

    let currentState = DOM_Class.GetStyle(domElement)._snapEdge[edge];

    let units = DOM_CSS_MANAGER_Class.standardUnits;
    let pos = units.indexOf(currentState);
    if(pos == -1){
        currentState = units[0];
    }else{
        pos++;
        if(pos >= units.length){
            currentState = false;
        }else{
            currentState = units[pos];
        }
    }

    if(state !== undefined) currentState = state;

    if(!currentState){
        switch(edge){
            case 'left':
                return DOM_Class.UnsnapAbsoluteLeft(domElement);
            break;

            case 'top':
                return DOM_Class.UnsnapAbsoluteTop(domElement);
            break;

            case 'right':
                return DOM_Class.UnsnapAbsoluteRight(domElement);
            break;

            case 'bottom':
                return DOM_Class.UnsnapAbsoluteBottom(domElement);
            break;
        }
    }else{
        switch(edge){
            case 'left':
                return DOM_Class.SnapAbsoluteLeft(domElement , currentState);
            break;

            case 'top':
                return DOM_Class.SnapAbsoluteTop(domElement , currentState);
            break;

            case 'right':
                return DOM_Class.SnapAbsoluteRight(domElement , currentState);
            break;

            case 'bottom':
                return DOM_Class.SnapAbsoluteBottom(domElement , currentState);
            break;
        }
    }
};


DOM_Class.ToggleSnapAbsolute = function(domElement , edge , state){

    let currentState = DOM_Class.GetStyle(domElement)._snapEdge[edge];

    if(state === undefined) state = !currentState;

    if(state != currentState){
        switch(edge){
            case 'left':
                return DOM_Class.ToggleSnapAbsoluteLeft(domElement);
            break;

            case 'top':
                return DOM_Class.ToggleSnapAbsoluteTop(domElement);
            break;

            case 'right':
                return DOM_Class.ToggleSnapAbsoluteRight(domElement);
            break;

            case 'bottom':
                return DOM_Class.ToggleSnapAbsoluteBottom(domElement);
            break;
        }
    }

    return undefined;
};


DOM_Class.SetEdgeSnapUnit = function(domElement , edgeName , snapUnit){
    if(!snapUnit) snapUnit = 'px';
};

DOM_Class.GetEdgeSnapUnit = function(domElement , edgeName){
    let style = DOM_Class.GetStyle(domElement);
};


DOM_Class.ToggleSnapAbsoluteBottom = function(domElement){
    if(DOM_Class.GetStyle(domElement)._snapEdge.bottom){
        return DOM_Class.UnsnapAbsoluteBottom(domElement);
    }else{
        return DOM_Class.SnapAbsoluteBottom(domElement);
    }
};

DOM_Class.ToggleSnapAbsoluteTop = function(domElement){
    if(DOM_Class.GetStyle(domElement)._snapEdge.top){
        return DOM_Class.UnsnapAbsoluteTop(domElement);
    }else{
        return DOM_Class.SnapAbsoluteTop(domElement);
    }
};

DOM_Class.ToggleSnapAbsoluteRight = function(domElement){
    if(DOM_Class.GetStyle(domElement)._snapEdge.right){
        return DOM_Class.UnsnapAbsoluteRight(domElement);
    }else{
        return DOM_Class.SnapAbsoluteRight(domElement);
    }
};

DOM_Class.ToggleSnapAbsoluteLeft = function(domElement){
    if(DOM_Class.GetStyle(domElement)._snapEdge.left){
        return DOM_Class.UnsnapAbsoluteLeft(domElement);
    }else{
        return DOM_Class.SnapAbsoluteLeft(domElement);
    }
};

DOM_Class.SnapAbsoluteRight = function(domElement , snapUnit){
    DOM_Class.UnsetHorizontalPercentagePosition(domElement);

    let style = DOM_Class.GetStyle(domElement);
    let parentStyle = DOM_Class.GetStyle(domElement.parentNode);

    let offset = (parentStyle.rect.right - style.rect.right) - (parentStyle.BR + style.MR );

    if(style._snapEdge.left){
        domElement.style.setProperty('width' , 'auto');
    }else{
        DOM_Class.SetGlobalWidth(domElement , style.rect.width);
        domElement.style.setProperty('left' , 'auto');
    }

    if(!snapUnit) snapUnit = 'px';
    switch(snapUnit){
        case 'rem':
            domElement.style.setProperty('right' , DOM_CSS_MANAGER_Class.PxToEm(offset , domElement.parentNode , true));
        break;

        case 'em':
            domElement.style.setProperty('right', DOM_CSS_MANAGER_Class.PxToEm(offset , domElement.parentNode , true));
        break;

        case '%':
            let px = 0;
            if(offset < 0){
                // on dépasse dans le border
                domElement.style.setProperty('right' , offset+'px');
            }else{
                let parent_innerwidth = parentStyle.rect.width - parentStyle.BH;
                let rightPercent = ((1 - (style.rect.right - (parentStyle.rect.left + parentStyle.BL)) / parent_innerwidth)*100).toFixed(3);

                domElement.style.setProperty('right' , rightPercent+'%');
            }

        break;


        default:
            domElement.style.setProperty('right' , offset+'px');
        break;
    }

    //style._snapRight = snapUnit;
    style._snapEdge.right = snapUnit;
    return style._snapEdge.right;
};

DOM_Class.SnapAbsoluteBottom = function(domElement , snapUnit){
    DOM_Class.UnsetVerticalPercentagePosition(domElement);

    let style = DOM_Class.GetStyle(domElement);
    let parentStyle = DOM_Class.GetStyle(domElement.parentNode);

    let offset = (parentStyle.rect.bottom - style.rect.bottom) - (parentStyle.BB + style.MB );

    if(style._snapEdge.top){
        domElement.style.setProperty('height' , 'auto');
    }else {
        DOM_Class.SetGlobalHeight(domElement , style.rect.height);
        domElement.style.top = 'auto';
    }

    if(!snapUnit) snapUnit = 'px';
    switch(snapUnit){
        case 'rem':
            domElement.style.bottom = DOM_CSS_MANAGER_Class.PxToEm(offset , domElement.parentNode , true);
        break;

        case 'em':
            domElement.style.bottom = DOM_CSS_MANAGER_Class.PxToEm(offset , domElement.parentNode , true);
        break;

        case '%':
            let parent_innerheight = parentStyle.rect.height - parentStyle.BV;
            let bottomPercent = ((1 - (style.rect.bottom - (parentStyle.rect.top + parentStyle.BT)) / parent_innerheight)*100).toFixed(3);

            domElement.style.bottom = bottomPercent+'%';
        break;

        default:
            domElement.style.bottom = offset+'px';
        break;
    }

    style._snapEdge.bottom = snapUnit;

    return style._snapEdge.bottom;
};

DOM_Class.SnapAbsoluteLeft = function(domElement , snapUnit){
    DOM_Class.UnsetHorizontalPercentagePosition(domElement);

    let style = DOM_Class.GetStyle(domElement);
    let parentStyle = DOM_Class.GetStyle(domElement.parentNode);

    let offset = (style.rect.left - parentStyle.rect.left) - (parentStyle.BL + style.ML );

    if(domElement.style.right.indexOf('px')>0 || style._snapEdge.right){
        domElement.style.width = 'auto';
    }

    if(!snapUnit) snapUnit = 'px';
    switch(snapUnit){
        case 'rem':
            domElement.style.left = DOM_CSS_MANAGER_Class.PxToEm(offset , domElement.parentNode , true);
        break;

        case 'em':
            domElement.style.left = DOM_CSS_MANAGER_Class.PxToEm(offset , domElement.parentNode , true);
        break;

        case '%':
            if(offset < 0){
                // on dépasse dans le border
                domElement.style.left = offset+'px';
            }else{
                let parent_innerwidth = parentStyle.rect.width - parentStyle.BH;
                let leftPercent = ((offset / parent_innerwidth)*100).toFixed(3);
                domElement.style.left = leftPercent+'%';
            }
        break;

        default:
            domElement.style.left = offset+'px';
        break;
    }

    style._snapEdge.left = snapUnit;

    return style._snapEdge.left;
};

DOM_Class.SnapAbsoluteTop = function(domElement , snapUnit){
    DOM_Class.UnsetVerticalPercentagePosition(domElement);

    let style = DOM_Class.GetStyle(domElement);
    let parentStyle = DOM_Class.GetStyle(domElement.parentNode);

    let offset = (style.rect.top - parentStyle.rect.top) - (parentStyle.BT + style.MT );

    if(domElement.style.bottom.indexOf('px')>0 || style._snapEdge.bottom){
        domElement.style.height = 'auto';
    }

    if(!snapUnit) snapUnit = 'px';
    switch(snapUnit){
        case 'rem':
            domElement.style.top = DOM_CSS_MANAGER_Class.PxToEm(offset , domElement.parentNode , true);
        break;

        case 'em':
            domElement.style.top = DOM_CSS_MANAGER_Class.PxToEm(offset , domElement.parentNode , true);
        break;

        case '%':

            if(offset < 0){
                // on dépasse dans le border
                domElement.style.top = offset+'px';
            }else{
                let parent_innerheight = parentStyle.rect.height - parentStyle.BV;
                let topPercent = ((offset / parent_innerheight)*100).toFixed(3);
                domElement.style.top = topPercent+'%';
            }
        break;

        default:
            domElement.style.top = offset+'px';
        break;
    }

    style._snapEdge.top = snapUnit;
    return style._snapEdge.top;
};

DOM_Class.UnsnapAbsoluteTop = function(domElement){
    let style = DOM_Class.GetStyle(domElement);

    if(style._snapEdge.top !== false){
        style._snapEdge.top = false;
        //style._snapTop = false;

        DOM_Class.SetGlobalTop(domElement , style.rect.top);

        if(domElement.style.bottom.indexOf('px')>0 || style._snapEdge.bottom){
            DOM_Class.SetGlobalHeight(domElement , style.rect.height);
            domElement.style.top = 'auto';

        }else if(!style._snapEdge.bottom){
            DOM_Class.SetGlobalTop(domElement , style.rect.top);
            DOM_Class.SetGlobalHeight(domElement , style.rect.height);
        }
        //domElement.style.borderTopColor = 'blue';
    }

    return false;
};

DOM_Class.UnsnapAbsoluteLeft = function(domElement){
    let style = DOM_Class.GetStyle(domElement);

    if(style._snapEdge.left !== false){
        DOM_Class.SetGlobalLeft(domElement , style.rect.left);

        style._snapEdge.left = false;

        if(domElement.style.right.indexOf('px')>0 || style._snapEdge.right){
            DOM_Class.SetGlobalWidth(domElement , style.rect.width);
            domElement.style.left = 'auto';

        }else if(!style._snapEdge.right){
            DOM_Class.SetGlobalLeft(domElement , style.rect.left);
            DOM_Class.SetGlobalWidth(domElement , style.rect.width);
        }
        //domElement.style.borderLeftColor = 'blue';
    }

    return false;
};

DOM_Class.UnsnapAbsoluteRight = function(domElement){
    let style = DOM_Class.GetStyle(domElement);

    if(style._snapEdge.right !== false){
        DOM_Class.SetGlobalRight(domElement , style.rect.right);

        style._snapEdge.right = false;

        if(domElement.style.left.indexOf('px')>0 || style._snapEdge.left){
            DOM_Class.SetGlobalWidth(domElement , style.rect.width);
            domElement.style.right = 'auto';

        }else if(!style._snapEdge.left){
            DOM_Class.SetGlobalLeft(domElement , style.rect.left);
            DOM_Class.SetGlobalWidth(domElement , style.rect.width);
            domElement.style.right = 'auto';
        }

        //domElement.style.borderRightColor = 'blue';
    }

    return false;
};

DOM_Class.UnsnapAbsoluteBottom = function(domElement){
    let style = DOM_Class.GetStyle(domElement);

    if(style._snapEdge.bottom !== false){
        DOM_Class.SetGlobalBottom(domElement , style.rect.bottom);

        style._snapEdge.bottom = false;

        if(domElement.style.top.indexOf('px')>0 || style._snapEdge.top){
            DOM_Class.SetGlobalHeight(domElement , style.rect.height);
            domElement.style.bottom = 'auto';

        }else if(!style._snapEdge.top){
            DOM_Class.SetGlobalTop(domElement , style.rect.top);
            DOM_Class.SetGlobalHeight(domElement , style.rect.height);
            domElement.style.bottom = 'auto';
        }

        //domElement.style.borderBottomColor = 'blue';
    }

    return false;
};

DOM_Class.SetHorizontalPercentagePosition = function(domElement){

    let parentStyle = DOM_Class.GetStyle(domElement.parentNode);
    let style = DOM_Class.GetStyle(domElement);
    let rect = style.rect;
    let precision = 2;

    DOM_Class.UnsnapAbsoluteLeft(domElement);
    DOM_Class.UnsnapAbsoluteRight(domElement);

    let leftPercent = (rect.left - parentStyle.rect.left) / (parentStyle.rect.width - rect.width);

    let a = (leftPercent*100).toFixed(precision);
    let b = ((style.rect.width*leftPercent + parentStyle.BL*(1-leftPercent) - parentStyle.BR*leftPercent) ).toFixed(precision);

    domElement.style.left = DOM_Class.GetCssPrefix()+"calc("+a+ "% - "+b+"px)";
    domElement.style.right = '';

    domElement._ComputedStyle._snapCenter.horizontal = true;

    DOM_Class._SetRectDirty (domElement);

};


DOM_Class.UnsetHorizontalPercentagePosition = function(domElement){
    domElement._ComputedStyle._snapCenter.horizontal = false;

    let style = DOM_Class.GetStyle(domElement);
    let rect = style.rect;

    DOM_Class.SetGlobalLeft(domElement,rect.left);

    DOM_Class._SetRectDirty (domElement);
};

DOM_Class.UnsetVerticalPercentagePosition = function(domElement){
    domElement._ComputedStyle._snapCenter.vertical = false;

    let style = DOM_Class.GetStyle(domElement);
    let rect = style.rect;

    DOM_Class.SetGlobalTop(domElement,rect.top);

    DOM_Class._SetRectDirty (domElement);
};

DOM_Class.SetVerticalPercentagePosition = function(domElement){

    let parentStyle = DOM_Class.GetStyle(domElement.parentNode);
    let style = DOM_Class.GetStyle(domElement);
    let rect = style.rect;
    let precision = 2;

    DOM_Class.UnsnapAbsoluteBottom(domElement);
    DOM_Class.UnsnapAbsoluteTop(domElement);

    let topPercent = (rect.top - parentStyle.rect.top) / (parentStyle.rect.height - rect.height);

    domElement.style.top = DOM_Class.GetCssPrefix()+"calc("+(topPercent*100).toFixed(precision) + "% - "+((style.rect.height*topPercent + parentStyle.BT*(1-topPercent) - parentStyle.BB*topPercent) ).toFixed(precision) +"px)";
    domElement.style.bottom = '';

    domElement._ComputedStyle._snapCenter.vertical = true;

    DOM_Class._SetRectDirty (domElement);

};


DOM_Class.DuplicateDomElement = function(domElement , cloneContent){
    let newElement = domElement.cloneNode(cloneContent);
    DOM_Class._SetRectDirty(newElement);
    DOM_Class._SetStyleDirty(newElement);
    let style = DOM_Class.GetStyle(newElement);
    return newElement;
};

//-----------------------------------------------------------------------------------

DOM_Class.PickElementAt = function(x,y){
    var doc = document.documentElement;
    var left = (window.pageXOffset || doc.scrollLeft) - (doc.clientLeft || 0);
    var top = (window.pageYOffset || doc.scrollTop)  - (doc.clientTop || 0);
    return document.elementFromPoint(x-left,y-top);
};


DOM_Class.PickElementsListAt = function(x,y){
    var element, elements = [];
    var old_visibility = [];

    var doc = document.documentElement;
    var left = (window.pageXOffset || doc.scrollLeft) - (doc.clientLeft || 0);
    var top = (window.pageYOffset || doc.scrollTop)  - (doc.clientTop || 0);

    while (true) {
        element = document.elementFromPoint(x - left, y - top);

        if (!element || element === document.documentElement) {
            break;
        }
        elements.push(element);
        old_visibility.push(element.style.visibility);
        element.style.visibility = 'hidden'; // Temporarily hide the element (without changing the layout)
    }
    for (var k = 0; k < elements.length; k++) {
        elements[k].style.visibility = old_visibility[k];
    }
    elements.reverse();
    return elements;
};

DOM_Class.TestOverlap = function(a , b){
    let ra = DOM_Class.GetGlobalRect(a);
    let rb = DOM_Class.GetGlobalRect(b);

    if(ra.left > rb.right || rb.left > ra.right){
        return false;
    }

    if(ra.top > rb.bottom || rb.top > ra.bottom){
        return false;
    }

    return true;
};


DOM_Class.InsertAfterStart = function(domElement , insideMe){
    insideMe.insertAdjacentElement('afterbegin',domElement);
    DOM_Class._SetRectDirty(domElement);
    DOM_Class._SetRectDirty(insideMe);
};

DOM_Class.InsertBeforeEnd = function(domElement , insideMe){
    insideMe.insertAdjacentElement('beforeend',domElement);
    DOM_Class._SetRectDirty(domElement);
    DOM_Class._SetRectDirty(insideMe);
};

//----------------------------------------------------------------------------
var DOM_CSS_MANAGER_Class = function(){};
DOM_CSS_MANAGER_Class.prototype.constructor = DOM_CSS_MANAGER_Class;
//~ class DOM_CSS_MANAGER_Class{
    //~ constructor() {
    //~ }
//~ }

DOM_CSS_MANAGER_Class.standardUnits = ['px','%','rem','em'];

DOM_CSS_MANAGER_Class.ExtractValue = function(source , valueName){

    if(valueName.indexOf(':') > -1){
        let tmp = valueName.split(':');
        if(tmp[0] != 'css'){
            debugger;
            return undefined;
        }
        valueName = tmp[1];
    }

    if(GENERICS_Class.IsFilledArray(source)){
        source = source[0];
    }

    if(GENERICS_Class.IsObject(source) && source.sourceElement != undefined){
        source = source.sourceElement;

    }else if(GENERICS_Class.IsObject(source) && source.domElement != undefined){
        source = source.domElement;
    }

    if(GENERICS_Class.IsObject(source)){
        let value = DOM_Class.GetStyleValue(source , valueName);
        return value;
    }

    return undefined;
};

DOM_CSS_MANAGER_Class.ExtractUnit = function(source , valueName){

    if(valueName.indexOf(':') > -1){
        let tmp = valueName.split(':');
        if(tmp[0] != 'css'){
            debugger;
            return undefined;
        }
        valueName = tmp[1];
    }

    if(GENERICS_Class.IsFilledArray(source)){
        source = source[0];
    }

    if(GENERICS_Class.IsObject(source) && source.sourceElement != undefined){
        source = source.sourceElement;

    }else if(GENERICS_Class.IsObject(source) && source.domElement != undefined){
        source = source.domElement;
    }

    if(GENERICS_Class.IsObject(source)){
        let value = DOM_Class.GetStyleValue(source , valueName);
        let unit = value.replace(/([0-9]|(\.))/gi,'').toLowerCase();
        return unit;
    }

    return undefined;
};

DOM_CSS_MANAGER_Class.GetEmUnitValue = function(parentNode){
    if (!parentNode) {
        parentNode = document.body;
    }

    if(!DOM_CSS_MANAGER_Class._EMscopeTester){
        DOM_CSS_MANAGER_Class._EMscopeTester = document.createElement('DIV');
        DOM_CSS_MANAGER_Class._EMscopeTester.style = 'display: block; font-size: 1em; margin: 0; padding:0; height: auto; line-height: 1; border:0;';
        DOM_CSS_MANAGER_Class._EMscopeTester.innerHTML = '&nbsp;';
    }

    parentNode.appendChild(DOM_CSS_MANAGER_Class._EMscopeTester);

    let scopeVal = DOM_CSS_MANAGER_Class._EMscopeTester.offsetHeight;
    DOM_CSS_MANAGER_Class._EMscopeTester.remove();

    return parseFloat(scopeVal);
};

DOM_CSS_MANAGER_Class.EmToPx = function(emValue , parentNode , addPxSuffix){

    if (!parentNode || (emValue+'').toLowerCase().indexOf("rem") >= 0) {
        parentNode = document.body;
    }

    let emScale = DOM_CSS_MANAGER_Class.GetEmUnitValue(parentNode);

    return Math.round(parseFloat(emValue) * emScale) + (addPxSuffix?'px':0);
};

DOM_CSS_MANAGER_Class.PxToEm = function(pxValue , parentNode , addEmSuffix){

    if (!parentNode || (pxValue+'').toLowerCase().indexOf("rem") >= 0) {
      parentNode = document.body;
    }

    let emScale = DOM_CSS_MANAGER_Class.GetEmUnitValue(parentNode);

    return (parseFloat(pxValue) / emScale) + (addEmSuffix?'rem':0);
};

DOM_CSS_MANAGER_Class.ToPx = function(anyValue , parentNode , addPxSuffix){

    if(GENERICS_Class.IsString(anyValue)){
        if(anyValue.indexOf('px') > 0){
            return addPxSuffix ? anyValue : parseFloat(anyValue);
        }

        if(anyValue.indexOf('%') > 0){
            let parentStyle = DOM_Class.GetStyle(parentNode);

            let val = (parseFloat(anyValue)/100) * parentStyle.rect.width;
            return addPxSuffix ? val+'px':val;
        }

        if (!parentNode || (anyValue+'').toLowerCase().indexOf("rem") >= 0) {
            parentNode = document.body;
        }

        let emScale = DOM_CSS_MANAGER_Class.GetEmUnitValue(parentNode);

        return Math.round(parseFloat(anyValue) * emScale) + (addPxSuffix?'px':0);
    }
    console.log('wrong value');
    return 0;
};
//manage all events and avoid redondancies... 
//to switch event activation on dom element without removing it look at DOM_Class.XXXMouseEvents in dom.js

var EVENTS_Class = function(){
    this._eventHandlers = {};
};
EVENTS_Class.prototype.constructor = EVENTS_Class;
//~ class EVENTS_Class{
    //~ constructor() {
        //~ this._eventHandlers = {};
    //~ }
//~ }

EVENTS_Class.debug = false;
EVENTS_Class.currentMouseOverElement = null;
EVENTS_Class.currentMouseDownEvent = null;
EVENTS_Class.previousMouseDownEvent = null;
EVENTS_Class.hideOnMouseDownOutside = [];
EVENTS_Class.eventOnMouseDownOutside = [];
EVENTS_Class.clickTimer = 0;
EVENTS_Class.keys = {shiftKey:false,ctrlKey:false,altKey:false};
EVENTS_Class.mouse = {left:false,right:false,middle:false};
EVENTS_Class.lockEventsRemoving = false;
EVENTS_Class.eventsToRemove = [];

// For disabling doubleclick on element
EVENTS_Class.disableDoubleClick = [];

EVENTS_Class.EVENT_FOCUS = 'focus';
EVENTS_Class.EVENT_BLUR = 'blur';
// ces noms de variables ne sont pas ceux du html pour que tout les cliques passent par les GlobalMouseDown et GlobalMouseUp
// et executé toute les events du tableau _eventHandlers
EVENTS_Class.EVENT_MOUSEDOWN = 'MouseDown';
EVENTS_Class.EVENT_MOUSEUP = 'MouseUp';
EVENTS_Class.EVENT_CLICK = 'Click';
EVENTS_Class.EVENT_DOUBLECLICK = 'DblClick';

EVENTS_Class.EVENT_MOUSEENTER = 'mouseenter';
EVENTS_Class.EVENT_MOUSEOVER = 'mouseover';

EVENTS_Class.EVENT_MOUSEOUT = 'mouseout';
EVENTS_Class.EVENT_MOUSELEAVE = 'mouseleave';

EVENTS_Class.EVENT_KEYUP = 'KeyUp';
EVENTS_Class.EVENT_KEYDOWN = 'KeyDown';
EVENTS_Class.EVENT_CHANGE = 'change';

EVENTS_Class.outsideEvents = {};

EVENTS_Class.EVENT_MOUSEUP_OUTSIDE = 'MouseUpOutSide';
EVENTS_Class.EVENT_MOUSEDOWN_OUTSIDE = 'MouseDownOutSide';

EVENTS_Class.EVENT_TOUCHSTART = 'touchstart';
EVENTS_Class.EVENT_TOUCHEND = 'touchend';
EVENTS_Class.EVENT_TOUCHMOVE = 'touchmove';

EVENTS_Class.defaultDropCallback = null;

EVENTS_Class._windowResizeTimer = 0;

EVENTS_Class._resizeData = {left:false , top:false , right:false , bottom:false , domElement:null , cursor:'auto' , resizing:false };
EVENTS_Class._dragging = false;
EVENTS_Class._dragInitialized = false;

EVENTS_Class._windowOnLoadHandlers = [];
EVENTS_Class._windowOnResizeHandlers = [];

EVENTS_Class._windowLoaded = false;

var isMac = navigator.userAgent.toUpperCase().indexOf('MAC') >= 0;
// console.log(navigator);
var isMacLike = /(Mac|iPhone|iPod|iPad)/i.test(navigator.userAgent);
// var isIOS = /(iPhone|iPod|iPad)/i.test(navigator.userAgent);
var isIOS = (() => {
    if (/iPad|iPhone|iPod/.test(navigator.platform)) {
      return true;
    } else {
      return navigator.maxTouchPoints &&
        navigator.maxTouchPoints > 2 &&
        /MacIntel/.test(navigator.platform);
    }
  })();
var isIpadOS = (() => {
    return navigator.maxTouchPoints && 
      navigator.maxTouchPoints > 2 &&
      /MacIntel/.test(navigator.platform);
  })();

var isMobile =/(Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini)/i.test(navigator.userAgent);
var is_chrome = navigator.userAgent.indexOf('Chrome') > -1;
var is_firefox = navigator.userAgent.indexOf('Firefox') > -1;
var is_safari = navigator.userAgent.indexOf("Safari") > -1;
var is_opera = navigator.userAgent.toLowerCase().indexOf("op") > -1;
if ((is_chrome)&&(is_safari)) { is_safari = false; }
if ((is_chrome)&&(is_opera)) { is_chrome = false; }
//~ EVENTS_Class._passiveSupported = false;
/* Feature detection for touch */
//~ try {
    //~ window.addEventListener("test", null, Object.defineProperty({}, "passive", { get: function() { EVENTS_Class._passiveSupported = true; } }));
//~ } catch(err) {}

// EVENTS_Class.prototype.constructor = EVENTS_Class;

//----------------------------------------------------------------------------------
EVENTS_Class.Init = function(){
    //~ EVENTS_Class.AddEvent(document,'mouseup',EVENTS_Class.GlobalMouseUp);
    //~ EVENTS_Class.AddEvent(document,'mousedown',EVENTS_Class.GlobalMouseDown);
    //~ EVENTS_Class.AddEvent(document,'mousemove',EVENTS_Class.GlobalMouseMove);
    
    // console.log('event '+isIOS);
    if ((isMac || isMacLike) && !isIOS){
        // if (isIOS){
        //     if(EVENTS_Class.debug){
        //         console.log('ios');
        //     }
        //     document.addEventListener("touchstart",EVENTS_Class.TouchHandler);
        //     document.addEventListener("touchmove",EVENTS_Class.TouchHandler, {'passive':false});
        //     document.addEventListener("touchend",EVENTS_Class.TouchHandler);
        //     document.addEventListener("touchcancel",EVENTS_Class.TouchHandler);
        // }else{
            if(EVENTS_Class.debug){
                console.log('mac');
            }
            document.addEventListener('mouseup',EVENTS_Class.GlobalMouseUp);
            document.addEventListener('mousedown',EVENTS_Class.GlobalMouseDown);
            document.addEventListener('mousemove',EVENTS_Class.GlobalMouseMove);
        // }
    } else {
        //~ document.addEventListener('mouseup',EVENTS_Class.GlobalMouseUp);
        document.addEventListener('pointerup',EVENTS_Class.GlobalMouseUp);
        //~ document.addEventListener('mousedown',EVENTS_Class.GlobalMouseDown);
        document.addEventListener('pointerdown',EVENTS_Class.GlobalMouseDown);
        //~ document.addEventListener('mousemove',EVENTS_Class.GlobalMouseMove);
        document.addEventListener('pointermove',EVENTS_Class.GlobalMouseMove);
        //~ document.addEventListener('pointercancel',EVENTS_Class.GlobalMouseUp);
    }
    
    //~ if (event.pointerType == 'touch'){
    EVENTS_Class.TouchHandlerIsActive = true;
    //dedié artisan ?
    document.addEventListener("touchmove", EVENTS_Class.disableScrollOnTouch, {'passive':false});
    document.addEventListener("touchend", ()=>{
        //~ console.log('touchend');
        EVENTS_Class.longPress = -1;
        if (!EVENTS_Class.TouchHandlerIsActive){
            EVENTS_Class.TouchHandlerIsActive = true;
            document.addEventListener("touchmove", EVENTS_Class.disableScrollOnTouch, {'passive':false});
        }
    });


    //~ }
    // remove old event
    //~ let events_to_remove = ['mousedown', 'click', 'dblclick', 'touchstart', 'touchend', 'touchmove', 'mousemove', 'mouseup'];
    //~ let events_to_remove = ['touchmove'];
    //~ events_to_remove.forEach((eventName)=>{
        //~ document.addEventListener(eventName, (event)=>{
            //~ EVENTS_Class.StopEvent(event);
            //~ return false;
        //~ });
    //~ });
    
    // transform touch event to mouse event
    // document.addEventListener("touchstart",EVENTS_Class.TouchHandler);
    // document.addEventListener("touchmove",EVENTS_Class.TouchHandler, {'passive':false});
    // document.addEventListener("touchend",EVENTS_Class.TouchHandler);
    // document.addEventListener("touchcancel",EVENTS_Class.TouchHandler);

    //~ EVENTS_Class.AddEvent(document,'keydown',EVENTS_Class.GlobalKeyDown);
    //~ EVENTS_Class.AddEvent(document,'keyup',EVENTS_Class.GlobalKeyUp);
    document.addEventListener('keydown',EVENTS_Class.GlobalKeyDown);
    document.addEventListener('keyup',EVENTS_Class.GlobalKeyUp);
    
    EVENTS_Class.EnableDrop(document , EVENTS_Class.GlobalDrop);

    //~ EVENTS_Class.AddEvent(window,'resize',EVENTS_Class.WindowResize);
    window.addEventListener('resize',EVENTS_Class.WindowResize);
    
    window.addEventListener('load',EVENTS_Class.WindowLoad);
    //~ EVENTS_Class.AddEvent(window,'load',EVENTS_Class.WindowLoad);
};

EVENTS_Class.AddLoadHandler = function(handler,timed=false){
    if (timed){
        handler=eval(handler);
    }
    if (GENERICS_Class.IsString(handler)) {
         setTimeout(EVENTS_Class.AddLoadHandler , 50 , handler, true);
    }else{
        if (handler === undefined){
            console.log('!!! LOAD HANDLER BAD REGISTRATION !!!');
        }else{
            
            if(EVENTS_Class._windowOnLoadHandlers.indexOf(handler) < 0){
                if(EVENTS_Class._windowLoaded){
                    //window already loaded, execute directly !
                    handler();
                }else{
                    EVENTS_Class._windowOnLoadHandlers.push(handler);
                }
            }else{
                console.log('load already registered ',handler);
            }
        }
    }
};

EVENTS_Class.RemoveLoadHandler = function(handler){
    let pos = EVENTS_Class._windowOnLoadHandlers.indexOf(handler);
    if(pos >= 0){
        EVENTS_Class._windowOnLoadHandlers.splice(pos,1);
    }else{
        console.log('handler not found ',handler);
    }
};

EVENTS_Class.WindowLoad = function(event){
    for(let i = 0 ; i < EVENTS_Class._windowOnLoadHandlers.length ; i++){
        let func = EVENTS_Class._windowOnLoadHandlers[i];
        if(GENERICS_Class.IsFunction(func)){
            func();
        }else{
            console.log('wrong onload handler registered ',func.name);
        }
    }
    EVENTS_Class._windowLoaded = true;
};

EVENTS_Class.MouseInteracting = function(){
    return EVENTS_Class._dragging || EVENTS_Class._dragInitialized || EVENTS_Class._resizeData.resizing;
};

EVENTS_Class.AddResizeHandler = function(handler,timed=false){
    if (timed){
        handler=eval(handler);
    }
    if (GENERICS_Class.IsString(handler)) {
         setTimeout(EVENTS_Class.AddResizeHandler , 50 , handler, true);
    }else{
        if (handler === undefined){
            console.log('!!! RESIZE HANDLER BAD REGISTRATION !!!');
        }else{
            if(EVENTS_Class._windowOnResizeHandlers.indexOf(handler) < 0){
                EVENTS_Class._windowOnResizeHandlers.push(handler);
            }else{
                console.log('handler already registered ',handler);
            }
        }
    }
};

EVENTS_Class.RemoveResizeHandler = function(handler){
    let pos = EVENTS_Class._windowOnResizeHandlers.indexOf(handler);
    if(pos >= 0){
        EVENTS_Class._windowOnResizeHandlers.splice(pos,1);
    }else{
        console.log('handler not found ',handler);
    }
};

EVENTS_Class.WindowResize = function(event){
    if(EVENTS_Class._windowResizeTimer){
        clearTimeout(EVENTS_Class._windowResizeTimer);
    }
    EVENTS_Class._windowResizeTimer = setTimeout(DOM_Class._SetRectDirty , 100 , document.body);
    for(let i = 0 ; i < EVENTS_Class._windowOnResizeHandlers.length ; i++){
        let func = EVENTS_Class._windowOnResizeHandlers[i];
        if(GENERICS_Class.IsFunction(func)){
            func();
        }else{
            console.log('wrong resize handler registered ',func);
        }
    }
};

EVENTS_Class.GlobalKeyDown = function(event){
    if(EVENTS_Class.debug){
        console.log('keydown',event);
    }

    EVENTS_Class.keys.shiftKey = event.shiftKey;
    EVENTS_Class.keys.ctrlKey = event.ctrlKey;
    EVENTS_Class.keys.altKey = event.altKey;
    EVENTS_Class.keys[event.keyCode] = true;
    
    EVENTS_Class.ApplyEvent(EVENTS_Class.EVENT_KEYDOWN , event);
};

EVENTS_Class.GlobalKeyUp = function(event){
    if(EVENTS_Class.debug){
        console.log('keyup',event);
    }
    
    EVENTS_Class.keys.shiftKey = event.shiftKey;
    EVENTS_Class.keys.ctrlKey = event.ctrlKey;
    EVENTS_Class.keys.altKey = event.altKey;
    EVENTS_Class.keys[event.keyCode] = false;
    
    EVENTS_Class.ApplyEvent(EVENTS_Class.EVENT_KEYUP , event);
};

EVENTS_Class.GlobalMouseDown = function(event){
    
    if (event.pointerType == 'touch'){
        EVENTS_Class.TouchHandlerIsActive = true;
        document.addEventListener("touchmove", EVENTS_Class.disableScrollOnTouch, {'passive':false});
    }
    
    if (event.target.hasPointerCapture(event.pointerId)) {
        event.target.releasePointerCapture(event.pointerId);
    }
    
    if(EVENTS_Class.previousMouseDownEvent){
        if(!DOM_Class.IsSameElement( EVENTS_Class.previousMouseDownEvent.target , event.target )){
            EVENTS_Class.ApplyBlur(EVENTS_Class.previousMouseDownEvent);
        }
    }

    EVENTS_Class.DetectMouseButtons(event);
    
    if (EVENTS_Class.mouse.left) {
        if(EVENTS_Class.currentMouseDownEvent){
            EVENTS_Class.previousMouseDownEvent = EVENTS_Class.currentMouseDownEvent;
        }

        EVENTS_Class._InitMouseDownEvent(event);
        
        if(EVENTS_Class.IsDraggable(EVENTS_Class.currentMouseDownEvent.target)){
            EVENTS_Class.StopEvent(event);
        }

        EVENTS_Class.ApplyEvent(EVENTS_Class.EVENT_MOUSEDOWN , event , EVENTS_Class.previousMouseDownEvent);

        // don't initiate resize or drag on touch, wait for a long press that will be detect by move
        if (event.pointerType != 'touch'){
            if(EVENTS_Class._InitResize(EVENTS_Class.currentMouseDownEvent)){


            }else if(EVENTS_Class.IsDraggable(EVENTS_Class.currentMouseDownEvent.target)){
                // disable init drag on mousedown when touch, it will be trig by touchmove after a long press , see function touchHandler below
                if(EVENTS_Class.currentMouseDownEvent.button == 0){
                    //~ console.log('init drag');
                    EVENTS_Class._InitDrag(EVENTS_Class.currentMouseDownEvent.target);
                }
            }
        }

        EVENTS_Class.ApplyHideMouseDownOutside(event);
    }
};

EVENTS_Class.DetectMouseButtons = function(event){
    EVENTS_Class.mouse.left = (event.buttons & 1) > 0?true:false;
    EVENTS_Class.mouse.right = (event.buttons & 2) > 0?true:false;
    EVENTS_Class.mouse.middle = (event.buttons & 4) > 0?true:false;
};

EVENTS_Class._InitMouseDownEvent = function(event){

    EVENTS_Class.currentMouseDownEvent = event;
    
    EVENTS_Class.currentMouseDownEvent.realTime = new Date().getTime();

    // compute exact local position of the mouse pointer inside the clicked element
    let localPos = DOM_Class.GetGlobalToLocal(event.target , event.pageX , event.pageY );
    EVENTS_Class.currentMouseDownEvent.localX = localPos.x;
    EVENTS_Class.currentMouseDownEvent.localY = localPos.y;

    // get the offset between the mouse position and the out bound of the clicked element
    let rect = DOM_Class.GetGlobalRect(event.target,true);
    EVENTS_Class.currentMouseDownEvent.offsetLeft = rect.left - event.pageX;
    EVENTS_Class.currentMouseDownEvent.offsetTop = rect.top - event.pageY;
    EVENTS_Class.currentMouseDownEvent.offsetRight = rect.right - event.pageX;
    EVENTS_Class.currentMouseDownEvent.offsetBottom = rect.bottom - event.pageY;

};

EVENTS_Class.DisableEventCallback = function(event){
    event.preventDefault();
    return false;
};

EVENTS_Class.TouchHandlerIsActive = false;
EVENTS_Class.GlobalMouseUp = function(event){
    
    //~ console.log('up', event);
    
    if(EVENTS_Class.debug){
        console.log('global mouseup');
        console.log(event);
    }
    
    // no detect mouse for mouseup because it's already done by previous mousedown event
    //do not work with touch
    if(EVENTS_Class.currentMouseDownEvent && EVENTS_Class.mouse.left){

        EVENTS_Class.ApplyEvent(EVENTS_Class.EVENT_MOUSEUP , event);

        // same target
        if(DOM_Class.IsSameElement(EVENTS_Class.currentMouseDownEvent.target , event.target)){

            // same position, within a circle of 3px
            let difX = event.pageX - EVENTS_Class.currentMouseDownEvent.pageX;
            let difY = event.pageY - EVENTS_Class.currentMouseDownEvent.pageY;
            if(difX < 3 && difX > -3 && difY < 3 && difY > -3){

                let delay = event.timeStamp - EVENTS_Class.currentMouseDownEvent.timeStamp;

                let prevDelay = 1000;
                
                if(EVENTS_Class.previousMouseDownEvent){
                    prevDelay = event.timeStamp - EVENTS_Class.previousMouseDownEvent.timeStamp;
                }
                
                if(EVENTS_Class.debug){
                    console.log(EVENTS_Class.previousMouseDownEvent);
                    console.log('prevDelay',prevDelay);
                }
                
                if(prevDelay < 500 && DOM_Class.IsSameElement(EVENTS_Class.previousMouseDownEvent.target , event.target) && EVENTS_Class.disableDoubleClick.indexOf(event.target.id) == -1){
                    clearTimeout(EVENTS_Class.clickTimer);

                    EVENTS_Class.ApplyEvent(EVENTS_Class.EVENT_DOUBLECLICK , event);

                }else if(delay < 300){
                    clearTimeout(EVENTS_Class.clickTimer);
                    var eventA = event;
                    var eventB = EVENTS_Class.previousMouseDownEvent;

                    EVENTS_Class.clickTimer = setTimeout(function(){EVENTS_Class.ApplyEvent( EVENTS_Class.EVENT_CLICK , eventA);},5);
                }else{
                    if(EVENTS_Class.debug){
                        console.log('long click');
                    }
                }
            }else{
                // same target but not same position
                if(EVENTS_Class.debug){
                    console.log('drag over the same element');
                }
            }
        }else{
            EVENTS_Class.ApplyEvent(EVENTS_Class.EVENT_MOUSEUP_OUTSIDE , event , EVENTS_Class.previousMouseDownEvent );
        }
    }

    EVENTS_Class._EndGlobalMove(event);

    EVENTS_Class.previousMouseDownEvent = EVENTS_Class.currentMouseDownEvent;
    EVENTS_Class.currentMouseDownEvent = null;
};

// when a class method is send as a callback for an event, a bind must be done to the original class
// to keep the right reference for the 'this' variable in the class method
// bound methods are stored in an array to not have to recreate them each time
// and to keep the same pointer adress in memory to allow the RemoveEventOnMouseDownOutside() function to identify them properly
// examples in colorpicker.js and page.js
EVENTS_Class.BindCallback = function(sourceClass , callback){

    // create the internal list of bound callbacks for the specified class object
    if(!sourceClass.__callbacks){
        sourceClass.__callbacks = {};
    }

    // there is now native way to clearly identify a function, so a unique identifier is assigned to it
    if(!callback.__uniqueID){
        callback.__uniqueID = 'FUNC_'+GENERICS_Class.GetUniqueId();
    }

    if(!sourceClass.__callbacks[callback.__uniqueID]){
        if(arguments.length == 2){
            sourceClass.__callbacks[callback.__uniqueID] = callback.bind(sourceClass);
        }else{
            let args = [];
            for(let i = 2; i < args.length ; i++){
                args.push('arguments['+i+']');
            }
            let command = 'sourceClass.__callbacks[callback.__uniqueID] = callback.bind(sourceClass,'+args.join(',')+');';
            debugger;
            eval(command);
        }
    }

    return sourceClass.__callbacks[callback.__uniqueID];
};


EVENTS_Class._eventsListeners = {};

// send a global event to all related elements
// eventName : name of the event
// data : data received by the event’s callback
// from (optional) : sender of the event
// if from is not specified, all elements listening to an event with the name specified in eventName will be invoked
EVENTS_Class.BroadcastEvent = function(eventName , data , from){

    let id = '__all__';

    if(from){
        if(!from._eventBroadcasterId){
            from._eventBroadcasterId = GENERICS_Class.GetUniqueId();
        }
        id = from._eventBroadcasterId;
    }

    if(EVENTS_Class._eventsListeners[eventName] === undefined){
        EVENTS_Class._eventsListeners[eventName] = {};
    }

    if(EVENTS_Class._eventsListeners[eventName][id] !== undefined){
        let lst = EVENTS_Class._eventsListeners[eventName][id];
        for(let i = 0 ; i< lst.length ; i++){
            EVENTS_Class.SendEvent(lst[i] , eventName , data);
        }
    }
};

// associates  a global event to one element
// to : element receiving the event
// eventName : name of the event
// callback : function to be executed
// from (optional) : sender of the event
// if from is not specified, all elements listening to an event with the name specified in eventName will be invoked
EVENTS_Class.ListenToEvent = function(to , eventName , callback , from){
    if(EVENTS_Class._eventsListeners[eventName] === undefined){
        EVENTS_Class._eventsListeners[eventName] = {};
    }

    let id = '__all__';

    if(from){
        if(!from._eventBroadcasterId){
            from._eventBroadcasterId = GENERICS_Class.GetUniqueId();
        }
        id = from._eventBroadcasterId;
    }

    if(EVENTS_Class._eventsListeners[eventName][id] === undefined){
        EVENTS_Class._eventsListeners[eventName][id] = [];
    }

    if(EVENTS_Class._eventsListeners[eventName][id].indexOf(to) === -1){
        EVENTS_Class._eventsListeners[eventName][id].push(to);
        EVENTS_Class.AddEvent(to, eventName, callback);
    }
};

// dispatch a classic event at an element of the dom
EVENTS_Class.SendEvent = function(domElement,type,data,bubbles,cancelable){

    if(bubbles === undefined){
        bubbles = true;
    }

    if(cancelable === undefined){
        cancelable = true;
    }

    bubbles = bubbles?true:false;
    cancelable = cancelable?true:false;

    var event = false;
    switch (type){
        // mouse events
        case EVENTS_Class.EVENT_MOUSEDOWN:
        case EVENTS_Class.EVENT_MOUSEUP:
        case EVENTS_Class.EVENT_CLICK:
        case EVENTS_Class.EVENT_DOUBLECLICK:
            event = new MouseEvent(type, {detail: data, bubbles: bubbles , cancelable: true });
        break;

        // others
        default:
            event = new CustomEvent(type, {detail: data, bubbles: bubbles , cancelable: true } );
        break;
    }
    if (event) domElement.dispatchEvent(event);
    else console.log('can\'t dispatch event', event);
};

EVENTS_Class.AddEvent = function (domElement, eventName, callback, useCapture,timed=false) {
    // if(EVENTS_Class.debug){
    //     console.log(domElement);
    //     console.log(callback);
    // }
    if (timed){
        callback=eval(callback);
    }
    if (GENERICS_Class.IsString(callback)) {
        setTimeout(EVENTS_Class.AddEvent,50, domElement, eventName, callback, useCapture, true);
    }else{
        if (callback === undefined){
            console.log('!!! ADD EVENT BAD CALLBACK !!!');
        }else{
            if (!domElement._eventListeners) {
                domElement._eventListeners = [];
            }
            
            let foundEvent = false;
            let foundCallback = false;
            for(let i = 0 ; i < domElement._eventListeners.length ; i++){
                if(domElement._eventListeners[i].event === eventName ){
                    foundEvent = true;
                    if (domElement._eventListeners[i].callback === callback ){
                        foundCallback= true;
                        break;
                    }
                }
            }
            //no listener, should add it
            if(!foundEvent){
                useCapture = useCapture ? true : false;
                domElement.addEventListener(eventName, EVENTS_Class.HandlerEvent, useCapture);
            }
            //and push the callback !
            if(!foundCallback){
                domElement._eventListeners.push({'event':eventName,'callback':callback});
                if (CONSTANTS.sids){
                    if (domElement.dataset){
                        let callbackName = callback.name != '' ? callback.name : callback;
                        if (!domElement.dataset.debug) {
                            domElement.dataset.debug='event:'+eventName+' - callback:'+callbackName+' |';
                        }else{
                            domElement.dataset.debug+='event:'+eventName+' - callback:'+callbackName+' |';
                        }
                    }
                }
                switch(eventName){
                    case EVENTS_Class.EVENT_MOUSEUP_OUTSIDE:
                    case EVENTS_Class.EVENT_MOUSEDOWN_OUTSIDE:
                        if( !EVENTS_Class.outsideEvents[eventName] ){
                            EVENTS_Class.outsideEvents[eventName] = [];
                        }

                        if(EVENTS_Class.outsideEvents[eventName].indexOf(domElement) == -1){
                            EVENTS_Class.outsideEvents[eventName].push(domElement);
                        }
                    break;
                }

                return true;
            }
            return false;
        }
    }

    
};

EVENTS_Class.HandlerEvent = function(event){
    EVENTS_Class.ApplyEvent(event.type, event);
};

EVENTS_Class.AddEventDelayed = function(domElement, eventName, callback, useCapture , delay){
    if(!delay){
        delay = 3;
    }
    setTimeout(EVENTS_Class.AddEvent , delay , domElement, eventName, callback, useCapture);
};

EVENTS_Class.ApplyEvent = function(eventName , event , otherEvent){
    
    switch(eventName){
        case EVENTS_Class.EVENT_MOUSEUP_OUTSIDE:
        case EVENTS_Class.EVENT_MOUSEDOWN_OUTSIDE:

            if(GENERICS_Class.IsFilledArray(EVENTS_Class.outsideEvents[eventName])){
                let lst = EVENTS_Class.outsideEvents[eventName];
                let isInside = false;

                for(let i = 0 ; i < lst.length ; i++){
                    let domElement = lst[i];
                    
                    if( DOM_Class.PointInsideElement(event.pageX , event.pageY , domElement) ){
                        // click is inside
                        // do nothing
                        isInside = true;
                        continue;
                    }else{
                        for(let i = 0; i < domElement._eventListeners.length; i++){
                            if(domElement._eventListeners[i].event === eventName){
                                domElement._eventListeners[i].callback(event , otherEvent);

                                if(EVENTS_Class.debug){
                                    console.log('Apply ',eventName , ' to ', domElement, 'callback', document._eventListeners[i]);
                                }
                            }
                        }
                    }
                }
                if (isInside) return false;
            }
        break;

        case EVENTS_Class.EVENT_MOUSEDOWN:
            EVENTS_Class.ApplyEvent(EVENTS_Class.EVENT_MOUSEDOWN_OUTSIDE , event , otherEvent);
        break;

        case EVENTS_Class.EVENT_MOUSEUP:
            EVENTS_Class.ApplyEvent(EVENTS_Class.EVENT_MOUSEUP_OUTSIDE , event , otherEvent);
        break;

        case 'contextmenu':
            EVENTS_Class.ApplyEvent(EVENTS_Class.EVENT_MOUSEDOWN_OUTSIDE , event , otherEvent);
            EVENTS_Class.ApplyEvent(EVENTS_Class.EVENT_MOUSEUP_OUTSIDE , event , otherEvent);
        break;
    }

    var classObject = DOM_Class.GetClassObject(event.target);

    EVENTS_Class.lockEventsRemoving = true;
    if(GENERICS_Class.IsFilledArray(classObject)){
        for(var i=0;i<classObject.length;i++){
            if(classObject[i][eventName]){
                classObject[i][eventName](event , otherEvent);

                if(EVENTS_Class.debug){
                    console.log(eventName+' '+event.target.id);
                }
            }
        }
    }else if(classObject && classObject[eventName]){
        classObject[eventName](event , otherEvent);

        if(EVENTS_Class.debug){
            console.log(eventName+' '+event.target.id);
        }
    }
    
    let domElement = event.target;

    let executed = false;

    if(GENERICS_Class.IsFilledArray(domElement._eventListeners)){
        for(let i = 0; i < domElement._eventListeners.length; i++){
            if(domElement._eventListeners[i].event === eventName){

                domElement._eventListeners[i].callback(event , otherEvent);

                executed = true;

                if(EVENTS_Class.debug){
                    console.log('Apply ',eventName , ' to ', domElement, 'callback', document._eventListeners[i]);
                }
            }
        }
    }
    
    if (eventName == EVENTS_Class.EVENT_KEYUP || eventName == EVENTS_Class.EVENT_KEYDOWN){
        // in case of keyUp or keyDown, much event are on document but the target depends of the last clicked item.
        // this may be the best way to trig event on document when there is no event on the targeted item 
        // this way, when pressing a key in an input the event from document will not be trigged 
        if(GENERICS_Class.IsFilledArray(document._eventListeners)){
            for(let i = 0; i < document._eventListeners.length; i++){
                if(document._eventListeners[i].event === eventName){

                    document._eventListeners[i].callback(event , otherEvent);

                    executed = true;

                    if(EVENTS_Class.debug){
                        console.log('Apply ',eventName , ' to ', document, 'callback', document._eventListeners[i]);
                    }
                }
            }
        }
    }

    if(event.cancelBubble == false){
        if(domElement.children){
            for(let j = 0 ; j < domElement.children.length ; j ++){
                let child = domElement.children[j];
                if( DOM_Class.PointInsideElement(event.pageX , event.pageY , child) ){
                    
                    let pointerEventsNone = getComputedStyle(child)['pointer-events'] == 'none';

                    if(child._eventListeners && (!pointerEventsNone || (child.dataset && child.dataset.disabled == 'true'))){
                        for(let k = 0; k < child._eventListeners.length; k++){
                            if(child._eventListeners[k].event === eventName){
                                
                                child._eventListeners[k].callback(event , otherEvent);
                                
                                if (EVENTS_Class.debug){
                                    console.log('should Apply ',eventName , ' to ', child, 'callback', child._eventListeners[k]);
                                }

                                executed = true;
                            }
                        }
                    }

                }
            }
        }else{
            //~ console.log('bug !');
        }
    }
    
    
    

    /*
     * TODO : upstream of the event on the parents
     * NOT SURE !
    if(event.cancelBubble == false){
        let p = domElement.parentNode;
        while(p && event.cancelBubble == false){
            if( DOM_Class.PointInsideElement(event.pageX , event.pageY , p) ){
                if(p._eventListeners){
                    for(let k = 0; k < p._eventListeners.length; k++){
                        if(p._eventListeners[k].event === eventName){
                            p._eventListeners[k].callback(event , otherEvent);
                            executed = true;
                        }
                    }
                }
            }
            p = p.parentNode;
        }
    }
*/

    EVENTS_Class.lockEventsRemoving = false;

    if ( GENERICS_Class.IsFilledArray(EVENTS_Class.eventsToRemove)) {
        for(let c = 0 ; c < EVENTS_Class.eventsToRemove.length ; c++){
            let infos = EVENTS_Class.eventsToRemove[c];

            if(infos.length == 1){
                EVENTS_Class.RemoveAllEvents(infos[0]);

            }else if (infos.length == 3){
                EVENTS_Class.RemoveEvent(infos[0] , infos[1] , infos[2]);

            }else{
                debugger;
            }
        }
        EVENTS_Class.eventsToRemove.length = 0;
    }
};

EVENTS_Class.HasEvent = function (domElement, eventName) {
    if ( !GENERICS_Class.IsFilledArray(domElement._eventListeners)) {
        return false;
    }

    for(let i = 0 ; i < domElement._eventListeners.length ; i++){
        if(domElement._eventListeners[i].event === eventName){
            return true;
        }
    }

    return false;
};

EVENTS_Class.HasEventCallback = function (domElement, eventName , callback) {

    if ( !GENERICS_Class.IsFilledArray(domElement._eventListeners)) {
        return false;
    }

    for(let i = 0 ; i < domElement._eventListeners.length ; i++){
        if(domElement._eventListeners[i].event === eventName && domElement._eventListeners[i].callback === callback){
            return true;
        }
    }

    return false;
};

EVENTS_Class.RemoveEvent = function(domElement, eventName, callback) {

    if ( !GENERICS_Class.IsFilledArray(domElement._eventListeners)) {
        return false;
    }

    if(EVENTS_Class.lockEventsRemoving){
        EVENTS_Class.eventsToRemove.push([domElement , eventName , callback]);
        return false;
    }

    for(let i = 0, len = domElement._eventListeners.length; i < len; i++) {
        let e = domElement._eventListeners[i];
        if((e.event === eventName && e.callback === callback) || (e.event == eventName && !callback) ){
            if ( domElement.removeEventListener ) {
                domElement.removeEventListener(e.event, e.callback);

            } else if ( domElement.attachEvent ) {
                domElement.detachEvent( 'on' + e.event, e.callback );
            }

            domElement._eventListeners.splice(i,1);

            if(EVENTS_Class.outsideEvents){
                switch(eventName){
                    case EVENTS_Class.EVENT_MOUSEUP_OUTSIDE:
                    case EVENTS_Class.EVENT_MOUSEDOWN_OUTSIDE:
                        if( GENERICS_Class.IsFilledArray(EVENTS_Class.outsideEvents[eventName])){
                            let pos = EVENTS_Class.outsideEvents[eventName].indexOf(domElement);
                            if( pos > -1){
                                EVENTS_Class.outsideEvents[eventName].splice(pos,1);
                            }
                        }
                    break;
                }
            }

            len--;
            i--;
        }
    }
};

EVENTS_Class.RemoveAllEvents = function(domElement) {
    if ( !GENERICS_Class.IsFilledArray(domElement._eventListeners)) {
        return false;
    }

    if(EVENTS_Class.lockEventsRemoving){
        EVENTS_Class.eventsToRemove.push([domElement]);
        return false;
    }

    for(let i = 0, len = domElement._eventListeners.length; i < len; i++) {
        let e = domElement._eventListeners[i];
        if ( domElement.removeEventListener ) {
            domElement.removeEventListener(e.event, e.callback);

        } else if ( elem.attachEvent ) {
            domElement.detachEvent( "on" + e.event, e.callback );
        }
    }

    domElement._eventListeners.length = 0;

    if(EVENTS_Class.outsideEvents){
        let keys = Object.keys(EVENTS_Class.outsideEvents);
        for(let i = 0 ; i < keys.length ; i++){
            let pos = EVENTS_Class.outsideEvents[keys[i]].indexOf(domElement);
            if(pos > -1){
                EVENTS_Class.outsideEvents[keys[i]].splice(pos,1);
            }
        }
    }
};

EVENTS_Class._moveList = [];

EVENTS_Class.StartGlobalMove = function(domElement,moveHandler,endMoveHandler){

    let lst = EVENTS_Class._moveList;
    for(let i = 0 ; i < lst.length ; i++){
        if(lst[i].domElement === domElement && lst[i].moveHandler === moveHandler && EVENTS_Class._moveList[i].moveHandler){
            return false;
        }
    }

    EVENTS_Class._moveList.push({'domElement':domElement , 'moveHandler':moveHandler , 'endMoveHandler':endMoveHandler});
    //EVENTS_Class._currentMoveHandler = moveHandler;
    //EVENTS_Class._currentEndMoveHandler = endMoveHandler;

    if(this.debug){
        console.log("start move");
    }

    //~ EVENTS_Class.AddEvent(document,'mousemove', EVENTS_Class.GlobalMouseMove);
    //~ EVENTS_Class.AddEvent(document,'mouseup', EVENTS_Class._EndGlobalMove);

};

// long press determine si on doit déclencher le drag pour le touch,
// remis a false par mouseUp
// -1 , pas assigné, 0 press normal, 1 long press
EVENTS_Class.longPress = -1;
EVENTS_Class.GlobalMouseMove = function(event){
    //~ console.log('move', event);

    // on touch, the move is initialised after a long press, do nothing if the move is too little
    // Apparently there is no need to do the test for the little move.
    if (event.pointerType == 'touch'){
        //~ console.log(EVENTS_Class.currentMouseDownEvent);
        if (EVENTS_Class.currentMouseDownEvent === null){
            return false;
        }
        let difX = Math.abs(EVENTS_Class.currentMouseDownEvent.screenX - event.screenX);
        let difY = Math.abs(EVENTS_Class.currentMouseDownEvent.screenY - event.screenY);
        if (difX < 5 && difY < 5){
            return false;
        }
        
        if (EVENTS_Class.longPress == -1){
            let now = new Date().getTime();
            let difT = now - EVENTS_Class.currentMouseDownEvent.realTime;
            // console.log(difT);
            if (difT < 500){
                EVENTS_Class.longPress = 0;
                
                if (EVENTS_Class.currentMouseDownEvent.pointerType == 'touch'){
                    EVENTS_Class.TouchHandlerIsActive = false;
                    document.removeEventListener("touchmove", EVENTS_Class.disableScrollOnTouch);
                }
                
            } else {
                EVENTS_Class.longPress = 1;
                
                if(EVENTS_Class._InitResize(EVENTS_Class.currentMouseDownEvent)){


                }else if(EVENTS_Class.IsDraggable(EVENTS_Class.currentMouseDownEvent.target)){
                    // disable init drag on mousedown when touch, it will be trig by touchmove after a long press , see function touchHandler below
                    if(EVENTS_Class.currentMouseDownEvent.button == 0){
                        //~ console.log('init drag');
                        EVENTS_Class._InitDrag(EVENTS_Class.currentMouseDownEvent.target);
                    }
                }
            }
        }
        
        if (EVENTS_Class.longPress == 0){
            return false;
        }
    }

    if(GENERICS_Class.IsFilledArray(EVENTS_Class._moveList)){
        for(let i = 0; i < EVENTS_Class._moveList.length ; i++){
            if(EVENTS_Class._moveList[i].moveHandler){
                EVENTS_Class._moveList[i].moveHandler(event , EVENTS_Class._moveList[i].domElement);
            }
        }
    }

    let prevElement = EVENTS_Class.currentMouseOverElement;

    EVENTS_Class.currentMouseOverElement = event.target;

    if(prevElement != EVENTS_Class.currentMouseOverElement){
        if(prevElement){
            EVENTS_Class.ApplyEvent(EVENTS_Class.EVENT_MOUSELEAVE , event , prevElement);
        }
        EVENTS_Class.ApplyEvent(EVENTS_Class.EVENT_MOUSEENTER , event);
    }

    if(!EVENTS_Class._dragging && !EVENTS_Class._resizeData.resizing){

        if(EVENTS_Class.IsResizable(EVENTS_Class.currentMouseOverElement)){
            let doResize = EVENTS_Class._CheckResize(event);

            if(doResize){

                DOM_Class.SetGlobalCursor(EVENTS_Class._resizeData.cursor);

                EVENTS_Class._overResizable = true;

            }else if(EVENTS_Class._overResizable){

                EVENTS_Class._overResizable = false;
                DOM_Class.UnsetGlobalCursor();
            }

        }else if(EVENTS_Class._overResizable){

            EVENTS_Class._overResizable = false;

            DOM_Class.UnsetGlobalCursor();

        }else{
            EVENTS_Class._overResizable = false;
        }
    }
    
    EVENTS_Class.ParsingMouseMove = false;

};

EVENTS_Class._EndGlobalMove = function(event){

    if(GENERICS_Class.IsFilledArray(EVENTS_Class._moveList)){
        for(let i = 0; i < EVENTS_Class._moveList.length ; i++){
            if(EVENTS_Class._moveList[i].endMoveHandler){
                EVENTS_Class._moveList[i].endMoveHandler(event , EVENTS_Class._moveList[i].domElement);
            }
        }
        EVENTS_Class._moveList.length = 0;
    }

    //~ if(this.debug){
        //~ console.log("end move",EVENTS_Class._moveList);
    //~ }
};

EVENTS_Class.StopEvent = function (event){
    //~ console.log('stop event');
    if(event.stopPropagation){
        event.stopPropagation();
    }

    if(event.preventDefault && event.cancelable){
        event.preventDefault();
    }
    //~ else{
        //~ event.returnValue = false;
    //~ }

    return false;
};

EVENTS_Class.StopPropagation = function (event){

    if(event.stopPropagation){
        event.stopPropagation();
    }
};

EVENTS_Class.PreventDefault = function (event){
    if(event.preventDefault){
        event.preventDefault();
    }else{
        event.returnValue = false;
    }
};

//------------------------------------------------------
EVENTS_Class.EnableResize = function (domElement , startResizeHandler , resizeHandler , endResizeHandler , boderDetectionSize){

    if(!boderDetectionSize){
        boderDetectionSize = 10;
    }

    domElement.setAttribute('data-resizeable',true);
    domElement.setAttribute('data-resizeborder',boderDetectionSize);
    domElement.draggable = false;

    domElement._startResizeHandler = startResizeHandler;
    domElement._resizeHandler = resizeHandler;
    domElement._endResizeHandler = endResizeHandler;
};
//NOT USED !
EVENTS_Class.DisableResize = function (domElement){
    domElement.removeAttribute('data-resizeable');
    domElement.draggable = false;
};

EVENTS_Class.IsResizable = function (domElement){
    return domElement && domElement.getAttribute?domElement.getAttribute('data-resizeable'):false;
};

EVENTS_Class._CheckResize = function (event){
    if(!EVENTS_Class.IsResizable(event.target)){
        return false;
    }

    let domElement = event.target;

    let b = parseInt(domElement.getAttribute('data-resizeborder'));

    let rect = DOM_Class.GetGlobalRect(event.target);
    let offsetLeft = rect.left - event.pageX;
    let offsetTop = rect.top - event.pageY;
    let offsetRight = rect.right - event.pageX;
    let offsetBottom = rect.bottom - event.pageY;

    if( b*2 >= rect.height || b*2 >= rect.width){
        b = Math.max(5,b/2);
    }


    let doResize = false;

    let css_cursor = '';
    let style = null;
    if(domElement._sourceElement){
        style = DOM_Class.GetStyle(domElement._sourceElement);
    }else{
        style = DOM_Class.GetStyle(domElement);
    }
    let is_relative = style.POS != 'absolute' && style.POS != 'fixed';

    EVENTS_Class._resizeData.left = false;
    EVENTS_Class._resizeData.top = false;
    EVENTS_Class._resizeData.right = false;
    EVENTS_Class._resizeData.bottom = false;
    EVENTS_Class._resizeData.domElement = domElement;

    // a relative element with width auto cannot be resized
    let auto_width = is_relative && style._width_unit == 'auto';

    let left_resize = true;
    let right_resize = true;
    if(is_relative && style._align == '') left_resize = false;
    if(is_relative && style._align == 'right') right_resize = false;

    if(Math.abs(offsetTop) < b && !is_relative){// cannot change top of relative items
        EVENTS_Class._resizeData.top = true;
        doResize = true;
        css_cursor += 'n';

    }else if(Math.abs(offsetBottom) < b && !is_relative){ // cannot change height on relative items
        EVENTS_Class._resizeData.bottom = true;
        doResize = true;

        css_cursor += 's';
    }

    if(Math.abs(offsetRight) < b && !auto_width && right_resize){
        EVENTS_Class._resizeData.right = true;
        doResize = true;

        css_cursor += 'e';

    }else if(Math.abs(offsetLeft) < b && !auto_width && left_resize){
        EVENTS_Class._resizeData.left = true;
        doResize = true;

        css_cursor += 'w';
    }

    if(doResize){
        css_cursor += '-resize';
    }

    EVENTS_Class._resizeData.cursor = css_cursor;

    return doResize;
};

EVENTS_Class._InitResize = function (mouseDownEvent){

    if(!EVENTS_Class.IsResizable(mouseDownEvent.target)){
        return false;
    }

    let doResize = EVENTS_Class._CheckResize(mouseDownEvent);

    if(doResize){
        // update current rect
        DOM_Class.GetGlobalRect(mouseDownEvent.target);

        EVENTS_Class._resizeData.resizing = true;

        // activate drag
        EVENTS_Class.StartGlobalMove(mouseDownEvent.target , EVENTS_Class._Resize , EVENTS_Class._EndResize);

        if(mouseDownEvent.target._startResizeHandler){
            mouseDownEvent.target._startResizeHandler();
        }
    }else{

    }

    return doResize;
};

EVENTS_Class._EndResize = function (event){
    EVENTS_Class._resizeData.resizing = false;

    if(event.target._endResizeHandler){
        event.target._endResizeHandler();
    }
};

EVENTS_Class._Resize = function (event){
    let domElement = EVENTS_Class.currentMouseDownEvent.target;
    let areaRect = null;

    if(domElement._dragArea){
        areaRect = DOM_Class.GetGlobalRect(domElement._dragArea);
    }

    if(EVENTS_Class._resizeData.left){
        if(areaRect){
            DOM_Class.SetGlobalLeft(domElement , Math.max(areaRect.left , event.pageX + EVENTS_Class.currentMouseDownEvent.offsetLeft) );

        }else{
            DOM_Class.SetGlobalLeft(domElement , event.pageX + EVENTS_Class.currentMouseDownEvent.offsetLeft);
        }

    }else if(EVENTS_Class._resizeData.right){
        if(areaRect){
            DOM_Class.SetGlobalRight(domElement , Math.min(areaRect.right , event.pageX + EVENTS_Class.currentMouseDownEvent.offsetRight));
        }else{
            DOM_Class.SetGlobalRight(domElement , event.pageX + EVENTS_Class.currentMouseDownEvent.offsetRight);
        }
    }

    if(EVENTS_Class._resizeData.top){
        if(areaRect){
            DOM_Class.SetGlobalTop(domElement , Math.max(areaRect.top , event.pageY + EVENTS_Class.currentMouseDownEvent.offsetTop));
        }else{
            DOM_Class.SetGlobalTop(domElement , event.pageY + EVENTS_Class.currentMouseDownEvent.offsetTop);
        }

    }else if(EVENTS_Class._resizeData.bottom){
        if(areaRect){
            DOM_Class.SetGlobalBottom(domElement , Math.min(areaRect.bottom , event.pageY + EVENTS_Class.currentMouseDownEvent.offsetBottom));
        }else{
            DOM_Class.SetGlobalBottom(domElement , event.pageY + EVENTS_Class.currentMouseDownEvent.offsetBottom);
        }
    }

    if(domElement._resizeHandler){
        domElement._resizeHandler();
    }
};

//----------------------------------------------------------------------------------
EVENTS_Class.EnableDrag = function (domElement , startHandler , moveHandler , endHandler , avatarHandler){

    if(EVENTS_Class.HasDrag(domElement)){
        if (EVENTS_Class.debug) console.log('Drag already assigned to ',domElement);
        return false;
    }
    domElement.setAttribute('data-draggable',true);
    domElement.draggable = false;

    domElement._dragStart = undefined;
    domElement._dragMove = undefined;
    domElement._dragEnd = undefined;

    if(startHandler && !GENERICS_Class.IsFunction(startHandler) && GENERICS_Class.IsObject(startHandler) ){
        let settings = startHandler;

        domElement._dragStart = settings.startHandler;
        domElement._dragMove = settings.moveHandler;
        domElement._dragEnd = settings.endHandler;
        domElement._useAvatar = settings.avatar;

    }else{
        domElement._dragStart = startHandler;
        domElement._dragMove = moveHandler;
        domElement._dragEnd = endHandler;
        domElement._useAvatar = avatarHandler;
    }


    return true;
};

EVENTS_Class.HasDrag = function (domElement){
    if(domElement === document){
        domElement = document.body;
    }

    return domElement.getAttribute('data-draggable');
};

EVENTS_Class.DisableDrag = function (domElement){
    domElement.removeAttribute('data-draggable');
    domElement.draggable = false;
};

EVENTS_Class.IsDraggable = function (domElement){
    return domElement.getAttribute('data-draggable');
};

EVENTS_Class.SetDragArea = function (domElement , areaDomElement , padding){
    domElement._dragArea = areaDomElement;
    domElement._dragAreaPadding = padding === undefined ? 0:parseInt(padding);

    if(domElement._overlay){
        domElement._overlay.domElement._dragArea = areaDomElement;
    }
};
//NOT USED ANYWHERE ! But should !
EVENTS_Class.UnsetDragArea = function (domElement){
    domElement._dragArea = null;
};

EVENTS_Class._InitDrag = function (domElement){
    //~ console.log('init drag');
    EVENTS_Class._dragInitialized = true;

    // update current rect
    let rect = DOM_Class.GetGlobalRect(domElement,true);
    DOM_Class.GetGlobalRect(domElement._dragArea,true);

    domElement._dragStarted = false;

    // activate drag
    EVENTS_Class.StartGlobalMove(domElement , EVENTS_Class._Drag , EVENTS_Class._DragEnd);

    DOM_Class.SetGlobalCursor('move');

    if(!domElement._sourceRect){
        domElement._sourceRect = {};
    }
    GENERICS_Class.CopyObject(rect , domElement._sourceRect);

    domElement._sourceParent = domElement.parentNode;

    if(!EVENTS_Class._currentDragElement){
        EVENTS_Class._currentDragElement = [];
    }
    EVENTS_Class._currentDragElement.push(domElement);
};

EVENTS_Class._Drag = function (event , b){
    
    EVENTS_Class.StopEvent(event);

    let difx = Math.abs(event.pageX - EVENTS_Class.currentMouseDownEvent.pageX);
    let dify = Math.abs(event.pageY - EVENTS_Class.currentMouseDownEvent.pageY);

    if(difx < 3 && dify < 3){
        return;
    }

    let domElement = EVENTS_Class.currentMouseDownEvent.target;



    if(!domElement._dragStarted){

        if(GENERICS_Class.IsString(domElement._useAvatar)){

            domElement._avatar = DOM_Class.StringToDom(domElement._avatar);
            document.body.appendChild(domElement._avatar);

        }else if(GENERICS_Class.IsFunction(domElement._useAvatar)){

            let tmp = domElement._useAvatar(domElement);
            
            if(GENERICS_Class.IsString(tmp)){
                tmp = DOM_Class.StringToDom(tmp);
            }
            
            domElement._avatar = tmp;
            document.body.appendChild(domElement._avatar);

        }else{
            domElement._avatar = domElement;
        }



        if(domElement._avatar !== domElement){
            let style = DOM_Class.GetStyle(domElement._avatar);
            domElement._avatar._originalPositionStyle = style.POS;

            DOM_Class.SetStyleValue(domElement._avatar , 'position' , 'absolute');

            let pos = DOM_Class.GetGlobalPosition(domElement);
            DOM_Class.SetGlobalPosition(domElement._avatar , pos.x , pos.y);
        }


        DOM_Class.DisableMouseEvents(domElement._avatar);
        DOM_Class.MoveToFront(domElement._avatar);

        // activate custom functions
        //EVENTS_Class.StartGlobalMove(domElement , domElement._dragMove , domElement._dragEnd);
    }

    EVENTS_Class._dragging = true;
    let avatar = domElement._avatar || domElement;

    if(domElement._dragArea){
        let rect = DOM_Class.GetGlobalRect(avatar);
        let areaRect = DOM_Class.GetGlobalRect(domElement._dragArea);

        let x = event.pageX + EVENTS_Class.currentMouseDownEvent.offsetLeft;
        let y = event.pageY + EVENTS_Class.currentMouseDownEvent.offsetTop;
        let w = DOM_Class.GetGlobalWidth(avatar);
        let h = DOM_Class.GetGlobalHeight(avatar);
        let right = x + w;
        let bottom = y + h;

        let padding = domElement._dragAreaPadding;

        if(x < areaRect.left - padding){
            x = areaRect.left - padding;
        }
        if(y < areaRect.top - padding){
            y = areaRect.top - padding;
        }
        if(right > areaRect.right + padding){
            x = (areaRect.right + padding) - w;
        }
        if(bottom > areaRect.bottom + padding){
            y = (areaRect.bottom + padding) - h;
        }

        DOM_Class.SetGlobalPosition(avatar , x,y);

    }else{
        let px = event.pageX + EVENTS_Class.currentMouseDownEvent.offsetLeft;
        let py = event.pageY + EVENTS_Class.currentMouseDownEvent.offsetTop;
        DOM_Class.SetGlobalPosition(avatar , px , py);
    }

    if(!domElement._dragStarted && domElement._dragStart){
        domElement._dragStart(event , domElement);
    }

    domElement._dragStarted = true;

    if(domElement._dragMove) domElement._dragMove(event , domElement);
};

EVENTS_Class._DragEnd = function (event){
    EVENTS_Class._dragging = false;
    EVENTS_Class._dragInitialized = false;

    DOM_Class.UnsetGlobalCursor();

    let domElement = EVENTS_Class.currentMouseDownEvent.target;

    if(domElement._dragStarted){

        // event.detail.target used for touch
        dropOnElement = event.target || event.detail.target;
        //~ console.log(event);

        if(dropOnElement.tagName == 'HTML' || dropOnElement==document){
            dropOnElement = document.body;
        }

        if(EVENTS_Class.HasDrop(dropOnElement)){
            //~ console.log(event);
            EVENTS_Class.SendEvent(dropOnElement,'drop' , {'dropEvent':event ,'elements':EVENTS_Class._currentDragElement.slice()});
        }

        if(domElement._dragEnd) domElement._dragEnd(event , domElement);
    }else{
        //console.log('drag aborted');
    }

    if(domElement._avatar && domElement._avatar !== domElement){
        DOM_Class.RemoveElement(domElement._avatar);

    }else if(domElement._avatar) {
        DOM_Class.SetStyleValue(domElement._avatar , 'position' , domElement._avatar._originalPositionStyle);

    }else if( domElement._originalPositionStyle !== undefined ){
        DOM_Class.SetStyleValue(domElement , 'position' , domElement._originalPositionStyle);
    }

    for(let i = 0; i < EVENTS_Class._currentDragElement.length ; i++){
        DOM_Class.RestoreMouseEvents(EVENTS_Class._currentDragElement[i]);
        DOM_Class.RestoreZindex(EVENTS_Class._currentDragElement[i]);
    }
    EVENTS_Class._currentDragElement.length = 0;

    EVENTS_Class.currentMouseOverElement = document.elementFromPoint(event.pageX, event.pageY);
};

EVENTS_Class.disableScrollOnTouch = function(event){
    //~ if (event.cancelable){
    //~ console.log('disable touchmove');
    event.preventDefault();
    //~ }
    return false;
};
//----------------------------------------------------------------------
EVENTS_Class.SetDefaultDropCallback = function(callback){
    EVENTS_Class.defaultDropCallback = callback;
};

EVENTS_Class.GlobalDrop = function(event){
    EVENTS_Class.StopEvent(event);

    if(GENERICS_Class.IsFunction(EVENTS_Class.defaultDropCallback)){

        EVENTS_Class.defaultDropCallback(event);
    }

};

EVENTS_Class.EnableDrop = function (domElement , callback){

    if(domElement === document){
        if(!document.body){
            // body not loaded yet, try again later;
            setTimeout(EVENTS_Class.EnableDrop , 100 , domElement , callback);
            return false;
        }

        EVENTS_Class.AddEvent(domElement , 'dragover' , EVENTS_Class.DisableEventCallback , false);
        EVENTS_Class.AddEvent(domElement , 'drop' , callback , false);
        domElement = document.body;
    }
    
    if(EVENTS_Class.HasDrop(domElement)){
        console.log('Drop event already assigned to ',domElement);
        return false;
    }
    if(domElement){
        domElement.setAttribute('data-drop',true);

        EVENTS_Class.AddEvent(domElement , 'dragover' , EVENTS_Class.DisableEventCallback , false);
        EVENTS_Class.AddEvent(domElement , 'drop' , callback , false);
    }else{
        //~ console.log('Wrong target for EnableDrop',domElement);
    }

    return true;
};

EVENTS_Class.DisableDrop = function (domElement){
    if(domElement === document){
        EVENTS_Class.RemoveEvent(domElement , 'dragover' , EVENTS_Class.DisableEventCallback);
        EVENTS_Class.RemoveEvent(domElement , 'drop');
        domElement = document.body;
    }

    domElement.setAttribute('data-drop',false);

    EVENTS_Class.RemoveEvent(domElement , 'dragover' , EVENTS_Class.DisableEventCallback);
    EVENTS_Class.RemoveEvent(domElement , 'drop');
};

EVENTS_Class.HasDrop = function (domElement){
    if(domElement === document){
        domElement = document.body;
    }
    if(!domElement) debugger;
    let has = domElement.getAttribute('data-drop');
    if (has) has = (has == 'true') ? 1 : 0;
    return has;
};

EVENTS_Class.DROP_FILES = 'Files';
EVENTS_Class.DROP_HTML = 'text/html';
EVENTS_Class.DROP_TEXT = 'text/plain';

EVENTS_Class.ExtractDataFromDropEvent = function(event , filter){

    let result = {};

    let eventType = GENERICS_Class.GetType(event);

    switch(eventType){
        case 'DragEvent':
            for(let i in event.dataTransfer.types){
                let type = event.dataTransfer.types[i];

                if(filter && filter.indexOf(type) == -1 ){
                    continue;
                }

                switch(type){
                    case EVENTS_Class.DROP_FILES:
                        result[type] = event.dataTransfer.files;
                    break;

                    default:
                        result[type] = event.dataTransfer.getData(type);
                    break;
                }
            }
            result.destination = event.currentTarget;
        break;

        case 'CustomEvent':
            result.dropData = {'pageX':event.detail.dropEvent.pageX , 'pageY':event.detail.dropEvent.pageY , 'elements':event.detail.elements};
            result.destination = event.target;
        break;
    }

    if(result.destination === document){
        result.destination = document.body;
    }

    return result;
};

//----------------------------------------------------------------------

EVENTS_Class.ApplyHideMouseDownOutside = function(event){
    if(EVENTS_Class.hideOnMouseDownOutside.length){

        for(let i = 0 ; i < EVENTS_Class.hideOnMouseDownOutside.length ; i++){
            var rect = DOM_Class.GetGlobalRect(EVENTS_Class.hideOnMouseDownOutside[i], true);
            if(event.pageX >= rect.left && event.pageX <= rect.right && event.pageY >= rect.top && event.pageY <= rect.bottom){

            }else{
                var classObject = DOM_Class.GetClassObject(EVENTS_Class.hideOnMouseDownOutside[i]);
                if(GENERICS_Class.IsArray(classObject)){
                    for(let j = 0 ; j < classObject.length ; j++){
                        if(classObject[j].Hide){
                            classObject[j].Hide(event);
                        }
                    }
                }else if(classObject && classObject.Hide){
                    classObject.Hide(event);
                    console.log("HIDED EVENTS");
                }
            }
        }
    }
};
//colorpicker and csseditor only !
EVENTS_Class.AddHideOnMouseDownOutside = function(domElement){
    if(EVENTS_Class.hideOnMouseDownOutside.indexOf(domElement) == -1){
        EVENTS_Class.hideOnMouseDownOutside.push(domElement);
    }
};
//colorpicker and csseditor only !
EVENTS_Class.RemoveHideOnMouseDownOutside = function(domElement){
    let i = EVENTS_Class.hideOnMouseDownOutside.indexOf(domElement);
    if(i>-1){
        EVENTS_Class.hideOnMouseDownOutside.splice(i,1);
    }
};

EVENTS_Class.ApplyBlur = function(event){
    var classObject = DOM_Class.GetClassObject(event.target);

    if(DOM_Class.debug){
        console.log('blur '+event.target.id);
    }

    if(GENERICS_Class.IsArray(classObject)){
        for(var i=0;i<classObject.length;i++){
            if(classObject[i].Blur){
                classObject[i].Blur(event);
            }
        }
    }else if(classObject && classObject.Blur){
        classObject.Blur(event);
    }
};

EVENTS_Class.Touch = {};
EVENTS_Class.Touch.mousedownElem = null;
EVENTS_Class.Touch.prevOverElem = null;
EVENTS_Class.Touch.history = [];
EVENTS_Class.Touch.preveventtime = 0;
EVENTS_Class.Touch.prevbtn = '';
EVENTS_Class.Touch.eventsList = [];
EVENTS_Class.Touch.prevtouch = "";
EVENTS_Class.Touch.prevclicktime = 0;
EVENTS_Class.Touch.clickcount = 0;
EVENTS_Class.Touch.prevX = 0;
EVENTS_Class.Touch.prevY = 0;
EVENTS_Class.Touch.has_moved = false;

EVENTS_Class.TouchHandler = function(event){
    var touches = event.changedTouches, first = touches[0], type = "";
    
    //~ EVENTS_Class.debug = true;
    //~ console.log(event);

    switch(event.type){
        case "touchstart":
            type = "mousedown";
        break;

        case "touchmove":
            type="mousemove";
            //~ event.preventDefault();
            //~ window.scroll(0,0);
        break;

        case "touchend":
            type="mouseup";
        break;
        
        default:
            EVENTS_Class.StopEvent(event);
            return;
    }
    
    let whichbtn = 0;
    let btnFlags = 1;
    let relatedTarget = null;
    
    if (event.touches.length > 1){
        whichbtn = 2;
        btnFlags = 1+2;
    }
    
    if (type =="mouseup") whichbtn = EVENTS_Class.prevbtn;
    
    if(type == "mousedown"){
        EVENTS_Class.Touch.mousedownElem = first.target;
        EVENTS_Class.Touch.prevOverElem = null;
    }
    
    let difX = 0;
    let difY = 0;
    var now = new Date().getTime();
    var difT = now - EVENTS_Class.Touch.preveventtime;
    
    var longPress = difT > 500;
    
    if(type == "mousemove"){
        //~ let difT = (EVENTS_Class.Touch.history[EVENTS_Class.Touch.history.length-1].time - first.time);
        
        //~ console.log('difT', difT, 'longPress', longPress);
        
        var overElem = document.elementFromPoint(first.pageX , first.pageY );
    
        if(EVENTS_Class.Touch.prevOverElem && overElem != EVENTS_Class.Touch.prevOverElem){
            EVENTS_Class.SendEvent(EVENTS_Class.Touch.prevOverElem,'mouseout');
            EVENTS_Class.SendEvent(overElem,'mouseover');
            //~ console.log('moved out');
        }
        EVENTS_Class.Touch.prevOverElem = overElem;

        if(EVENTS_Class.Touch.history.length > 1){
            let t = EVENTS_Class.Touch.history[EVENTS_Class.Touch.history.length-1];            
            difX = Math.abs(t.x - first.screenX);
            difY = Math.abs(t.y - first.screenY);
            //dbg(difX+" "+difY);

            if(difX < 5 && difY < 5){
                EVENTS_Class.StopEvent(event);
                return false;
            }
        }
    }
    
    if(event.type != 'touchmove') EVENTS_Class.Touch.history.push({'type':event.type,'x':first.screenX,'y':first.screenY,'time':now});
    var cnt = EVENTS_Class.Touch.history.length;

    if(type != 'click' && cnt>2 && (event.type == "touchend" || event.type == "touchcancel") && EVENTS_Class.Touch.mousedownElem == first.target){
        let t = EVENTS_Class.Touch.history[cnt-2];
        let difX = Math.abs(t.x - first.screenX);
        let difY = Math.abs(t.y - first.screenY);
        let difT = (now - t.time);

        if(t.type == "touchstart" && difT < 300 && difX < 30 * window.devicePixelRatio && difY < 30 * window.devicePixelRatio ){
            type = "click";
            EVENTS_Class.Touch.history.push({'type':event.type,'x':first.screenX,'y':first.screenY,'time':now});
        }

    }
    
    while(EVENTS_Class.Touch.history.length > 4){
        EVENTS_Class.Touch.history.shift();
    }

    if(type == "click"){
        whichbtn = EVENTS_Class.Touch.prevbtn;
    }

    var dif = 999;
    EVENTS_Class.Touch.preveventtime = now;

    cnt = EVENTS_Class.Touch.eventsList.length;
    if(type == "click"){
        if(cnt > 1){
            let o = EVENTS_Class.Touch.eventsList[cnt-1];
            let difX = Math.abs(o.x - first.screenX);
            let difY = Math.abs(o.y - first.screenY);
            let difT = (EVENTS_Class.Touch.preveventtime - o.time);

            if(o.type=="click" && difX < 30 * window.devicePixelRatio && difY < 30 * window.devicePixelRatio &&  difT < 300 ){
                type = "dblclick";
                EVENTS_Class.previousMouseDownEvent;
            }
        }
        EVENTS_Class.Touch.eventsList.push({'type':type,'x':first.screenX,'y':first.screenY,'time':now});
    }

    while(EVENTS_Class.Touch.eventsList.length > 4){
        EVENTS_Class.Touch.eventsList.shift();
    }

    EVENTS_Class.Touch.prevtouch = event.type;
    EVENTS_Class.Touch.prevbtn = whichbtn;
    
    if (EVENTS_Class.debug){
        console.log('touch type',type);
        console.log('event.type',event.type);
    }
    
    //~ if (type != 'mousemove'){
    //~ EVENTS_Class.StopEvent(event);
    //~ }
    
    if(type == "click" || type == "dblclick" || type == 'mouseup'){
        let simulatedEvent = EVENTS_Class.createMouseEvent("mouseup" , first.screenX , first.screenY , first.clientX , first.clientY , false , false , false , false , whichbtn , btnFlags , relatedTarget);
        if (EVENTS_Class.debug){
            console.log('simulate mouseup');
        }
        first.target.dispatchEvent(simulatedEvent);
        //~ document.dispatchEvent(simulatedEvent);
        
        // the touch moved (can be a scroll or a drag) we don't want the normal behavior of sending click event because
        // this will lead to unwanted trig of click event when scrolling but if we do wnat the trig of mouseup event to trig the end handler of dragging
        // mouseup ->  end of drag
        // click -> all our mouse event
        if (EVENTS_Class.Touch.has_moved){
            return false;
        }
        
        
        let clickSimulatedEvent = EVENTS_Class.createMouseEvent("click" , first.screenX , first.screenY , first.clientX , first.clientY , false , false , false , false , whichbtn , btnFlags , relatedTarget);
        if (EVENTS_Class.debug){
            console.log('simulate click');
            console.log(first.target);
        }
        first.target.dispatchEvent(clickSimulatedEvent);
        //~ document.dispatchEvent(clickSimulatedEvent);
        first.target.focus();
    }

    if(type == "mousedown"){
        EVENTS_Class.Touch.has_moved = false;
        let simulatedEvent = EVENTS_Class.createMouseEvent("mouseover" , first.screenX , first.screenY , first.clientX , first.clientY , false , false , false , false , whichbtn , btnFlags , relatedTarget);
        if (EVENTS_Class.debug){
            console.log('simulate mouseover');
        }
        first.target.dispatchEvent(simulatedEvent);
        //~ document.dispatchEvent(simulatedEvent);
        
        let simulatedEventMousedown = EVENTS_Class.createMouseEvent("mousedown" , first.screenX , first.screenY , first.clientX , first.clientY , false , false , false , false , whichbtn , btnFlags , relatedTarget);
        if (EVENTS_Class.debug){
            console.log('simulate mousedown');
        }
        first.target.dispatchEvent(simulatedEventMousedown);
        //~ document.dispatchEvent(simulatedEventMousedown);
        // simulate mousedown
        
    }
   
    if (type == 'mousemove'){
        //~ console.log('MOVED');
        if (longPress){
            EVENTS_Class._InitDrag(EVENTS_Class.currentMouseDownEvent.target);
            EVENTS_Class.Touch.has_moved = true;
            
            //~ overElem.style['touch-action'] = 'none';
            //~ console.log("overElem.style['touch-action']", overElem.style['touch-action']);
            // disable scroll when dragging an item
        }
        
        if (EVENTS_Class.Touch.has_moved){
            //~ EVENTS_Class.StopEvent(event);
            //~ overElem.setAttribute('style', 'touch-action: none;');
            //~ overElem.parentElement.setAttribute('style', 'touch-action: none;');
            /* 
             * For the move and the drag.
             * On Mobile, there is a passive mode on the event that ease the scroll
             * Need to stop the touch event here for disabling the touch
             */
            if(GENERICS_Class.IsFilledArray(EVENTS_Class._moveList)){
                event.preventDefault();
                //~ EVENTS_Class.StopEvent(event);
                //~ if (EVENTS_Class.Touch.mousedownElem == first.target)
                //~ let difT = (EVENTS_Class.Touch.mousedownElem.time - o.time);
                //~ if (difT > 1000){
                    //~ return;
                //~ }
                //~ console.log('moved');
                
                
                //~ event.target.style['touch-action'] = 'none';
            }
            let simulatedEvent = EVENTS_Class.createMouseEvent("mousemove" , first.screenX , first.screenY , first.clientX , first.clientY , false , false , false , false , whichbtn , btnFlags , relatedTarget);
            if (EVENTS_Class.debug){
                console.log('simulate mousemove');
            }
            first.target.dispatchEvent(simulatedEvent);
            //~ document.dispatchEvent(simulatedEvent);
        } else {
            //~ $_e.StopEvent(event);
            //~ overElem.style['touch-action'] = null;
            //~ console.log("overElem.style['touch-action']", overElem.style['touch-action']);
            //~ overElem.parentElement.removeAttribute('style');
            //~ overElem.parentElement.style['touch-action'] = 'initial';
        }
    }
    
    //~ if (type == 'mouseup'){
        //~ let simulatedEvent = EVENTS_Class.createMouseEvent("mouseup" , first.screenX , first.screenY , first.clientX , first.clientY , false , false , false , false , whichbtn , btnFlags , relatedTarget);
        //~ if (EVENTS_Class.debug){
            //~ console.log('simulate mouseup');
        //~ }
        //~ first.target.dispatchEvent(simulatedEvent);
    //~ }

    if(type == "mouseup" || type=="click" || type=="dblclick"){
        mousedownElem = null;
        prevOverElem = null;
        //~ EVENTS_Class.StopEvent(event);
    }
    
    //~ if (event.type == 'touchend'){
        //~ EVENTS_Class.StopEvent(event);
        //~ event.cancelBubble = true;
        //~ event.returnValue = false;
        //~ return false;
    //~ } 

    //~ if (type == "click"){
        
    //~ }else{
        //~ let simulatedEvent = EVENTS_Class.createMouseEvent(type , first.screenX , first.screenY , first.clientX , first.clientY , false , false , false , false , whichbtn , btnFlags , relatedTarget);
        //~ if (EVENTS_Class.debug){
            //~ console.log('simulate '+type);
        //~ }
        //~ first.target.dispatchEvent(simulatedEvent);
        
    //~ }

    //~ if(STOPME){
        //~ STOPME = false;
    //~ }
    
    //~ let mouseEvent = EVENTS_Class.createMouseEvent(type,first.screenX,first.screenY,first.clientX,first.clientY,false,false,false,false,whichbtn,btnFlags,relatedTarget);
    //~ first.target.dispatchEvent(mouseEvent);
    //~ if (type == 'mouseup'){
        //~ let mouseEvent = EVENTS_Class.createMouseEvent('click',first.screenX,first.screenY,first.clientX,first.clientY,false,false,false,false,whichbtn,btnFlags,relatedTarget);
        //~ first.target.dispatchEvent(mouseEvent);
    //~ }
    
    //~ EVENTS_Class.StopEvent(event);

    //~ event.cancelBubble = true;
    //~ event.returnValue = false;

    //~ return false;
};

EVENTS_Class.createMouseEvent = function(type , sX, sY , cX , cY , cK , sK , aK , mK , btnValue , btnFlags , relatedTarget, detail={}){
    return new MouseEvent(type,{
        'screenX':sX,
        'screenY':sY,
        'clientX':cX,
        'clientY':cY,
        'ctrlKey':cK,
        'shiftKey':sK,
        'altKey':aK,
        'metaKey':mK,
        'button':btnValue,
        'buttons':btnFlags,
        'relatedTarget':relatedTarget,
        'detail': detail,
        'bubbles': true,
        'cancelable': true,
    });
};

/*
 * SHORTCUT FUNCTION 
 * All module use those functions to manage their events
 */
 
/* ADD EVENT */
EVENTS_Class.AddEventClick = function(domElement, callback, useCapture,timed=false){
    EVENTS_Class.AddEvent(domElement, EVENTS_Class.EVENT_CLICK, callback, useCapture,timed);
};
EVENTS_Class.AddEventDblClick = function(domElement, callback, useCapture,timed=false){
    EVENTS_Class.AddEvent(domElement, EVENTS_Class.EVENT_DOUBLECLICK, callback, useCapture,timed);
};
EVENTS_Class.AddEventKey = function(domElement, callback, useCapture,timed=false){
    EVENTS_Class.AddEvent(domElement, EVENTS_Class.EVENT_KEYUP, callback, useCapture,timed);
};
EVENTS_Class.AddEventClickOutside = function(domElement, callback, useCapture,timed=false){
    EVENTS_Class.AddEvent(domElement, EVENTS_Class.EVENT_MOUSEDOWN_OUTSIDE, callback, useCapture,timed);
};

/* REMOVE EVENT */
EVENTS_Class.RemoveEventClick = function(domElement, callback){
    EVENTS_Class.RemoveEvent(domElement, EVENTS_Class.EVENT_CLICK, callback);
};
EVENTS_Class.RemoveEventDblClick = function(domElement, callback){
    EVENTS_Class.RemoveEvent(domElement, EVENTS_Class.EVENT_DOUBLECLICK, callback);
};
EVENTS_Class.RemoveEventKey = function(domElement, callback){
    EVENTS_Class.RemoveEvent(domElement, EVENTS_Class.EVENT_KEYUP, callback);
};
EVENTS_Class.RemoveEventClickOutside = function(domElement, callback){
    EVENTS_Class.RemoveEvent(domElement, EVENTS_Class.EVENT_MOUSEDOWN_OUTSIDE, callback);
};

/* SEND EVENT */
/* DO NOT USED FROM ANOTHER EVENT ! NESTED EVENT SYNDROME WILL OCCURED WITH dispatchEvent */
EVENTS_Class.SendEventClick = function(domElement, data, bubbles, cancelable){
    EVENTS_Class.SendEvent(domElement, EVENTS_Class.EVENT_CLICK, data, bubbles, cancelable);
};
EVENTS_Class.SendEventDblClick = function(domElement, data, bubbles, cancelable){
    EVENTS_Class.SendEvent(domElement, EVENTS_Class.EVENT_DOUBLECLICK, data, bubbles, cancelable);
};
EVENTS_Class.SendEventKey = function(domElement, data, bubbles, cancelable){
    EVENTS_Class.SendEvent(domElement, EVENTS_Class.EVENT_KEYUP, data, bubbles, cancelable);
};
EVENTS_Class.SendEventClickOutside = function(domElement, data, bubbles, cancelable){
    EVENTS_Class.SendEvent(domElement, EVENTS_Class.EVENT_MOUSEUP_OUTSIDE, data, bubbles, cancelable);
};
//Spade 3 History script to manage ajax calls from history move
var tablehash=new Array('');
var timer_modal = false;
var timer_modal_is_hide = true;

// handle the hash change event
function detect_hash(){
    let hash = document.location;
    hash=hash.toString();
    hash=hash.split('#');

    if (hash[1] !== "" && hash[1] !== undefined) {
        // full hash compare
        let full_hash = decodeURI(hash[1]);
        let previous_hash = '';
        if(tablehash.length){
            previous_hash = tablehash[tablehash.length-1];
        }
        if(previous_hash != full_hash){
            // not the same need to do something
            // split by � to handle multiple ajax call in one hash
            // the symbol � is not accepted by javascript, so we use the encodeURI replacement
            // if we add decodeURI on the hash, it will break this code
            let hashArray = full_hash.split("%C2%A4");
            // get the first part of the hash
            let new_hash = hashArray.shift();
            // console.log(new_hash);
            // handle the first part of the hash and pass the rest of the call
            // when first part done will pass the next hash in array
            //redirect check
            let recheck=new_hash.split("|")[0];
            if (recheck!='artiredirect'){
                set_hash(new_hash,hashArray);
            }
        }
    }else{
        //if we're back to start
        if (tablehash.length>1){
            set_hash('');
        }
    }
}


// handle the hash with multiple ajax call to chain
//~ function multiple_hash(hashArray){
    //~ let new_hash = hashArray.shift();
    //~ let previous_hash = '';
    //~ if(tablehash.length){
        //~ previous_hash = tablehash[tablehash.length-1];
    //~ }
    //~ if(previous_hash.includes(new_hash) === false){
        //~ set_hash(new_hash,hashArray);
    //~ } else {
        //~ if (hashArray.length > 0) multiple_hash(hashArray);
    //~ }
//~ }

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// new_hash is the current one
// hashArray contains the next call to do
function set_hash(new_hash,hashArray=false){
    //close burger
    if (UI_Burger!=undefined){
        UI_Burger.Close();
    }
    var modal = false;
    let previous_hash = '';
    if(tablehash.length){
        previous_hash = tablehash[tablehash.length-1];
    }
    // back to the home
    if (new_hash == ''){
        document.location = document.location.toString().split('#')[0].split('?')[0];
        return;
    }
    // if the previous hash contains the new hash, that mean that this part of the hash is already loaded
    // nothing more to do here except (if there is one) loading the next part of the hash 
    //~ console.log(new_hash);
    //~ console.log(hashArray);
    //~ console.log(previous_hash.includes(new_hash));
    if(previous_hash.includes(new_hash) === false || hashArray.length==0){  //si pas de hasharray il n'y a plus rien � splitter il faut reload le module, cas du #news
        //Parse and send ajax call
        let params=new_hash.split('-');
        // hash format : moduleData-lang-container
        let settings = {};
        settings.url = document.baseURI.split('?')[0];
        if (params[2] !== "" && params[2] !== undefined) {
            settings.dom_target=params[2];
        }else{
            settings.dom_target='lemain';
        }
        settings.data = {};
        // always needed
        // without will try to load the full site not only the wanted module
        settings.data.core_action = 'core_mono';
        let module_name='';
        params[0] = params[0].replace('<>', '-');
        if (params[0].includes('|')){
            // if it's a custom link (with multiple parameters in it)
            // need to get all the parameters and populate them in the settings data.
            let module = params[0].split('|');
            //~ module_name = module[0].split('/')[0];
            module_name = (module[0].endsWith('=')) ? module[0].slice(0,-1) : module[0];
            module.splice(0,1);
            module.forEach( (str) => {
                let tt = str.split('=');
                settings.data[tt[0]] = tt[1];
            });
            // don't forget to add the module name (with no parameters in this case)
            // without that the module will not load (security ?)
            settings.data[module_name]='';
        } else {
            let custom = false;
            let module=params[0].split('=');
            module_name=module[0];
            let module_param=module[1];
            settings.data[module_name]=module_param;
            // and a switch of language
        }
        if (params[1] !== "" && params[1] !== undefined) {
            settings.data.language = params[1];
        }
        
        // we have a request for an indexable module
        //~ if (module_name !== "" && module_name !== undefined) {
            
            
        //~ if (settings.url.replace(CONSTANTS.base_url, '').split('/').length == 1){
            settings.success = function(res){
                if (window.anim){
                    detect_anime(res);
                }
                // if (!timer_modal_is_hide){
                //     timer_modal.Hide();
                //     timer_modal_is_hide = true;
                // }
                
                // if we have hashArray, that mean that we are doing a multiple call, need to exec the next
                if (hashArray && hashArray.length > 0) {
                    new_hash = hashArray.shift();
                    set_hash(new_hash,hashArray);
                } else {
                    // add the full hash to the list
                    // can't use new_hash because it can be just a part of the full hash (when in a multiple call)
                    tablehash.push(document.location.toString().split('#')[1]);
                }
            };
            
            // if (!timer_modal){
            //     timer_modal =  UI_Class.AddWindow(null, {'modal': true, 'nodrag': true, 'class':'timer_requete', 'disableBackgroundClick': true});
            //     timer_modal.SetParent(document.body, 0.5, 0.5);
            //     timer_modal_is_hide = false;
            // } else {
            //     if (timer_modal_is_hide) {
            //         timer_modal.Show();
            //         timer_modal_is_hide = false;
            //     }
            // }
        //~ }
        $_a.send(settings,10);
        window.scrollTo(0, 0);
        //~ }
    } else if (hashArray) {
        //~ console.log(hashArray);
        new_hash = hashArray.shift();
        set_hash(new_hash,hashArray);
    }
}
//la m�me chose que set-hash mais sans toucher � l'historique
// same thing than set-hash but without modify history
function jump_hash(new_hash){

    let params=new_hash.split('-');
    // hash format : moduleData-lang-container
    let settings = {};
    settings.url = document.baseURI.split('?')[0];
    if (params[2] !== "" && params[2] !== undefined) {
        settings.dom_target=params[2];
    }else{
        settings.dom_target='lemain';
    }
    settings.data = {};
    // always needed
    // without will try to load the full site not only the wanted module
    settings.data.core_action = 'core_mono';
    let module_name='';
    params[0] = params[0].replace('<>', '-');
    if (params[0].includes('|')){
        // if it's a custom link (with multiple parameters in it)
        // need to get all the parameters and populate them in the settings data.
        let module = params[0].split('|');
        //~ module_name = module[0].split('/')[0];
        module_name = (module[0].endsWith('=')) ? module[0].slice(0,-1) : module[0];
        module.splice(0,1);
        module.forEach( (str) => {
            let tt = str.split('=');
            settings.data[tt[0]] = tt[1];
        });
        // don't forget to add the module name (with no parameters in this case)
        // without that the module will not load (security ?)
        settings.data[module_name]='';
    } else {
        let custom = false;
        let module=params[0].split('=');
        module_name=module[0];
        let module_param=module[1];
        settings.data[module_name]=module_param;
        // and a switch of language
    }
    if (params[1] !== "" && params[1] !== undefined) {
        settings.data.language = params[1];
    }
    
    // we have a request for an indexable module
    //~ if (module_name !== "" && module_name !== undefined) {
        
        
    //~ if (settings.url.replace(CONSTANTS.base_url, '').split('/').length == 1){
        settings.success = function(res){
            if (window.anim){
                detect_anime(res);
            }
            if (!timer_modal_is_hide){
                timer_modal.Hide();
                timer_modal_is_hide = true;
            }
            
            // if we have hashArray, that mean that we are doing a multiple call, need to exec the next
            // if (hashArray && hashArray.length > 0) {
            //     new_hash = hashArray.shift();
            //     set_hash(new_hash,hashArray);
            // } else {
            //     // add the full hash to the list
            //     // can't use new_hash because it can be just a part of the full hash (when in a multiple call)
            //     tablehash.push(document.location.toString().split('#')[1]);
            // }
        };
        
        if (!timer_modal){
            timer_modal =  UI_Class.AddWindow(null, {'modal': true, 'nodrag': true, 'class':'timer_requete', 'disableBackgroundClick': true});
            timer_modal.SetParent(document.body, 0.5, 0.5);
            timer_modal_is_hide = false;
        } else {
            if (timer_modal_is_hide) {
                timer_modal.Show();
                timer_modal_is_hide = false;
            }
        }
    //~ }
    $_a.send(settings,10);
    window.scrollTo(0, 0);
    //~ console.log(new_hash);
    // var modal = false;
    // //Parse and send ajax call
    // let params=new_hash.split('-');
    // let settings = {};
    // settings.url = document.baseURI;
    // if (params[2] !== "" && params[2] !== undefined) {
    //     settings.dom_target=params[2];
    // }else{
    //     settings.dom_target='lemain';
    // }
    // let module=params[0].split('=');
    // let module_name=module[0];
    // let module_param=module[1];
    // settings.data = {};
    // we have a request for an indexable module
    // if (module_name !== "" && module_name !== undefined) {
        // settings.data[module_name]=module_param;
        // settings.data.core_action = 'core_mono';
        // // and a switch of language
        // if (params[1] !== "" && params[1] !== undefined) {
        //     settings.data.language = params[1];
        // }
        // if (settings.url.replace(CONSTANTS.base_url, '').split('/').length == 1){
        //     settings.success = function(res){
        //         if (window.anim){
        //             detect_anime(res);
        //         }
        //         if (!timer_modal_is_hide){
        //             timer_modal.Hide();
        //             timer_modal_is_hide = true;
        //         }
        //     };
            
        //     if (!timer_modal){
        //         timer_modal =  UI_Class.AddWindow(null, {'modal': true, 'nodrag': true, 'class':'timer_requete', 'disableBackgroundClick': true});
        //         timer_modal.SetParent(document.body, 0.5, 0.5);
        //         timer_modal_is_hide = false;
        //     } else {
        //         if (timer_modal_is_hide) {
        //             timer_modal.Show();
        //             timer_modal_is_hide = false;
        //         }
        //     }
        // }
        // $_a.send(settings,10);
        // window.scrollTo(0, 0);
    // }
    //}
}

var try_socials=false;
function update_socials(module_name,module_param,language=false,collapse=false){
    let social_container = document.getElementById('socials_public_container');
    if (social_container){
        let settings = {};
        let url = CONSTANTS.base_url+'public/socials/index.php';
        settings.url = url;
        //settings.dom_target='';
        settings.data = {};
        if (language) {
            settings.data.language = language;
        }
        if (social_container.children.length == 3 || collapse){
            settings.data.social_collapse = true;
        }
        //~ settings.data['core_insert']=false;
        settings.skip_container = true;
        settings.data.module_name = module_name;
        settings.data.module_param = module_param;

        settings.success = function(res, e){
            if (!res.includes('Error')) {
                let container = document.getElementById('socials_public_container');
                container.innerHTML=res;
                if (container.children.length == 3){
                    Socials.init(1);
                }
            }
        };
        try_socials=false;
        $_a.send(settings);
    }else{
        if (try_socials==false){
            try_socials=true;
            //~ console.log(module_name+module_param+language);
            setTimeout(function(){update_socials(module_name,module_param,language);},500);
        }
    }
}
//complexe UI objects or method that are not related to only ONE dom element (see dom.js for that).
var UI_Class = function(){};
UI_Class.prototype.constructor = UI_Class;
//~ class UI_Class{
    //~ constructor() {
        //~ this._eventHandlers = {};
    //~ }
//~ }
UI_Class.lastZIndex;
UI_Class.img = false;

// params : css class of the buttons
// buttons must have data-id_target that points to the corresponding tinyMce field
UI_Class.CopyPasteTinymce = function(copyClass, pasteClass) {
    var tinyContent;
    var btnsCopy = document.getElementsByClassName(copyClass);
    var btnsPaste = document.getElementsByClassName(pasteClass);
    for (let i = 0; i < btnsCopy.length; i++) {
        btnsPaste[i].style.display = 'none';
        btnsCopy[i].addEventListener('click', function(e){
            var id = e.target.dataset.id_target;
            var elem = document.getElementById(id);
            tinyContent = elem._tinymce.getContent();
            curLang = elem.name.split('[')[3].replace(']', '');
            for (let i = 0; i < btnsPaste.length; i++) {
                btnsPaste[i].style.display = 'inline-block';
                if (!$_e.HasEvent(btnsPaste[i], EVENTS_Class.EVENT_CLICK)){
                    EVENTS_Class.AddEvent(btnsPaste[i], EVENTS_Class.EVENT_CLICK, function(e){
                        var id = e.target.dataset.id_target;
                        var elem = document.getElementById(id);
                        let domContent = DOM_Class.StringToDom(tinyContent, true);
                        UI_Class.img = false;
                        for (let j = 0; j < domContent.length; j++){
                            UI_Class.RecurseGetImg(domContent[j]);
                        }
                        if (UI_Class.img){
                            let old_field_identifier = UI_Class.img.dataset.field_identifier;
                            let new_field_identifier = old_field_identifier.replace(curLang, elem.name.split('[')[3].replace(']', ''));
                            let re = new RegExp(old_field_identifier, 'g');
                            tinyContent = tinyContent.replace(re,  new_field_identifier);
                            let settings = {};
                            settings.url = document.baseURI.split('?')[0].split('#')[0] + 'media/index.php';
                            settings.skip_container = true;
                            settings.dom_target = '';
                            settings.data = {
                                'media_action': 'media_copy_tinymce',
                                'src_field_identifier': old_field_identifier,
                                'dst_field_identifier': new_field_identifier
                            };
                            settings.success = function(){
                                elem._tinymce.focus();
                                elem._tinymce.insertContent(tinyContent);
                            };
                            $_a.send(settings);
                        } else {
                            //~ elem._tinymce.focus();
                            elem._tinymce.insertContent(tinyContent);
                        }
                    });
                }
            }
        });
    }
};

UI_Class.RecurseGetImg = function(domElem){
    if (domElem.tagName == 'IMG' && domElem.dataset.field_identifier){
        UI_Class.img = domElem;
        return;
    } else if (domElem.children){
        for (let k = 0; k < domElem.children.length; k++){
            UI_Class.RecurseGetImg(domElem.children[k]);
        }
    }
};

// params:  cible -> css class of the elements receiving the click 
//          cssClass -> the css class to toggle
//          customFunc -> custom function executed when displaying an elem
//          indicator -> id of the collapse indicator
// the target must have "data-target_id" that points to the element to toggle
UI_Class.ToggleAccordion = function(cible, cssClass, customFunc=false, indicator=false) {
    var elems = document.getElementsByClassName(cible);
    for (let i = 0; i < elems.length; i++) {
        var elem = elems[i];
        let indic = false;
        if (!indicator){
            indic = elem.previousElementSibling;
        } else {
            indic = document.getElementById(indicator);
        }
        if (!$_e.HasEvent(elem, EVENTS_Class.EVENT_CLICK)){
            EVENTS_Class.AddEvent(elem, EVENTS_Class.EVENT_CLICK, onClick);
        }
        if (indic && !$_e.HasEvent(indic, EVENTS_Class.EVENT_CLICK)){
            indic.dataset.cible = '1';
            $_e.AddEvent(indic, EVENTS_Class.EVENT_CLICK, onClick);
        }
    }
    
    function onClick(e){
        let elem = e.target;
        if (elem.dataset.cible){
            elem = elem.nextElementSibling;
        }
        var targ = document.getElementById(elem.dataset.target_id);
        DOM_Class.ToggleClass(targ, cssClass);
        var indicator = elem.previousElementSibling;
        if (!indicator) {
            indicator = document.getElementById(indicator);
        }
        if (indicator){
            if (indicator.textContent.includes('►')) {
                indicator.textContent = '▼';
                if (customFunc){
                    customFunc(e);
                }
            } else {
                indicator.textContent = '►';
            }
        }
    }
};

UI_Class.ChangeImageClass = function(classname){
    var imgs = document.getElementsByClassName(classname);
    var i = 0;
    while(imgs.length > 0) {
        var img = imgs[i];
        let rect = DOM_Class.GetGlobalRect(img);
        var height = DOM_Class.GetGlobalHeight(img);
        var width = DOM_Class.GetGlobalWidth(img);
        if (width >= height) {
            DOM_Class.ToggleClass(img, classname);
            DOM_Class.ToggleClass(img, classname+'_paysage');
        } else {
            DOM_Class.ToggleClass(img, classname);
            DOM_Class.ToggleClass(img, classname+'_portrait');
        }
    }
};

// params :
//      container -> id of the container to refresh
//      params -> parameters for the post
UI_Class.RefreshContainer = function(container, params, pub = true){
    if (!container) {
        return false;
    }
    var settings = {};
    settings.dom_target = container;
    var moduleName = container.split('_');
    moduleName = moduleName[0];

    settings.skip_container = true;

    var url = document.baseURI;
    url = url.split('#');
    url = url[0].split('?');
    url = url[0];
    if (pub) url += 'public/';
    url += moduleName +'/index.php';

    settings.url = url;


    settings.data = {};
    if (params){
        settings.data = params;
    }

    $_a.send(settings);
};

UI_Class.LoadModuleInPage = function(domElem, params){

    let settings={};

    settings.url = CONSTANTS.base_url + 'public/core/index.php';

    settings.dom_target = domElem;

    settings.data = {'core_action': 'core_mono'};
    Object.entries(params).forEach((arr) => {
        settings.data[arr[0]] = arr[1];
    });

    settings.success = function(res){
        if (document.baseURI.includes('page')){
            domElem._overlay.mceEditor.editorManager.execCommand('mceRemoveEditor',true, domElem.id);
            domElem._overlay.EnableTextEditor();
        }
    };
    $_a.send(settings);

};

UI_Class.ShowBigImage = function(evt, newUrl = false){
    let url = document.baseURI;
    if (evt && url.replace(CONSTANTS.base_url, '').split('/').length == 1){
        let targ = evt.target;

        // make container big image
        let big = document.getElementById('ui_container_big_image');
        if (!big){
            big = DOM_Class.CreateElement('DIV', {'class': 'ui_container_big_image', 'id': 'ui_container_big_image'});
            let div = DOM_Class.CreateElement('DIV');
            let img = DOM_Class.CreateElement('IMG', {'class': 'ui_big_image'});
            let croix = DOM_Class.CreateElement('DIV', {'class': 'galerie_close'});
            DOM_Class.AppendContent(div, img);
            DOM_Class.AppendContent(div, croix);
            DOM_Class.AppendContent(big, div);
            DOM_Class.AppendContent(document.body, big);

            $_e.AddEventClick(croix, closeBigImage);
        }
        let img = big.firstElementChild.firstElementChild;
        if (newUrl) img.src = newUrl;
        else img.src = targ.src;

        // make overlay
        let overlay = document.getElementById('ui_overlay_big_image');
        if (!overlay){
            overlay = DOM_Class.CreateElement('DIV', {'class': 'ui_overlay_big_image', 'id': 'ui_overlay_big_image'});
            DOM_Class.AppendContent(document.body, overlay);
        }
        // DOM_Class.ToggleClass(big, 'hide', false);
        // DOM_Class.ToggleClass(overlay, 'hide', false);
        DOM_Class.ToggleClass(big, 'hidden', false);
        DOM_Class.ToggleClass(overlay, 'hidden', false);

        $_e.AddEventClick(overlay, closeBigImage);

        function closeBigImage(evt){
            console.log(evt);
            // DOM_Class.ToggleClass(big, 'hide', true);
            // DOM_Class.ToggleClass(overlay, 'hide', true);
            DOM_Class.ToggleClass(big, 'hidden', true);
            DOM_Class.ToggleClass(overlay, 'hidden', true);
        }
    }
    return;
};

// elemID -> dom id of the dom target
// nbrPx -> number of pixel to scroll before add the css class
// className -> name of the css class to add
UI_Class.ScrollToggleClass = function(elemID, nbrPx, className){
    $_e.AddEvent(window, 'scroll', function(event){
        let elem = document.getElementById(elemID);
        if (elem){
            let py = event.pageY || document.body.scrollTop || window.pageYOffset;
            if (py > nbrPx && !DOM_Class.HasClass(elem, className)){
                DOM_Class.ToggleClass(elem, className, true);
            }
            if (py <= nbrPx && DOM_Class.HasClass(elem, className)){
                DOM_Class.ToggleClass(elem, className, false);
            }
        }
    });
};
// specific for siteLA public, be carefull to don't break it
UI_Class.ScrollTo = function(domID, offset=0){
    let domElem = document.getElementById(domID);
    let rect = DOM_Class.GetGlobalRect(domElem, true);
    
    let top = Math.round(rect.top - 70);
    console.log(top);
    
    window.scrollTo(0, top);
};

UI_Class.getToken = function(evt,fromForm = false){
    //~ $_e.StopEvent(evt);
    //~ let targ = evt.target;
    //~ console.log('get token');
    let form = (fromForm) ? evt.target : evt.target.form;
    //~ let form = evt.target.form;
    let settings = {};
    settings.url = form.action;
    settings.skip_container = true;
    settings.dom_target = '';
    settings.data = {
        'action': 'formgettoken'
    };
    settings.success = function(res){
        if (res){
            //~ console.log(res.trim());
            //~ let form = evt.target.form;
            let id = form.id + '-token';
            let inpHidden = document.getElementById(id);
            if (inpHidden) {
                inpHidden.value = res.trim();
            } else {
                inpHidden = DOM_Class.CreateElement('INPUT', {'id': id,'type': 'hidden', 'name': 'jsToken', 'value': res.trim(),'data-alwaysposted':1});
            }
            DOM_Class.AppendContent(form, inpHidden);
            
            //~ console.log('token added');
            //~ AJAX_Class.setFormSubmitter(evt.target);
            
            $_e.SendEvent(form, 'submit');
        }
    };
    $_a.send(settings);
};

UI_Class.popup = function(lapage,titre,w,h,scroll){ // open a window
    sx = screen.availWidth;
    sy = screen.availHeight;

    if(String(scroll)=="undefined" ) scroll=1;

    if(String(w)!="undefined" && String(h)=="undefined"){
        h = Math.floor(sy * w/100);
        w = Math.floor(sx * w/100);
    }

    if(h<2){ h = sy*h; }
    if(w<2){ w = sx*w; }

    if(h>sy) h=sy-64;
    if(w>sx) w=sx;

    titre = String(titre);
    if(titre=="undefined") titre="_new";

    px = ((sx - w) / 2);
    py = ((sy - (h+64)) / 2);

    params='scrollbars='+scroll+',status=1,resizable=1,width='+w+',height='+h+',screenx='+px+',left='+px+',screeny='+py+',top='+py;
    //titre="";
    open(String(lapage),String(titre),String(params));
    //~ open(String(lapage),String(titre));
    //~ top.opener.window.open('',String(titre));
};

UI_Class.newtab = function(lapage){ //ouvre un nouvel onglet...
    params='_blank';
    window.open(String(lapage),String(params));
};
//------------------------------------------------------------

UI_Class.popupModal = false;
UI_Class.popupSpecial = [];
// start moduleName with public/ to indicate that is a public url (automaticly add public to the url)
UI_Class.openPopupModal = function(evt, moduleName, params, special=false, special_level=1){
    //~ console.log(moduleName);
    //~ console.log(params);
    if (!moduleName) {
        console.log('no moduleName');
        return;
    }
    
    let is_public = false;
    if (moduleName.includes('public/')){
        moduleName = moduleName.replace('public/','');
        is_public = true;
    }
    
    
    if (special !== false){
        if (!UI_Class.popupSpecial[special]){
            UI_Class.popupSpecial.push(special);
            UI_Class.popupSpecial[special] = UI_Class.AddWindow(document.body, {'nodrag': false, 'hidden': true, 'modal': true, 'class': 'ui_window special '+moduleName, 'special':true, 'special_level': special_level});
            UI_Class.popupSpecial[special].domElement.setAttribute('id', 'popup_special_'+special);
            UI_Class.popupSpecial[special]._modalContent.setAttribute('id', 'popup_special_content_'+special);
        } else {
            UI_Class.popupSpecial[special].domElement.setAttribute('class', 'ui_window special hidden '+moduleName);
        }
    } else {
        if (!UI_Class.popupModal){
            UI_Class.popupModal = UI_Class.AddWindow(document.body, {'nodrag': false, 'hidden': true, 'modal': true, 'class': 'ui_window '+moduleName});
            UI_Class.popupModal.domElement.setAttribute('id', 'popup_modal');
            UI_Class.popupModal._modalContent.setAttribute('id', 'popup_modal_content');
        } else {
            UI_Class.popupModal.domElement.setAttribute('class', 'ui_window hidden '+moduleName);
        }
    }
    
    var url = document.baseURI;
    url = url.split('#');
    url = url[0].split('?');
    if (is_public) url = url[0] + 'public/' + moduleName + '/index.php';
    else url = url[0] + moduleName + '/index.php';

    let settings = {};
    settings.url = url;
    settings.dom_target = '';
    settings.skip_container = true;
    settings.container_name = 'popup_modal';
    if (params && GENERICS_Class.IsObject(params)) settings.data = params;
    else settings.data = {};
    settings.success = function(res){
        if (special !== false){
            UI_Class.popupSpecial[special].SetContent(res);
            UI_Class.popupSpecial[special].close = 'x';
            UI_Class.popupSpecial[special].Show();
            setTimeout(function(){DOM_Class.SetAlignment(UI_Class.popupSpecial[special].domElement, 0.5 , 0.5, false, true);},50);
        } else {
            UI_Class.popupModal.SetContent(res);
            UI_Class.popupModal.close = 'x';
            UI_Class.popupModal.Show();
            setTimeout(function(){DOM_Class.SetAlignment(UI_Class.popupModal.domElement, 0.5 , 0.5, false, true);},50);
        }
    };
    $_a.send(settings);
};

//---------------------------------------------
UI_Class.AddWindow = function(parentNode,settings){
    let win = new UI_Window(settings);

    if(parentNode){
        win.SetParent(parentNode);
    }

    return win;
};

UI_Class.modalKeyDownHandler = [];
UI_Class.modalKeyDownHandlerMaxLevel = 1;
UI_Class.modalErr = false;
//---------------------------------------------

UI_Window = function(settings){
    settings = settings || {};

    if(!settings.class) settings.class = 'ui_window';

    this.domElement = DOM_Class.CreateElement('DIV',{'class':settings.class});
    this.domElement._ui_object = this;

    EVENTS_Class.EnableDrag(this.domElement);

    this._modal = false;
    this._modalMask = null; // background div
    this._modalClose = null; // close button
    this._modalContent = DOM_Class.CreateElement('DIV',{'class':'ui_window_content'});
    this.domElement.appendChild(this._modalContent);
    this._special = false;
    this._special_level = 1;

    if(settings.disableBackgroundClick) this._disableBackgroundClick = true;
    // has to be before modal
    if(settings.special) this._special = true;
    if(settings.special_level) {
        this._special_level = settings.special_level;
        if (settings.special_level == 'err'){
            UI_Class.modalErr = this;
        } else {
            UI_Class.modalKeyDownHandlerMaxLevel = (UI_Class.modalKeyDownHandlerMaxLevel < this._special_level) ? this._special_level : UI_Class.modalKeyDownHandlerMaxLevel;
        }
    }
    if(settings.modal) this.modal = true;
    if(settings.close) this.close = settings.close;
    if(settings.hidden) this.Hide();
    if(settings.nodrag) EVENTS_Class.DisableDrag(this.domElement);
    
    if(!settings.disableKeydownClose && !this._disableBackgroundClick){
        UI_Class.modalKeyDownHandler.push(this);
    }
};
UI_Window.prototype.constructor = UI_Window;

Object.defineProperty(UI_Window.prototype, 'modal', {
    set: function(value) {
        if(value){
            if(!this._modalMask){
                this._modalMask = DOM_Class.CreateElement('DIV',{'class':'ui_modal_mask'});
                if(!this._disableBackgroundClick){
                    //~ EVENTS_Class.AddEvent(this._modalMask , EVENTS_Class.EVENT_DOUBLECLICK , this.OnDoubleClickMask.bind(this));
                    EVENTS_Class.AddEvent(this._modalMask , $_e.EVENT_CLICK , this.OnDoubleClickMask.bind(this));
                    //~ EVENTS_Class.AddEvent(this.domElement , $_e.EVENT_CLICK , this.OnDoubleClickMask.bind(this));
                }
            }
            if(this.domElement.parentNode){
                this.domElement.parentNode.insertBefore(this._modalMask , this.domElement);
            }
            this._modal = true;
            let base_zIndex = 100;
            if (this._special) {
                if (this._special_level == 'err'){
                    base_zIndex += 10;
                } else {
                    base_zIndex = base_zIndex - (this._special_level+2);
                }
                DOM_Class.SetStyleValue(this._modalMask , 'z-index',base_zIndex);
                DOM_Class.SetStyleValue(this.domElement , 'z-index',base_zIndex+1);
            } else {
                DOM_Class.SetStyleValue(this._modalMask , 'z-index',base_zIndex);
                DOM_Class.SetStyleValue(this.domElement , 'z-index',base_zIndex+1);
            }
        }else{
            if(this._modal){
                this._modalMask.remove();
            }
            this._modal = false;
            DOM_Class.SetStyleValue(this.domElement , 'z-index','');
        }
    }
});

Object.defineProperty(UI_Window.prototype, 'visible', {
    get: function() {
        // if (document.body.contains(this.domElement) && !this.domElement.classList.contains('hidden'))
        return (document.body.contains(this.domElement) && !this.domElement.classList.contains('hidden'));
    }
});

Object.defineProperty(UI_Window.prototype, 'close', {
    set: function(value) {
        //~ console.log(value);
        if (value){
            if (!this._modalClose) {
                this._modalClose = DOM_Class.CreateElement('BUTTON',{'class':'ui_window_close'}, value);
                EVENTS_Class.AddEvent(this._modalClose, $_e.EVENT_CLICK, this.Toggle.bind(this));
            }
            if(this.domElement){
                this.domElement.appendChild(this._modalClose);
            }
            //~ console.log(this._modalClose);
            //~ console.log(this.domElement);
            
        }
    }
});

UI_Window.prototype.onKeyPress = function(evt){
    // When key ESC press, close the modal
    if (evt.keyCode == 27 || evt.key == 'Escape' || evt.key == 'Esc'){
        // console.log(evt);
        let has_delete = false;
        // first we hide the err modal
        if (UI_Class.modalErr && UI_Class.modalErr.visible){
            UI_Class.modalErr.Hide();
            has_delete = true;
        }
        if (!has_delete){
            // second we hide all the modal that are not special
            UI_Class.modalKeyDownHandler.forEach((obj)=>{
                if (obj && !obj._special && obj.visible) {
                    obj.Hide();
                    has_delete = true;
                }
            });
            if (!has_delete){ // no normal, so we hide the first level of special
                for(let i=0;i < UI_Class.modalKeyDownHandlerMaxLevel;i++){
                    let levelFound = false;
                    UI_Class.modalKeyDownHandler.every((obj)=>{
                        if (obj && obj.visible && obj._special_level == (i+1)) {
                            obj.Hide();
                            levelFound = true;
                            return false;
                        }
                        return true;
                    });
                    // stop execution if we hide an element from the current level
                    if (levelFound) break;
                }
            }
        }
        // if (!has_delete){
            
        // }
    }
};

UI_Window.prototype.SetContent = function(content){
    if(GENERICS_Class.IsString(content)){
        DOM_Class.WriteHtml(this._modalContent, content);
        //~ this.domElement.innerHTML = content;
        //~ if (this._modalClose) this._modalContent.appendChild(this._modalClose);
    }else if(GENERICS_Class.IsDomObject(content)){
        this._modalContent.innerHTML = '';
        this._modalContent.appendChild(content);
        //~ if (this._modalClose) this._modalContent.appendChild(this._modalClose);
    } else if (GENERICS_Class.IsArray(content)){
        this._modalContent.innerHTML = '';
        content.forEach((elem)=>{
            if (GENERICS_Class.IsDomObject(elem)){
                this._modalContent.appendChild(elem);
            } else if(GENERICS_Class.IsString(content)){
                this._modalContent.innerHTML += content;
            }
        });
        //~ if (this._modalClose) this._modalContent.appendChild(this._modalClose);
    }
};

UI_Window.prototype.SetParent = function(parentNode , alignHorizontal , alignVertical){
    if(this._modalMask){
        parentNode.appendChild(this._modalMask);
    }
    parentNode.appendChild(this.domElement);
    DOM_Class._SetRectDirty(this.domElement);
    if(alignHorizontal) DOM_Class.SetAlignment(this.domElement , alignHorizontal , alignVertical);
    if (this.domElement._ComputedStyle && this.domElement._ComputedStyle.POS != 'fixed'){
        this.UpdateScrollPosition();
    }
};

UI_Window.prototype.UpdateScrollPosition = function(){
    let scrollY = window.pageYOffset;
    if(scrollY > 0){
        if (this.domElement){
            let top = parseInt(this.domElement.style.top.replace('px', ''));
            this.domElement.style.top = top + scrollY + 'px';
        }
    }
};

UI_Window.prototype.Toggle = function(){
    if(this.visible){
        this.Hide();
    }else{
        this.Show();
    }
    DOM_Class._SetRectDirty(this.domElement);
};

UI_Window.prototype.Hide = function(){
    if(this._modal){
        this._modalMask.classList.toggle('hidden',true);
    }
    this.domElement.classList.toggle('hidden',true);
    
    if (UI_Class.modalKeyDownHandler.indexOf(this) > -1){
        let disableKeyPressEvent = true;
        for (let index = 0; index < UI_Class.modalKeyDownHandler.length; index++) {
            let obj = UI_Class.modalKeyDownHandler[index];
            if (obj && obj.visible){
                disableKeyPressEvent = false;
                break;
            }
        }
        if (disableKeyPressEvent){
            console.log('disable event KeyUp');
            $_e.RemoveEventKey(document, this.onKeyPress);
        }
    }
};

UI_Window.prototype.Show = function(){
    if(this._modal){
        this._modalMask.classList.toggle('hidden',false);
    }
    this.domElement.classList.toggle('hidden',false);
    
    if (UI_Class.modalKeyDownHandler.indexOf(this) > -1){
        console.log('add event KeyUp');
        $_e.AddEventKey(document, this.onKeyPress);
    }
};

UI_Window.prototype.Remove = function(){
    if(this._modal){
        this._modalMask.remove();
    }
    this.domElement.remove();

    if (UI_Class.modalKeyDownHandler.indexOf(this) > -1){
        UI_Class.modalKeyDownHandler.splice(UI_Class.modalKeyDownHandler.indexOf(this), 1);
    }

};


UI_Window.prototype.OnDoubleClickMask = function(event){
    EVENTS_Class.StopEvent(event);
    this.Hide();
};

//------------------------------------------------------------
// UI_Button and UI_input only used in page and cropdrop at the moment
// to release or to evolve into a real class, is not convertible into a class as it is?

UI_Button = function(settings){
    var self = this;
    settings = settings || {};
    let domElement = settings.domElement;

    if(GENERICS_Class.IsString(domElement)){
        domElement = DOM_Class.GetDomElement(domElement);
    }
    if(GENERICS_Class.IsDomObject(domElement)){
        this.domElement = domElement;
        this.domElement.classList.toggle('ui_btn',true);
        this.domElement.classList.toggle('default',true);
    }else{
        this.domElement = DOM_Class.CreateElement('DIV',{'class':'ui_btn default'});
    }

    this.domElement._ui_object = this;

    if(settings.icon){
        this.domElement.innerHTML = '';
        this.domElement.classList.toggle('icon' , true);
        this.domElement.classList.toggle(settings.icon , true);

        this.domElement.classList.toggle('default' , false);

    }else if(settings.label){
        this.domElement.innerHTML = settings.label;
    }

    if(settings.css){
        this.domElement.className += ' '+settings.css;
    }

    if(settings.tooltip){
        this.tooltip = settings.tooltip;
        this.domElement.title = this.tooltip;
    }

    // indicates that this element can only be activated if a selection is present in the editing document
    this.select_active = settings.select_active || false;

    this.action = settings.action || null;

    if(settings.onclick){
        this._handler = settings.onclick;
    }

    EVENTS_Class.AddEvent(this.domElement , EVENTS_Class.EVENT_MOUSEUP , EVENTS_Class.BindCallback(this , this.OnClick) );
    if(settings.returnclick){
        EVENTS_Class.AddEvent(document, EVENTS_Class.EVENT_KEYDOWN , EVENTS_Class.BindCallback(this , this.ReturnClick) );
    }
};

UI_Button.prototype.constructor = UI_Button;

UI_Button.prototype.SetParent = function(parentNode){
    if(!parentNode){
        this.domElement.remove();
    }else{
        parentNode.appendChild(this.domElement);
    }
    //parentNode.appendChild(this.domElement);
    DOM_Class._SetRectDirty(this.domElement);
};

UI_Button.prototype.OnClick = function(event){
    if(event.button === 0){
        EVENTS_Class.StopEvent(event);
        if(GENERICS_Class.IsFunction(this._handler)){
            this._handler(event);
        }
    }
};

UI_Button.prototype.ReturnClick = function(event){
    if(event.key == "Enter" || event.keyCode == 13){
        EVENTS_Class.StopEvent(event);
        if(GENERICS_Class.IsFunction(self._handler)){
            self._handler(event);
        }
        // event.button=0;
        // this.OnClick(event);
    }
};

//------------------------------------------------------------

UI_Input = function(settings){
    settings = settings || {};

    let domElement = settings.domElement;

    if(GENERICS_Class.IsString(domElement)){
        domElement = DOM_Class.GetDomElement(domElement);
    }
    if(GENERICS_Class.IsDomObject(domElement)){
        this.domElement = domElement;
        this.domElement.classList.toggle('ui_input',true);
        this.domElement.innerHTML = '';
    }else{
        this.domElement = DOM_Class.CreateElement('DIV',{'class':'ui_input'});
    }


    this._input = DOM_Class.CreateElement('INPUT');
    this._label = DOM_Class.CreateElement('LABEL');
    this._text = document.createTextNode('');

    this.select_active = settings.select_active || false;

    this._label.appendChild(this._text);
    this._label.appendChild(this._input);
    this.domElement.appendChild(this._label);


    this.domElement._ui_object = this;

    if(settings.restrict){
        this._input.dataset.restrict = settings.restrict;
        $_v.protectInput(this._input);
    }

    if(settings.label){
        this._text.textContent = settings.label;
    }

    if(settings.css){
        this.domElement.className += ' '+settings.css;
    }

    if(settings.tooltip){
        this.tooltip = settings.tooltip;
        this.domElement.title = this.tooltip;
    }

    if(GENERICS_Class.IsFunction(settings.onchange)){

        this._onchange = settings.onchange;

        EVENTS_Class.AddEvent(this._input , EVENTS_Class.EVENT_CHANGE , this.OnChange.bind(this) );
        EVENTS_Class.AddEvent(this._input , EVENTS_Class.EVENT_KEYUP , this.OnChange.bind(this) );
        EVENTS_Class.AddEvent(this._input , EVENTS_Class.EVENT_MOUSEUP , this.OnChange.bind(this) );
    }

    this.action = settings.action || null;

};
UI_Input.prototype.constructor = UI_Input;

UI_Input.prototype.SetParent = function(parentNode){
    if(this.domElement.parent != parentNode){
        if(!parentNode){
            this.domElement.remove();
        }else{
            parentNode.appendChild(this.domElement);
        }
    }
    DOM_Class._SetRectDirty(this.domElement);
};

UI_Input.prototype.OnChange = function(event){
    if(this._onchange){
        if(this.action){
            this._onchange(this.action , this._input.value);
        }else{
            this._onchange(this._input.value);
        }
    }
};

Object.defineProperty(UI_Input.prototype, 'value', {
    get: function() {
        return this._input.value;
    },set: function(v) {
        this._input.value = v;
    }
});

Object.defineProperty(UI_Input.prototype, 'label', {
    get: function() {
        return this._label.value;
    },set: function(v) {
        this._label.value = v;
    }
});

//------------------------------------------------------------

UI_Class.MessagePopup = function(message , ok_handler){
    let settings = {};

    if(GENERICS_Class.IsArray(message)) message = message.join('<br>');

    settings.content = message;

    settings.buttons = [];
    settings.buttons.push({'label':CONSTANTS.texts.tlc_ok,'css':'btnokpopup','handler':ok_handler,'keyPress': ['Enter','Escape']});

    let w = new UI_PromptWindow(settings);
    w.SetParent(document.body,0.5,0.3);
};

UI_Class.ConfirmPopup = function(message , ok_handler , cancel_handler){
    let settings = {};

    if(GENERICS_Class.IsArray(message)) message = message.join('<br>');

    settings.content = message;

    settings.buttons = [];
    settings.buttons.push({'label':CONSTANTS.texts.tlc_ok,'handler':ok_handler,'keyPress': 'Enter'});
    settings.buttons.push({'label':CONSTANTS.texts.tlc_annuler,'handler':cancel_handler,'keyPress': 'Escape'});

    let w = new UI_PromptWindow(settings);
    w.SetParent(document.body,0.5,0.3);
    // console.log(w);
};

UI_PromptWindow = function(settings){
    settings.modal = true;
    settings.disableBackgroundClick = true;

    this.fields = settings.fields || {};

    UI_Window.call(this,settings);

    this.contentDiv = DOM_Class.CreateElement('DIV',{'class':'ui_prompt_message'});
    this.domElement.appendChild(this.contentDiv);
    if(settings.contentClass){
        this.contentDiv.className += ' '+settings.contentClass;
    }
    DOM_Class.AppendContent(this.contentDiv , settings.content);

    this.keyPress_btns = [];

    if(GENERICS_Class.IsArray(settings.buttons)){
        this.buttonsDiv = DOM_Class.CreateElement('DIV',{'class':'ui_prompt_buttons'});
        this.domElement.appendChild(this.buttonsDiv);

        for(let i = 0; i < settings.buttons.length ; i++){
            let b = settings.buttons[i];
            let btn = new UI_Button(b);
            btn.SetParent(this.buttonsDiv);
            btn.domElement._handler = b.handler;
            $_e.AddEventClick(btn.domElement,EVENTS_Class.BindCallback(this , this.OnClickButton));
            if (b.keyPress){
                if (GENERICS_Class.IsString(b.keyPress)){
                    this.keyPress_btns.push({'target': btn.domElement, 'key': b.keyPress});
                } else {
                    b.keyPress.forEach( key => {
                        this.keyPress_btns.push({'target': btn.domElement, 'key': key});
                    });
                }
                
            }
        }
    }else{
        let cancel_btn = new UI_Button({'tooltip':CONSTANTS.texts.tlc_annuler,'label':CONSTANTS.texts.tlc_annuler});
        cancel_btn.SetParent(this.domElement);
        cancel_btn.domElement._handler = settings.cancel_handler ? settings.cancel_handler : null;
        $_e.AddEventClick(cancel_btn.domElement,EVENTS_Class.BindCallback(this , this.OnClickButton));
        this.keyPress_btns.push({'target': cancel_btn, 'key': 'Escape'});
    }

    if (this.keyPress_btns.length > 0){
        $_e.AddEvent(document, EVENTS_Class.EVENT_KEYUP, EVENTS_Class.BindCallback(this , this.OnKeyPress));
    }
};
UI_PromptWindow.prototype = new UI_Window();

UI_PromptWindow.prototype.OnClickButton = function(event){
    if(event.button === 0){
        EVENTS_Class.StopEvent(event);
        if(event.target._handler) event.target._handler(this.fields , this.domElement);
        this.Remove();
        if (this.keyPress_btns.length > 0){
            $_e.RemoveEvent(document, EVENTS_Class.EVENT_KEYUP, EVENTS_Class.BindCallback(this , this.OnKeyPress));
        }
    }
};

UI_PromptWindow.prototype.OnKeyPress = function(event){
    // $_e.StopEvent(event);
    this.keyPress_btns.forEach((obj) => {
        if (obj.key == event.key){
            $_e.SendEventClick(obj.target);
        }
    });
};

UI_PromptWindow.prototype.HideButtons = function(event){
    this.buttonsDiv.classList.toggle('hidden',true);
};

UI_PromptWindow.prototype.ShowButtons = function(event){
    this.buttonsDiv.classList.toggle('hidden',false);
};


//

function on_show_translate_block(evt){
    let button = evt.target;

    let selector = button.parentNode;
    let isolist = [];
    for(let i=0 ; i<selector.children.length;i++){
        let child = selector.children[i];
        if(child.dataset.iso == button.dataset.iso){
            child.classList.toggle('selected',true);
        }else if(!evt.shiftKey){
            child.classList.toggle('selected',false);
        }
        if(child.classList.contains('selected')){
            isolist.push(child.dataset.iso);
        }
    }

    let container = selector.parentNode;

    for(let i=0 ; i < container.children.length;i++){
        let child = container.children[i];
        if(child.dataset && child.dataset.iso){
            if(isolist.indexOf(child.dataset.iso) > -1){
                child.classList.toggle('selected',true);
            }else{
                child.classList.toggle('selected',false);
            }
        }

    }
}
//window screen logarythmique ratio calculator and base CSS var creation, called from init.js
function detect_screen_infos(){
  let root = document.documentElement;
  root.style.setProperty('--screen-x', window.screen.width*window.devicePixelRatio);
  root.style.setProperty('--screen-y', window.screen.height*window.devicePixelRatio);
  root.style.setProperty('--inner-x', window.innerWidth);
  root.style.setProperty('--inner-y', window.innerHeight);
  root.style.setProperty('--ar', window.screen.width/window.screen.height);
  root.style.setProperty('--innerar', window.innerWidth/window.innerHeight);
  if (window.screen.height <= 1080) {
      root.style.setProperty('--fhd-hr', 1);
      root.style.setProperty('--fhd-vr', 1);
      fhdVR=1;
  }else{
        if (window.outerWidth > 2230 ){
            let hr = 1+(Math.log(window.screen.width/window.devicePixelRatio) -  Math.log(1920));
            hr=(hr<1)?1:hr;
            let vr = 1+(Math.log(window.screen.height/window.devicePixelRatio) - Math.log(1080));
            vr=(vr<1)?1:vr;
            root.style.setProperty('--fhd-hr', hr);
            root.style.setProperty('--fhd-vr', vr);
            fhdVR=vr;
        }else{
            let hr = 1+(Math.log(window.outerWidth/window.devicePixelRatio) -  Math.log(1920));
            hr=(hr<1)?1:hr;
            let vr = 1+(Math.log(window.outerHeight/window.devicePixelRatio) - Math.log(1080));
            vr=(vr<1)?1:vr;
            root.style.setProperty('--fhd-hr', hr);
            root.style.setProperty('--fhd-vr', vr);
            fhdVR=vr;
        }
    }
}

function updateCssfhdvr(){
  let root = document.documentElement;
  if (window.innerWidth > 1920 && window.innerWidth < 2230 ) {
    let hr = 1+(Math.log(window.outerWidth/window.devicePixelRatio) -  Math.log(1920));
    hr=(hr<1)?1:hr;
    root.style.setProperty('--fhd-vr', hr);
    root.style.setProperty('--innerar', window.innerWidth/window.innerHeight);
    fhdVR=hr;
  }
  if (window.innerWidth > 2230){
       let vr = 1+(Math.log(window.screen.height/window.devicePixelRatio) - Math.log(1080));
       root.style.setProperty('--fhd-vr',vr);
       fhdVR=vr;
  }
}

// Search functions
function recherche(){
    this.shouldSearch = function(event,moduleName=''){
        if (event.keyCode == 13) {
            //~ document.getElementById(moduleName+'_admin_btn_search').click();
            document.getElementById(moduleName+'_admin_btn_search').click();
        }
    };
    this.filter=function(val,moduleName=''){
        document.getElementById(moduleName+'_order_filter').value=val;
        let page_jumper=document.getElementById(moduleName+'_page_jumper');
        if (page_jumper!=undefined){
            page_jumper.value=1;
        }
        document.getElementById(moduleName+'_admin_btn_search').click();
    };
    
    this.prev = function (moduleName=''){
        let start_index=document.getElementById(moduleName+'_start_index');
        let nbr_res = document.getElementById(moduleName+'_nbr_resultat');
        nbr_res = nbr_res.selectedOptions[0].value;
        let index_value = start_index.value != '' ? parseInt(start_index.value) : 0;
        start_index.value=index_value-parseInt(nbr_res);
        if (start_index.value<0) start_index.value=0;
        let page_jumper=document.getElementById(moduleName+'_page_jumper');
        if (page_jumper!=undefined){
            page_jumper.value=1;
        }
        // in this case we don't send with event.js because it's the normal behavior of submit button to submit the form
        // there is no special event click for this
        document.getElementById(moduleName+'_admin_btn_search').click();
    };
     
    this.next = function (moduleName=''){
        let start_index=document.getElementById(moduleName+'_start_index');
        let nbr_res = document.getElementById(moduleName+'_nbr_resultat');
        nbr_res = nbr_res.selectedOptions[0].value;
        let index_value = start_index.value != '' ? parseInt(start_index.value) : 0;
        start_index.value=index_value+parseInt(nbr_res);
        let page_jumper=document.getElementById(moduleName+'_page_jumper');
        if (page_jumper!=undefined){
            page_jumper.value=1;
        }
        document.getElementById(moduleName+'_admin_btn_search').click();
    };
    
    this.jumpto = function (e,moduleName=''){
        let start_index=document.getElementById(moduleName+'_start_index');        
        let startpageindex = e.target.selectedOptions[0].value;
        start_index.value=startpageindex;
        let page_jumper=document.getElementById(moduleName+'_page_jumper');
        if (page_jumper!=undefined){
            page_jumper.value=1;
        }
        document.getElementById(moduleName+'_admin_btn_search').click();
    };
    
    this.ToggleMessage = function(tgt,moduleName=''){
        let target = document.getElementById(tgt);
        DOM_Class.ToggleClass(target, 'messageoff');
    };
    
    this.changeFilter = function(evt,moduleName=''){
        let form = document.getElementById(moduleName+'_form');
        let btn = document.getElementById(moduleName+'_btn_send');
        for (let i = 0; i  < form.length; i++){
            let elem = form[i];
            if (elem.tagName == 'INPUT' || elem.tagName == 'SELECT'){
                $_e.AddEvent(elem, 'change', function(){
                    //~ let btn = document.getElementById('dumplist_btn_send');
                    DOM_Class.ToggleClass(btn, 'filter_change', true);
                });
            }
        }
    };
    
    this.save = function(moduleName=''){
        let btn = document.getElementById(moduleName+'_admin_btn_save');
        //shouldn't it be separated in a this.search method ?
        let btnSrch = document.getElementById(moduleName+'_admin_btn_search');
        if (btn) btn.click();
        if (btnSrch) setTimeout(()=>{btnSrch.click();},200);
        //if (modal) modal.Hide();
    };
    
    this.del = function(evt, moduleName='', id=0){
        let txt = evt.target.dataset.confirm;
        UI_Class.ConfirmPopup(txt, ()=>{
            if (id>0){
                let btn = document.getElementById(moduleName+'_admin_btn_del_'+id);
                let btnSrch = document.getElementById(moduleName+'_admin_btn_search');
                if (modal) modal.Hide();
                btn.click();
                setTimeout(()=>{btnSrch.click();}, 500);
            }
        });
    };

    var modal = false;
    this.modalEdit = function(id=0,moduleName='',tableName='',action=''){
        if (!modal){
            modal = UI_Class.AddWindow(document.body, {'hidden': true, 'modal': true, 'close': 'x'});
            modal.domElement.setAttribute('id', 'edit_modal');
            let div = DOM_Class.CreateElement('div', {'class': 'edit_modal_container','id':'edit_modal_container'});
            modal.SetContent(div);
        }
        var url = document.baseURI;
        url = url.split('#');
        url = url[0].split('?');
        url = url[0] + moduleName + '/index.php';
        
        //~ var url = CONSTANTS.base_url + moduleName + '/index.php';

        let settings = {};
        settings.url = url;
        settings.dom_target = 'edit_modal_container';
        settings.skip_container = true;
        settings.data = {};
        settings.data[moduleName+'_action'] = moduleName+'_'+action;
        settings.data[moduleName+'-'+tableName+'-id'] = id;
        settings.success = function(res){
            modal.Show();
            DOM_Class.SetAlignment(modal.domElement, 0.5, 0.5);
        };
        $_a.send(settings);
    };
}
var srch = new recherche();

function autocomplete(){
    var self = this;
    var lst = [];
    
    var closeOnClick=false;
    //~ var toInit=[];
    
    this.init=function(name,moduleName,tableName,fieldName,submit,confirm,callback){
        //~ console.log(fieldName);
        if (name){
            lst[name]=[];
            lst[name]['submit']=submit;
            lst[name]['confirm']=confirm;
            lst[name]['inp']=document.getElementById(name+'_id');
            lst[name]['moduleName']=moduleName;
            lst[name]['tableName']=tableName;
            lst[name]['fieldName']=fieldName;
            lst[name]['callback'] = callback;
            lst[name]['txt']=document.getElementById(name+'_autocomp');
            
            lst[name]['txt'].addEventListener('input', (e)=>{onInput(e,name);});
            lst[name]['txt'].addEventListener('keydown', (e)=>{onKeyDown(e,name);});
            
            //~ console.log(lst[id]['txt']);
            if (!closeOnClick){
                // EVENTS_Class.AddEventClickOutside()
                // $_e.AddEventClickOutside()
                $_e.AddEvent(window, EVENTS_Class.EVENT_CLICK, closeAllLists);
                // closeOnClick=true;
            }
        }
    };
    
    //~ this.preInit=function(...params){
        //~ let t = params;
        //~ toInit.push(t);
        //~ console.log(toInit);
    //~ }
    
    //~ function activate(id){
        
        //~ $_e.AddEvent(lst[id]['txt'],'input',onInput);
        //~ $_e.AddEvent(lst[id]['txt'],'keydown',onKeyDown);
    //~ };
    
    function onInput(e,name){
        lst[name]['val'] = e.target.value;
        if (lst[name]['val'].length>1){
            /*close any already open lists of autocompleted values*/
            closeAllLists();
            if (!lst[name]['val']) {return false;}
            lst[name]['currentFocus'] = -1;
            /*create a DIV element that will contain the items (values):*/
            lst[name]['a'] = DOM_Class.CreateElement('DIV', {'id': name + '_autocomplete-list', 'class': 'autocomplete-items'});

            /*append the DIV element as a child of the autocomplete container:*/
            //~ e.target.parentNode.appendChild(lst[name]['a']);
            e.target.parentNode.parentNode.appendChild(lst[name]['a']);
            //now we're getting our datas :
            let settings = {};
            let url = e.target.form.action;
            // let url = document.baseURI.split('?')[0].split('#')[0]+lst[name]['moduleName']+'/index.php';
            settings.url = url;
            settings.dom_target = '';
            settings.skip_container = true;
            settings.notimer = true;
            settings.data = {};
            settings.data[lst[name]['moduleName']+'_action']=lst[name]['moduleName']+'_autocomp';
            settings.data['table']= lst[name]['tableName'];
            settings.data['fields']= lst[name]['fieldName'];
            settings.data['value']= lst[name]['val'];
            // get the extra data with data-autocomp from parent form
            let form=lst[name]['inp'].form;
            for(let i=0;i<form.length;i++){
                if (form[i].getAttribute('data-autocomp')){
                    settings.data[form[i].name]=form[i].value;
                }
            }
            settings.success = function(res){
                /*for each item in the array...*/
                //~ console.log(res);
                arr=JSON.parse(res);
                // remove all elements from the list before adding the new one
                while(lst[name]['a'].firstChild){
                    lst[name]['a'].removeChild(lst[name]['a'].firstChild);
                }
                for (i = 0; i < arr.length; i++) {
                    //~ console.log(arr[i]);
                    let txt = arr[i].name;
                    let id = arr[i].id;
                    /*check if the item starts with the same letters as the text field value:*/
                    //remove extract slaches
                    //~ txt=txt.stripSlashes();
                    //~ if (txt.substr(0, lst[name]['val'].length).toUpperCase() == lst[name]['val'].toUpperCase()) {
                        /*create a DIV element for each matching element:*/
                        lst[name]['b'] = DOM_Class.CreateElement('DIV');
                        /*make the matching letters bold:*/
                        lst[name]['b'].innerHTML = "<strong>" + txt.substr(0, lst[name]['val'].length) + "</strong>";
                        lst[name]['b'].innerHTML += txt.substr(lst[name]['val'].length);
                        /*insert a input field that will hold the current array item's value:*/
                        lst[name]['b'].innerHTML += '<input type="hidden" value="' + txt + '">';
                        /*execute a function when someone clicks on the item value (DIV element):*/
                        lst[name]['b'].addEventListener("click", function(e) {
                            /*insert the value for the autocomplete text field:*/
                            lst[name]['txt'].value = txt;
                            lst[name]['inp'].value = id;
                            /*close the list of autocompleted values,
                            (or any other open lists of autocompleted values:*/
                            closeAllLists();
                            if (lst[name]['confirm'] == 'false'){
                                if(lst[name]['submit']) EVENTS_Class.SendEvent(lst[name]['inp'].form , 'submit');
                                EVENTS_Class.SendEvent(lst[name]['inp'],'change');
                            } else {
                                UI_Class.ConfirmPopup(lst[name]['confirm'], ()=>{
                                    if(lst[name]['submit']) EVENTS_Class.SendEvent(lst[name]['inp'].form , 'submit');
                                    EVENTS_Class.SendEvent(lst[name]['inp'],'change');
                                });
                            }
                            // if (window.confirm(lst[name]['confirm'])) {
                            //     if(lst[name]['submit']) EVENTS_Class.SendEvent(lst[name]['inp'].form , 'submit');
                            //     EVENTS_Class.SendEvent(lst[name]['inp'],'change');
                            // }
                            if (lst[name]['callback']) lst[name]['callback'](e);
                        });
                        lst[name]['a'].appendChild(lst[name]['b']);
                    //~ }
                }
            };
            $_a.send(settings);
        }
    }
    
    function closeAllLists(){
        /*close all autocomplete lists in the document,
        except the one passed as an argument:*/
        var x = document.getElementsByClassName("autocomplete-items");
        for (var i = 0; i < x.length; i++) {
            //~ if (elmnt != x[i] && elmnt != inp) {
            x[i].parentNode.removeChild(x[i]);
            //~ }
        }
    }
    
    function onKeyDown(e,name){
        lst[name]['x'] = document.getElementById(name + "_autocomplete-list");
        if (lst[name]['x']) lst[name]['x'] = lst[name]['x'].getElementsByTagName("div");
        if (e.keyCode == 40) {
            /*If the arrow DOWN key is pressed,
            increase the currentFocus variable:*/
            lst[name]['currentFocus']++;
            /*and and make the current item more visible:*/
            addActive(lst[name]['x'],name);
        } else if (e.keyCode == 38) { //up
            /*If the arrow UP key is pressed,
            decrease the currentFocus variable:*/
            lst[name]['currentFocus']--;
            /*and and make the current item more visible:*/
            addActive(lst[name]['x'],name);
        } else if (e.keyCode == 13) {
            /*If the ENTER key is pressed, prevent the form from being submitted,*/
            e.preventDefault();
            if ( lst[name]['currentFocus'] > -1) {
                /*and simulate a click on the "active" item:*/
                if (lst[name]['x']) lst[name]['x'][lst[name]['currentFocus']].click();
            }
        }
    }
  
    function addActive(x,name) {
        /*a function to classify an item as "active":*/
        if (!x) return false;
        /*start by removing the "active" class on all items:*/
        removeActive(x);
        if (lst[name]['currentFocus'] >= x.length) lst[name]['currentFocus'] = 0;
        if (lst[name]['currentFocus'] < 0) lst[name]['currentFocus'] = (x.length - 1);
        /*add class "autocomplete-active":*/
        x[lst[name]['currentFocus']].classList.add("autocomplete-active");
    }
    function removeActive(x) {
        /*a function to remove the "active" class from all autocomplete items:*/
        for (var i = 0; i < x.length; i++) {
            x[i].classList.remove("autocomplete-active");
        }
    }
}
var autocomp = new autocomplete();

function initRangeTracks(){
    //update size of track subitem for a styled input range with styled_progress class
    for (let e of document.querySelectorAll('input[type="range"].styled_progress')) {
      e.style.setProperty('--value', e.value);
      e.style.setProperty('--min', e.min == '' ? '0' : e.min);
      e.style.setProperty('--max', e.max == '' ? '100' : e.max);
      e.addEventListener('input', () => e.style.setProperty('--value', e.value));
    }
}

var UI_Multi_State_lst = {};
var UI_Multi_State = function(domId,side='',toggle_mode=false){
    var self = this;
    var buttons = [];
    var container,toggler,active,toggle;
    var avatar_active=false;
    var sided = (side != '') ? true : false;
    var opened = false;
    
    this.domID = domId;
    this.avatar = false;
    
    function init(){
        //~ console.log(toggle_mode);
        
        container = document.getElementById(domId);
        //~ $_e.AddEventClick(container, ()=>{});
        
        // the element to click on for opening
        toggler = document.getElementById(domId + '-toggler');
        
        // the element to toggle when opening
        toggle = document.getElementById(domId + '-toggle');
        
        for (let i = 0; i < toggle.children.length; i++){
            let btn = toggle.children[i];
            // add on every buttons the close event
            $_e.AddEventClick(btn,onClickBtn);
            if (!toggle_mode){ // no active by default in toggle mode
                if (DOM_Class.HasClass(btn,'state_active')){
                    // the currently selected item
                    active = btn;
                }
            } else { // but need to add the first item to active for creating the avatar
                active = buttons[0];
            }
            DOM_Class.AddClass(active, 'current_avatar');
            
            buttons.push(btn);
        }
        
        if (sided){
            // move the element to toggle as a child of document for him to be in front of every other elements (like a modal)
            DOM_Class.AppendContent(document.body, toggle);
        }
        
        changeAvatar();
        toggleButtons();
    }
    function onClickToggler(evt){
        //~ console.log('toggle');
        if (!opened) {
            // show every buttons
            toggleButtons(false);
            // hide toggler
            toggler.style.display = 'none';
            opened = true;
        } else {
            onClose(evt);
        }
        
    }
    function onClickBtn(evt, btn = false){
        // console.log(evt);
        let targ = (btn !== false) ? btn : evt.target;
        //~ if (buttons.indexOf(targ) > -1){
        if (targ.dataset.no_toggle) {
            onClose();
            return;
        }
        if (toggle_mode){
            if (DOM_Class.HasClass(targ,'state_active')){
                DOM_Class.RemoveClass(targ,'state_active');
            } else {
                DOM_Class.AddClass(targ,'state_active');
            }
        } else {
            if (targ != active){
                // remove class from previous
                DOM_Class.RemoveClass(active, 'current_avatar');
                DOM_Class.RemoveClass(active, 'state_active');
                
                active = targ;
                DOM_Class.AddClass(active,'state_active');
                DOM_Class.AddClass(active,'current_avatar');
                changeAvatar();
            }
            onClose();
        }
        //~ }
    }
    function onClose(evt){
        opened = false;
        toggler.style.display = '';
        toggleButtons();
    }
    // toggle every button except the active one
    function toggleButtons(hide=true){
        if (hide){
            toggle.style.display = 'none';
            if (!sided) avatar_active.style.display = '';
            $_e.RemoveEventClickOutside(toggle,onClickOutside);
        } else {
            toggle.style.display = '';
            if (!sided) avatar_active.style.display = 'none';
            else {
                let rect = DOM_Class.GetGlobalRect(container,true);
                let rectToggle = DOM_Class.GetGlobalRect(toggle,true);
                let difWidth = rectToggle.width - rect.width;
                switch (side) {
                    case 'left':
                        toggle.style.top = Math.round(rect.top) + 'px';
                        toggle.style.left = Math.round(rect.left - rectToggle.width) + 'px';
                    break;
                    case 'right':
                        toggle.style.top = Math.round(rect.top) + 'px';
                        toggle.style.left = Math.round(rect.right) + 'px';
                    break;
                    case 'top':
                        //~ let rectToggle = DOM_Class.GetGlobalRect(toggle,true);
                        if (difWidth >= 0){
                            toggle.style.left = Math.round(rect.left - (difWidth / 2)) + 'px';
                        } else {
                            toggle.style.left = Math.round(rect.left + (difWidth / 2)) + 'px';
                        }
                        toggle.style.bottom = Math.round(rect.top) + 'px';
                    break;
                    case 'down':
                    //~ case '':
                        //~ console.log(difWidth);
                        //~ console.log(difWidth / 2);
                        //~ console.log(rect.left - (difWidth / 2));
                        //~ console.log(rect.left + (difWidth / 2));
                        //~ if (difWidth >= 0){
                        toggle.style.left = Math.round(rect.left - (difWidth / 2)) + 'px';
                        //~ } else {
                            //~ toggle.style.left = Math.round(rect.left + (difWidth / 2)) + 'px';
                        //~ }
                        toggle.style.top = Math.round(rect.bottom) + 'px';
                    break;
                }
            }
            $_e.AddEventClickOutside(toggle,onClickOutside);
        }
    }
    function onClickOutside(evt){
        // if the click is on toggler, do nothing.
        // the function that handle the click on the toggler will trigger the close
        // this is like a clickOutside execpt this element
        //~ console.log(evt);
        if (evt.target != avatar_active){
            onClose(evt);
        }
    }
    // take the active element to create an avatar
    // put the avatar as the toggler 
    function changeAvatar(){
        // remove old avatar
        let old_avatar = false;
        if (avatar_active){
            old_avatar = avatar_active;
        }
        
        avatar_active = active.cloneNode();
        avatar_active.id += 'clone';
        avatar_active.innerHTML = active.innerHTML;
        DOM_Class.AddClass(avatar_active, 'avatar');
        DOM_Class.RemoveClass(avatar_active, 'current_avatar');
        // to remove if we add the automatic addEvent for onclick
        if (avatar_active.onclick) avatar_active.onclick = '';
        //~ $_e.RemoveAllEvents(avatar_active);
        
        if (old_avatar){
            DOM_Class.ReplaceElement(old_avatar, avatar_active);
        } else {
            DOM_Class.ReplaceElement(toggler, avatar_active);
        }
        
        $_e.AddEventClick(avatar_active,onClickToggler);

        self.avatar = avatar_active;
        //~ DOM_Class.AppendContent(toggler, avatar_active);
        //~ DOM_Class.InsertAfter(avatar_active,toggler);
    }
    
    this.next = function(loop=false){
        let nextBtn = active.nextElementSibling;
        if (nextBtn){
            $_e.SendEventClick(nextBtn);
        } else if (loop){
            $_e.SendEventClick(buttons[0]);
        }
    };
    this.prev = function(loop=false){
        let prevBtn = active.previousElementSibling;
        if (prevBtn){
            $_e.SendEventClick(prevBtn);
        } else if (loop){
            $_e.SendEventClick(buttons[buttons.length - 1]);
        }
    };
    
    this.setAvatar = function(domId = ''){
        buttons.forEach((btn)=>{
            if (btn.id == domId){
                onClickBtn(false, btn);
            }
        });
    };
    
    this.clean = function(){
        if (sided){
            // remove element from document
            DOM_Class.RemoveElement(toggle);
        }
    };
    
    init();
};
UI_Multi_State.create_instance = function(domId,side='',toggle_mode=false){
    
    if (UI_Multi_State_lst[domId]){
        UI_Multi_State_lst[domId].clean();
        delete(UI_Multi_State_lst[domId]);
    }
    UI_Multi_State_lst[domId] = new UI_Multi_State(domId,side,toggle_mode);

    UI_Multi_State.clean_instances();
};
UI_Multi_State.clean_instances = function(){
    let toClean = [];
    for (var key in UI_Multi_State_lst) {
        let exist = document.getElementById(UI_Multi_State_lst[key].domID);
        if (!exist) {
            UI_Multi_State_lst[key].clean();
            toClean.push(key);
        }
    }
    toClean.forEach((key)=>{
        delete(UI_Multi_State_lst[key]);
    });
};

// call create_instance with domId and settings.
// if a button from settings.buttons has dataset.child = true, don't put hide event on it but show child
var UI_Context_Menu = function(domId, settings){
    var self = this;
    this.domID = domId;
    this.buttons = settings.buttons;
    var openCallback = (settings.openCallback) ? settings.openCallback : false;
    var hideCallback = (settings.hideCallback) ? settings.hideCallback : false;
    
    let modSetts = {
        'modal': false,
        'disableBackgroundClick': true,
        'class': 'ui_window contextmenu',
        'nodrag': true,
        'disableKeydownClose': true,
        'hidden': true
    };
    if (settings.class) modSetts.class += settings.class;
    this.modal = new UI_Window(modSetts);
    this.content = DOM_Class.CreateElement('DIV',{'id': domId, 'class': 'UI_context_menu'});
    this.buttons.forEach((btn)=>{
        if (btn.dataset && btn.dataset.child == 'true'){
            $_e.AddEventClick(btn, toggleChild);
        } else {
            $_e.AddEventClick(btn, ()=>{self.modal.Hide();});
        }
        DOM_Class.AppendContent(this.content, btn);
    });
    this.modal.SetContent(this.content);
    this.modal.SetParent(document.body, 0.5, 0.5);
    
    this.clean = function(){
        this.modal.Remove();
    };
    
    this.open = function(evt){
        $_e.StopEvent(evt);
        
        if (openCallback) openCallback(evt);
        
        // console.log(self);
        if (evt.pointerType == 'touch'){
            return false;
        }
        self.modal.Show();
        
        let rect = DOM_Class.GetGlobalRect(self.modal.domElement, true);
        let parentRect = DOM_Class.GetGlobalRect(self.modal.domElement.parentElement, true);
        
        // verify if it's smaller than the window
        let display = false;
        if (parentRect.height > rect.height) display = true;
        
        // verify if it's going outside the window
        let left = evt.clientX + window.pageXOffset;
        let right = left + rect.width;
        if (right < parentRect.width) {
            self.modal.domElement.style.left = left + 'px';
        } else {
            self.modal.domElement.style.left = (left - rect.width) + 'px';
        }
        
        let top = evt.clientY + window.pageYOffset;
        let bottom = top + rect.height;
        if (bottom < parentRect.height) {
            self.modal.domElement.style.top = top + 'px';
        } else if ((top - rect.height) > parentRect.top){
            self.modal.domElement.style.top = (top - rect.height) + 'px';
        } else {
            self.modal.domElement.style.top = (parentRect.height - rect.height - 1) + 'px';
        }
        
        self.modal.domElement.style.visibility = 'visible';
        $_e.AddEventClickOutside(self.modal.domElement, self.hide);
    };
    
    this.hide = function(evt){
        self.modal.Hide();
        // console.log('hide');
        $_e.RemoveEventClickOutside(self.modal.domElement, self.hide);
        if (hideCallback) hideCallback(evt);
    };
    
    function toggleChild(evt){
        let targ = evt.target;
        for (let i = 0; i < targ.children.length; i++){
            DOM_Class.RemoveClass(targ.children[i], 'hidden');
        }
        $_e.AddEventClickOutside(targ, hideChild);
    }
    function hideChild(evt){
        let targ = evt.target;
        for (let i = 0; i < targ.children.length; i++){
            DOM_Class.RemoveClass(targ.children[i], 'hidden');
        }
        $_e.RemoveEventClickOutside(targ, hideChild);
    }
    //~ init();
};
UI_Context_Menu.lst = {};
UI_Context_Menu.create_instance = function(domId, settings){
    
    if (UI_Context_Menu.lst[domId]){
        UI_Context_Menu.lst[domId].clean();
        delete(UI_Context_Menu.lst[domId]);
    }
    UI_Context_Menu.lst[domId] = new UI_Context_Menu(domId,settings);

    UI_Context_Menu.clean_instances();
    
    //~ console.log(UI_Context_Menu.lst[domId]);
    return UI_Context_Menu.lst[domId];
};
UI_Context_Menu.clean_instances = function(){
    let toClean = [];
    for (var key in UI_Context_Menu.lst) {
        let exist = document.getElementById(UI_Context_Menu.lst[key].domID);
        if (!exist) {
            UI_Context_Menu.lst[key].clean();
            toClean.push(key);
        }
    }
    toClean.forEach((key)=>{
        delete(UI_Context_Menu.lst[key]);
    });
};

var UI_Upload_Progress = function(files,parent,domId){
    var self = this;
    this.numberFiles,this.totalPercent,this.speed,this.totalBarProgress;
    this.btn_stop, this.btn_play;
    this.files = {'dom': false, 'lst': [], 'hidden': true};
    
    this.show = function(files, parent = false, domId = ''){
        if (files){
            // console.log(files);
            //~ let blockFiles;
            if (!UI_Class.popupSpecial['upload_'+domId]){
                UI_Class.popupSpecial['upload_'+domId] = new UI_Window({'modal': false, 'nodrag':true, 'disableKeydownClose': true, 'special': true, 'class': 'upload_progress', 'hidden': true});
                
                let content = [];
                let total = DOM_Class.CreateElement('DIV', {'class':'upload_total'});
                    let label = DOM_Class.CreateElement('SPAN', {'class':'upload_total_label'}, UI_Upload_Progress.tl['upload_ttl']);
                    this.numberFiles = DOM_Class.CreateElement('SPAN', {'id':'fileupload_total_files'});
                    this.totalPercent = DOM_Class.CreateElement('SPAN', {'id':'fileupload_percent'}, '0%');
                    this.speed = DOM_Class.CreateElement('SPAN', {'id':'fileupload_speed'});
                    this.totalBarProgress = DOM_Class.CreateElement('DIV', {'class':'filemanager_progress_upload_total_bar_progress', 'id':'fileupload_bar_progress'});
                    let totalBar = DOM_Class.CreateElement('DIV', {'class':'filemanager_progress_upload_total_bar', 'id':'fileupload_bar'}, this.totalBarProgress);
                DOM_Class.AppendContent(total, [label, this.numberFiles,this.totalPercent,this.speed,totalBar]);
                
                    // this.btn_stop = DOM_Class.CreateElement('BUTTON', {'class':'upload_btn_pause'}, 'pause');
                    // this.btn_play = DOM_Class.CreateElement('BUTTON', {'class':'upload_btn_play hidden'}, 'play');
                    let btn_cancel = DOM_Class.CreateElement('BUTTON', {'class':'upload_btn_cancel'}, 'cancel');
                
                DOM_Class.AppendContent(total, btn_cancel);
                content.push(total);
                
                this.files.dom = DOM_Class.CreateElement('DIV', {'id':'fileupload_block_files'});
                content.push(this.files.dom);
                
                UI_Class.popupSpecial['upload_'+domId].SetContent(content);
                if (!parent) UI_Class.popupSpecial['upload_'+domId].SetParent(document.body);
                else UI_Class.popupSpecial['upload_'+domId].SetParent(parent);
                
                
                
                $_e.AddEventClick(total, this.toggleFileBlock);
                // $_e.AddEventClick(this.btn_stop, this.stop);
                // $_e.AddEventClick(this.btn_play, this.play);
                $_e.AddEventClick(btn_cancel, this.cancel);
                
            }
            
            DOM_Class.AddClass(this.files.dom, 'hidden');
            this.files.hidden = true;
            
            files.forEach((file, index)=>{
                let filename = file.webkitRelativePath != '' ? file.webkitRelativePath : file.name;
                this.files.lst[filename] = {};
                
                let line = DOM_Class.CreateElement('DIV', {'class':'upload_file'});
                    let name = DOM_Class.CreateElement('SPAN', {'class':'upload_file_name'}, filename);
                    let size = DOM_Class.CreateElement('SPAN', {'class':'upload_file_size'}, AJAX_Class.readableFileSize(file.size));
                    this.files.lst[filename].percent = DOM_Class.CreateElement('SPAN', {'class':'upload_file_percent'}, '0%');
                    this.files.lst[filename].barProgress = DOM_Class.CreateElement('DIV', {'class':'upload_file_bar_progress'});
                    let bar = DOM_Class.CreateElement('DIV', {'class':'upload_file_bar'}, this.files.lst[filename].barProgress);
                DOM_Class.AppendContent(line, [name,size,this.files.lst[filename].percent,bar]);
                DOM_Class.AppendContent(this.files.dom, line);
            });
            
            UI_Class.popupSpecial['upload_'+domId].Show();
        }
    };
    this.hide = function(){
        // hide and reinit
        
        UI_Class.popupSpecial['upload_'+domId].Remove();
        
        // while(this.files.dom.firstChild){
        //     DOM_Class.RemoveElement(this.files.dom.firstChild);
        // }
        
        // this.files.lst = [];
        // this.numberFiles.textContent = '';
        // this.totalPercent.textContent = '0%';
        // this.speed.textContent = '';
        // this.totalBarProgress.style.width = '0%';
        
        // this.prevReq = false;
    };
    this.toggleFileBlock = function(evt){
        if (self.files.hidden){
            self.updateCurrentFile();
            DOM_Class.RemoveClass(self.files.dom, 'hidden');
            self.files.hidden = false;
        } else {
            DOM_Class.AddClass(self.files.dom, 'hidden');
            self.files.hidden = true;
        }
    };
    this.prevReq = false;
    this.update = function(res,req){
        
        //~ console.log(res);
        //~ console.log(req);
        
        if (!req.speed) return;
        
        //~ console.log('test');
        if (!self.prevReq || self.prevReq.fileSended != req.fileSended){
            self.numberFiles.textContent = (req.fileSended + 1) + '/' + req.fileCount;
        }
        
        let percent = Math.round(req.all.progress * 100) + '%';
        self.totalPercent.textContent = percent;
        self.speed.textContent = '('+ AJAX_Class.readableFileSize(req.speed) +'/s )';
        self.totalBarProgress.style.width = percent;
        
        self.prevReq = Object.assign({}, req);
        
        if (!self.files.hidden) self.updateCurrentFile();
    };
    this.updateCurrentFile = function(){
        // current file progress
        //~ console.log(this.prevReq);
        let req = this.prevReq;
        let filename = req.current.name;
        let currentPercent = Math.round(req.current.progress * 100) + '%';
        this.files.lst[filename].percent.textContent = currentPercent;
        this.files.lst[filename].barProgress.style.width = currentPercent;
    };
    
    this.stop = function(evt){
        if (self.prevReq){
            self.prevReq.pauseFile();
            // DOM_Class.AddClass(this.btn_stop, 'hidden');
            DOM_Class.RemoveClass(self.btn_play, 'hidden');
        }
    };
    this.play = function(evt){
        if (self.prevReq){
            self.prevReq.reprendreFile();
            DOM_Class.AddClass(self.btn_play, 'hidden');
            DOM_Class.RemoveClass(self.btn_stop, 'hidden');
        }
    };
    this.cancel = function(evt){
        if (self.prevReq){
            self.prevReq.cancelFile(()=>{
                self.hide();
                // sp3_job.cleanBar();
                // sp3_job.initBar();
            });
        }
    };

    this.show(files,parent,domId);
};
UI_Upload_Progress.tl = [];

function inputCopyToClipboard(id,popup=true,html=false){
    let inp = document.getElementById(id);
    // Select the text field
    inp.select();
    if (isMobile){
        inp.setSelectionRange(0, 99999); // For mobile devices
    }
    // Copy the text inside the text field
    if (html){
        if(typeof ClipboardItem === "undefined") {
            //ff polyfill
            const el = document.createElement('textarea');
            el.value = inp.value;
            document.body.appendChild(el);
            el.select();
            el.addEventListener('copy', (event) => {
                event.clipboardData.setData('text/html',content);
            });
            const result = document.execCommand('copy');
            document.body.removeChild(el);
        }else{
            const blob = new Blob([inp.value], { type: "text/html" });
            const richTextInput = new ClipboardItem({ "text/html": blob });
            navigator.clipboard.write([richTextInput]);
        }
    }else{
        navigator.clipboard.writeText(inp.value);
    }
    if(popup){
        popup=(GENERICS_Class.IsString(popup))?popup:'Copied to clipboard';
        UI_Class.MessagePopup(popup);
    }   
}
function copyToClipboard(content,popup=true,html=false){
    // Copy the text inside the text field
    if (html){
        // if(typeof ClipboardItem === "undefined") {
            //ff polyfill
            const el = document.createElement('textarea');
            el.value = content;
            document.body.appendChild(el);
            el.select();
            el.addEventListener('copy', (event) => {
                event.clipboardData.setData('text/html',content);
            });
            const result = document.execCommand('copy');
            document.body.removeChild(el);
        // }else{
        //     const blob = new Blob([content], { type: "text/html" });
        //     // const richTextInput = new ClipboardItem({ "text/html": blob });
        //     // navigator.clipboard.write([richTextInput]);
        //     let data = [new ClipboardItem({ [blob.type]: blob })];
        //     navigator.clipboard.write(data);
        // }
    }else{
        navigator.clipboard.writeText(content);
    }
    if(popup){
        popup=(GENERICS_Class.IsString(popup))?popup:'Copied to clipboard';
        UI_Class.MessagePopup(popup);
    }   
}
var UI_Precomplete = function(domId, data, submitOnChange){
    // console.log(domId, data, submitOnChange);
    var self = this;

    this.domID = domId;
    this.data = data;
    this.submit = (submitOnChange) ? submitOnChange : false;

    this.init = function(){
        this.list = document.getElementById(this.domID + '_list');
        this.input_txt = document.getElementById(this.domID + '_input_search');
        $_e.AddEventKey(this.input_txt, this.changeInput);
        $_e.AddEvent(this.input_txt, 'focus', this.focusIn);
        // $_e.AddEvent(this.input_txt, 'blur', this.focusOut);
        this.value = document.getElementById(this.domID + '_value');
        this.form  = this.value.form;

        // elements when clicked on don't close the list (validatorDiv parent, precomplete search block, label before)
        this.keep_focus_elem = [];
        this.keep_focus_elem.push(document.getElementById(this.domID + '_input_search_label'), this.list);

        if (this.data){
            this.data.forEach((row,index) =>{
                row.domElem = document.getElementById(this.domID + '_row_' + row.id);
                row.domElem.dataset.key = index;
                $_e.AddEventClick(row.domElem, this.onClickRow);
                this.keep_focus_elem.push(row.domElem);
            });
        }
    };
    this.onClickRow = function(evt){
        self.focusOut(evt, false, true);
        let index = evt.target.dataset.key;
        self.value.value = self.data[index].id; // change the value in the hidden field (the submitted one)
        self.input_txt.value = self.data[index].name; // change the value in the input field
        
        if (self.submit){ // auto submit form
            if (GENERICS_Class.IsString(self.submit)){
                eval(self.submit);
            } else {
                $_e.SendEvent(self.form, 'submit');
            }
        }
    };
    this.changeInput = function(evt){
        let currentVal = evt.target.value;
        
        self.data.forEach((row)=>{
            if (currentVal == '' || row.name.includes(currentVal)){
                DOM_Class.ToggleClass(row.domElem, 'hidden', false);
            } else {
                DOM_Class.ToggleClass(row.domElem, 'hidden', true);
            }
        });
    };
    this.focusIn = function(evt){
        $_e.StopEvent(evt);
        DOM_Class.ToggleClass(self.list, 'hidden', false);
        $_e.AddEventClickOutside(self.input_txt, self.focusOut);
    };
    this.focusOut = function(evt, otherEvt=false, force=false){
        if (self.keep_focus_elem.indexOf(evt.target) == -1 || force){
            DOM_Class.ToggleClass(self.list, 'hidden', true);
            $_e.RemoveEventClickOutside(self.input_txt, self.focusOut);
        }
    };
    this.init();
};
var VALIDATOR_Class = function(){};
VALIDATOR_Class.prototype.constructor = VALIDATOR_Class;
//~ class VALIDATOR_Class{
    //~ constructor() {
        
    //~ }
//~ }
VALIDATOR_Class.dateSeparator = ' / ';

VALIDATOR_Class.usernameValidString = CONSTANTS && CONSTANTS.usernameValidString ? CONSTANTS.usernameValidString : 'abcdefghijklmnopqrstuvwxyz-ABCDEFGHIJKLMNOPQRSTUVWXYZ_0123456789';
VALIDATOR_Class.alphaValidString = ' abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
VALIDATOR_Class.integerValidString = '-0123456789';
VALIDATOR_Class.floatValidString = '-0123456789.,';

VALIDATOR_Class.OK = 0;
VALIDATOR_Class.tooSmall = 1;
VALIDATOR_Class.tooBig = 2;

VALIDATOR_Class.modal = null;

VALIDATOR_Class.translated = {
    'fr': {
        'err_form': 'Problème avec le formulaire :',
        'err_red': 'Veuillez remplir les champs bordés de rouge.',
        'close': 'Fermer',
        'required_field': 'Champ requis',
        'invalid_content': 'Contenu invalide',
        'short_content': 'Contenu trop court',
        'long_content': 'Contenu trop long',
        'out_of_bounds': 'Contenu hors limites'
    },
    'en': {
        'err_form': 'Problem with form :',
        'err_red': 'Please complete the fields lined with red.',
        'close': 'Close',
        'required_field': 'Required field',
        'invalid_content': 'Invalid content',
        'short_content': 'Content is too short',
        'long_content': 'Content is too long',
        'out_of_bounds': 'Value is out of bounds'
    },
    'de': {
        'err_form': 'Problem mit dem Formular :',
        'err_red': 'Bitte füllen Sie die rot umrandeten Felder aus.',
        'close': 'Schließen',
        'required_field': 'Champ requis',
        'invalid_content': 'Contenu invalide',
        'short_content': 'Contenu trop court',
        'long_content': 'Contenu trop long',
        'out_of_bounds': 'Contenu hors limites'
    },
    'es': {
        'err_form': 'Problema con la forma :',
        'err_red': 'Complete los campos bordeados de rojo.',
        'close': 'Cerrar',
        'required_field': 'Champ requis',
        'invalid_content': 'Contenu invalide',
        'short_content': 'Contenu trop court',
        'long_content': 'Contenu trop long',
        'out_of_bounds': 'Contenu hors limites'
    }
};

// to limit the fields when entering, take a look at : https://www.w3.org/TR/DOM-Level-3-Events/#event-type-beforeinput

VALIDATOR_Class.prototype.parseFields = function(formDomObject){
    if (GENERICS_Class.IsString(formDomObject)){
        let test = document.getElementById(formDomObject);
        if (test){
            formDomObject = test;
        } else {
            setTimeout(()=>{this.parseFields(formDomObject);},100);
            formDomObject = false;
        }
    }
    
    if(!formDomObject){
        console.log('Form not found...');
        return false;
    }

    let lst = formDomObject.elements;

    formDomObject._validator = this;

    EVENTS_Class.RemoveAllEvents(formDomObject);

    EVENTS_Class.AddEvent(formDomObject,'submit',this.onSubmitForm);

    var previous_field = null;
    var first_field = null;

    for(let i = 0 ; i < lst.length ; i++){
        let input = lst[i];
        
        this.displayErrorField(input,[]);
        
        // skip tinymce fields or unidentified fields
        let parent_id = input.parentNode.getAttribute('id');
        if(parent_id){
            if(parent_id.substr(0,4)=='mce_' || parent_id.substr(0,5)=='mceu_' || input.id.substr(0,4)=='mce_' || input.id.substr(0,5)=='mceu_' || (!input.id && !input.name)){
                //console.log('skip',input.id);
                continue;
            }
        }

        if(!this.protectInput(input)){
            continue;
        }

        if(!first_field){
            first_field = input;
        }

        if(previous_field){
            input._prev = previous_field;
            previous_field._next = input;
        }
        previous_field = input;
    }

    if(first_field){
        first_field._prev = previous_field;
        previous_field._next = first_field;
    }

    //~ setTimeout(this.checkForm , 100 , formDomObject);
};

VALIDATOR_Class.prototype.protectInput = function(input){

    let type = input.getAttribute('data-type') || input.type;

    input._validator = this;
    if (type != 'submit' || type != 'button') input.classList.toggle('validatorField',true);
    input._originalValue = input.value;

    //~ EVENTS_Class.RemoveAllEvents(input);

    switch(type){
        case 'hidden':
            return false;

        case 'textarea':
        case 'text':
        case 'password':
        case 'email':
        case 'select-one':
            EVENTS_Class.AddEvent(input , 'change' , this.checkEventText);
            EVENTS_Class.AddEvent(input , 'keydown' , this.checkEventText);
            EVENTS_Class.AddEvent(input , 'blur' , this.checkEventText);
            EVENTS_Class.AddEvent(input , 'input' , this.checkEventValidity);
        break;

        case 'int':
        case 'float':
            EVENTS_Class.AddEvent(input , 'change' , this.checkEventText);
            EVENTS_Class.AddEvent(input , 'keydown' , this.checkEventText);

            EVENTS_Class.AddEvent(input , 'blur' , this.checkEventLimits);
            EVENTS_Class.AddEvent(input , 'input' , this.checkEventValidity);
        break;

        case 'date':
            EVENTS_Class.AddEvent(input , 'change' , this.checkEventDate);
        break;
    }

    EVENTS_Class.AddEvent(input , 'dblclick' , EVENTS_Class.StopPropagation);


    //~ switch(type){
        //~ case 'textarea':
        //~ case 'text':
        //~ case 'password':
        //~ case 'int':
        //~ case 'float':
        //~ case 'date':
        //~ case 'email':

            //~ let inputStyle = window.getComputedStyle(input);

            //~ let offsetHeight = input.offsetHeight;

            //~ let icon = document.createElement('DIV');

            //~ if(input._tinymce){
                //~ let tiny_container = input._tinymce.editorContainer;

                //~ if(tiny_container){
                    //~ tiny_container.style.display = 'inline-block';
                    //~ tiny_container.style.verticalAlign = 'middle';
                    //~ offsetHeight = tiny_container.offsetHeight;

                    //~ tiny_container.insertAdjacentElement('afterend',icon);
                //~ }
            //~ }else{
                //~ input.insertAdjacentElement('afterend',icon);
            //~ }

            //~ icon.classList.toggle('validatorIcon',true);
            //~ let style = window.getComputedStyle(icon);

            //~ let bs = parseInt(style.borderLeftWidth);

            //~ let height = (offsetHeight-bs*2);
            //~ icon.style.height = height+'px';
            //~ icon.style.width = Math.min(20,height)+'px';

            //~ input._validatorIcon = icon;

            //~ // TODO : completely clear these icons and replace them with a tooltip
            //~ //grumph not so sure...
            //~ icon.style.display = 'none';

        //~ break;
    //~ }

    return true;
};

VALIDATOR_Class.prototype.onSubmitForm = function(event,confirmed = undefined){
    //~ console.log(event);

    let formDomObject = event.currentTarget;
    
    if (event.submitter) formDomObject._submitter = event.submitter;

    if(formDomObject._disableNextSubmit){
        EVENTS_Class.StopEvent(event);
        formDomObject._disableNextSubmit = false;
        return false;
    }

    let validator = formDomObject._validator;
    let test = validator.checkForm(formDomObject);

    if(!test){
        EVENTS_Class.StopEvent(event);
/*
        if (!validator.modal){

            let cur_lng = CONSTANTS.current_lang_iso;
            validator.modal = UI_Class.AddWindow(null, {'modal': true, 'nodrag': true, 'close': CONSTANTS.GetText('close'), 'special': true, 'special_level': 'err'});

                // modal's content
                let container_info = DOM_Class.CreateElement('DIV', {'class': 'validator_info_container'});
                let msg_err = DOM_Class.CreateElement('DIV', {'class': 'validator_info_general'}, CONSTANTS.GetText('err_form'));
                DOM_Class.AppendContent(container_info, msg_err);

                let container_spe = DOM_Class.CreateElement('DIV', {'class': 'validator_info_spe_container'});
                let spe = DOM_Class.CreateElement('DIV', {'class': 'validator_info_spe'}, CONSTANTS.GetText('err_red'));
                DOM_Class.AppendContent(container_spe, spe);

                DOM_Class.AppendContent(container_info, container_spe);

            validator.modal.SetContent(container_info);
            validator.modal.SetParent(document.body);
            validator.modal.domElement.classList.add('err_form');

        } else {
            validator.modal.Show();
        }
*/
        if(validator.error_field){
            validator.error_field.focus();
        }

        return false;
    }else{

        EVENTS_Class.StopEvent(event);

        if(formDomObject._submitter){
            if (formDomObject._submitter.dataset.withtoken){
                let id = formDomObject.id + '-token';
                let inpHidden = document.getElementById(id);
                if (!inpHidden){
                    UI_Class.getToken(event, formDomObject);
                    return;
                }
            } 
            
            let tmp = formDomObject._submitter.getAttribute('data-submit_function');
            if(tmp){
                submit_handler_name = tmp;
            }

            let confirm_message = formDomObject._submitter.getAttribute('data-confirm');
            if(confirm_message){
                UI_Class.ConfirmPopup(confirm_message, ()=>{validator.onSubmitFormConfirmed(formDomObject);}, null);
                return false;
            }else{
                validator.onSubmitFormConfirmed(formDomObject);
            }
        }else{

            validator.onSubmitFormConfirmed(formDomObject);
        }

    }

    return true;
};

VALIDATOR_Class.prototype.onSubmitFormConfirmed = function(formDomObject){
    var settings = {};

    let submit_handler_name = formDomObject.getAttribute('data-submit_function');
    let dom_target_name = formDomObject.getAttribute('data-dom_target');

    if(dom_target_name){
        
        if(dom_target_name == '.parent'){
            settings.dom_target = formDomObject.parentNode;
        }else{
            let dom_target = document.getElementById(dom_target_name);
            if(dom_target){
                settings.dom_target = dom_target;
            }
        }
    }

    let upload_tinymce = false;
    if(formDomObject._submitter){

        if(formDomObject._submitter.getAttribute('data-tinymce_save')){
            if(tinymce && tinymce.activeEditor){
                tinymce.triggerSave();
                upload_tinymce = true;
            }
        }

        // if a target is specified in the submit button
        // it replaces the one on the form
        let dom_target_name = formDomObject._submitter.getAttribute('data-dom_target');

        if(dom_target_name){
            let dom_target = document.getElementById(dom_target_name);
            if(dom_target){
                settings.dom_target = dom_target;
            }
        }
        //~ console.log(dom_target_name);
        // send only the data set in the submit button
        let tmp = formDomObject._submitter.getAttribute('data-only');
        if(tmp){
            settings.data = {};
            // action / value of the submit button
            settings.data[formDomObject._submitter.name] = formDomObject._submitter.value;

            // add fields that must always be posted
            for(let i = 0; i < formDomObject.length ;i++){
                let input = formDomObject[i];
                if(input.getAttribute('data-alwaysposted')){
                    settings.data[input.name] = input.value;
                }
            }

            // if a select is used for the submit  of the form
            // it can (and should) contain two attributes to determine the action to be taken
            // data-actionname = name of the variable to post (equivalent to the name of a submit button)
            // data-actionvalue = value to post in this variable (equivalent to the value of a submit button)
            //
            // it also works with any other input
            let actionName = formDomObject._submitter.getAttribute('data-actionname');
            if(actionName){
                let actionValue = formDomObject._submitter.getAttribute('data-actionvalue');
                if(actionValue !== null){
                    settings.data[actionName] = actionValue;
                }
            }

        }else{
            settings.data = formDomObject;
        }
        
        let extra_parameters = formDomObject._submitter.dataset.parameters;
        if(extra_parameters){
            extra_parameters = JSON.parse(extra_parameters);
            if(GENERICS_Class.IsFilledObject(extra_parameters)){
                settings.extra_data = GENERICS_Class.MergeObjects(settings.extra_data,extra_parameters);
            }
        }

        // use the action from the submit button if one is defined
        settings.url = formDomObject._submitter.getAttribute('action') || formDomObject.getAttribute('action');

    }else{
        settings.data = formDomObject;
        settings.url = formDomObject.getAttribute('action');
    }

    if(upload_tinymce){
        // tinymce images must be uploaded before the form is submitted
        tinymce.activeEditor.uploadImages(function(success) {
            if(submit_handler_name){
                let func = window[submit_handler_name];
                if(typeof func == 'function'){
                    // EVENTS_Class.StopEvent(event);
                    func(settings);
                }else{
                    console.log('Invalid submit function');
                }
            }else{
                $_a.send(settings);
            }
        });
    }else{

        if(submit_handler_name){
            let func;
            if (submit_handler_name.includes('.')){
                submit_handler_name = submit_handler_name.split('.');
                //~ console.log(window[submit_handler_name[0]]);
                //~ console.log(window[submit_handler_name[0]][submit_handler_name[1]]);
                func = window[submit_handler_name[0]][submit_handler_name[1]];
            } else {
                func = window[submit_handler_name];
            }
            
            if(typeof func == 'function'){
                // EVENTS_Class.StopEvent(event);
                func(settings);
            }else{
                console.log('Invalid submit function');
            }

        }else{

            $_a.send(settings);
        }
    }
    return false;
};

VALIDATOR_Class.prototype.SendForm = function(settings){
    $_a.send(settings);
};

VALIDATOR_Class.prototype.checkForm = function(formDomObject){

    let lst = formDomObject.elements;
    let validator = formDomObject._validator;
    let submitter = formDomObject._submitter;
    let errorCount = 0;

    this.error_field = null;

    let only_submiter = false;
    if(submitter){
        only_submiter = submitter.getAttribute('data-only') !== null;
        if(submitter.getAttribute('data-cancel') !== null){
            return true;
        }
    }

    for(let i = 0 ; i < lst.length ; i++){

        let field = lst[i];
        
        //~ if (validator.firstTime){
            //~ validator.displayErrorField(field,[]);
            //~ validator.firstTime = false;
        //~ } else {
            
        //~ }
        
        //~ let parent = document.getElementById(id+'_parent');
        //~ if (!parent){
            //~ moved = true;
            //~ parent = DOM_Class.CreateElement('DIV',{'id':id+'_parent', 'class':'validatorParent'});
            //~ DOM_Class.InsertAfter(parent,input);
            //~ DOM_Class.AppendContent(parent, input);
            //~ input.focus();
        //~ }

        if(only_submiter && field.getAttribute('data-alwaysposted') === null){
            continue;
        }

        if (field.tagName == 'FIELDSET'){   // fieldset doesn't need validation
            continue;
        }

        if(!validator.checkField(field)){
            if(!this.error_field){
                this.error_field = field;
            }
            errorCount++;
        }
    }

    return errorCount === 0;
};

VALIDATOR_Class.prototype.checkField = function(input){

    let validator = input._validator;
    if(!validator){
        return true;
    }

    let type = input.getAttribute('data-type') || input.type;
    if(type == "submit"){
        return true;
    }

    let test = true;
    let formDomObject = input.form;
    let icon = input._validatorIcon;
    
    let err_list = [];

    let sizeTest = validator.evaluateSize(input);
    let required = input.getAttribute('data-required') !== null ? parseInt(input.getAttribute('data-required')) > 0 : false;
    let optional = input.getAttribute('data-optional') !== null ? parseInt(input.getAttribute('data-optional')) > 0 : false;

    if(optional && input.value == ''){
        return true;
    }

    // replace tinymce \n
    let parent_id = input.parentNode.getAttribute('id');
    if(input.id){
        if(input.id.substr(0,8)=='tinymce_'){
            input.value = input._tinymce.getContent({format: 'raw'}).replace(/data-mce(.*?)"(.*?)"/g, '');
        }
    }

    // original field
    // input = confirmation field
    let checkfield_id = input.getAttribute('data-checkfield');
    if(checkfield_id){
        let checkfield = document.getElementById(checkfield_id);
        if(checkfield){
            let ok = true;
            // if the original field has changed :
            if(checkfield._originalValue != checkfield.value && checkfield.value != input.value){
                
                ok = false;
            }else if(input.value.length > 0 && checkfield.value != input.value){
                ok = false;
            }

            if(ok){
                input.classList.toggle('wrong',false);
                input.classList.toggle('good',required);
            }else{
                input.classList.toggle('wrong',true);
                input.classList.toggle('good',false);
                return false;
            }
        }
    }

    let confirm_id = input.getAttribute('data-confirmfield');
    if(confirm_id){
        let confirm = document.getElementById(confirm_id);
        if(confirm){
            let ok = true;
            if(input._originalValue != input.value){
                if(confirm.value != input.value){
                    ok = false;
                }
            }else{
                if(confirm.value.length > 0 && confirm.value != input.value){
                    ok = false;
                }
            }
            if(ok){
                input.classList.toggle('wrong',false);
                input.classList.toggle('good',true);
                confirm.classList.toggle('wrong',false);
            }else{
                confirm.classList.toggle('wrong',true);
                confirm.classList.toggle('good',false);
            }
        }
    }

    if(input.value === '' && !required && sizeTest == VALIDATOR_Class.OK){
        input.classList.toggle('wrong',false);
        input.classList.toggle('good',false);
        if(icon){
            icon.classList.toggle('wrong',false);
            icon.classList.toggle('good',false);
        }
        return true;
    }

    switch(type){
        case 'text':
        case 'textarea':
        case 'password':
            let restriction = input.getAttribute('data-restrict');
            let exclusion = input.getAttribute('data-exclude');
            test = validator.checkText(input.value,restriction,exclusion);
        break;

        case 'int':
            test = validator.checkInt(input.value);
        break;

        case 'float':
            test = validator.checkFloat(input.value);
        break;

        case 'date':
            test = validator.checkDate(input.value);
        break;

        case 'email':
            test = validator.checkEmail(input.value);
        break;

    }


    if(icon){
        icon.title = '';
        input.title = '';
    }

    let length = input.value.trim().length;
    if (input.type == 'checkbox' && !input.checked) {
        length = 0;
    }
    let cur_lng = CONSTANTS.current_lang_iso;

    if(!test){
        if(icon){ icon.title += CONSTANTS.GetText('invalid_content'); }
        input.title += CONSTANTS.GetText('invalid_content');
        
        err_list.push('invalid_content');
    }
    
    if(length === 0 && required){
        // nothing entered in a required field.
        test = false;
        if(icon){ icon.title = CONSTANTS.GetText('required_field')+'\n'; }
        input.title = CONSTANTS.GetText('required_field')+'\n';
        
        err_list.push('required_field');
    }

    //let sizeTest = validator.evaluateSize(input);
    if(sizeTest !== VALIDATOR_Class.OK){
        test = false;
        if(sizeTest == VALIDATOR_Class.tooSmall){
            if(icon){ icon.title += CONSTANTS.GetText('short_content'); }
            input.title += CONSTANTS.GetText('short_content');
            err_list.push('short_content');
        }
        if(sizeTest == VALIDATOR_Class.tooBig){
            if(icon){ icon.title += CONSTANTS.GetText('long_content'); }
            input.title += CONSTANTS.GetText('long_content');
            err_list.push('long_content');
        }

    }

    if(type == 'int' || type=='float'){
        if(validator.checkInputLimits(input) !== VALIDATOR_Class.OK){
            test = false;
            if(icon){ icon.title += CONSTANTS.GetText('out_of_bounds'); }
            input.title += CONSTANTS.GetText('out_of_bounds');
            
            err_list.push('out_of_bounds');
        }
    }

    if(test && input.value !== ''){

        input.classList.toggle('wrong',false);
        input.classList.toggle('good',true);

        if(icon){
            icon.classList.toggle('wrong',false);
            icon.classList.toggle('good',true);
        }
    }else if(!test){

        input.classList.toggle('wrong',true);
        input.classList.toggle('good',false);

        if(icon){
            icon.classList.toggle('wrong',true);
            icon.classList.toggle('good',false);
        }
    }
    
    validator.displayErrorField(input, err_list);

    return test;
};

VALIDATOR_Class.prototype.displayErrorField = function(input,err_list){
    //~ console.log(input);
    //~ console.log(err_list);
    if (input.type == 'hidden' || input.tagName == 'FIELDSET' || input.tagName == 'BUTTON' || input.type == 'button') return;
    if (input._tinymce) return;
    
    if (input.id == ''){
        input.id = GENERICS_Class.GetUniqueId();
    }
    let id = input.id;
    
    let parent = document.getElementById(id+'_parent');
    if (!parent){
        moved = true;
        parent = DOM_Class.CreateElement('DIV',{'id':id+'_parent', 'class':'validatorParent'});
        DOM_Class.InsertAfter(parent,input);
        DOM_Class.AppendContent(parent, input);
        //~ input.focus();
    } else {
        while (parent.lastChild && parent.lastChild.tagName != 'INPUT' && parent.lastChild.tagName != 'SELECT' && parent.lastChild.tagName != 'TEXTAREA'){
            DOM_Class.RemoveElement(parent.lastChild);
        }
    }
    
    if (err_list.length > 0){
        err_list.forEach((tl)=>{
            let msg = DOM_Class.CreateElement('DIV',{'class':'msg_err'},CONSTANTS.GetText(tl));
            DOM_Class.AppendContent(parent, msg);
        });
    }
    
    //~ input.focus();
};

VALIDATOR_Class.prototype.badFieldModal = function(input){
    let validator = input._validator;
    if (!validator.modal) validator.modal = [];
    if (!validator.modal[input.name]){
        let cur_lng = CONSTANTS.current_lang_iso;
        validator.modal[input.name] = UI_Class.AddWindow(null, {'modal': true, 'nodrag': true, 'class': 'modal_validator_info','id':input.name+'_validator'});

            // modal's content
            let container_info = DOM_Class.CreateElement('DIV', {'class': 'validator_info_container'});
            let msg_err = DOM_Class.CreateElement('DIV', {'class': 'validator_info_general'}, CONSTANTS.GetText('required_field'));
            DOM_Class.AppendContent(container_info, msg_err);

        validator.modal[input.name].SetContent(container_info);
        DOM_Class.InsertAfter(validator.modal[input.name].domElement, input);
        let rect = DOM_Class.GetGlobalRect(input);
        console.log(rect);
        DOM_Class.SetPosition(validator.modal[input.name].domElement, rect.right, rect.y-rect.height);
        
        //~ validator.modal.SetParent(document.getElementById('lemain'));
        //~ validator.modal.domElement.classList.add('err_form');

    } else {
        validator.modal[input.name].Show();
    }

    if(validator.error_field){
        validator.error_field.focus();
    }
};


VALIDATOR_Class.prototype.checkEmail = function(email){
  var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  return re.test(email);
};

VALIDATOR_Class.prototype.checkEventDate = function(event){
    
    let input = event.target;
    let validator = input._validator;
    
    validator.checkField(input);
    return;
    
    
/*
    let chunks = input.value.split(VALIDATOR_Class.dateSeparator);
    if(chunks.length != 3){
        chunks = ['01','01','1900'];
        input.value = chunks.join(VALIDATOR_Class.dateSeparator);
    }
    let currentValue = input.value;

    let minimums = [1,1,1900];
    let maximums = [31,12,9999];
    let paddings = ['00','00','0000'];

    let positions = [];
    let cumul = 0;



    for(let i = 0; i < chunks.length ; i++){
        cumul += chunks[i].length;
        positions.push(cumul);
        cumul += 3;
        chunks[i] = Math.min(maximums[i],Math.max(isNaN(parseInt(chunks[i]))?minimums[i]:parseInt(chunks[i]) , minimums[i]));
    }

    while(positions.length < 2){
        positions.push(input.value.length);
        input.value += VALIDATOR_Class.dateSeparator;
    }

    let dateIndex = positions.length;
    for(let i = 0 ; i < positions.length ; i++){
        if(input.selectionStart <= positions[i]+1){
            dateIndex = i;
            break;
        }
    }

    let maxDays = new Date(parseInt(chunks[2]), parseInt(chunks[1]), 0).getDate();
    let sepLength = VALIDATOR_Class.dateSeparator;

    maximums[0] = maxDays;

    if(event.type == 'keydown'){

        let s_s = input.selectionStart;
        let s_e = input.selectionEnd;

        let v = parseInt(chunks[dateIndex]);

        if(isNaN(v)){
            v = 0;
        }

        switch(event.keyCode){
            case 8: // backspace

                for(let i = 0 ; i < positions.length ; i++){
                    if(input.selectionStart >=positions[i]+1 && input.selectionStart <= positions[i]+sepLength){
                        EVENTS_Class.StopEvent(event);
                        return false;
                    }
                }

                return false;

            case 46: // delete
                for(let i = 0 ; i < positions.length ; i++){
                    if(input.selectionStart >=positions[i] && input.selectionStart <= positions[i]+(sepLength-1)){
                        EVENTS_Class.StopEvent(event);
                        return false;
                    }
                }

                return false;

            case 9: // tab
                if(event.shiftKey){
                    dateIndex--;
                    if(dateIndex < 0){
                        return false;
                    }
                }else{
                    dateIndex++;
                    if(dateIndex >= chunks.length){
                        return false;
                    }
                }

                s_s = positions[dateIndex-1]+sepLength;
                s_e = s_s;
                input.selectionStart = s_s;
                input.selectionEnd = s_e;
                EVENTS_Class.StopEvent(event);
                return false;

            case 13: // return
            case 35: // page down
            case 36: // page up
                //case 37: // left
                //case 39: // right
                return false;

            case 38:
                v++;
                if(v > maximums[dateIndex]){
                    if(dateIndex == 2){
                        v = maximums[dateIndex];
                    }else{
                        let j = dateIndex;
                        let w = v;
                        v = minimums[dateIndex];
                        while(j < 2 && w > maximums[j]){
                            j++;
                            w = chunks[j];
                            w++;
                            let n = w;
                            if( n > maximums[j]){
                                n = minimums[j];
                            }
                            chunks[j] = (paddings[j]+n).slice(-paddings[j].length);
                        }
                    }
                }

                chunks[dateIndex] = v;

                if(dateIndex == 1){
                    maxDays = new Date(parseInt(chunks[2]), parseInt(chunks[1]), 0).getDate();
                    if(chunks[0] > maxDays){
                        chunks[0] = maxDays;
                    }
                }

                for(let i = 0; i < chunks.length ; i++){
                    chunks[i] = (paddings[i]+chunks[i]).slice(-paddings[i].length);
                }
                input.value = chunks.join(VALIDATOR_Class.dateSeparator);
                input.selectionStart = s_s;
                input.selectionEnd = s_e;
                EVENTS_Class.StopEvent(event);
                return false;


            case 40:
                v--;
                if(v < minimums[dateIndex]){
                    if(dateIndex == 2){
                        v = minimums[dateIndex];
                    }else{
                        let j = dateIndex;
                        let w = v;
                        v = maximums[dateIndex];
                        while(j < 2 && w < minimums[j]){
                            j++;
                            w = chunks[j];
                            w--;
                            let n = w;
                            if( n < minimums[j]){
                                n = maximums[j];
                            }
                            chunks[j] = (paddings[j]+n).slice(-paddings[j].length);
                            if(j == 1 && dateIndex === 0){
                                v = new Date(parseInt(chunks[2]), parseInt(chunks[1]), 0).getDate();
                            }
                        }
                    }
                }

                chunks[dateIndex] = v;

                if(dateIndex == 1){
                    maxDays = new Date(parseInt(chunks[2]), parseInt(chunks[1]), 0).getDate();
                    if(chunks[0] > maxDays){
                        chunks[0] = maxDays;
                    }
                }

                for(let i = 0; i < chunks.length ; i++){
                    chunks[i] = (paddings[i]+chunks[i]).slice(-paddings[i].length);
                }
                input.value = chunks.join(VALIDATOR_Class.dateSeparator);
                input.selectionStart = s_s;
                input.selectionEnd = s_e;
                EVENTS_Class.StopEvent(event);
                return false;


        }

        if(event.keyCode == 37){
            let currentPos = 0;
            if(input.selectionStart != input.selectionEnd){
                currentPos = input.selectionStart;
            }else{
                currentPos = Math.max(input.selectionStart - 1 , 0);
            }

            for(let i = 0 ; i < positions.length ; i++){
                if(currentPos >= positions[i] && currentPos <= positions[i]+(sepLength-1)){
                    input.selectionStart = positions[i];
                    break;
                }
            }

            return false;
        }

        if(event.keyCode == 39){
            let currentPos = 0;
            if(input.selectionStart != input.selectionEnd){
                currentPos = input.selectionEnd;
            }else{
                currentPos = Math.min(input.selectionEnd + 1 , input.value.length);
            }

            for(let i = 0 ; i < positions.length ; i++){
                if(currentPos > positions[i] && currentPos <= positions[i]+(sepLength-1)){
                    input.selectionStart = positions[i]+(sepLength-1);
                    break;
                }
            }

            return false;
        }

        let restriction = '0123456789';
        if(restriction.indexOf(event.key) == -1){
            EVENTS_Class.StopEvent(event);
            return false;
        }
    }

    if(event.type == 'mouseup'){
        for(let i = 0 ; i < positions.length ; i++){
            if(input.selectionStart > positions[i] && input.selectionStart <= positions[i]+(sepLength-1)){
                input.selectionStart = input.selectionEnd = positions[dateIndex-1]+sepLength;
                break;
            }
        }
    }

    if(event.type == 'focus' || event.type == 'blur'){
        var d = new Date(chunks[2], chunks[1] - 1, chunks[0]);

        if(validator.checkDate(input.value)){
            // ok
        }else{
            chunks[0] = d.getDate();
            chunks[1] = d.getMonth()+1;
            chunks[2] = d.getFullYear();
            for(let i = 0; i < chunks.length ; i++){
                chunks[i] = (paddings[i]+chunks[i]).slice(-paddings[i].length);
            }
            input.value = chunks.join(VALIDATOR_Class.dateSeparator);
        }
        if(event.type == 'focus'){
            input.selectionStart = input.selectionEnd = input.value.length;
        }
    }


    validator.checkField(input);
    //console.log(input.selectionStart,' -> ',input.selectionEnd);
    */
};

VALIDATOR_Class.prototype.checkEventValidity = function(event){
    let input = event.target;
    let validator = input._validator;
    validator.checkField(input);
};

VALIDATOR_Class.prototype.checkDate = function(dateString){
    // TODO : modify to take into account native html date fields
    // useless, they are necessarily valid even if they may be illogical. . .
    // the prepared queries will clean up.
    return true;
};

VALIDATOR_Class.prototype.validateDate = function(dateString){
    let chunks = dateString.split(VALIDATOR_Class.dateSeparator);

    let minimums = [1,1,1900];
    let maximums = [31,12,9999];
    let paddings = ['00','00','0000'];

    for(let i = 0; i < chunks.length ; i++){
        chunks[i] = Math.min(maximums[i],Math.max(isNaN(chunks[i])?0:parseInt(chunks[i]) , minimums[i]));
    }

    let d = new Date(chunks[2], chunks[1] - 1, chunks[0]);
    while(!(d && (d.getMonth() + 1) == parseInt(chunks[1]))){

        d = new Date(chunks[2], chunks[1] - 1, chunks[0]);
    }

    return chunks.join(VALIDATOR_Class.dateSeparator);
};


VALIDATOR_Class.convertStringFilter = function(restriction){
    switch(restriction){
        case '_username':
            restriction = VALIDATOR_Class.usernameValidString;
        break;

        case '_alpha':
            restriction = VALIDATOR_Class.alphaValidString;
        break;

        case '_int':
            restriction = VALIDATOR_Class.integerValidString;
        break;

        case '_float':
        case '_num':
            restriction = VALIDATOR_Class.floatValidString;
        break;
    }

    return restriction;
};

// return false if str contains bad caracters
VALIDATOR_Class.prototype.checkText = function(str,restriction,exclusion){

    restriction = VALIDATOR_Class.convertStringFilter(restriction);
    exclusion = VALIDATOR_Class.convertStringFilter(exclusion);

    if(restriction || exclusion){
        let result = '';
        for(let i = 0 , c = str.length ; i < c ; i++){
            if((restriction && restriction.indexOf(str.charAt(i)) == -1) || (exclusion && exclusion.indexOf(str.charAt(i)) > -1) ){
                return false;
            }
        }
        return true;
    }else{
        return true;
    }
};


// return false if str is not an int value
VALIDATOR_Class.prototype.checkInt = function(str){
    return (!isNaN(parseInt(str)) && parseInt(str)+'' == str+'');
};

// return false if str is not a float value
VALIDATOR_Class.prototype.checkFloat = function(str){
    return !isNaN(parseFloat(str));
};

VALIDATOR_Class.prototype.evaluateSize = function(input){

    let sizemin = parseInt(input.getAttribute('data-sizemin'));
    let sizemax = parseInt(input.getAttribute('data-sizemax'));

    let length = input.value.trim().length;
    let required = input.getAttribute('data-required') !== null ? parseInt(input.getAttribute('data-required')) > 0 : false;

    if(length === 0 && !required){
        return VALIDATOR_Class.OK;
    }

    if(!isNaN(sizemin) && length < sizemin){
        return VALIDATOR_Class.tooSmall;

    }else if(!isNaN(sizemax) && length > sizemax){
        return VALIDATOR_Class.tooBig;
    }

    return VALIDATOR_Class.OK;
};

VALIDATOR_Class.prototype.checkEventText = function(event){

    let input = event.target;
    let type = input.getAttribute('data-type') || input.type;
    let s_s = input.selectionStart;
    let s_e = input.selectionEnd;
    let validator = input._validator;

    if(input.tagName == 'TEXTAREA'){
        switch(event.keyCode){
            case 8: // backspace
            case 9: // tab
            case 46: // delete
                validator.checkField(input);
            break;
        }
        return true;
    }

    switch(event.keyCode){

        case 35: // page down
        case 36: // page up
        case 37: // left
        case 39: // right
            return false;


        case 13: // return
            let auto_submit = input.getAttribute('data-returnsubmit');
            if(auto_submit){

                let form = input.form;
                form._disableNextSubmit = false;

                if(GENERICS_Class.IsString(auto_submit)){
                    let json = null;
                    try{
                        json = JSON.parse(auto_submit);
                    }catch(e){
                    }
                    if(GENERICS_Class.IsObject(json)){
                        let k = Object.keys(json)[0];

                        let submitter = DOM_Class.CreateElement('INPUT',{'name':k , 'value':json[k] , 'type':'hidden'});
                        form._validator.protectInput(submitter);
                        form.appendChild(submitter);

                        AJAX_Class.setFormSubmitter(submitter);

                    }else{
                        for(let i=0; i<form.elements.length ; i++){
                            let e = form.elements[i];
                            if(e.name == auto_submit){
                                AJAX_Class.setFormSubmitter(e);
                                break;
                            }
                        }
                    }
                }

                EVENTS_Class.StopEvent(event);

                EVENTS_Class.SendEvent(form,'submit');

                return false;
            }else{

                let form = input.form;
                form._disableNextSubmit = true;
            }

            return true;

        case 8: // backspace
        case 9: // tab

        case 46: // delete
            validator.checkField(input);
            return false;

        case 38: // up
            let max = parseFloat(input.getAttribute('max'));

            if(type == 'int'){
                if(isNaN(max)){
                    input.value = parseInt(input.value||0)+1;
                }else{
                    input.value = Math.min(parseInt(input.value||0)+1 , max);
                }

                input.selectionStart = s_s;
                input.selectionEnd = s_e;

                EVENTS_Class.StopEvent(event);
                return false;
            }

            if(type == 'float'){
                if(!input.value){
                    input.value = '0.0';
                }
                let comma = '.';
                if(input.value.indexOf(',') > -1){
                    comma = ',';
                }

                let tmp = input.value.split(comma);
                let v = parseInt(tmp[0]);
                if(isNaN(v)){
                    v = 0;
                }
                v++;
                v += (tmp.length>1?'.'+tmp[1]:'.0');
                if(!isNaN(max) && v > max){
                    v = max+'';
                    if(v.indexOf('.') == -1){
                        v += '.0';
                    }
                }
                if(comma != '.'){
                    v = v.replace('.',comma);
                }
                input.value = v;

                input.selectionStart = s_s;
                input.selectionEnd = s_e;

                EVENTS_Class.StopEvent(event);
                return false;
            }

            return true;

        case 40: // down
            let min = parseFloat(input.getAttribute('min'));

            if(type == 'int'){
                if(isNaN(min)){
                    input.value = parseInt(input.value||0)-1;
                }else{
                    input.value = Math.max(parseInt(input.value||0)-1 , min);
                }

                input.selectionStart = s_s;
                input.selectionEnd = s_e;
                EVENTS_Class.StopEvent(event);
                return false;
            }

            if(type == 'float'){
                if(!input.value){
                    input.value = '0.0';
                }
                let comma = '.';
                if(input.value.indexOf(',') > -1){
                    comma = ',';
                }

                let tmp = input.value.split(comma);
                let v = parseInt(tmp[0]);
                if(isNaN(v)){
                    v = 0;
                }
                v--;
                v += (tmp.length>1?'.'+tmp[1]:'.0');
                if(!isNaN(min) && v < min){
                    v = min+'';
                    if(v.indexOf('.') == -1){
                        v += '.0';
                    }
                }
                if(comma != '.'){
                    v = v.replace('.',comma);
                }
                input.value = v;

                input.selectionStart = s_s;
                input.selectionEnd = s_e;
                EVENTS_Class.StopEvent(event);
                return false;
            }

            return true;
    }


    let restriction = input.getAttribute('data-restrict');
    let exclusion = input.getAttribute('data-exclude');

    switch(restriction){
        case '_alpha':
            restriction = VALIDATOR_Class.alphaValidString;
        break;

        default:
            switch(type){
                case 'int':
                    restriction = VALIDATOR_Class.integerValidString;
                    if(event.key=='-' && (input.value.indexOf('-') > -1 || input.selectionStart > 0)){
                        EVENTS_Class.StopEvent(event);
                        return false;
                    }
                break;

                case 'float':
                    restriction = VALIDATOR_Class.floatValidString;
                    if((event.key=='-' && (input.value.indexOf('-') > -1 || input.selectionStart > 0)) || (event.key=='.' || event.key==',') && (input.value.indexOf('.') > -1 || input.value.indexOf(',') > -1) ){
                        EVENTS_Class.StopEvent(event);
                        return false;
                    }
                break;
            }
        break;
    }

    if(event.type == 'keydown'){
        restriction = VALIDATOR_Class.convertStringFilter(restriction);
        exclusion = VALIDATOR_Class.convertStringFilter(exclusion);

        if((restriction && restriction.indexOf(event.key) == -1) || (exclusion && exclusion.indexOf(event.key) > -1)){
            EVENTS_Class.StopEvent(event);
            return false;
        }

    }else{
        if(restriction){
            input.value = validator.restrictString(input.value , restriction , exclusion);
        }
    }

    validator.checkField(input);
};

VALIDATOR_Class.prototype.restrictString = function(str,restriction,exclusion){

    restriction = VALIDATOR_Class.convertStringFilter(restriction);
    exclusion = VALIDATOR_Class.convertStringFilter(exclusion);

    if(restriction || exclusion){
        let result = '';
        for(let i = 0 , c = str.length ; i < c ; i++){
            if((restriction && restriction.indexOf(str.charAt(i)) > -1) || (exclusion && exclusion.indexOf(str.charAt(i)) == -1) ){
                result += str.charAt(i);
            }
        }
        return result;
    }else{
        return str;
    }
};

VALIDATOR_Class.prototype.checkEventLimits = function(event){
    let validator = event.target._validator;
    validator.applyInputLimits(event.target);
};

VALIDATOR_Class.prototype.applyInputLimits = function(input){

    let s_s = input.selectionStart;
    let s_e = input.selectionEnd;
    let min,max,v;
    switch(input.getAttribute('data-type')){
        case 'float':

            min = parseFloat(input.getAttribute('min'));
            max = parseFloat(input.getAttribute('max'));
            v = parseFloat(input.value);

            if(!isNaN(min) && v < min){
                input.value = min;
            }

            if(!isNaN(max) && v > max){
                input.value = max;
            }
            input.selectionStart = s_s;
            input.selectionEnd = s_e;
        break;

        case 'int':
            min = parseInt(input.getAttribute('min'));
            max = parseInt(input.getAttribute('max'));
            v = parseInt(input.value);

            if(!isNaN(min) && v < min){
                input.value = min;
            }

            if(!isNaN(max) && v > max){
                input.value = max;
            }
            input.selectionStart = s_s;
            input.selectionEnd = s_e;
        break;
    }
};

VALIDATOR_Class.prototype.checkInputLimits = function(input){

    let min,max,v;
    switch(input.getAttribute('data-type')){
        case 'float':

            min = parseFloat(input.getAttribute('min'));
            max = parseFloat(input.getAttribute('max'));
            v = parseFloat(input.value);
        break;

        case 'int':
            min = parseInt(input.getAttribute('min'));
            max = parseInt(input.getAttribute('max'));
            v = parseInt(input.value);
        break;
    }

    if(!isNaN(min) && !isNaN(v) && v < min){
                return VALIDATOR_Class.tooSmall;
    }

    if(!isNaN(max) && !isNaN(v) && v > max){
        return VALIDATOR_Class.tooBig;
    }

    return VALIDATOR_Class.OK;
};
var anim = function(){};
anim.prototype.constructor = anim;

anim._animate = [];

anim.checkAnim = function(){
    if (anim._animate.length > 0){
        for (let i = 0; i < anim._animate.length; i++){
            anim.ProcessAnim(anim._animate[i]);
        }
    }
};

anim.ProcessAnim = function(a){
    if (a){
        let type = a.type;
        var domElem = document.getElementById(a.domID);
        switch(type){
           
            case 'spanim':
                let opts = a.opts.replace(/'/g, '"');
                //~ console.log(opts);
                spanim(JSON.parse(opts));
            break;
            
            default:
                return false;
            break;
        }
    }
};

// -------------------------------------------------------------------
// ----------------------- DETECT ANIM -------------------------------
// -------------------------------------------------------------------

function detect_anime(res=false){
    anim._animate = [];
    if (res) {
        var dom = DOM_Class.StringToDom(res);
        recurseDom(dom);
    } else {
        dom = document.body;
        recurseDom(dom);
    }
    anim.checkAnim();
}

function recurseDom(domElem){
    if (domElem){
        
        testAnimExist(domElem);
        var children = domElem.children;
        if (children){
            for (let i = 0; i < children.length; i++){
                recurseDom(children[i]);
            }
        }
    }
}

function testAnimExist(domElem){
    if (domElem.dataset && domElem.dataset.animate){
        var type = domElem.dataset.animate;
        if (type == 'spanim') {
            var opts = domElem.dataset.anim_opts;
            anim._animate.push({type, opts});
        } else {
            var params = domElem.dataset.anim_params;
            var id = domElem.parentElement.id;
            anim._animate.push({'type': type, 'params': params, 'domID': id});
        }
    }
}

// BEZIER EASING        https://github.com/gre/bezier-easing
// =============

var Bezier = function(mX1, mY1, mX2, mY2){
    if (!(0 <= mX1 && mX1 <= 1 && 0 <= mX2 && mX2 <= 1)) {
        throw new Error('bezier x values must be in [0, 1] range');
    }

    // Precompute samples table
    var sampleValues = Bezier.float32ArraySupported ? new Float32Array(Bezier.kSplineTableSize) : new Array(Bezier.kSplineTableSize);
    if (mX1 !== mY1 || mX2 !== mY2) {
        for (var i = 0; i < Bezier.kSplineTableSize; ++i) {
            sampleValues[i] = Bezier.calcBezier(i * Bezier.kSampleStepSize, mX1, mX2);
        }
    }

    function getTForX (aX) {
        var intervalStart = 0.0;
        var currentSample = 1;
        var lastSample = Bezier.kSplineTableSize - 1;

        for (; currentSample !== lastSample && sampleValues[currentSample] <= aX; ++currentSample) {
            intervalStart += Bezier.kSampleStepSize;
        }
        --currentSample;

        // Interpolate to provide an initial guess for t
        var dist = (aX - sampleValues[currentSample]) / (sampleValues[currentSample + 1] - sampleValues[currentSample]);
        var guessForT = intervalStart + dist * Bezier.kSampleStepSize;

        var initialSlope = Bezier.getSlope(guessForT, mX1, mX2);
        if (initialSlope >= Bezier.NEWTON_MIN_SLOPE) {
            return Bezier.newtonRaphsonIterate(aX, guessForT, mX1, mX2);
        } else if (initialSlope === 0.0) {
            return guessForT;
        } else {
            return Bezier.binarySubdivide(aX, intervalStart, intervalStart + Bezier.kSampleStepSize, mX1, mX2);
        }
    }

    return function BezierEasing (x) {
        if (mX1 === mY1 && mX2 === mY2) {
            return x; // linear
        }
        // Because JavaScript number are imprecise, we should guarantee the extremes are right.
        if (x === 0) {
            return 0;
        }
        if (x === 1) {
            return 1;
        }
        return Bezier.calcBezier(getTForX(x), mY1, mY2);
    };
};
Bezier.prototype.constructor = Bezier;

Bezier.NEWTON_ITERATIONS = 4;
Bezier.NEWTON_MIN_SLOPE = 0.001;
Bezier.SUBDIVISION_PRECISION = 0.0000001;
Bezier.SUBDIVISION_MAX_ITERATIONS = 10;

Bezier.kSplineTableSize = 11;
Bezier.kSampleStepSize = 1.0 / (Bezier.kSplineTableSize - 1.0);

Bezier.float32ArraySupported = typeof Float32Array === 'function';

Bezier.A = function (aA1, aA2) { return 1.0 - 3.0 * aA2 + 3.0 * aA1; };
Bezier.B = function (aA1, aA2) { return 3.0 * aA2 - 6.0 * aA1; };
Bezier.C = function (aA1)      { return 3.0 * aA1; };

// Returns x(t) given t, x1, and x2, or y(t) given t, y1, and y2.
Bezier.calcBezier = function (aT, aA1, aA2) { return ((Bezier.A(aA1, aA2) * aT + Bezier.B(aA1, aA2)) * aT + Bezier.C(aA1)) * aT; };

// Returns dx/dt given t, x1, and x2, or dy/dt given t, y1, and y2.
Bezier.getSlope = function (aT, aA1, aA2) { return 3.0 * Bezier.A(aA1, aA2) * aT * aT + 2.0 * Bezier.B(aA1, aA2) * aT + Bezier.C(aA1); };

Bezier.binarySubdivide = function (aX, aA, aB, mX1, mX2) {
    var currentX, currentT, i = 0;
    do {
        currentT = aA + (aB - aA) / 2.0;
        currentX = Bezier.calcBezier(currentT, mX1, mX2) - aX;
        if (currentX > 0.0) {
            aB = currentT;
        } else {
            aA = currentT;
        }
    } while (Math.abs(currentX) > Bezier.SUBDIVISION_PRECISION && ++i < Bezier.SUBDIVISION_MAX_ITERATIONS);
    return currentT;
};

Bezier.newtonRaphsonIterate = function (aX, aGuessT, mX1, mX2) {
    for (var i = 0; i < Bezier.NEWTON_ITERATIONS; ++i) {
        var currentSlope = Bezier.getSlope(aGuessT, mX1, mX2);
        if (currentSlope === 0.0) {
            return aGuessT;
        }
        var currentX = Bezier.calcBezier(aGuessT, mX1, mX2) - aX;
        aGuessT -= currentX / currentSlope;
    }
    return aGuessT;
};

// -------------------------------------------------------------------
// ------------------------ SpaNim------------------------------------
// -------------------------------------------------------------------
var spanim = function(opts){
    if (!opts.elements) {console.log('noelements');return false;}
    
    var rest = Object.keys(opts).filter((key) => {
        if (!spanim.defaultSettings.hasOwnProperty(key)) return true;
    });
    
    var keyframes = {};
    rest.forEach( (key) => {keyframes[key] = opts[key];});
    
    opts.elements = spanim.getElements(opts.elements);
    opts.preset = (!opts.preset) ? false : true;
    opts.duration = (!opts.duration) ? 300 : opts.duration;
    opts.delay = (!opts.delay) ? 0 : opts.delay;
    opts.loop = (!opts.loop) ? false : opts.loop;
    opts.direction = (!opts.direction) ? 'normal' : opts.direction ;
    opts.event = (!opts.event) ? 'load' : opts.event;
    opts.speed = (!opts.speed) ? 1 : opts.speed;
    opts.easing = (!opts.easing) ? 'OutCubic' : opts.easing;
    opts.change = (!opts.change) ? null : opts.change;
    opts.end = (!opts.end) ? null : opts.end;
    
    if (opts.event == 'click' || opts.event == 'hover' || opts.event == 'scroll' ) opts.loop = false;    
    if ((opts.event == 'hover' || opts.event == 'scroll') && opts.direction == 'alternate') opts.direction = 'normal';
    //~ if (opts.event == 'hover' || opts.event == 'scroll') opts.delay = 0;
    
    if (opts.preset) keyframes = spanim.makeKeyframe(opts.elements, keyframes);
    if (typeof(opts.loop) == 'number') {
        opts.loop = Math.trunc(opts.loop);
        if (opts.loop == 1) opts.loop = true;
        if (opts.direction == 'alternate' && opts.loop != true) opts.loop = 2 * opts.loop;
    }
    
    
    
    return new Promise(resolve => spanim.addAnimations(opts, keyframes, resolve));
};
spanim.prototype.constructor = spanim;

spanim.first = function([item]) { return item; };

spanim.isFunction = (operand) => typeof operand == "function";


// collect elems in the dom
spanim.getElements = function(elements){
    if (Array.isArray(elements)) {
        return elements;
    }
    if (!GENERICS_Class.IsString(elements) && elements.nodeType) {
        return [elements];
    } 
    return Array.from(GENERICS_Class.IsString(elements) ? document.querySelectorAll(elements) : elements);
};

spanim.defaultSettings = {
    elements: null,
    preset: false,
    duration: 1000,
    delay: 0,
    loop: false,
    direction: 'normal',
    event: 'load',
    speed: 1,
    easing: 'out-cubic',
    change: null,
    end: null
};


spanim.makeKeyframe = function(elems, keyframe){

    let maxRect = {bottom: 0, height: 0, left: 0, right: 0, top: 0, width: 0, x: 0, y: 0};
    
    elems.forEach((elem)=>{
        let rect = DOM_Class.GetGlobalRect(elem, true);
        for (let key in rect){
            maxRect[key] = Math.max(rect[key], maxRect[key]);
        }
    });
    
    let screenW = window.screen.width;
    let screenY = window.screen.height;
    
    for (let property in keyframe){
        if (property == 'transform'){
            let arr = keyframe[property][0].split('(');
            let type = arr[0];
            switch(type){
                case 'translateX':
                    let left = arr[1].includes('-');
                    if (left) {
                        let nbr = maxRect.width + maxRect.left;
                        type += '(-' + nbr + 'px)';
                    } else {
                        let nbr = screenW - maxRect.left;
                        type += '(' + nbr + 'px)';
                    }
                    keyframe[property][0] = type;
                    console.log(type);
                    break;
                    
                case 'translateY':
                    let top = arr[1].includes('-');
                    if (top) {
                        let nbr = maxRect.height + maxRect.top;
                        type += '(-' + nbr + 'px)';
                    } else {
                        let nbr = screenY - maxRect.bottom;
                        type += '(' + nbr + 'px)';
                    }
                    keyframe[property][0] = type;
                    break;
                    
                default:
                    break;
            }
        }
    }
    
    
    return keyframe;
};
// color conversion
// ================

spanim.hexPairs = color => {
  const split = color.split("");
  const pairs = color.length < 5 ? split.map(string => string + string) : split.reduce((array, string, index) => {
      if (index % 2)
        array.push(split[index - 1] + string);
      return array;
    }, []);
  if (pairs.length < 4)
    pairs.push("ff");
  return pairs;
};

spanim.convert = color =>
  spanim.hexPairs(color).map(string => parseInt(string, 16));

spanim.rgba = hex => {
  const color = hex.slice(1);
  const [r, g, b, a] = spanim.convert(color);
  return `rgba(${r}, ${g}, ${b}, ${a / 255})`;
};

// easing equations             https://github.com/juliangarnier/anime
// ================

spanim.easeNames = ['Quad', 'Cubic', 'Quart', 'Quint', 'Sine', 'Expo', 'Circ', 'Back'];

spanim.elastic = function(t, p) {
    return t === 0 || t === 1 ? t :
    -Math.pow(2, 10 * (t - 1)) * Math.sin((((t - 1) - (p / (Math.PI * 2.0) * Math.asin(1))) * (Math.PI * 2)) / p );
};

spanim.equations = {
    In: [
        [0.550, 0.085, 0.680, 0.530], /* InQuad */
        [0.550, 0.055, 0.675, 0.190], /* InCubic */
        [0.895, 0.030, 0.685, 0.220], /* InQuart */
        [0.755, 0.050, 0.855, 0.060], /* InQuint */
        [0.470, 0.000, 0.745, 0.715], /* InSine */
        [0.950, 0.050, 0.795, 0.035], /* InExpo */
        [0.600, 0.040, 0.980, 0.335], /* InCirc */
        [0.600, -0.280, 0.735, 0.045], /* InBack */
        //~ spanim.elastic /* InElastic */
    ], Out: [
        [0.250, 0.460, 0.450, 0.940], /* OutQuad */
        [0.215, 0.610, 0.355, 1.000], /* OutCubic */
        [0.165, 0.840, 0.440, 1.000], /* OutQuart */
        [0.230, 1.000, 0.320, 1.000], /* OutQuint */
        [0.390, 0.575, 0.565, 1.000], /* OutSine */
        [0.190, 1.000, 0.220, 1.000], /* OutExpo */
        [0.075, 0.820, 0.165, 1.000], /* OutCirc */
        [0.175, 0.885, 0.320, 1.275], /* OutBack */
        //~ (t, f) => 1 - spanim.elastic(1 - t, f) /* OutElastic */
    ], InOut: [
        [0.455, 0.030, 0.515, 0.955], /* InOutQuad */
        [0.645, 0.045, 0.355, 1.000], /* InOutCubic */
        [0.770, 0.000, 0.175, 1.000], /* InOutQuart */
        [0.860, 0.000, 0.070, 1.000], /* InOutQuint */
        [0.445, 0.050, 0.550, 0.950], /* InOutSine */
        [1.000, 0.000, 0.000, 1.000], /* InOutExpo */
        [0.785, 0.135, 0.150, 0.860], /* InOutCirc */
        [0.680, -0.550, 0.265, 1.550], /* InOutBack */
        //~ (t, f) => t < .5 ? spanim.elastic(t * 2, f) / 2 : 1 - spanim.elastic(t * -2 + 2, f) / 2 /* InOutElastic */
    ]
};

spanim.easings = {
    linear: Bezier(0.250, 0.250, 0.750, 0.750)
};

for (let type in spanim.equations) {
    spanim.equations[type].forEach((f, i) => {
        spanim.easings[type+spanim.easeNames[i]] = Bezier(...f);
    });
}


spanim.decomposeEasing = function(string) {
    let [easing, amplitude = 1, period = .4] = string.trim().split(" ");
    return {easing, amplitude, period};
};

spanim.ease = function({easing, amplitude, period}, progress) {
    return spanim.easings[easing](progress);
};

// keyframes composition
// =====================

spanim.validTransforms = ['translateX', 'translateY', 'translateZ', 'rotate', 'rotateX', 'rotateY', 'rotateZ', 'scale', 'scaleX', 'scaleY', 'scaleZ', 'skewX', 'skewY', 'perspective'];

spanim.extractRegExp = /-?\d*\.?\d+/g;

spanim.extractStrings = function(value) {
    let t = value.split(spanim.extractRegExp);
    return t;
};

spanim.extractNumbers = function(value) {
    let t = value.match(spanim.extractRegExp).map(Number);
    return t;
};

spanim.sanitize = function(values){
    let t = values.map(value => {
        let string = String(value);
        return string.startsWith("#") ? spanim.rgba(string) : string;
    });
    return t;
};

spanim.addPropertyKeyframes = function(property, values, element) {
    let animatable = spanim.sanitize(values);
    let strings = spanim.extractStrings(spanim.first(animatable));
    let numbers = animatable.map(spanim.extractNumbers);
    let round = spanim.first(strings).startsWith("rgb");
    return {property, strings, numbers, round};
};

spanim.createAnimationKeyFrames = function(keyframes, index, element){
    return Object.entries(keyframes).map(([property, values]) =>
    spanim.addPropertyKeyframes(property, spanim.isFunction(values) ? values(index) : values, element));
};

spanim.getCurrentValue = function(from, to, easing){
    return from + (to - from) * easing;
};

spanim.recomposeValue = function([from, to], strings, round, easing) {
    let tstr = Object.assign([], strings);
    return tstr.reduce(function(style, string, index) {
        let previous = index - 1;
        let value = spanim.getCurrentValue(from[previous], to[previous], easing);
        return style + (round && index < 4 ? Math.round(value) : value) + string;
    });
};

spanim.createStyles = function(keyframes, easing) {
    return keyframes.reduce((styles, {property, numbers, strings, round}) => {
        styles[property] = spanim.recomposeValue(numbers, strings, round, easing);
        return styles;
    }, {});
};

spanim.reverseKeyframes = function(keyframes){
    keyframes.forEach(({numbers}) => numbers.reverse());
};



// animation tracking
// ==================

// animation list
spanim.all = {
    list: [],
    click: [],
    hover: [],
    scroll: [],
    add(object) {
        if (object.event == 'load') {
            this.list.push(object);
            if (this.list.length == 1){
                requestAnimationFrame(spanim.tick);
            }
        }
        if (object.event == 'click') this.click.push(object);
        if (object.event == 'hover') this.hover.push(object);
        if (object.event == 'scroll') this.scroll.push(object);
    }
};

spanim.paused = {};

spanim.trackTime = function(timing, now) {
    if (!timing.startTime) timing.startTime = now;
    timing.elapsed = now - timing.startTime;
};

spanim.resetTime = function(obj) {
    obj.startTime = 0;
};

spanim.getProgress = function({elapsed, duration}) {
    let prog;
    if (duration > 0) prog = Math.min(elapsed / duration, 1);
    else prog = 1;
    return prog;
};

spanim.setSpeed = function(speed, value, index) {
    return speed > 0 ? (spanim.isFunction(value) ? value(index) : value) / speed : 0;
};

// add animation to the list

spanim.addAnimations = function(opts, keyframes, resolve){
    
    let last = {
        totalDuration: -1
    };
    
    opts.elements.forEach( async (elem, index) => {
        let keyframe = spanim.createAnimationKeyFrames(keyframes, index, elem);
        let animation = {
            elem,
            keyframe,
            'loop': opts.loop,
            'direction': opts.direction,
            'duration': spanim.setSpeed(opts.speed, opts.duration, index),
            'event': opts.event,
            'easing': spanim.decomposeEasing(opts.easing),
            'change': opts.change,
        };
        
        if (animation.event == 'scroll') {
            let rect = DOM_Class.GetGlobalRect(animation.elem);
            animation.top = rect.top;
            animation.bottom = rect.bottom;
        }
        
        let animationDelay = spanim.setSpeed(opts.speed, opts.delay, index);
        let totalDuration = animationDelay + animation.duration;
        
        if (animation.direction != 'normal') spanim.reverseKeyframes(keyframe);
        if (animation.direction == 'alternate' && !animation.loop) animation.first = true;
        
        if (totalDuration > last.totalDuration){
            last.animation = animation;
            last.totalDuration = totalDuration;
        }
        
        animation.delay = animationDelay;
        
        if (animationDelay && animation.event == 'load') setTimeout(function(){spanim.all.add(animation);}, animationDelay);
        else spanim.all.add(animation);
        //~ console.log(animation);
    });
    
    let {animation} = last;
    if (!animation) return;
    animation.end = resolve;
    animation.options = opts;
    
    if ( opts.event == ('click' || 'onclick') ) spanim.initClick(opts);
    if ( opts.event == 'hover' ) spanim.initHover(opts);
    //~ console.log(opts);
    if ( opts.event == 'scroll') spanim.initScroll(opts);
};

spanim.delay = function(duration){
    new Promise(resolve => spanim.all.add({
        duration,
        end: resolve
    }));
};

spanim.initClick = function(opts){
    opts.active = false;
    opts.elements.forEach( (elem) => {
        //~ elem.dataset.active = false;
        $_e.AddEvent(elem, EVENTS_Class.EVENT_CLICK, spanim.onClick.bind(opts));
    });
};

spanim.onClick = function(evt){
    if (!this.active) {
        spanim.all.click.forEach( (obj) => {
            this.elements.forEach( (elem) => {
                if (elem == obj.elem) {
                    spanim.resetTime(obj);
                    if (!obj.first) obj.first = true;
                    if (spanim.all.list.length) {
                        if (obj.delay) setTimeout(()=>{spanim.all.list.push(obj);}, obj.delay);
                        else spanim.all.list.push(obj);
                    } else {
                        spanim.all.list.push(obj);
                        if (obj.delay) setTimeout(()=>{requestAnimationFrame(spanim.tick);}, obj.delay);
                        else requestAnimationFrame(spanim.tick);
                    }
                    this.active = true;
                }
            });
        });
    }
};

spanim.initHover = function(opts){
    opts.active = false;
    opts.elements.forEach( (elem) => {
        $_e.AddEvent(elem, EVENTS_Class.EVENT_MOUSEOVER, spanim.onMouseEnter.bind(opts));
        $_e.AddEvent(elem, EVENTS_Class.EVENT_MOUSEOUT, spanim.onMouseLeave.bind(opts));
    });
};

spanim.onMouseEnter = function(evt){
    if (!this.active) {
        spanim.all.hover.forEach( (obj) => {
            this.elements.forEach( (elem) => {
                if (elem == obj.elem) {
                    let tObj = Object.assign({}, obj);
                    tObj.keyframe = JSON.parse(JSON.stringify(obj.keyframe));
                    if (spanim.all.list.length) {
                        spanim.all.list.push(tObj);
                    } else {
                        spanim.all.list.push(tObj);
                        requestAnimationFrame(spanim.tick);
                    }
                }
            });
        });
        this.active = true;
    }
};

spanim.onMouseLeave = function(evt){
    if (spanim.all.list.length) {
        let stop;
        let number;
        spanim.all.list.forEach( (obj) => {
            this.elements.forEach( (elem) => {
                if (elem == obj.elem) {
                    let animatable = obj.elem.style;
                    obj.keyframe.forEach(({property, strings, numbers, round}, index)=>{
                        let nbr = spanim.extractNumbers(animatable[property]);
                        if (strings[0].includes('rgba') && nbr.length < 4) nbr.push(1);
                        numbers[1] = numbers[0];
                        numbers[0] = GENERICS_Class.IsArray(nbr) ? nbr : [Number(nbr)];
                        Object.assign(obj.keyframe[index], {property, strings, numbers, round});
                    });
                    spanim.resetTime(obj);
                    obj.duration = obj.elapsed;
                }
            });
        });
    }
};

spanim.obsconfig = {
            root: null,
            rootMargin: '0px',
            threshold: 0.5
          };

spanim.observer = new IntersectionObserver(spanimonScroll, spanim.obsconfig);

spanim.initScroll = function(opts){
    opts.active = false;
    if ('IntersectionObserver' in window) {
       opts.elements.forEach( (elem) => {
        if ( opts.opacity[0]) {
            elem.style.opacity=opts.opacity[0];
        }
            spanim.observer.observe(elem);
        });
    } else {
        
       spanim.all.scroll.forEach( (obj) => {
            this.elements.forEach( (elem) => {
                    spanim.resetTime(obj);
                    if (!obj.first) obj.first = true;
                    if (spanim.all.list.length) {
                        if (obj.delay) setTimeout(()=>{spanim.all.list.push(obj);}, obj.delay);
                        else spanim.all.list.push(obj);
                    } else {
                        spanim.all.list.push(obj);
                        if (obj.delay) setTimeout(()=>{requestAnimationFrame(spanim.tick);}, obj.delay);
                        else requestAnimationFrame(spanim.tick);
                    }
                    this.active = true;
            });
        });
    }
   
};

function spanimonScroll(changes, observer){
    changes.forEach(change => {
          if (change.intersectionRatio > 0) {
            observer.unobserve(change.target);
            if (!this.active) {
                spanim.all.scroll.forEach( (obj) => {
                        if (change.target == obj.elem) {
                            spanim.resetTime(obj);
                            if (!obj.first) obj.first = true;
                            if (spanim.all.list.length) {
                                if (obj.delay) setTimeout(()=>{spanim.all.list.push(obj);}, obj.delay);
                                else spanim.all.list.push(obj);
                            } else {
                                spanim.all.list.push(obj);
                                if (obj.delay) setTimeout(()=>{requestAnimationFrame(spanim.tick);}, obj.delay);
                                else requestAnimationFrame(spanim.tick);
                            }
                        }
                });
            }
        }
    });
}

spanim.tick = function(now){
    spanim.all.list.forEach( function(opts, index) {
        spanim.trackTime(opts, now);
        let progress;

        progress = spanim.getProgress(opts);

        if (opts.direction) {
            let curve = progress;
            switch (progress) {
                case 0:
                    if (opts.loop) {
                        if (typeof(opts.loop) == 'number') {
                            opts.loop--;
                        }
                    }
                    if (opts.direction == "alternate") spanim.reverseKeyframes(opts.keyframe);
                break;
                case 1:
                    if (opts.loop) {
                        spanim.resetTime(opts);
                        break;
                    }
                    if (opts.direction == 'alternate' && opts.first) {
                        opts.first = false;
                        spanim.resetTime(opts);
                        break;
                    }
                    spanim.all.list.splice(index, 1);
                    if (opts.end) {
                        opts.end(opts.options);
                    }
                    if (opts.options ) {
                        if (opts.options.active) opts.options.active = false;
                        if (opts.options.callback) opts.options.callback(Object.assign({}, opts.options));
                    }
                break;
                default:
                    curve = spanim.ease(opts.easing, progress);
                break;
            }
            if (opts.change && opts.end) opts.change(progress, opts.elem);
            if (opts.elem) Object.assign(opts.elem.style, spanim.createStyles(opts.keyframe, curve));
            return;
        }
        
        // opts is a delay
        if (progress < 1) return;
        spanim.all.list.delete(opts);
        opts.end(opts.duration);
    });

    if (spanim.all.list.length ) requestAnimationFrame(spanim.tick);
};

// stop/start animation when hide/show navigator
document.addEventListener("visibilitychange", () => {
    let now = performance.now();

    if (document.hidden) {
        spanim.paused.time = now;
        spanim.paused.all = spanim.all.list;
        spanim.all.list = [];
        return;
    }

    if (!spanim.paused.all) return;
    let elapsed = now - spanim.paused.time;
    requestAnimationFrame(() =>
        spanim.paused.all.forEach(object => {
            object.startTime += elapsed;
            spanim.all.add(object);
        })
    );
});
/*jshint esversion: 6 */
var UI_Burger = function(){};
UI_Burger.prototype.constructor = UI_Burger;

UI_Burger._prev = null;
UI_Burger._first = false;
UI_Burger._indicators = [];

UI_Burger.init = function(burgerID, menuID){
    if (!this._first){
        this.burger = document.getElementById(burgerID).firstElementChild;
        if (!this.burger) return false;
        $_e.AddEventClick(this.burger, this.Open.bind(this));

        this.overlay = DOM_Class.CreateElement('DIV', {'class': 'burger_public_overlay', 'id': 'burger_public_overlay'});
        DOM_Class.AppendContent(document.body, this.overlay);
        $_e.AddEventClick(this.overlay, this.Close.bind(this));

        this.menu = document.getElementById(menuID);
        if (!this.menu) return false;
        if (this.menu.tagName != 'UL'){
            this.menu = this.menu.firstChild;
        }
        let childs = this.menu.children;
        for (let i = 0; i < childs.length; i++){
            UI_Burger.CreateIndicator(childs[i]);
        }
        this._first = true;
    }
};

UI_Burger.CreateIndicator = function(domElem){
    if (domElem.tagName == 'LI' && domElem.lastElementChild.tagName == 'UL' && domElem.lastElementChild.previousElementSibling.tagName != 'DIV'){
        let indic = DOM_Class.CreateElement('DIV', {'class': 'burger_public_collapse_indicator'}, CONSTANTS.symbols.sign_plus );
        DOM_Class.InsertBefore(indic, domElem.lastElementChild);
        $_e.AddEventClick(indic, this.CollapseIndicator.bind(this));
        this._indicators.push(indic);
        
        // modification left-angle les menu déroulant sont cliquable pour dérouler.
        //~ $_e.AddEventClick(domElem, this.CollapseIndicator.bind(this));
        domElem.firstElementChild.style.pointerEvents = "none";
    }
    if (domElem.tagName == 'LI'){
        let lien = domElem.firstElementChild;
        if (lien.tagName == 'A' && lien.href == CONSTANTS.base_url+'?'){    // cas du lien vide
            $_e.AddEventClick(domElem, this.CollapseIndicator.bind(this));
            //MIS DANS LE Set_hash d'history sinon impossible de gérer ce close sur les liens textes et sous éléments de hierarchie
            //~ if (domElem.lastElementChild.tagName == 'UL'){
                //~ let ul = domElem.lastElementChild;
                //~ for (let i = 0; i < ul.children.length; i++){
                    //~ $_e.AddEventClick(ul.children[i], this.Close.bind(this));
                    //~ $_e.AddEventClick(ul.children[i].firstElementChild, this.Close.bind(this));
                //~ }
            //~ }
        }
        //~ } else {
            //~ $_e.AddEventClick(domElem, this.Close.bind(this));
            //~ $_e.AddEventClick(lien, this.Close.bind(this));
            //~ $_e.AddEventClick(lien.firstElementChild, this.Close.bind(this));
        //~ }
    }
    if (domElem.lastElementChild.tagName == 'UL'){
        let childs = domElem.lastElementChild.children;
        for (let i = 0; i < childs.length; i++){
            UI_Burger.CreateIndicator(childs[i]);
        }
    }
};

UI_Burger.CollapseIndicator = function(evt){
    $_e.StopEvent(evt);
    let target = evt.target;
    //~ console.log(evt);
    //~ console.log(target.className);
    //~ if (!target.classList.contains('burger_public_collapse_indicator')){
        //~ target = target.parentElement.nextElementSibling;
    //~ }
    if (target.tagName == 'LI'){
        target = target.firstElementChild.nextElementSibling;
    }
    if (target){
        if (target.classList.contains('burger_public_collapse_indicator')){
            if (!this._prev) {
                this._prev = {};
                this._prev.dom = target;
                this._prev.childs = Array.from(target.parentElement.parentElement.children);
            }
            DOM_Class.ToggleClass(target, 'burger_public_collapse_indicator_open');
            DOM_Class.ToggleClass(target.nextElementSibling, 'burger_public_show');
            if (target.innerHTML == CONSTANTS.symbols.sign_minus){
                target.innerHTML = CONSTANTS.symbols.sign_plus;
            }else{
                target.innerHTML = CONSTANTS.symbols.sign_minus;
            }
            let parentChild =  Array.from(target.parentElement.parentElement.children);
            if (this._prev.dom != target) {
                if (this._prev.childs.length === parentChild.length && this._prev.childs.every(function(v,i) { return v === parentChild[i];})){
                    DOM_Class.ToggleClass(this._prev.dom, 'burger_public_collapse_indicator_open', false);
                    DOM_Class.ToggleClass(this._prev.dom.nextElementSibling, 'burger_public_show', false);
                    if (this._prev.dom.innerHTML == CONSTANTS.symbols.sign_minus){
                        this._prev.dom.innerHTML = CONSTANTS.symbols.sign_plus;
                    }
                }
                this._prev.dom = target;
                this._prev.childs =  Array.from(target.parentElement.parentElement.children);
            }
        }
    }
};

UI_Burger.Open = function(evt){
    //~ console.log('evt');
    DOM_Class.ToggleClass(this.menu, 'burger_public_show');
    DOM_Class.ToggleClass(this.burger, 'burger_public_croix');
    DOM_Class.ToggleClass(this.overlay, 'burger_public_overlay_show');
    this._indicators.forEach(function(elem){
        DOM_Class.ToggleClass(elem, 'burger_public_show_indic');
    });
    if (document.body.style.overflow != 'hidden'){
        document.body.style.overflow = 'hidden';
    }else{
        document.body.style.overflow = 'auto';
    }
    window.scrollTo(0, 0);
};

UI_Burger.Close = function(evt){
    //~ console.log(evt);
    if (this.burger && this.menu && this.overlay){
        DOM_Class.ToggleClass(this.menu, 'burger_public_show', false);
        DOM_Class.ToggleClass(this.burger, 'burger_public_croix', false);
        DOM_Class.ToggleClass(this.overlay, 'burger_public_overlay_show', false);
        this._indicators.forEach(function(elem){
            DOM_Class.ToggleClass(elem, 'burger_public_show_indic', false);
        });
        document.body.style.overflow = 'unset';
    }
};
var filemanager_movedSelection = false;
var filemanager_lastSelection = 0;
var filemanager_clipBoard = false;
var filemanager_clipBoardType = false;
var filemanager_translation = false;
var filemanager_context_menu = [];
var trees = {};
var filemanager_timer_modal = false;
var Filemanager = function(domId,rootAcess,callback,callbackParam){
    var self = this;
    // url of the module
    var url = CONSTANTS.base_url + 'public/filemanager/index.php';
    // shortcut settings for ajax call
    var setts = {
        'url': url,
        'skip_container': true,
        'dom_container': ''
    };
    // the tree domId, when there is multiple tree on the page
    this.domId = domId;
    
    // owner and admin can do action on root path directly, others can't.
    this.can_access_root = rootAcess ? true : false;
    
    this.mouse_is_over = false;
    
    this.sort = false;
    this.lastSort = false;
    
    // current path loaded
    //~ var current_path = '';
    
    /* current mode :
     * - 1 : mode tree, multiple level of folder at once
     * - 2 : mode simple, one level of folder at once */
    this.current_mode = 1;
    
    /* display mode :
     * - 1 : normal, detail
     * - 2 : vignette, available only for mode simple */
    this.display_mode = 1;
    
    // previous mouseover
    this.previous_mouseover = false;
    
    // current selection
    this.selection = [];
    this.last_selected = false;
    // for touch only, indicates if we are in a multiple selection or not
    this.selection_multiple = false;
    this.selection_square = {x1:0, y1:0, x2:0, y2:0};
    this.selection_square_active = false;
    
    // list of file droped for upload
    this.parsing,this.droped_files = [],this.droped_files_path = [];
    this.uploadReadingFile = [],this.uploadDirectoryList = [];
    
    // when from context menu, current_taget_action is the element where right click was pressed
    // otherwise it depends of the selection and the type of action
    this.current_target_action = false;
    
    this.opened_items = {};
    
    this.DOM_container = document.getElementById('tree_ui_' + this.domId);
    // get all domElements needed (controls button)
    this.DOM_h_back = document.getElementById('tree_history_back_' + this.domId);
    this.DOM_h_next = document.getElementById('tree_history_next_' + this.domId);
    // corbeille
    this.DOM_corbeille = document.getElementById('tree_actions_corbeille_' + this.domId);
    
    this.DOM_btn = document.getElementById('tree_path_btn_' + this.domId);
    this.DOM_inp = document.getElementById('tree_path_inp_' + this.domId);
    // the whole container, to apply the onMouseOutside and remove selection
    this.DOM_panel = document.getElementById('tree_panel_' + this.domId);
    this.DOM_square = document.getElementById('tree_square_' + this.domId);
    
    // for mobile only, toggle the multiple selected mode
    this.DOM_multiple_selection = document.getElementById('tree_multiple_selection_' + this.domId);
    
    // avatar
    this.DOM_avatar = document.getElementById('tree_avatar_' + this.domId);
    
    this.DOM_actions = document.getElementById('tree_actions_on_path_' + this.domId);
    this.DOM_actions_bin = document.getElementById('tree_actions_bin_' + this.domId);
    DOM_Class.AddClass(self.DOM_actions_bin, 'hidden');
    
    this.DOM_mkdir = document.getElementById('tree_mkdir_' + this.domId);
    // this.DOM_mkdir_inp,DOM_mkdir_btn;
    // download 
    this.DOM_download = document.getElementById('tree_download_' + this.domId);
    this.DOM_upload = document.getElementById('tree_upload_' + this.domId);
    // rename 
    this.DOM_rename = document.getElementById('tree_rename_' + this.domId);
    // remove
    this.DOM_remove = document.getElementById('tree_remove_' + this.domId);
    // copy
    this.DOM_copy = document.getElementById('tree_copy_' + this.domId);
    // paste
    this.DOM_paste = document.getElementById('tree_paste_' + this.domId);
    this.DOM_proxy = document.getElementById('tree_proxy_' + this.domId);
    this.DOM_unpack = document.getElementById('tree_unpack_' + this.domId);
    this.DOM_pack = document.getElementById('tree_pack_' + this.domId);
    this.DOM_share = document.getElementById('tree_share_' + this.domId);
    this.DOM_link = document.getElementById('tree_link_' + this.domId);
    
    this.DOM_restore = document.getElementById('tree_restore_' + this.domId);
    this.DOM_delete = document.getElementById('tree_delete_' + this.domId);
    
    this.DOM_path_container = document.getElementById('tree_path_parts_' + this.domId);
    this.DOM_path_first = document.getElementById('tree_path_part_0_' + this.domId);
    this.DOM_path_last;
    this.DOM_refresh = document.getElementById('tree_path_refresh_' + this.domId);
    
    // search
    this.DOM_btn_search = document.getElementById('tree_search_btn_' + this.domId);
    this.DOM_container_search = document.getElementById('tree_actions_search_' + this.domId);
    this.DOM_inp_search = document.getElementById('tree_search_inp_' + this.domId);
    this.DOM_send_search = document.getElementById('tree_send_search_btn_' + this.domId);
    
    // btns mode
    this.DOM_mode_tree = document.getElementById('tree_mode_tree_' + this.domId);
    this.DOM_mode_vignet = document.getElementById('tree_mode_vignet_' + this.domId);
    this.DOM_mode_list = document.getElementById('tree_mode_list_' + this.domId);
    this.DOM_mode_chat = document.getElementById('tree_mode_chat_' + this.domId);
    this.DOM_header = document.getElementById('tree_header_' + this.domId);
    
    // list btns that need a selection to be active
    this.btns_with_selections = [this.DOM_download,this.DOM_rename,this.DOM_remove,this.DOM_copy,this.DOM_pack,this.DOM_restore];
    if (this.DOM_share) this.btns_with_selections.push(this.DOM_share);
    if (this.DOM_delete) this.btns_with_selections.push(this.DOM_delete);
    this.cntxMenu;
    
    function init(){
        // initialise modal that will be used by this module.
        // there is some special action when hiding/displaying the modale
        if (!UI_Class.popupSpecial.filemanager){
            
            UI_Class.popupSpecial['filemanager'] = UI_Class.AddWindow(document.body, {'nodrag': false, 'hidden': true, 'modal': true, 'class': 'ui_window special filemanager', 'special':true, 'special_level': 1, 'close': 'x'});
            UI_Class.popupSpecial['filemanager'].domElement.setAttribute('id', 'popup_special_filemanager');
            UI_Class.popupSpecial['filemanager'].dom_panel = self.DOM_panel;
            
            UI_Class.popupSpecial['filemanager'].Hide = function(){
                if (this.visible){
                    if(this._modal){
                        this._modalMask.classList.toggle('hidden',true);
                    }
                    this.domElement.classList.toggle('hidden',true);
                    $_e.AddEventClickOutside(this.dom_panel,onClickOutsidePanel);
                }

                let disableKeyPressEvent = true;
                for (let index = 0; index < UI_Class.modalKeyDownHandler.length; index++) {
                    let obj = UI_Class.modalKeyDownHandler[index];
                    if (obj && obj.visible){
                        disableKeyPressEvent = false;
                        break;
                    }
                }
                if (disableKeyPressEvent){
                    $_e.RemoveEventKey(document, this.onKeyPress);
                }
            };
            
            UI_Class.popupSpecial['filemanager'].Show = function(){
                if(this._modal){
                    this._modalMask.classList.toggle('hidden',false);
                }
                this.domElement.classList.toggle('hidden',false);
                $_e.AddEventKey(document, this.onKeyPress);
                //~ if (!$_e.HasEventCallback(window,'keydown',this.onKeyPress)){
                    //~ $_e.AddEvent(window,'keydown',this.onKeyPress);
                //~ }
                $_e.RemoveEvent(this.dom_panel,$_e.EVENT_MOUSEDOWN_OUTSIDE);
                
                DOM_Class.SetAlignment(this.domElement, 0.5, 0.5);
            };
            
            //~ UI_Class.popupSpecial['filemanager'].Hide();
        } else {
            UI_Class.popupSpecial['filemanager'].dom_panel = self.DOM_panel;
        }
        
        
        // deactivate mousedown outside event on the panel to keep the selection when clicking on modal
        //~ $_e.RemoveEvent(self.DOM_panel,$_e.EVENT_MOUSEDOWN_OUTSIDE);
        // init mode
        initContextMenu();
        initActions();
        
        toggleTreeMode();
        toggleDisplayMode();
        
        self.history.reset();
        self.history.add(self.DOM_inp.value);
        
        toggleButtonsBySelection();
        
        // first load, the first is always the last
        self.DOM_path_last = self.DOM_path_first;
    }
    
    this.entries = [];
    // init event on list elem, when loading a tree or a part of the tree
    this.initList = function(ids, addToEntriesArray = true){
        if (self.modeCorbeille){
            disableCorbeilleMode();
        }
        if (ids){
            if (self.current_mode != 1) self.entries = [];
            let elem;
            ids.forEach((id)=>{
                elem = document.getElementById(id);
                if(elem){
                    addEventsOnItem(elem);
                    
                    if (addToEntriesArray){
                        let info = parseInfoElem(elem);
                        // if (info.level == 0){
                            let obj = {
                                'domElem': elem,
                                'name': elem.dataset.name.toLowerCase(),
                                'date': elem.dataset.date,
                                'size': (elem.dataset.size) ? elem.dataset.size : 0,
                                'id': elem.id,
                                'type': elem.dataset.type,
                                'html': elem.outerHTML,
                                'level': info.level
                            };
                            self.entries.push(obj);
                        // }
                    }
                }
            });

            if(elem){
                let parent = elem.parentElement;
                EVENTS_Class.EnableDrag(parent, onSelectionSquareStart, onSelectionSquareMove, onSelectionSquareEnd);
                if (self.can_access_root && !$_e.HasDrop(parent)) $_e.EnableDrop(parent, onDropElem);
            }

            if (self.can_access_root){
                Filemanager_displaySharedState(ids, true);
            }
            
            if (self.display_mode == 2){
                loadVignet();
            }
        }
    };
    function addEventsOnItem(item){
        $_e.AddEventClick(item, onClickSelectable);
        // double click, open
        $_e.AddEventDblClick(item, toggle);
        if (!$_e.HasDrag(item)) $_e.EnableDrag(item, onDragItemStart, onDragItemMove, onDragItemEnd);
        if (!$_e.HasDrop(item)) $_e.EnableDrop(item, onDropElem);
        $_e.AddEvent(item, 'dragover', overDropItem);
        
        // context menu
        $_e.AddEvent(item, 'contextmenu', openCntxMenu);
    }
    // init items after search
    this.initSearch = function(ids){
        if (self.modeCorbeille){
            
            disableCorbeilleMode();
            
            initActions();
            
            self.modeCorbeille = false;
        }
        if (ids){
            ids.forEach((id)=>{
                let item = document.getElementById(id);
                $_e.AddEventClick(item,onClickSelectable);
                $_e.EnableDrag(item, onDragItemStart, onDragItemMove, onDragItemEnd);
                $_e.AddEventDblClick(item, toggle);
            });
        }
    };
    // add events on controls button (history, path change, refresh...)
    function initActions(){
        // actions inside the test are executed one time when opening the module
        // others are executed after a bin display to reenable some action that are disabled for bin mode
        if (!self.modeCorbeille){
            // btn change path
            $_e.AddEventClick(self.DOM_btn, changeTreePath);
            
            // detect if the mouse is on this filemanager
            $_e.AddEvent(self.DOM_panel, 'mouseenter', (evt)=>{entering(evt,false);});
            $_e.AddEvent(self.DOM_panel, 'mouseleave', (evt)=>{outering(evt,false);});
            
            if (self.can_access_root){
                $_e.AddEvent(self.DOM_panel, 'contextmenu', openCntxMenu);
                $_e.AddEvent(self.DOM_container, 'contextmenu', openCntxMenu);
                let firstUL = document.getElementById('tree_' + self.domId + '_parent');
                if (firstUL) $_e.AddEvent(firstUL, 'contextmenu', openCntxMenu);
            }
            
            // btns menu action on top
            $_e.AddEventClick(self.DOM_mkdir, modalNewDirectory);
            $_e.AddEventClick(self.DOM_upload, modalUpload);
            $_e.AddEventClick(self.DOM_download, download);
            $_e.AddEventClick(self.DOM_rename, modalRename);
            $_e.AddEventClick(self.DOM_remove, onClickDelete);
            $_e.AddEventClick(self.DOM_copy, onClickCopy);
            $_e.AddEventClick(self.DOM_paste, onClickPaste);
            $_e.AddEventClick(self.DOM_proxy, modalProxy);
            if (self.DOM_share) $_e.AddEventClick(self.DOM_share, modalShare);
            if (self.DOM_link) $_e.AddEventClick(self.DOM_link, modalLink);
            
            // to remove selection when not clicking on an item
            $_e.AddEventClick(self.DOM_container, onClickOutsidePanel);
            $_e.AddEventClick(self.DOM_panel, onClickOutsidePanel);
            $_e.AddEventClickOutside(self.DOM_panel, onClickOutsidePanel);
            
            // clean previous outside events, it's still alive because of events class.....
            if (EVENTS_Class.outsideEvents[EVENTS_Class.EVENT_MOUSEDOWN_OUTSIDE]){
                EVENTS_Class.outsideEvents[EVENTS_Class.EVENT_MOUSEDOWN_OUTSIDE].forEach((domElem,index)=>{
                    if (!document.body.contains(domElem)){
                        EVENTS_Class.outsideEvents[EVENTS_Class.EVENT_MOUSEDOWN_OUTSIDE].splice(index,1);
                    }
                });
            }
            
            // add keydown event, for delete, open, etc...
            $_e.AddEventKey(document, onKeyDown);
            
            /*
             * For touch only,
             * all simple click on selectable item that are normally classic click
             * are considered like Ctrl + click
             */
            $_e.AddEventClick(self.DOM_multiple_selection, toggleMultipleSelection);
            
            // btns mode
            $_e.AddEventClick(self.DOM_mode_tree,modeTree);
            $_e.AddEventClick(self.DOM_mode_vignet,modeVignet);
            $_e.AddEventClick(self.DOM_mode_list,modeList);
            $_e.AddEventClick(self.DOM_mode_chat,switchConversationFilemanager);
            
            // btn history forward
            $_e.AddEventClick(self.DOM_h_back, self.history.back);
            $_e.AddEventClick(self.DOM_h_next, self.history.next);
            
            // corbeille
            if (self.DOM_corbeille) $_e.AddEventClick(self.DOM_corbeille, openCorbeille);
            
            // path
            // $_e.AddEventDblClick(self.DOM_path_container, displayInputPath);
            $_e.AddEventClick(self.DOM_path_first, onClickPathElem);
            // path refresh
            $_e.AddEventClick(self.DOM_refresh, self.refresh);
            
            // search
            $_e.AddEventClick(self.DOM_btn_search, openSearch);
            $_e.AddEventKey(self.DOM_inp_search,(event)=>{
                if (event.key == 'Enter') onClickSearch(event);
                return false;
            });
            $_e.AddEventClick(self.DOM_send_search, onClickSearch);
            
            // header for sort, firstChild is container div of item
            for(let i = 0; i < self.DOM_header.firstChild.children.length; i++){
                let itemHeader = self.DOM_header.firstChild.children[i];
                $_e.AddEventClick(itemHeader, onClickSort);
            }
        }
        
        self.sort = false;
        
        // drop for upload
        // if (self.can_access_root){
            $_e.EnableDrop(self.DOM_panel, onDropElem);
            $_e.EnableDrop(self.DOM_container, onDropElem);
            $_e.AddEvent(self.DOM_container, 'dragover', overDropItem);
        // } else {
        //     // $_e.EnableDrop(self.DOM_panel, );
        //     // $_e.EnableDrop(self.DOM_container, onDropElem);
        // }
        
        // selection square, the square doesn't work on touch, add a long press detection that activate the square for touch
        EVENTS_Class.EnableDrag(self.DOM_container, onSelectionSquareStart, onSelectionSquareMove, onSelectionSquareEnd);
        
        // the HOME button of path
        if (self.can_access_root){
            if (!$_e.HasDrop(self.DOM_path_first)){
                $_e.EnableDrop(self.DOM_path_first, onDropElem);
            }
            $_e.AddEvent(self.DOM_path_first, 'contextmenu', openCntxMenu);
            $_e.AddEvent(self.DOM_path_first, 'dragover', overDropItem);
        }
    }
    function openCntxMenu(event){
        if (!self.modeCorbeille){
            self.cntxMenu.open(event);
        } else {
            $_e.StopEvent(event);
            return false;
        }
    }
    function modeTree(evt){
        self.current_mode = 1;
        self.display_mode = 1;
        toggleTreeMode();
        toggleDisplayMode();
        
        if (self.observerScroll) {
            self.observerScroll.disconnect();
            self.observerScroll = false;
        }
    }
    
    this.observerScroll = false;
    this.observerList = [];
    function modeVignet(evt){
        self.current_mode = 2;
        self.display_mode = 2;
        toggleTreeMode();
        toggleDisplayMode();
        
        // load vignet for image and video
        if (!self.observerScroll) self.observerScroll = new IntersectionObserver(handleIntersect, {'root': self.DOM_container});
        loadVignet();
    }
    function modeList(evt){
        self.current_mode = 2;
        self.display_mode = 1;
        toggleTreeMode();
        toggleDisplayMode();
        
        if (self.observerScroll) {
            self.observerScroll.disconnect();
            self.observerScroll = false;
        }
    }
    
    //~ function switchDisplay(evt){
        //~ self.display_mode++;
        //~ if (self.current_mode == 1 && self.display_mode > 2 || self.display_mode > 3) self.display_mode = 1;
        //~ toggleDisplayMode();
    //~ }
    function toggleDisplayMode(){
        // change hidden class on elems        
        switch (self.display_mode){
            //~ case 1:
                //~ DOM_Class.ToggleClass(self.DOM_panel, 'disp_list', true);
                //~ DOM_Class.ToggleClass(self.DOM_panel, 'disp_detail', false);
                //~ DOM_Class.ToggleClass(self.DOM_panel, 'disp_vignet', false);
            //~ break;
            case 1:
                //~ DOM_Class.ToggleClass(self.DOM_panel, 'disp_list', false);
                DOM_Class.ToggleClass(self.DOM_panel, 'disp_detail', true);
                DOM_Class.ToggleClass(self.DOM_panel, 'disp_vignet', false);
            break;
            case 2:
                //~ DOM_Class.ToggleClass(self.DOM_panel, 'disp_list', false);
                DOM_Class.ToggleClass(self.DOM_panel, 'disp_detail', false);
                DOM_Class.ToggleClass(self.DOM_panel, 'disp_vignet', true);
            break;
        }
    }
    //~ function switchTreeMode(evt){
        //~ self.current_mode = (self.current_mode == 1) ? 2 : 1;
        
        //~ toggleTreeMode();
        //~ selectionReset();
    //~ }
    function toggleTreeMode(){
        if (self.current_mode == 1){ // tree
            // hide path and history stuff
            //~ DOM_Class.ToggleClass(self.DOM_h_back,'hidden',true);
            //~ DOM_Class.ToggleClass(self.DOM_h_next,'hidden',true);
            //~ DOM_Class.ToggleClass(DOM_folder_back,'hidden',true);
            //~ DOM_Class.ToggleClass(self.DOM_btn,'hidden',true);
            //~ DOM_Class.ToggleClass(self.DOM_inp,'hidden',true);
        } else { // classic
            //~ DOM_Class.ToggleClass(self.DOM_h_back,'hidden',false);
            //~ DOM_Class.ToggleClass(self.DOM_h_next,'hidden',false);
            //~ DOM_Class.ToggleClass(DOM_folder_back,'hidden',false);
            //~ DOM_Class.ToggleClass(self.DOM_btn,'hidden',false);
            //~ DOM_Class.ToggleClass(self.DOM_inp,'hidden',false);
            
            // hide all opened
            let clean = [];
            for (let id in self.opened_items){
                DOM_Class.RemoveClass(self.opened_items[id], 'opened');
                DOM_Class.AddClass(self.opened_items[id], 'closed');
                clean.push(id);
                self.updateEntry(self.opened_items[id]);
            }
            clean.forEach(key=>{delete(self.opened_items[key]);});
            

            // entries = [];
            //~ let lstOpened = getOpenedItems(false,true);
            //~ lstOpened.forEach((domElem)=>{
                //~ DOM_Class.RemoveClass(domElem, 'opened');
                //~ DOM_Class.AddClass(domElem, 'closed');
                //~ DOM_Class.ToggleClass(item,'opened',false);
                //~ DOM_Class.ToggleClass(item,'closed',true);
            //~ });
        }
    }
    function onClickPathElem(evt){
        let targ = evt.target;
        let newPath = (targ.dataset.path != '') ? targ.dataset.path : '/';
        if (self.history.lst[self.history.current] == newPath){
            // refresh
            changeTreePath(evt,true);
        } else {
            // change path
            self.DOM_inp.value = targ.dataset.path;
            $_e.SendEventClick(self.DOM_btn);
        }
        
    }
    function onClickSelectable(evt){
        $_e.StopEvent(evt);
        
        let targ = getParentItem(evt.target);
        if (!targ){
            return false;
        }
        
        // first test is ctrl because if user press both ctrl and shift we want to add the element
        let normal_click = true;
        if (evt.ctrlKey || self.selection_multiple){
            // ctrl + click, add to selection
            normal_click = false;
            selectionToggle(targ);
        } else if (evt.shiftKey){
            // shift + click, add range to selection
            if (GENERICS_Class.IsDomObject(self.last_selected) && self.last_selected != targ){
                // detect range only if there is a previous selected item and not the same one
                let parentLast = self.last_selected.parentElement;
                let parentCur = targ.parentElement;
                if (parentLast == parentCur){
                    // Can select a range only if they have the same parent
                    normal_click = false;
                    //~ let in_range = false;
                    let parentArray = Array.from(parentCur.children);
                    let index_prev = parentArray.indexOf(self.last_selected);
                    let index_cur = parentArray.indexOf(targ);
                    // detect the range direction, it can be to the top or to the bottom
                    // do not add the first one because it's already in the selection
                    if (index_prev < index_cur){
                        // to to the bottom
                        for (let i = index_prev+1; i <= index_cur; i++){
                            selectionAdd(parentArray[i]);
                        }
                    } else {
                        // to the top
                        for (let i = index_prev-1; i >= index_cur; i--){
                            selectionAdd(parentArray[i]);
                        }
                    }
                    toggleButtonsBySelection();
                }
            }
        }
        
        if (normal_click){
            // normal click, new selection
            if ((GENERICS_Class.IsDomObject(self.last_selected) && self.last_selected != targ) || !self.last_selected){
                selectionReset(targ);
            } else {
                selectionReset();
            }
        }
    }
    function onClickOutsidePanel(evt){
        let reset = true;
        for (var domId in trees) {
            if (self.domId != trees[domId].domId){
                if (DOM_Class.PointInsideElement(evt.pageX,evt.pageY,trees[domId].DOM_panel)){
                    reset = false;
                }
            }
            if (trees[domId].modeCorbeille){
                if (trees[domId].cntx_menu_bin && DOM_Class.PointInsideElement(evt.pageX,evt.pageY,trees[domId].cntx_menu_bin.content)){
                    reset = false;
                }
            } else if (trees[domId].cntxMenu && DOM_Class.PointInsideElement(evt.pageX,evt.pageY,trees[domId].cntxMenu.content)){
                reset = false;
            }
        }
        if (reset) selectionReset();
        // if (trees.length > 1){
        //     // detect if click on an other filemanager and do not remove selection if it's the case
        //     // otherwise it will be hard to do some file manipulation
        //     for (var key in trees) {
        //         if (self.domId != trees[key].domId){
        //             if (DOM_Class.PointInsideElement(evt.pageX,evt.pageY,trees[key].self.DOM_panel)){
        //                 reset = false;
        //             }
        //         }
        //     }
        // }
        // // if click on contextmenu, do not reset
        // if (filemanager_context_menu[self.domId] && DOM_Class.PointInsideElement(evt.pageX,evt.pageY,filemanager_context_menu[self.domId].domElement)){
        //     reset = false;
        // }
        // if (reset) selectionReset();
    }
    
    // return an array of items from an array, if no array passed, used the current selection
    function getItems(array=false){
        let items = [];
        if (!array){
            array = self.selection;
        }
        array.forEach((elem)=>{
            // send the id for the return
            if (elem.dataset.bin){
                items.push({
                    'id': elem.id.split('-')[1],
                    'type': elem.dataset.type,
                    'bin': elem.dataset.bin
                });
            } else if (elem.dataset.type == 'sequence'){
                items.push({
                    'id': elem.id.split('-')[1],
                    'path': elem.dataset.path,
                    'sequence-name': elem.dataset.name,
                    'type': elem.dataset.type,
                    'total': elem.dataset.total
                });
            } else {
                items.push({
                    'id': elem.id.split('-')[1],
                    'path': elem.dataset.path,
                    'type': elem.dataset.type
                });
            }
        });
        return items;
    }
    function toggleButtonsBySelection(){

        if (self.selection.length == 0){
            self.btns_with_selections.forEach(btn => {
                btn.disabled = true;
                DOM_Class.AddClass(btn, 'icon_disable');
            });
        } else {
            self.btns_with_selections.forEach(btn => {
                btn.disabled = false;
                DOM_Class.RemoveClass(btn, 'icon_disable');
            });
        }
        
        // proxy
        if (self.selection.length == 1 && self.selection[0].dataset && self.selection[0].dataset.proxy == 1){
            DOM_Class.RemoveClass(self.DOM_proxy, 'hidden');
            if (self.DOM_proxy_cntx) DOM_Class.RemoveClass(self.DOM_proxy_cntx, 'hidden');
        } else {
            DOM_Class.AddClass(self.DOM_proxy, 'hidden');
            if (self.DOM_proxy_cntx) DOM_Class.AddClass(self.DOM_proxy_cntx, 'hidden');
        }
        
        // pack / unpack
        if (self.selection.length == 1 && self.selection[0].dataset && self.selection[0].dataset.type == 'archive'){
            DOM_Class.RemoveClass(self.DOM_unpack, 'hidden');
            if (self.DOM_unpack_cntx) DOM_Class.RemoveClass(self.DOM_unpack_cntx, 'hidden');
            DOM_Class.AddClass(self.DOM_pack, 'hidden');
            if (self.DOM_pack_cntx) DOM_Class.AddClass(self.DOM_pack_cntx, 'hidden');
        } else {
            DOM_Class.AddClass(self.DOM_unpack, 'hidden');
            if (self.DOM_unpack_cntx) DOM_Class.AddClass(self.DOM_unpack_cntx, 'hidden');
            DOM_Class.RemoveClass(self.DOM_pack, 'hidden');
            if (self.DOM_pack_cntx) DOM_Class.RemoveClass(self.DOM_pack_cntx, 'hidden');
        }
        
        // external link
        if (self.selection.length == 1 && self.selection[0].dataset && self.selection[0].dataset.type != 'folder' && self.selection[0].dataset.type != 'sequence'){
            DOM_Class.RemoveClass(self.DOM_link, 'hidden');
            if (self.DOM_link_cntx) DOM_Class.RemoveClass(self.DOM_link_cntx, 'hidden');
        } else {
            DOM_Class.AddClass(self.DOM_link, 'hidden');
            if (self.DOM_link_cntx) DOM_Class.AddClass(self.DOM_link_cntx, 'hidden');
        }

        // sharing, can't open it for sequence
        if (self.DOM_share && self.selection.length == 1 && self.selection[0].dataset && self.selection[0].dataset.type == 'sequence'){
            DOM_Class.AddClass(self.DOM_share, 'hidden');
            if (self.DOM_share_ctnx) DOM_Class.AddClass(self.DOM_share_ctnx, 'hidden');
        } else if (self.DOM_share){
            DOM_Class.RemoveClass(self.DOM_share, 'hidden');
            if (self.DOM_share_ctnx) DOM_Class.RemoveClass(self.DOM_share_ctnx, 'hidden');
        }
        // case of the paste button, disabled by default but
        // if there is something in clipboard have to enable it
        // depending if the selection is plural in tree mode
        //~ if (filemanager_clipBoard !== false) {
            //~ if (self.DOM_paste.disabled){
                //~ self.DOM_paste.disabled = false;
                //~ DOM_Class.RemoveClass(self.DOM_paste, 'icon_disable');
                
                //~ if (DOM_paste_cntx){
                    //~ DOM_paste_cntx.disabled = false;
                    //~ DOM_Class.RemoveClass(DOM_paste_cntx, 'icon_disable');
                //~ }
            //~ }
        //~ } else if (!self.DOM_paste.disabled) {
            //~ self.DOM_paste.disabled = true;
            //~ DOM_Class.AddClass(self.DOM_paste, 'icon_disable');
            
            //~ if (DOM_paste_cntx){
                //~ DOM_paste_cntx.disabled = true;
                //~ DOM_Class.AddClass(DOM_paste_cntx, 'icon_disable');
            //~ }
        //~ }
    }
    // reset selection
    function selectionReset(elem){
        // remove class on each elem from previous selection
        self.selection.forEach((domElem)=>{
            DOM_Class.ToggleClass(domElem,'selected',false);
            self.updateEntry(domElem);
        });
        self.selection = [];
        self.last_selected = false;
        if (elem && GENERICS_Class.IsDomObject(elem)){
            // start a new selection with elem
            selectionToggle(elem);
        } else {
            toggleButtonsBySelection();
        }
    }
    // add or remove from selection
    function selectionToggle(domElem){
        if (self.selection.indexOf(domElem) == -1){
            // add
            selectionAdd(domElem);
        } else {
            // remove
            selectionRemove(domElem);
        }
        
        toggleButtonsBySelection();
    }
    // on tree mode, if the item is opened, select all the child
    function selectionAdd(domElem){
        DOM_Class.ToggleClass(domElem,'selected',true);
        DOM_Class.ToggleClass(domElem,'last',true);
        // remove last class from last_selected
        DOM_Class.ToggleClass(self.last_selected,'last',false);
        self.selection.push(domElem);
        self.updateEntry(domElem);
        self.updateEntry(self.last_selected);
        // disable / enable some buttons when unique selection or multi selection
        if (self.selection.length == 1){
            DOM_Class.ToggleClass(self.DOM_rename,'disable',false);
        } else {
            DOM_Class.ToggleClass(self.DOM_rename,'disable',true);
        }
        
        self.last_selected = domElem;
        if (self.current_mode == 1){
            
            let firstUL = document.getElementById('tree_'+self.domId+'_parent');
            
            // check all parent and remove them from selection if they are selected
            let parent = domElem.parentElement; // parent = UL
            while (firstUL != parent){ // compare with first UL of the tree
                parent = parent.parentElement; // parent = LI
                if (self.selection.indexOf(parent) > -1){
                    selectionRemove(parent);
                }
                parent = parent.parentElement; // parent = UL
            }
            
            // check all child and remove them from selection if they are selected
            selectionRemoveChild(domElem);
        }
        filemanager_lastSelection = self.domId;
    }
    this.getSelection = function(){
        return self.selection;
    };
    
    function selectionRemoveChild(domElem){
        // only if they are loaded
        if (domElem.dataset.loaded == 1){
            let ul = domElem.lastElementChild;
            if (ul.children.length > 0){
                Array.from(ul.children).forEach((child)=>{
                    if (self.selection.indexOf(child) > -1){
                        selectionRemove(child);
                    } else {
                        selectionRemoveChild(child);
                    }
                });
            }
        }
    }
    function selectionRemove(domElem){
        DOM_Class.ToggleClass(domElem,'selected',false);
        DOM_Class.ToggleClass(domElem,'last',false);
        self.selection.splice(self.selection.indexOf(domElem),1);
        if (self.last_selected == domElem){
            // put the last element of the array as last selected or false if nothing in array
            self.last_selected = (self.selection.length > 0) ? self.selection[self.selection.length-1] : false;
            DOM_Class.ToggleClass(self.last_selected,'last',true);
            self.updateEntry(self.last_selected);
        }
        
        self.updateEntry(domElem);
        // disable / enable some buttons when unique selection or multi selection
        if (self.selection.length == 1){
            DOM_Class.ToggleClass(self.DOM_rename,'disable',false);
            DOM_Class.ToggleClass(self.DOM_link,'disable',false);
        } else {
            DOM_Class.ToggleClass(self.DOM_rename,'disable',true);
            DOM_Class.ToggleClass(self.DOM_link,'disable',true);
        }
        
        //~ toggleButtonsBySelection();
    }
    /*
     * For touch only, 
     * all simple click on selectable item that are normally classic click
     * are considered like Ctrl + click
     */
    function toggleMultipleSelection(evt){
        if (self.selection_multiple){
            self.selection_multiple = false;
            self.DOM_multiple_selection.textContent = 'multiple selection: off';
        } else {
            self.selection_multiple = true;
            self.DOM_multiple_selection.textContent = 'multiple selection: on';
        }
    }
    
    /*
     * Functions that manage the selection by square
     */
    function onSelectionSquareStart(evt){
        // console.log(evt);
        // console.log(evt.originalTarget);
        if (evt.originalTarget != evt.target && evt.originalTarget !== undefined){
            // click on the scroll bar, do nothing
            return false;
        }
        if (!self.DOM_square){
            self.DOM_square = document.getElementById('tree_square_'+self.domId);
        }
        self.selection_square_active = true;
        self.selection_square.x1 = evt.pageX || evt.touches[0].pageX;
        self.selection_square.y1 = evt.pageY || evt.touches[0].pageY;
        calcSquare();
        DOM_Class.ToggleClass(self.DOM_square,'hidden',false);
    }
    function onSelectionSquareMove(evt){
        // console.log(evt);
        if (!self.selection_square_active){
            return;
        }
        self.selection_square.x2 = evt.pageX || evt.touches[0].pageX;
        self.selection_square.y2 = evt.pageY || evt.touches[0].pageY;
        calcSquare();
    }
    function onSelectionSquareEnd(evt){
        if (!self.selection_square_active){
            return;
        }
        calcSquare(true);
        self.selection_square_active = false;
        DOM_Class.ToggleClass(self.DOM_square,'hidden',true);
        // need to detect all the item that are positionned under the square
        // solution 1 : parse every item visible and check if they are under
        if (!evt.shiftKey && !evt.ctrlKey) selectionReset(); // reset selection if both CTRL and SHIFT are not pressed
        self.entries.forEach((item)=>{
            // detect if it's visible by checking the offset parent
            if (item.domElem.offsetParent !== null){
                let div = item.domElem.firstElementChild;
                let rect = DOM_Class.GetGlobalRect(div,true);
                // check if it's inside the rect on x axis
                let x = false;
                let y = false;
                if (rect.top <= self.selection_square.y1 && rect.bottom >= self.selection_square.y1 || rect.top >=  self.selection_square.y1 && rect.bottom >= self.selection_square.y1 && rect.top <= self.selection_square.y2){
                    y = true;
                }
                if (rect.left <= self.selection_square.x1 && rect.right >= self.selection_square.x1 || rect.left >=  self.selection_square.x1 && rect.right >= self.selection_square.x1 && rect.left <= self.selection_square.x2){
                    x = true;
                }
                // check if the rect is under both axis
                if (x && y){
                    selectionAdd(item.domElem);
                }
                toggleButtonsBySelection();
            }
        });
        //~ }
    }
    // calcul position of the square
    function calcSquare(applyToSquare=false){
        if (self.selection_square_active){
            let x3 = Math.min(self.selection_square.x1,self.selection_square.x2);
            let x4 = Math.max(self.selection_square.x1,self.selection_square.x2);
            let y3 = Math.min(self.selection_square.y1,self.selection_square.y2);
            let y4 = Math.max(self.selection_square.y1,self.selection_square.y2);
            self.DOM_square.style.left = x3 + 'px';
            self.DOM_square.style.top = y3 + 'px';
            self.DOM_square.style.width = x4 - x3 + 'px';
            self.DOM_square.style.height = y4 - y3 + 'px';
            if (applyToSquare){
                self.selection_square.x1 = x3;
                self.selection_square.y1 = y3;
                self.selection_square.x2 = x4;
                self.selection_square.y2 = y4;
            }
        }
    }
    // called for refresh the list or a sub tree in tree mode
    this.refresh = function(domElem = false, forceElem = false){
        if (!self.history.lst[self.history.current].startsWith('srch:') && !self.modeCorbeille){

            let target = (!forceElem) ? self.current_target_action : forceElem;
            
            if (self.current_mode == 1 && target){ // tree
                let parent = false;
                if (target.dataset.type == 'folder' && target != self.DOM_path_last) parent = getParentItem(target);
                else parent = getParentItem(target.parentElement);
                if (parent){
                    self.loadPath(parent,true);
                    //~ let id = parent.id.split('-')[1];
                    //~ self.refreshTreeItem(id);
                    return;
                }
            }
            
            changeTreePath({},true);
        }
        
        if (self.modeCorbeille){
            // refresh bin
            openCorbeille();
        }
    };
    
    this.modeCorbeille = false;
    function openCorbeille(){
        let settings = Object.assign({}, setts);
        settings.data = {
            'filemanager_action': 'filemanager_display_corbeille',
            'domId': self.domId,
        };
        settings.success = function(res){
            if (self.DOM_container){
                // remove old child
                while(self.DOM_container.children.length > 0){
                    DOM_Class.RemoveElement(self.DOM_container.firstChild);
                }
                self.entries = [];
                // add new child
                DOM_Class.AppendContent(self.DOM_container,res);
            }
            
            // ajout a l'historique du tree
            self.history.add(self.DOM_inp.value);
            
            // genere l'ui du path
            self.displayPath('');
            
            selectionReset();
        };
        $_a.send(settings);
    }
    // init items of bin
    this.cntx_menu_bin = false;
    this.initCorbeille = function(ids, firstTime=true){
        initContextMenuBin();
        
        if (ids){
            ids.forEach((id)=>{
                let item = document.getElementById(id);
                $_e.AddEventClick(item,onClickSelectable);
                $_e.AddEvent(item, 'contextmenu', self.cntx_menu_bin.open);
                //~ $_e.EnableDrag(item, onDragItemStart, onDragItemMove, onDragItemEnd);
                //~ $_e.AddEventDblClick(item, toggle);
                //~ let info = parseInfoElem(item);
                //~ if (info.level == 0){
                let obj = {
                    'domElem': item,
                    'name': item.dataset.name.toLowerCase(),
                    'date': item.dataset.date,
                    'size': (item.dataset.size) ? item.dataset.size : 0,
                    'id': item.id,
                    'type': item.dataset.type,
                    'path': item.dataset.path,
                    'html': item.outerHTML
                };
                self.entries.push(obj);
            });
        }
        
        if (self.can_access_root) {
            var btn_clear = document.getElementById('tree_bin_clear_' + self.domId);
            if (btn_clear) $_e.AddEventClick(btn_clear, askClearCorbeille);
        }
        
        // header for sort, firstChild is container div of item
        let headers = document.getElementById('tree_header_bin_' + self.domId);
        let dateHeader = false;
        if (headers){
            for(let i = 0; i < headers.firstChild.children.length; i++){
                let itemHeader = headers.firstChild.children[i];
                $_e.AddEventClick(itemHeader, onClickSort);
            }
        }
        
        self.modeCorbeille = true;

        self.opened_items = {};
        
        if (firstTime){
            self.sort = 'date';
            // desactivate some of the action not required in bin mode
            $_e.DisableDrop(self.DOM_panel);
            $_e.DisableDrop(self.DOM_container);
            $_e.RemoveEvent(self.DOM_container, 'dragover', overDropItem);

            $_e.DisableDrag(self.DOM_container);
            // $_e.RemoveEvent(self.DOM_container, 'contextmenu', self.cntxMenu.open);
            
            $_e.DisableDrop(self.DOM_path_first);
            // $_e.RemoveEvent(self.DOM_path_first, 'contextmenu', self.cntxMenu.open);
            
            $_e.RemoveEvent(self.DOM_path_first, 'dragover', overDropItem);
            
            // hide normal header
            DOM_Class.AddClass(self.DOM_header, 'hidden');
            
            
            DOM_Class.AddClass(self.DOM_actions, 'hidden');
            DOM_Class.RemoveClass(self.DOM_actions_bin, 'hidden');
        }
    };
    function askClearCorbeille(evt){
        UI_Class.ConfirmPopup(filemanager_translation['ask_clear_bin'], clearCorbeille, null);
    }
    function clearCorbeille(){
        let settings = Object.assign({}, setts);
        settings.data = {
            'filemanager_action': 'filemanager_clear_corbeille',
            'domId': self.domId,
        };
        settings.success = onItemActionSuccess;
        $_a.send(settings);
    }
    function disableCorbeilleMode(){
        DOM_Class.RemoveClass(self.DOM_header, 'hidden');
        
        DOM_Class.RemoveClass(self.DOM_actions, 'hidden');
        DOM_Class.AddClass(self.DOM_actions_bin, 'hidden');
        
        initActions();
        self.modeCorbeille = false;
    }
    function initContextMenuBin(){
        let lst_btns = ['restore'];
        
        if (self.can_access_root) lst_btns.push('delete');
        
        lst_btns.forEach((action,key)=>{
            let icon = DOM_Class.CreateElement('SPAN',{'class':'icon'});
            let text = DOM_Class.CreateElement('SPAN',{'class':'text'}, filemanager_translation[action]);
            let btn = DOM_Class.CreateElement('DIV',{'id': 'tree_context_menu_'+action+'_' + self.domId, 'class': 'filemanager_btn icon_text context_menu '+action, 'title': filemanager_translation[action]});
            DOM_Class.AppendContent(btn, [icon, text]);
            switch(action){
                case 'restore':
                    $_e.AddEventClick(btn, onRestore);
                    self.btns_with_selections.push(btn);
                break;
                case 'delete':
                    $_e.AddEventClick(btn, ()=>{self.onItemDelete(false);});
                    self.btns_with_selections.push(btn);
                break;
            }
            lst_btns[key] = btn;
        });
        
        let domId = 'cntx_bin_tree_'+self.domId;
        let settings = {
            'buttons': lst_btns,
            'openCallback': openContextMenu,
            'hideCallback': ()=>{$_e.AddEventClickOutside(self.DOM_panel,onClickOutsidePanel);}
        };
        self.cntx_menu_bin = UI_Context_Menu.create_instance(domId, settings);
    }
    
    function changeTreePath(evt,refresh=false){
        if (self.DOM_inp){
            self.DOM_inp.value = self.DOM_inp.value.startsWith('/') ? self.DOM_inp.value.substring(1) : self.DOM_inp.value;
            self.DOM_inp.value = self.DOM_inp.value.endsWith('/') ? self.DOM_inp.value : self.DOM_inp.value+'/';
            let path = (refresh) ? self.history.lst[self.history.current] : self.DOM_inp.value;
            if (!refresh && self.history.lst[self.history.current] == path){
                return false;
            }
            let data = {
                // 'domId': self.domId,
                'level': -1, // we want it to be 0 at the end and we automaticly add +1
                'index': '',
                'path': path
            };
            let settings = Object.assign({}, setts);
            settings.data = {
                'filemanager_action': 'filemanager_display',
                'domId': self.domId,
                'item': data
            };
            if (refresh && self.current_mode == 1){ // refresh in tree mode, retrieve list of opened item
                let lst = [];
                for (let id in self.opened_items){
                    lst.push(id);
                }
                if (lst) {
                    settings.data.opened = lst;
                }
            }
            settings.success = function(res){
                if (self.DOM_container){
                    // remove old child
                    while(self.DOM_container.children.length > 0){
                        DOM_Class.RemoveElement(self.DOM_container.firstChild);
                    }
                    self.entries = [];
                    // add new child
                    DOM_Class.AppendContent(self.DOM_container,res);
                }
                
                // ajout a l'historique du tree
                self.history.add(self.DOM_inp.value);
                
                // genere l'ui du path
                self.displayPath(path);
                
                selectionReset();
            };
            $_a.send(settings);
        }
    }
    
    /* 
     * Depending of the mode,
     * load subpart of the tree or change the current viewing path
     */
    function toggle(evt) {
        $_e.StopEvent(evt);
        let targ = getParentItem(evt.target);
        if (!targ){
            return false;
        }
        if (targ.dataset.type == 'folder'){
            if (self.current_mode == 2){
                // change current path and load a new list
                self.DOM_inp.value = targ.dataset.path;
                changeTreePath({});
            } else {
                // open subtree, change self.entries
                let loaded = targ.dataset.loaded;
                if (loaded == '1'){ // already loaded
                    let id = targ.id;
                    
                    if (DOM_Class.HasClass(targ,'opened')){
                        DOM_Class.RemoveClass(targ,'opened');
                        DOM_Class.AddClass(targ,'closed');
                        
                        delete(self.opened_items[id]);
                    } else {
                        DOM_Class.AddClass(targ,'opened');
                        DOM_Class.RemoveClass(targ,'closed');
                        
                        self.opened_items[id] = targ;
                    }
                    
                    self.updateEntry(targ);
                } else { // not loaded
                    self.loadPath(targ);
                }
            }
        } else {
            // dans le cas d'une vidéo, charger artiviewer dans le container supérieur
            // call callback given when loading the filetree
            if (callback && targ.dataset.callback == 'true'){
                let params = {
                    'type': targ.dataset.type,
                    'path': targ.dataset.path,
                    'filename': targ.dataset.name
                };
                callback(callbackParam,params);
            } else if (CONSTANTS.video_ext.indexOf(targ.dataset.name.substring(targ.dataset.name.lastIndexOf('.') + 1)) > -1 || targ.dataset.type == 'sequence'){
                // vignette et vidéo sans proxy, affiche la modale
                selectionReset(targ);
                modalProxy(evt);
            }
        }
    }
    
    /* 
     * Depending of the mode,
     * load subpart of the tree or change the current viewing path
     * - replace: replace ul if found
     */
    this.loadPath = function(targ,replace=false,do_not_open=false) {
        let data = parseInfoElem(targ);
        let settings = Object.assign({}, setts);
        settings.data = {
            'filemanager_action': 'filemanager_display',
            'domId': self.domId,
            'item': data
        };
        if (self.current_mode == 1){ // refresh in tree mode
            let lst = [];
            for (let id in self.opened_items){
                lst.push(id);
            }
            if (lst.length > 0) {
                settings.data.opened = lst;
            }
        }
        settings.success = function(res){
            if (replace && targ.lastElementChild.tagName == 'UL'){
                DOM_Class.RemoveElement(targ.lastElementChild);
            }
            DOM_Class.AppendContent(targ,res);
            
            targ.dataset.loaded = '1';
            if (!do_not_open){
                DOM_Class.ToggleClass(targ,'opened',true);
                DOM_Class.ToggleClass(targ,'closed',false);
            }
            
            let id = targ.id;
            self.opened_items[id] = targ;
            
            selectionReset();

            self.updateEntry(targ);

            // add cntxt menu event on the new ul
            if (targ.lastElementChild.tagName == 'UL') $_e.AddEvent(targ.lastElementChild, 'contextmenu', openCntxMenu);
        };
        $_a.send(settings);
    };
    
    // modify one entry of the array of items displayed
    this.updateEntry = function(targ){
        for (let i = 0; i < self.entries.length; i++){
            if (self.entries[i].id == targ.id){
                // remove selection class
                //~ DOM_Class.ToggleClass(targ,'selected',false);
                self.entries[i].domElem = targ;
                self.entries[i].html = targ.outerHTML;
                self.entries[i].type = targ.dataset.type;
                //~ DOM_Class.ToggleClass(targ,'selected',true);
                break;
            }
        }
    };
    
    // get the li clicked on, if nothing found it can be false
    function getParentItem(domElem){
        if (domElem){
            while(domElem.parentElement && domElem.tagName != 'LI'){
                domElem = domElem.parentElement;
            }
            if (domElem.tagName == 'LI') return domElem;
            else return false;
        }
        return false;
    }
    // retrieve the li clicked on 
    function getRealTarget(domElem){
        let targ = getParentItem(domElem);
        if (!targ.dataset || !targ.dataset.type || targ.dataset.type != 'folder'){
            targ = getParentItem(targ.parentElement);
        }
        if (!targ){
            if (self.DOM_path_last == self.DOM_path_first) targ = (self.can_access_root) ? self.DOM_path_last : false;
            else targ = self.DOM_path_last;
        }
        return targ;
    }
    function parseInfoElem(domElem){
        let str = domElem.id;
        let data = {};
        let parts = str.split('-');
        data.tree = parts[0].split('_')[1];
        data.level = domElem.dataset.level;
        data.path = domElem.dataset.path;
        parts = parts[1].split('_');
        parts.shift(); // remove 'item' from array
        data.index = parts.join('_');
        //~ parts = parts[1].split('_');
        //~ parts.shift(); // remove 'item' from array
        //~ data.index = parts.pop();
        //~ data.parent = parts.join('_');
        
        return data;
    }
    
    // handle all drop elem and redirect to process function
    function onDropElem(evt){
        $_e.StopEvent(evt);
        
        self.current_target_action = getRealTarget(evt.target);
        // console.log(self.current_target_action);

        if (!self.current_target_action && ((evt.dataTransfer && evt.dataTransfer.files.length > 0) || (filemanager_movedSelection !== false))){
            // drop on the root folder without right to access it
            // display error message
            UI_Class.MessagePopup(filemanager_translation.fs_no_root_access);
            return;
        }

        if (evt.dataTransfer && evt.dataTransfer.files.length > 0){
            uploadParseDrop(evt);
        } else {
            if (filemanager_movedSelection !== false){
                onItemMove(evt);
            }
        }
    }
    
    // when uploading a folder, the first call of this function will trigger a parsing that is asynchronous
    // so when it is finnish, we have to recall this function with alreadyParse to true for not parsing again
    async function uploadParseDrop(evt, alreadyParse=false){
        if (!alreadyParse){
            if (!filemanager_timer_modal){
                filemanager_timer_modal = UI_Class.AddWindow(null, {'modal': true, 'nodrag': true, 'class':'timer_requete', 'disableBackgroundClick': true});
                filemanager_timer_modal.SetParent(document.body, 0.5, 0.5);
            }
            self.droped_files = [];
            self.droped_files_path = [];
            self.uploadDirectoryList = [];
            self.videoSize = [];
            await uploadParseFiles(evt.dataTransfer.items);
        }
        
        // IMPORTANT: do nothing until uploadReadingFile is empty, because some file can not be loaded.
        if (self.uploadReadingFile.length > 0){
            setTimeout(()=>{uploadParseDrop(evt,true);},50);
            return false;
        }
        
        // IMPORTANT: do nothing until self.waitForVideos is empty, because we need the size info of video
        if (self.waitForVideos.length > 0){
            setTimeout(()=>{uploadParseDrop(evt,true);},50);
            return false;
        }
        
        if (filemanager_timer_modal.visible){
            filemanager_timer_modal.Hide();
        }
        uploadPreRequest();
    }
    // folders and files are full when there is a conflict and the user have made a choice, parse those array to apply the user choice
    function uploadPreRequest(err_folders = false, err_files = false, sequence = false){
        // load proxies modal and check name, free space, etc...
        let settings = Object.assign({}, setts);
        settings.data = {
            'filemanager_action': 'filemanager_pre_upload',
            'domId': self.domId,
            'path': self.current_target_action.dataset.path
            //~ 'path': (self.current_target_action) ? self.current_target_action.dataset.path : self.history.lst[self.history.current]
        };
        
        settings.data.files = [];
        settings.data.files_path = [];
        settings.data.totalSize = 0;
        
        self.droped_files.forEach((file,index)=>{
            
            settings.data.totalSize += file.size;
            
            let ext = file.name.split('.');
            ext = ext[ext.length-1];

            let fileData = {};
            fileData.folder = self.droped_files_path[index] != '' ? self.droped_files_path[index] : '';
            fileData.name = file.name;

            if (CONSTANTS.video_ext.indexOf(ext) > -1){
                let id = file.name+'-'+file.lastModified;
                fileData.width = self.videoSize[id].width;
                fileData.height = self.videoSize[id].height;
                URL.revokeObjectURL(self.videoSize[id].source);
                let elem = document.getElementById(id);
                if (elem) DOM_Class.RemoveElement(elem);
            }

            if (err_files[index]) {
                if (err_files[index].choice == 'ignore') {
                    settings.data.totalSize -= file.size;
                    // remove it from the list
                    settings.data.files.splice(index, 1);
                    settings.data.files_path.splice(index, 1);
                }
                else {
                    if (err_files[index].choice == 'replace') fileData.replace = 1;
                    if (err_files[index].choice == 'replace_proxy') fileData.replace_proxy = 1;
                    if (err_files[index].sequence) fileData.sequence = 1;
                    // if (err_files[index].choice == 'name') fileData.name = err_files[index].name.value;
                    settings.data.files.push(fileData);
                }
            } else {
                settings.data.files.push(fileData);
            }

            
            // else {
                // let name = (file.webkitRelativePath != '') ? file.webkitRelativePath : file.name;
                // settings.data.files.push({'name': name, 'inside_folder': (file.webkitRelativePath != '') ? true });
            // }
        });

        if (self.uploadDirectoryList){
            if (err_folders){
                for(let i = 0; i < self.uploadDirectoryList.length; i++){
                    if (err_folders[i]) {
                        if (err_folders[index].choice == 'ignore') continue;
                        if (err_folders[index].choice == 'replace') self.uploadDirectoryList[i] = {'path': self.uploadDirectoryList[i], 'replace': 1};
                        if (err_folders[index].choice == 'name') self.uploadDirectoryList[i] = {'path': self.uploadDirectoryList[i], 'name': err_folders[index].name.value};
                    }
                }
            }
            settings.data.directories = self.uploadDirectoryList;
        }

        if (sequence){
            let seq = {};
            for (var key in sequence) {
                // sequence.list.forEach((key)=>{
                //     self.droped_files[key].replace
                // });
                seq[key] = {'choice':sequence[key].choice,'digits':sequence[key].digits};
            }
            settings.data.sequence = seq;
        }

        settings.success = function(res){
            let result = JSON.parse(res);
            if (result.code == 1){
                UI_Class.popupSpecial['filemanager'].SetContent(result.html);
                UI_Class.popupSpecial['filemanager'].Show();
                initModalUploadError();
                // let inps = document.getElementsByClassName('');
                // let btn = document.getElementById('modal-error-apply');
                // if (btn){
                    // $_e.RemoveEventClick(btn,)
                // }
            } else {
                if (result.html && result.html != ''){
                    UI_Class.popupSpecial['filemanager'].SetContent(result.html);
                    UI_Class.popupSpecial['filemanager'].Show();
                    if (result.in_sequence){
                        initModalUploadSequence();
                    }
                    //~ proxyInit();
                    return;
                }
                if (result.time) {
                    let time = (result.time) ? result.time : false;
                    uploadFile(time);
                } else {
                    UI_Class.popupSpecial['filemanager'].Hide();
                }
            }
        };
        
        $_a.send(settings);
    }
    this.modalUploadErrorInputs = {};
    function initModalUploadError(){
        let form = document.getElementById('upload-error-form');
        if (form){
            modalUploadErrorInputs = {};
            for (let i = 0; i < form.length; i++){
                let inp = form[i];
                
                let index = (inp.dataset && inp.dataset.index) ? inp.dataset.index : false;
                if (index && !modalUploadErrorInputs[index]) modalUploadErrorInputs[index] = {};
                
                if (inp.type == 'button'){
                    $_e.AddEventClick(inp, (evt)=>{
                        let can_send = true;
                    
                        for (var key in modalUploadErrorInputs) {
                            if (!modalUploadErrorInputs[key].valid) {
                                can_send = false;
                                break;
                            }
                        }
                        
                        if (modalUploadErrorInputs){
                            // onSubmitModal(evt, true);
                            // apply change to the file and with this index
                            applyUploadErrorChange();
                        }
                    });
                } else if (inp.type != 'hidden') {
                    if (inp.name == 'replace') modalUploadErrorInputs[index].replace = inp;
                    if (inp.name == 'replace-proxy') modalUploadErrorInputs[index].replace_proxy = inp;
                    if (inp.name == 'ignore') modalUploadErrorInputs[index].ignore = inp;
                    // if (inp.name == 'name') {
                    //     modalUploadErrorInputs[index].name = inp;
                    //     modalUploadErrorInputs[index].prev_name = inp.value;
                    // }
                    $_e.AddEvent(inp,'change',(event)=>{onChangeInputModalError(event,index,true);});
                    modalUploadErrorInputs[index].valid = false;
                    modalUploadErrorInputs[index].choice = false;
                    if (inp.dataset && inp.dataset.sequence) modalUploadErrorInputs[index].sequence = true;
                }
            }
        }
    }
    function applyUploadErrorChange(){
        // var ignoreFold = [];
        var folders = {};
        var files = {};
        for (var index in modalUploadErrorInputs) {
            let type = index.split('-')[0];
            let key = index.split('-')[1];
            if (type == 'fold'){
                folders[key] = modalUploadErrorInputs[index];
            } else {
                files[key] = modalUploadErrorInputs[index];
            }
        }
        UI_Class.popupSpecial['filemanager'].Hide();
        uploadPreRequest(folders,files);
    }
    this.modalUploadSequenceInputs = {};
    function initModalUploadSequence(){
        let form = document.getElementById('extend-sequence-form');
        if (form){
            self.modalUploadSequenceInputs = {};
            for (let i = 0; i < form.length; i++){
                let inp = form[i];
                
                let index = (inp.dataset && inp.dataset.index) ? inp.dataset.index : false;
                if (index && !self.modalUploadSequenceInputs[index]) {
                    self.modalUploadSequenceInputs[index] = {};
                    self.modalUploadSequenceInputs[index].valid = false;
                    self.modalUploadSequenceInputs[index].choice = false;
                }
                
                if (inp.type == 'button'){
                    $_e.AddEventClick(inp, (evt)=>{
                        let can_send = true;
                    
                        for (var key in self.modalUploadSequenceInputs) {
                            if (!self.modalUploadSequenceInputs[key].valid) {
                                can_send = false;
                                break;
                            }
                        }
                        
                        if (can_send){
                            // apply change to the file and with this index
                            // applyUploadSequenceChange();
                            UI_Class.popupSpecial['filemanager'].Hide();
                            uploadPreRequest(false,false,self.modalUploadSequenceInputs);
                        }
                    });
                } else if (inp.type != 'hidden') {
                    if (inp.name == 'delete_proxy') self.modalUploadSequenceInputs[index].delete_proxy = inp;
                    if (inp.name == 'remake_proxy') self.modalUploadSequenceInputs[index].remake_proxy = inp;
                    $_e.AddEvent(inp,'change',(event)=>{onChangeInputModalSequence(event,index);});
                    self.modalUploadSequenceInputs[index].digits = inp.dataset.digits.split(',');
                    // if (inp.dataset && inp.dataset.sequence) self.modalUploadSequenceInputs[index].sequence = true;
                } else if (inp.name == 'trou'){
                    self.modalUploadSequenceInputs[index].valid = true;
                    self.modalUploadSequenceInputs[index].choice = 'delete_proxy';
                    self.modalUploadSequenceInputs[index].digits = inp.dataset.digits.split(',');
                }
            }
        }
        let btn_apply = document.getElementById('upload-sequence-apply');
        if (btn_apply) {
            let ok = true;
            for (var key in self.modalUploadSequenceInputs) {
                if (!self.modalUploadSequenceInputs[key].valid) {
                    ok = false;
                    break;
                }
            }
            if (ok){
                btn_apply.disabled = false;
                DOM_Class.RemoveClass(btn_apply, 'icon_disable');
            }
        }
    }
    // function applyUploadSequenceChange(){
        // for (var index in self.modalUploadSequenceInputs) {
        //     let type = index.split('-')[0];
        //     let key = index.split('-')[1];
        //     if (type == 'fold'){
        //         folders[key] = self.modalUploadSequenceInputs[index];
        //     } else {
        //         files[key] = self.modalUploadSequenceInputs[index];
        //     }
        // }
        // UI_Class.popupSpecial['filemanager'].Hide();
        // uploadPreRequest(false,false,self.modalUploadSequenceInputs);
    // }
    function onChangeInputModalSequence(evt,key){
        let targ = evt.target;
        let btn_apply = document.getElementById('upload-sequence-apply');
        if (targ.type == 'checkbox'){
            if (targ.checked){
                if (targ == self.modalUploadSequenceInputs[key].delete_proxy){
                    self.modalUploadSequenceInputs[key].remake_proxy.checked = false;
                    self.modalUploadSequenceInputs[key].choice = 'delete_proxy';
                } else {
                    self.modalUploadSequenceInputs[key].delete_proxy.checked = false;
                    self.modalUploadSequenceInputs[key].choice = 'remake_proxy';
                }
                self.modalUploadSequenceInputs[key].valid = true;
                btn_apply.disabled = false;
                DOM_Class.RemoveClass(btn_apply, 'icon_disable');
            } else {
                self.modalUploadSequenceInputs[key].valid = false;
                btn_apply.disabled = true;
                DOM_Class.AddClass(btn_apply, 'icon_disable');
            }
        }
    }
    //~ async function uploadFile(evt,targ,alreadyParse=false){
    function modalUpload(evt){
        //~ closeContextMenu();
        
        if (!self.current_target_action){
            self.current_target_action = self.DOM_path_last;
        }
        
        let items = getItems([self.current_target_action]);
        let params = {
            'filemanager_action':'filemanager_form_upload',
            'action': 'upload',
            'domId': self.domId,
            'items': items
            //~ 'path': self.current_target_action ? self.current_target_action.dataset.path : self.history.lst[self.history.current]
        };
        UI_Class.openPopupModal(evt,'public/filemanager',params,'filemanager');
    }
    this.initFormUpload = function(){
        let inp = document.getElementById('filemanager_input_upload');
        $_e.AddEvent(inp, 'change', onChangeInputUpload);
        if (!is_safari){
            inp.click();
            setTimeout(()=>{UI_Class.popupSpecial['filemanager'].Hide();},100);
           
        }
    };
    function onChangeInputUpload(evt){
        if (is_safari){
            setTimeout(()=>{UI_Class.popupSpecial['filemanager'].Hide();},100);
        }
        // create obj that respect the same form than dropped one
        let obj = {};
        obj.dataTransfer = {};
        obj.dataTransfer.items = evt.target.files;
        uploadParseDrop(obj);
    }
    function openAndRefresh(target_action = false){
        let target = (target_action) ? target_action : self.current_target_action;
        if (self.current_mode == 1 && target != self.DOM_path_last && !self.modeCorbeille) {
            if (target.dataset.type != 'folder') {
                target = getParentItem(target.parentElement);
                if (!target) {
                    self.refresh();
                    return;
                }
            }
            if (target.dataset.loaded != "1") toggle({target: target});
            else {
                if (!DOM_Class.HasClass(target,'opened')){
                    toggle({target: target});
                }
                self.refresh();
            }
            return;
        }
        if (self.current_mode != 1 && target != self.DOM_path_last){
            toggle({target: target});
            return;
        }
        self.refresh();
    }
    function uploadFile(time){
        
        let settings = Object.assign({}, setts);
        
        let data = new FormData();
        data.append('filemanager_action', 'filemanager_upload');
        data.append('domId', self.domId);
        data.append('path', self.current_target_action.dataset.path);
        var target_action = self.current_target_action;
        self.droped_files.forEach((file,index)=>{
            data.append('file[]', file);
            data.append('file_path[]', self.droped_files_path[index]);
        });
        if (self.uploadDirectoryList){
            self.uploadDirectoryList.forEach((path)=>{
                data.append('directories[]', path);
            });
        }
        if (time){
            data.append('time', time);
        }
        
        settings.data = data;
        
        // redirige l'affichage de la progression de l'upload vers job
        let upload_id = sp3_job.newUpload(self.droped_files);
        
        settings.up_progress = (res,req)=>{sp3_job.updateUpload(res,req,upload_id);};
        
        settings.success = function(res){
            let result = JSON.parse(res);
            // console.log(result);
            if (result.code == 0){
                settings.up_progress = false;
                sp3_job.endUpload(upload_id);

                openAndRefresh(target_action);
                
                if (result.with_proxy){
                    // console.log(result.lst);
                    result.lst.forEach((job)=>{
                        sp3_job.newJob(job);
                    });
                }
                
                if (result.html){
                    UI_Class.popupSpecial['filemanager'].SetContent(result.html);
                    UI_Class.popupSpecial['filemanager'].Show();
                }
            }
        };
        settings.error = ()=>{sp3_job.endUpload(upload_id);};
        
        $_a.send(settings);
    }
    async function uploadParseFiles(filesList){
        let queue = [];
        for (let i = 0; i < filesList.length; i++) {
            let file = filesList[i];
            let entry;
            if (file.webkitGetAsEntry != null && (entry = file.webkitGetAsEntry())) {
                // item from drop, add it to queue to detect if it's a folder or a file
                queue.push(entry);
            } else {
                self.uploadReadingFile.push(file.name);
                // item from input, always a file, add it directly to the parsed array depending extension
                self.droped_files.push(file);
                self.droped_files_path.push('');
                
                let ext = file.name.split('.');
                ext = ext[ext.length-1];
                if (CONSTANTS.video_ext.indexOf(ext) > -1){
                    videoReadInfo(file);
                }
                self.uploadReadingFile.splice(self.uploadReadingFile.indexOf(file.name), 1);
            }
        }
        
        let pathTested = [];
        let allPath = [];
        while (queue.length > 0) {
            let entry = queue.shift();
            if (entry.isFile) {
                self.uploadReadingFile.push(entry.fullPath);
                entry.file((file)=>{
                    self.droped_files.push(file);

                    if (entry.fullPath == '/'+entry.name){
                        self.droped_files_path.push('');
                    } else {
                        let path = entry.fullPath.substring(0, entry.fullPath.lastIndexOf(entry.name));
                        self.droped_files_path.push(path);
                    }
                    
                    let ext = file.name.split('.');
                    ext = ext[ext.length-1];
                    if (CONSTANTS.video_ext.indexOf(ext) > -1){
                        videoReadInfo(file);
                    }
                    
                    self.uploadReadingFile.splice(self.uploadReadingFile.indexOf(entry.fullPath), 1);
                });
            } else if (entry.isDirectory) {
                // add path of every folder into an array
                let path = entry.fullPath.split('/');
                path.pop();
                let parentPath = path.join('/');
                if (parentPath != '' && self.uploadDirectoryList.indexOf(parentPath) > -1){
                    self.uploadDirectoryList.splice(self.uploadDirectoryList.indexOf(parentPath), 1);
                }
                self.uploadDirectoryList.push(entry.fullPath);

                let reader = entry.createReader();
                queue.push(...await uploadParseDirectory(reader));
            }
        }
    }
    async function uploadParseDirectory(reader){
        let lst = [];
        let readEntries = await uploadReadEntriesPromise(reader);
        while (readEntries.length > 0) {
            lst.push(...readEntries);
            readEntries = await uploadReadEntriesPromise(reader);
        }
        return lst;
    }
    async function uploadReadEntriesPromise(reader){
        try {
            return await new Promise((resolve, reject) => {
                reader.readEntries(resolve, reject);
            });
        } catch (err) {
            console.log(err);
        }
    }
    this.videoSize = [];
    this.waitForVideos = [];
    function videoReadInfo(file){
        let id = file.name+'-'+file.lastModified;
        
        self.waitForVideos.push(id);
        setTimeout(()=>{
            if (self.waitForVideos.indexOf(id) > -1){
                self.waitForVideos.splice(self.waitForVideos.indexOf(id), 1);
            }
        },3000);
        
        let urlObj = URL.createObjectURL(file);
        self.videoSize[id] = {'width': 1980, 'height': 1080, 'source': null};

        let source = DOM_Class.CreateElement('source', {'src': urlObj, 'type': file.type});
        let domVideo = DOM_Class.CreateElement('video', {'id': id, 'style': 'display: none;', 'preload': 'metadata'}, source, document.body);
        
        domVideo.onloadedmetadata = (evt)=>{
            let targ = evt.target;
            let videoWidth = domVideo.videoWidth;
            let videoHeight = domVideo.videoHeight;
            self.videoSize[targ.id] = {'width': videoWidth, 'height': videoHeight, 'source': urlObj};
            self.waitForVideos.splice(self.waitForVideos.indexOf(id), 1);
        };
        domVideo.onsuspend = (evt) => {
            let targ = evt.target;
            if (self.videoSize[targ.id].urlObj !== null) return;
            self.waitForVideos.splice(self.waitForVideos.indexOf(id), 1);
        };
    }

    function onItemMove(evt, cut = false){
        
        let array = (cut) ? filemanager_clipBoard : self.selection;
        if (filemanager_movedSelection != self.domId && !cut){
            onItemCopy(evt,true);
            return true;
        }

        let items = getItems(array);
        
        // verify if there is an action to do by checking if the moved item is not already inside the target
        let need_to_move = false;
        
        array.forEach((domElem)=>{
            let parent = getRealTarget(domElem.parentElement);
            if (parent != self.current_target_action) {
            // if (parent && parent != self.current_target_action) {
                need_to_move = true;
            }
        });
        
        if (need_to_move){
            let settings = Object.assign({}, setts);
            settings.data = {
                'filemanager_action': 'filemanager_on_file',
                'action': 'move',
                'domId': self.domId,
                'path': self.current_target_action.dataset.path,
                'items': items,
                'cut': cut
            };
            settings.success = onItemActionSuccess;
            
            $_a.send(settings);
        }
    }
    function onItemCopy(evt,fromDrop=false){
        let items = [];
        if (fromDrop){
            let selectionFromOthertree = trees[filemanager_movedSelection].getSelection();
            items = getItems(selectionFromOthertree);
        } else {
            items = getItems(filemanager_clipBoard);
        }

        // if right click on a file, or a file is currently selected when pressing CTRL + V, get the parent folder as target
        if (self.current_target_action.dataset.type != 'folder') self.current_target_action = getParentItem(self.current_target_action.parentElement);
        
        let settings = Object.assign({}, setts);
        settings.data = {
            'filemanager_action': 'filemanager_on_file',
            'action': 'copy',
            'domId': self.domId,
            'path': self.current_target_action.dataset.path,
            'items': items
        };
        settings.success = onItemActionSuccess;
        $_a.send(settings);
    }
    // delete one or more items
    this.onItemDelete = function(corbeille=true, confirmed = undefined){
        // do nothing if nothing selected
        if (self.selection.length == 0) return false;
        
        if (confirmed === undefined){
            let labelAsk = (corbeille && !self.modeCorbeille) ? filemanager_translation['askBin'] : filemanager_translation['askDel'];
            UI_Class.ConfirmPopup(labelAsk, ()=>{self.onItemDelete(corbeille, true);}, null);
        }

        if (confirmed){
            let items = getItems();
            
            self.current_target_action = self.DOM_path_last;
            
            let settings = Object.assign({}, setts);
            settings.data = {
                'filemanager_action': 'filemanager_delete',
                'domId': self.domId,
                'items': items,
                'corbeille': (corbeille && !self.modeCorbeille) ? 1 : 0
            };

            let clean_viewer = false;
            items.forEach((item)=>{
                for (let domId in artiviewers){
                    if (artiviewers[domId].path == item.path){
                        if (!clean_viewer) clean_viewer = [];
                        clean_viewer.push(domId);
                    }
                }
            });
            if (clean_viewer) settings.data.clean_viewer = clean_viewer;
            
            settings.success = onItemActionSuccess;
            $_a.send(settings);
        }
    };
    function onItemActionSuccess(res){
        UI_Class.popupSpecial['filemanager'].Hide();
        if (res == 'cancel') {
            return;
        }
        let result = JSON.parse(res);
        if (result.code == 1){
            UI_Class.popupSpecial['filemanager'].SetContent(result.html);
            UI_Class.popupSpecial['filemanager'].Show();
        } else {
            if (result.not_blocking){
                if (result.job) sp3_job.newJob(result.job);
                return true;
            }
            if (result.state == 'finished'){
                followProcessEnd(result);
            } else {
                followProcessModal(result);
            }
            if (result.cut){
                filemanager_clipBoard = false;
                let elems = Array.from(document.querySelectorAll('.filemanager_btn.paste'));
                elems.forEach((elem)=>{
                    DOM_Class.AddClass(elem, 'icon_disable');
                    elem.disabled = true;
                });
            }
        }
    }
    
    // load the modal for a new directory
    function modalNewDirectory(evt){
        
        //~ closeContextMenu();
        
        if (!self.current_target_action){
            self.current_target_action = self.DOM_path_last;
        }
        
        let items = getItems([self.current_target_action]);
        let params = {
            'filemanager_action':'filemanager_form_mkdir',
            'action': 'mkdir',
            'domId': self.domId,
            'items': items
            //~ 'path': self.current_target_action ? self.current_target_action.dataset.path : self.history.lst[self.history.current]
        };
        UI_Class.openPopupModal(evt,'public/filemanager',params,'filemanager');
    }
    function modalRename(evt){
        
        //~ closeContextMenu();
        
        if (!self.current_target_action && self.last_selected) {
            self.current_target_action = self.last_selected;
        }
        
        if (!self.current_target_action){
            return false;
        }
        
        let items = getItems([self.current_target_action]);
        let params = {
            'filemanager_action':'filemanager_form_rename',
            'action': 'rename',
            'domId': self.domId,
            'items': items,
        };
        UI_Class.openPopupModal(evt,'public/filemanager',params,'filemanager');
        DOM_Class.SetAlignment(UI_Class.popupSpecial['filemanager'].domElement, 0.5, 0.5);
    }
    function modalProxy(evt){
        let params = {
            'filemanager_action':'filemanager_form_proxy',
            'domId': self.domId,
            'items': getItems()
        };
        UI_Class.openPopupModal(evt,'public/filemanager',params,'filemanager');
    }
    function modalShare(evt){
        let params = {
            'filemanager_action':'filemanager_form_share',
            'domId': self.domId,
            'items': getItems()
        };
        UI_Class.openPopupModal(evt,'public/filemanager',params,'filemanager');
    }
    function modalLink(evt){
        let items = getItems();
        let params = {
            'path': items[0].path
        };
        UI_Class.openPopupModal(evt,'public/externallinks',params,'externallink');
    }

    function onKeyDown(evt){
        if (self.mouse_is_over){
            self.current_target_action = false;
            switch(evt.key){
                case 'Delete':
                    let corbeille = (!self.DOM_corbeille || !evt.shiftKey) ? true : false;
                    if (!self.can_access_root) corbeille = true;
                    self.onItemDelete(corbeille);
                break;
                
                case 'v':
                    if (evt.ctrlKey){
                        if (self.selection.length == 1 && self.selection[0].dataset.type != 'folder') {
                            self.current_target_action = getParentItem(self.selection[0].parentElement);
                        }
                        
                        onClickPaste(evt);
                    }
                break;
                case 'c':
                    if (evt.ctrlKey){
                        onClickCopy(evt);
                    }
                break;
                case 'x':
                    if (evt.ctrlKey){
                        onClickCut(evt);
                    }
                break;
                case 'F2':
                    modalRename(evt);
                break;
            }
        }
    }
    
    this.draggingItem = false;
    // start dragging an item from tree
    function onDragItemStart(evt){
        evt.preventDefault();
        
        let targ = getParentItem(evt.target);

        // check if the item come from the current selection, otherwise change selection to this item
        if (self.selection.indexOf(targ) == -1){
            selectionReset();
            selectionAdd(targ);
            toggleButtonsBySelection();
        }
        
        // display avatar
        DOM_Class.ToggleClass(self.DOM_avatar,'hidden',false);
        filemanager_movedSelection = self.domId;
        self.draggingItem = true;
        
        document.addEventListener('pointermove', detectOutsidePanel);
    }
    
    function onDragItemMove(evt){
        evt.preventDefault();
        
        overDropItem(evt);
        
        self.DOM_avatar._RectReady = false;
        DOM_Class.SetGlobalPosition(self.DOM_avatar , evt.clientX + 3 , evt.clientY  + 3);
    }
    function onDragItemEnd(evt){
        evt.preventDefault();
        // hide avatar
        DOM_Class.ToggleClass(self.DOM_avatar,'hidden',true);
        if (self.previous_mouseover){
            DOM_Class.ToggleClass(self.previous_mouseover,'dragOver',false);
            self.previous_mouseover = false;
        }
        
        self.draggingItem = false;
        filemanager_movedSelection = false;
        
        document.removeEventListener('pointermove', detectOutsidePanel);
    }
    /* Called when dragging element from the web interface AND when dragging a file from user system
     * Need to test if the evt.target got the dataset.drop because the move event is trigged everywhere not only on droppable item because of the custom drag of event.js
     */
    function overDropItem(evt){
        if (evt.target.dataset && evt.target.dataset.drop){
            let targ = getRealTarget(evt.target);
            if (targ != self.previous_mouseover){
                DOM_Class.ToggleClass(self.previous_mouseover,'dragOver',false);
                self.previous_mouseover = targ;
                DOM_Class.ToggleClass(self.previous_mouseover,'dragOver',true);
            }
        } else if (self.previous_mouseover){
            DOM_Class.ToggleClass(self.previous_mouseover,'dragOver',false);
            self.previous_mouseover = false;
        }
    }
    
    function download(evt){
        if (self.selection.length == 0) {
            // Display modal to indicate that a selection is required
            let info = DOM_Class.CreateElement('DIV',{'class': 'filemanager_info selection_required'}, filemanager_translation['selection_required']);
            UI_Class.popupSpecial['filemanager'].SetContent(info);
            UI_Class.popupSpecial['filemanager'].Show();
            return false;
        }
        
        let items = getItems();

        let settings = Object.assign({}, setts);
        settings.dom_target = '';
        settings.data = {
            'filemanager_action': 'filemanager_prepare_download',
            'domId': self.domId,
            'items': items
        };
        settings.success = function(res){
            res = JSON.parse(res);
            if (res['code'] == 0){
                let downloadPopup = window.open(res['url'],'_blank');
                // let downloadPopup = top.window.open(res['url'],'_blank');
            } else {
                UI_Class.popupSpecial['filemanager'].SetContent(res['html']);
                UI_Class.popupSpecial['filemanager'].Show();
            }
        };
        
        $_a.send(settings);
    }
    
    // Remove item list from DOM
    this.removeItem = function(id){
        let domElem = document.getElementById('tree_'+self.domId+'-'+id);
        if (domElem) DOM_Class.RemoveElement(domElem);
    };
    
    this.history = {
        'lst': [],
        'current': -1,
        'clickedOnHistory': false,  // 
        'add': function(path){
            // if clickedOnHistory is true, will not add the current path to history
            // detect if the add is toggled by a back/next in history or a true path change / seach
            if (!self.history.clickedOnHistory){
                path = path.startsWith('/') ? path.substring(1) : path;
                path = path.endsWith('/') ? path : path + '/';
                if (self.history.lst[self.history.current] != path){
                    if (path.startsWith('srch:')) path = path.replace('/','');
                    self.history.lst.push(path);
                    self.history.current = self.history.lst.length - 1;
                }
            }
            self.history.clickedOnHistory = false;
            self.history.toggleButtons();
        },
        'back': function(){
            if (self.history.current > 0){
                self.history.clickedOnHistory = true;
                let path = self.history.lst[self.history.current-1];
                if (path.startsWith('srch:')){
                    path = path.replace('srch:', '');
                    self.DOM_inp_search.value = path;
                    $_e.SendEventClick(self.DOM_btn_search);
                } else {
                    self.DOM_inp.value = path;
                    $_e.SendEventClick(self.DOM_btn);
                }
                self.history.current--;
            }
            self.history.toggleButtons();
            
        },
        'next': function(evt){
            if (self.history.current < (self.history.lst.length - 1)){
                self.history.clickedOnHistory = true;
                let path = self.history.lst[self.history.current+1];
                if (path.startsWith('srch:')){
                    path = path.replace('srch:', '');
                    self.DOM_inp_search.value = path;
                    $_e.SendEventClick(self.DOM_btn_search);
                } else {
                    self.DOM_inp.value = path;
                    $_e.SendEventClick(self.DOM_btn);
                }
                
                self.history.current++;
            }
            self.history.toggleButtons();
        },
        'reset': function(evt){
            self.history.lst = [];
            self.history.current = -1;
            self.history.toggleButtons();
            self.history.clickedOnHistory = false;
        },
        'toggleButtons': function(){
            // disabled button back
            if (self.history.current > 0){
                DOM_Class.ToggleClass(self.DOM_h_back,'icon_disable',false);
                self.DOM_h_back.disabled = false;
            } else {
                DOM_Class.ToggleClass(self.DOM_h_back,'icon_disable',true);
                self.DOM_h_back.disabled = true;
            }
            // disabled button next
            if (self.history.current == (self.history.lst.length - 1)){
                DOM_Class.ToggleClass(self.DOM_h_next,'icon_disable',true);
                self.DOM_h_next.disabled = true;
            } else {
                DOM_Class.ToggleClass(self.DOM_h_next,'icon_disable',false);
                self.DOM_h_next.disabled = false;
            }
            // disabled folder back
            //~ let path = self.history.lst[self.history.current];
            //~ if (path && path.split('/').length > 1){
                //~ DOM_Class.ToggleClass(DOM_folder_back,'disabled',false);
                //~ DOM_folder_back.disabled = false;
            //~ } else {
                //~ DOM_Class.ToggleClass(DOM_folder_back,'disabled',true);
                //~ DOM_folder_back.disabled = true;
            //~ }
        },
        'folderBack': function(evt){
            let path = self.history.lst[self.history.current].endsWith('/') ? self.history.lst[self.history.current] : self.history.lst[self.history.current] + '/';
            let pathArr = path.split('/');
            if (pathArr.length > 1){
                // 1st array.pop remove empty space, 2nd array.pop remove the current folder to get the previous
                pathArr.pop();
                pathArr.pop();
                path = pathArr.join('/');
                self.DOM_inp.value = path;
                $_e.SendEventClick(self.DOM_btn);
            }
        }
    };
    
    // decoupe le path pour afficher chaque élement dans l'ui
    this.displayPath = function(path){
        let parsedPath = path.split('/');
        self.DOM_path_last = self.DOM_path_first;
        let currentPath = '';
        parsedPath.forEach((val,key)=>{
            if (val != ''){
                currentPath += val+'/';
                let id = 'tree_path_part_' + (key+1) + '_' + self.domId;
                let dom = document.getElementById(id);
                if (!dom){
                    dom = self.DOM_path_first.cloneNode();
                    dom.id = id;
                    dom.dataset.drop = false;
                    DOM_Class.RemoveClass(dom, 'home');
                    dom.title = '';
                    DOM_Class.AppendContent(self.DOM_path_container, dom);
                    
                    $_e.AddEventClick(dom,onClickPathElem);
                    
                    $_e.AddEvent(dom, 'contextmenu', openCntxMenu);
                    
                    if (!$_e.HasDrop(dom)){
                        $_e.EnableDrop(dom, onDropElem);
                    }
                }
                dom.textContent = val;
                dom.dataset.path = currentPath;
                self.DOM_path_last = dom;
            }
        });
        while(self.DOM_path_last.nextElementSibling){
            DOM_Class.RemoveElement(self.DOM_path_last.nextElementSibling);
        }
    };
    function displayInputPath(evt){
        DOM_Class.ToggleClass(self.DOM_path_container,'hidden',true);
        
        DOM_Class.ToggleClass(self.DOM_btn,'hidden',false);
        DOM_Class.ToggleClass(self.DOM_inp,'hidden',false);
        
        // active click outside input to close it
        $_e.AddEventClickOutside(self.DOM_inp, hideInputPath);
    }
    function hideInputPath(evt){
        DOM_Class.ToggleClass(self.DOM_path_container,'hidden',false);
        
        DOM_Class.ToggleClass(self.DOM_btn,'hidden',true);
        DOM_Class.ToggleClass(self.DOM_inp,'hidden',true);
        
        $_e.RemoveEventClickOutside(self.DOM_inp, hideInputPath);
    }
    
    function openSearch(){
        if (DOM_Class.HasClass(self.DOM_container_search, 'hidden')){
            DOM_Class.ToggleClass(self.DOM_container_search, 'hidden', false);
            $_e.AddEventClickOutside(self.DOM_container_search, hideSearch);
        }
    }
    function hideSearch(){
        DOM_Class.ToggleClass(self.DOM_container_search, 'hidden', true);
        $_e.RemoveEventClickOutside(self.DOM_container_search, hideSearch);
    }
    function onClickSearch(evt){
        let val = self.DOM_inp_search.value.trim();
        if (val != ''){
            let settings = Object.assign({}, setts);
            settings.data = {
                'filemanager_action': 'filemanager_search',
                'domId': self.domId,
                'search': val,
                'path': self.history.lst[self.history.current].startsWith('srch:') ? '' : self.history.lst[self.history.current]
            };
            settings.success = function(res){
                if (self.DOM_container){
                    // remove old child
                    while(self.DOM_container.children.length > 0){
                        DOM_Class.RemoveElement(self.DOM_container.firstChild);
                    }
                    // add new child
                    DOM_Class.AppendContent(self.DOM_container,res);
                }
                
                self.history.add('srch:' + val);
            };
            $_a.send(settings);
        }
    }
    
    function onClickSort(evt, refresh = false){
        var alphanum = '0123456789abcdefghijklmnopqrstuvwxyz';
        var targ = evt.target;
        
        if (!refresh){
            if (self.sort == targ.dataset.sort){
                targ.dataset.ordre = (targ.dataset.ordre == 'a') ? 'b' : 'a';
            } else {
                targ.dataset.ordre = 'a';
            }
            self.sort = targ.dataset.sort;
            
            if (self.lastSort != targ){
                DOM_Class.ToggleClass(self.lastSort,'active',false);
                DOM_Class.ToggleClass(targ,'active',true);
                self.lastSort = targ;
            }
        }
        
        // first element is header, skip it
        if (self.entries){
            // separe tree entries by parent, folder and file
            let parents = {};
            self.entries.forEach(obj => {
                let parent = 'root';
                if (obj.level > 0){
                    parent = obj.domElem.parentElement.id;
                }
                if (!parents[parent]){
                    parents[parent] = {folders: [], files: []};
                }
                if (obj.type == 'folder'){
                    parents[parent].folders.push(obj);
                } else {
                    parents[parent].files.push(obj);
                }
            });

            let folder_first = true;
            switch (self.sort){
                // alphabetic compare
                case 'name':
                case 'path':
                    if (targ.dataset.ordre == 'b'){
                        for (let parent in parents) {
                            let obj = parents[parent];
                            obj.folders.sort((a,b)=>{
                                return new Intl.Collator().compare(a[self.sort], b[self.sort]);
                            });
                            obj.files.sort((a,b)=>{
                                return new Intl.Collator().compare(a[self.sort], b[self.sort]);
                            });
                        }
                    } else {
                        folder_first = false;
                        for (let parent in parents) {
                            let obj = parents[parent];
                            obj.folders.sort((a,b)=>{
                                return new Intl.Collator().compare(b[self.sort], a[self.sort]);
                            });
                            obj.files.sort((a,b)=>{
                                return new Intl.Collator().compare(b[self.sort], a[self.sort]);
                            });
                        }
                    }
                break;

                // number compare
                case 'date':
                case 'size':
                    if (targ.dataset.ordre == 'b'){
                        for (let parent in parents) {
                            let obj = parents[parent];
                            obj.folders.sort((a,b)=>{
                                return a[self.sort] - b[self.sort];
                            });
                            obj.files.sort((a,b)=>{
                                return a[self.sort] - b[self.sort];
                            });
                        }
                    } else {
                        folder_first = false;
                        for (let parent in parents) {
                            let obj = parents[parent];
                            obj.folders.sort((a,b)=>{
                                return b[self.sort] - a[self.sort];
                            });
                            obj.files.sort((a,b)=>{
                                return b[self.sort] - a[self.sort];
                            });
                        }
                    }
                break;
            }

            // clean root
            let parentRoot = document.getElementById('tree_' + self.domId + '_parent');
            while(parentRoot.lastChild && parentRoot.lastChild.tagName == 'LI'){
                DOM_Class.RemoveElement(parentRoot.lastChild);
            }
            let ids = [];
            if (folder_first){
                for (let parentId in parents) {
                    let parent = parentRoot;
                    if (parentId != 'root'){
                        // le parent est déplacé à sa nouvelle position mais il contient les éléments à leur position avant trie.
                        // Il vont être replacé dans le bon ordre à la suite du script, avant ça il faut supprimer les anciens
                        parent = document.getElementById(parentId);
                        while(parent.lastChild && parent.lastChild.tagName == 'LI'){
                            DOM_Class.RemoveElement(parent.lastChild);
                        }
                    }
                    let obj = parents[parentId];
                    obj.folders.forEach((entry)=>{
                        DOM_Class.AppendContent(parent, entry.html);
                        ids.push(entry.id);
                    });
                    obj.files.forEach((entry)=>{
                        DOM_Class.AppendContent(parent, entry.html);
                        ids.push(entry.id);
                    });
                }
            } else {
                // levels.forEach((obj)=>{
                for (let parentId in parents) {
                    let parent = parentRoot;
                    if (parentId != 'root'){
                        // le parent est déplacé à sa nouvelle position mais il contient les éléments à leur position avant trie.
                        // Il vont être replacé dans le bon ordre à la suite du script, avant ça il faut supprimer les anciens
                        parent = document.getElementById(parentId);
                        while(parent.lastChild && parent.lastChild.tagName == 'LI'){
                            DOM_Class.RemoveElement(parent.lastChild);
                        }
                    }
                    let obj = parents[parentId];
                    obj.files.forEach((entry)=>{
                        DOM_Class.AppendContent(parent, entry.html);
                        ids.push(entry.id);
                    });
                    obj.folders.forEach((entry)=>{
                        DOM_Class.AppendContent(parent, entry.html);
                        ids.push(entry.id);
                    });
                }
            }

            self.entries = [];
            if (!self.modeCorbeille){
                self.initList(ids);
            } else {
                self.initCorbeille(ids, false);
            }

            // console.log(self.opened_items);
            for (var key in self.opened_items){
                self.opened_items[key] = document.getElementById(self.opened_items[key].id);
            }
            if (self.selection){
                self.selection.forEach((domElem, key)=>{
                    self.selection[key] = document.getElementById(domElem.id);
                });
            }
            if (self.last_selected) self.last_selected = document.getElementById(self.last_selected.id);
        }
    }
    
    function onClickDelete(evt){
        //~ closeContextMenu();
        self.onItemDelete();
    }
    
    function onClickCut(evt){
        if (filemanager_clipBoard === false){
            let elems = Array.from(document.querySelectorAll('.filemanager_btn.paste'));
            elems.forEach((elem)=>{
                DOM_Class.RemoveClass(elem, 'icon_disable');
                elem.disabled = true;
            });
        } else {
            filemanager_clipBoard.forEach((elem)=>{
                DOM_Class.ToggleClass(elem, 'in_cut_selection', false);
            });
        }

        filemanager_clipBoard = self.selection;
        filemanager_clipBoardType = 'cut';
        
        filemanager_clipBoard.forEach((elem)=>{
            DOM_Class.ToggleClass(elem, 'in_cut_selection', true);
        });
        // if (filemanager_clipBoard === false){
        //     let elems = Array.from(document.querySelectorAll('.filemanager_btn.paste'));
        //     elems.forEach((elem)=>{
        //         DOM_Class.RemoveClass(elem, 'icon_disable');
        //         elem.disabled = true;
        //     });
        // }
        // UI_Class.MessagePopup('ça arrive bientôt');
    }
    function onClickCopy(evt){
        if (filemanager_clipBoard === false){
            let elems = Array.from(document.querySelectorAll('.filemanager_btn.paste'));
            elems.forEach((elem)=>{
                DOM_Class.RemoveClass(elem, 'icon_disable');
                elem.disabled = true;
            });
        } else {
            filemanager_clipBoard.forEach((elem)=>{
                DOM_Class.ToggleClass(elem, 'in_cut_selection', false);
            });
        }

        filemanager_clipBoard = self.selection.map(a => {return a;});
        // filemanager_clipBoard = self.selection;
        filemanager_clipBoardType = 'copy';
    }
    function onClickPaste(evt){
        //~ closeContextMenu();
        if (filemanager_clipBoard !== false){
            // when from context menu, current_taget_action is the element where right click was pressed
            if (!self.current_target_action){
                // if there is multiple folders in selection, display a modal to chose one
                // first get all folders from selection
                let folders = [];
                self.selection.forEach((item,index)=>{
                    if (item.dataset.type == 'folder'){
                        folders.push({'item': item, 'key': index});
                    }
                });
                if (folders.length > 0){
                    if (folders.length == 1) self.current_target_action = folders[0].item;
                    else {
                        choiceFromSelectionModal(folders);
                        return;
                    }
                }
            }
            if (!self.current_target_action){ // no folder in selection, get the current displayed folder
                self.current_target_action = self.DOM_path_last;
            }
            if (filemanager_clipBoardType == 'copy') onItemCopy(evt);
            else onItemMove(evt,true);
        }
    }
    function choiceFromSelectionModal(array){
        let form = DOM_Class.CreateElement('FORM',{'class':'filemanager_select_folders_form'});
            let ttl = DOM_Class.CreateElement('SPAN',{'class':'filemanager_select_folders_ttl'}, filemanager_translation['multiple_folder_ttl']);
        DOM_Class.AppendContent(form, ttl);
            let block = DOM_Class.CreateElement('DIV',{'class':'filemanager_select_folders_block'});
            array.forEach((obj, index)=>{
                let line = DOM_Class.CreateElement('DIV',{'class':'filemanager_select_folders_line'});
                    let lab = DOM_Class.CreateElement('LABEL',{'for':'inp_folder_'+index, 'class':'filemanager_select_folder_label'}, obj.item.dataset.path);
                    // value is the index from selection array
                    let inp = DOM_Class.CreateElement('INPUT',{'type':'radio', 'id':'inp_folder_'+index, 'name':'select_folder', 'value':obj.key, 'class':'filemanager_select_folder_inp'});
                    if (index == 0){
                        inp.checked = true;
                    }
                DOM_Class.AppendContent(line, [lab, inp]);
                DOM_Class.AppendContent(block, line);
            });
        DOM_Class.AppendContent(form, block);
            let btn_apply = DOM_Class.CreateElement('BUTTON',{'type':'button', 'class':'filemanager_btn multiple_folder'}, filemanager_translation['apply']);
        DOM_Class.AppendContent(form, btn_apply);
        $_e.AddEventClick(btn_apply, choiceFromSelectionApply);
        
        UI_Class.popupSpecial['filemanager'].SetContent(form);
        UI_Class.popupSpecial['filemanager'].Show();
    }
    function choiceFromSelectionApply(evt){
        let form = evt.target.form;
        
        let selected = form.select_folder;
        
        self.current_target_action = self.selection[selected.value];
        
        onItemCopy(evt);
    }
    
    function entering(evt){
        if (!self.mouse_is_over){
            self.mouse_is_over = true;
            if (self.previous_mouseover){
                DOM_Class.ToggleClass(self.previous_mouseover,'dragOver',false);
                self.previous_mouseover = false;
            }
        }
    }
    function outering(evt){
        if (self.mouse_is_over){
            self.mouse_is_over = false;
        }
    }
    
    this.modalErrorInputs = [];
    this.initModalError = function(totalKey){
        // reinit modal if not first call
        self.modalErrorInputs = [];
        
        let btn_apply = document.getElementById('modal-error-apply');
        $_e.AddEventClick(btn_apply, (evt)=>{
            let can_send = true;
        
            for (let i = 0; i < self.modalErrorInputs.length; i++){
                if (!self.modalErrorInputs[i].valid) {
                    can_send = false;
                    break;
                }
            }
            
            if (can_send){
                onSubmitModal(evt, true);
            }
        });
        
        for(let i = 0; i < totalKey; i++){
            let replace = document.getElementById('replace-'+i);
            $_e.AddEvent(replace, 'change', (evt)=>{onChangeInputModalError(evt,i);});
            
            let ignore = document.getElementById('ignore-'+i);
            $_e.AddEvent(ignore, 'change', (evt)=>{onChangeInputModalError(evt,i);});
            
            let name = document.getElementById('name-'+i);
            $_e.AddEvent(name, 'change', (evt)=>{onChangeInputModalError(evt,i);});
            
            self.modalErrorInputs.push({'replace': replace, 'ignore': ignore, 'name': name, 'valid': false, 'prev_name': name.value});
        }
    };
    function onChangeInputModalError(evt, key, upload = false){
        let targ = evt.target;
        let btn_apply;
        if (upload) btn_apply = document.getElementById('upload-error-apply');
        else btn_apply = document.getElementById('modal-error-apply');
        
        let obj = (upload) ? modalUploadErrorInputs : self.modalErrorInputs;

        if (targ.type == 'checkbox'){
            if (targ.checked){
                if (obj[key].name) {
                    DOM_Class.AddClass(obj[key].name, 'icon_disable');
                    obj[key].name.disabled = true;
                }
                if (targ == obj[key].replace){
                    obj[key].ignore.checked = false;
                    if (obj[key].replace_proxy) obj[key].replace_proxy.checked = false;
                    if (upload) obj[key].choice = 'replace';
                } else if (targ == obj[key].ignore) {
                    obj[key].replace.checked = false;
                    if (obj[key].replace_proxy) obj[key].replace_proxy.checked = false;
                    if (upload) obj[key].choice = 'ignore';
                } else {
                    obj[key].replace.checked = false;
                    obj[key].ignore.checked = false;
                    if (upload) obj[key].choice = 'replace_proxy';
                }
                obj[key].valid = true;
                btn_apply.disabled = false;
                DOM_Class.RemoveClass(btn_apply, 'icon_disable');
            } else if (obj[key].name) {
                DOM_Class.RemoveClass(obj[key].name, 'icon_disable');
                obj[key].name.disabled = false;
                if (obj[key].name.value == ''){
                    obj[key].valid = false;
                    btn_apply.disabled = true;
                    DOM_Class.AddClass(btn_apply, 'icon_disable');
                }
            } else {
                obj[key].valid = false;
                btn_apply.disabled = true;
                DOM_Class.AddClass(btn_apply, 'icon_disable');
            }
        } else if (obj[key].name) {
            if (obj[key].name.value == '' || obj[key].name.value == obj[key].prev_name){
                obj[key].valid = false;
                btn_apply.disabled = true;
                DOM_Class.AddClass(btn_apply, 'icon_disable');
            } else {
                obj[key].valid = true;
                btn_apply.disabled = false;
                DOM_Class.RemoveClass(btn_apply, 'icon_disable');
                if (upload) obj[key].choice = 'name';
            }
        }
    }
    
    this.DOM_name_inp;
    this.initModal = function(type){
        self.DOM_name_inp = document.getElementById('tree_'+ type +'_name_' + self.domId);
        $_e.AddEventKey(self.DOM_name_inp, (evt)=>{
            if (evt.keyCode == 13) onSubmitModal(evt);
        });
        
        let btn_apply = document.getElementById('tree_' + type + '_btn_' + self.domId);
        $_e.AddEventClick(btn_apply, onSubmitModal);
        
        setTimeout(()=>{self.DOM_name_inp.focus();},50);
    };
    function onSubmitModal(evt, fromModalError = false){
        if (!fromModalError && (self.DOM_name_inp.value == '' || self.DOM_name_inp.value == self.DOM_name_inp.dataset.prev)) {
            self.DOM_name_inp.focus();
            return ;
        }
        
        let form = evt.target.form;
        
        let settings = Object.assign({}, setts);
        settings.data = form;
        
        settings.success = onItemActionSuccess;

        $_a.send(settings);
    }
    
    function loadVignet(){
        self.entries.forEach((entry) => {
            if (entry.type == 'image' || entry.type == 'video' || entry.type == 'sequence' || entry.name.endsWith('.agp')){
                let already_loaded = entry.domElem.getElementsByClassName('filemanager_tree_item_vignet');
                if (already_loaded.length != 0) return;
                // add observer on each element that need to load a vignet
                self.observerScroll.observe(entry.domElem);
                self.observerList.push(entry);
            }
        });
    }
    // callback for observing the scrollable element
    // called when scrolling and a new item that need to display a vignet is visible
    // load the vignet and stop the observation for this item
    function handleIntersect(changes, observer){
        let elems = [];
        changes.forEach((change)=>{
            if (change.isIntersecting){
                elems.push(change.target);
                observer.unobserve(change.target);
            }
        });
        applyVignet(elems);
    }
    function applyVignet(array){
        
        let items = getItems(array);
        
        let settings = Object.assign({}, setts);
        settings.notimer = true;
        settings.data = {
            'filemanager_action': 'filemanager_load_vignet',
            'domId': self.domId,
            'items': items
        };
        
        settings.success = function(res){
            let result = JSON.parse(res);
            if (result.code == 1){
                if (result.html != ''){
                    UI_Class.popupSpecial['filemanager'].SetContent(result.html);
                    UI_Class.popupSpecial['filemanager'].Show();
                }
            } else {
                result.items.forEach((item)=>{
                    if (!item.error){
                        // check if item is still in the page
                        let domElem = document.getElementById(item.id);
                        if (domElem && domElem.dataset.path == item.path){
                            let vignet = DOM_Class.StringToDom(item.html);
                            let icon = domElem.firstElementChild.firstElementChild;
                            DOM_Class.InsertBefore(vignet, icon);
                            
                            if (domElem.dataset.type == 'video' || icon.classList.contains('sequence-video')){
                                $_e.AddEvent(domElem, EVENTS_Class.EVENT_MOUSEENTER, self.vignetOnEnter);
                                $_e.AddEvent(domElem, EVENTS_Class.EVENT_MOUSELEAVE, self.vignetOnLeave);
                            }
                        }
                    }
                });
            }
        };
        $_a.send(settings);
    }
    this.vignetOnEnter = function(evt){
        let targ = evt.target;
        $_e.AddEvent(targ, 'mousemove', vignetOnMove);
    };
    this.vignetTotalImage = 100 / 9; // la taille d'une portion pour un découpage par 10 (9 dans le calcul car le 0 compte)
    function vignetOnMove(evt){
        let targ = evt.target;
        let rect = DOM_Class.GetGlobalRect(targ, true);

        let posx = Math.round(((evt.clientX - rect.left) / rect.width) * 100);
        let imgx = Math.round(posx / self.vignetTotalImage);
        // imgx is the index of the image to display*
        targ.firstElementChild.firstElementChild.style.backgroundPositionX = 'calc(-' + (imgx) + ' * (100px * var(--fhd-vr)))';
    }
    this.vignetOnLeave = function(evt){
        let targ = evt.target;
        $_e.RemoveEvent(targ, 'mousemove', vignetOnMove);
    };
    
    this.DOM_paste_cntx = this.DOM_proxy_cntx = this.DOM_unpack_cntx = this.DOM_pack_cntx = this.DOM_link_cntx = this.DOM_share_ctnx = false;
    function openContextMenu(evt){
        let targ = getParentItem(evt.target);
        self.current_target_action = targ;
        
        if (targ){
            let isPathElem = !targ.id.includes('-');
            if (!isPathElem && !DOM_Class.HasClass(targ, 'selected')){
                if (evt.ctrlKey || evt.shiftKey) selectionAdd(targ);
                else selectionReset(targ);
            }
        } else {
            selectionReset();
        }
        
        $_e.RemoveEventClickOutside(self.DOM_panel,onClickOutsidePanel);
    }
    function initContextMenu(){
        let lst_btns = ['download','upload','mkdir','rename','copy','cut','paste','proxy','pack','unpack'];
        if (self.DOM_share) lst_btns.push('share');
        if (self.DOM_link) lst_btns.push('link');
        lst_btns.push('to_bin');
        
        lst_btns.forEach((action,key)=>{
            let icon = DOM_Class.CreateElement('SPAN',{'class':'icon'});
            let text = DOM_Class.CreateElement('SPAN',{'class':'text'}, filemanager_translation[action]);
            let btn = DOM_Class.CreateElement('DIV',{'id': 'tree_context_menu_'+action+'_' + self.domId, 'class': 'filemanager_btn icon_text context_menu '+action, 'title': filemanager_translation[action]});
            DOM_Class.AppendContent(btn, [icon, text]);
            switch(action){
                case 'download':
                    $_e.AddEventClick(btn, download);
                    self.btns_with_selections.push(btn);
                break;
                case 'upload':
                    $_e.AddEventClick(btn, modalUpload);
                    self.btns_with_selections.push(btn);
                break;
                case 'mkdir':
                    $_e.AddEventClick(btn, modalNewDirectory);
                break;
                case 'rename':
                    $_e.AddEventClick(btn, modalRename);
                    self.btns_with_selections.push(btn);
                break;
                case 'copy':
                    $_e.AddEventClick(btn, onClickCopy);
                    self.btns_with_selections.push(btn);
                break;
                case 'cut':
                    $_e.AddEventClick(btn, onClickCut);
                    self.btns_with_selections.push(btn);
                break;
                case 'paste':
                    $_e.AddEventClick(btn, onClickPaste);
                    btn.disabled = true;
                    DOM_Class.ToggleClass(btn, 'icon_disable', true);
                    self.DOM_paste_cntx = btn;
                break;
                case 'proxy':
                    $_e.AddEventClick(btn, modalProxy);
                    self.DOM_proxy_cntx = btn;
                break;
                case 'unpack':
                    DOM_Class.AddClass(btn, 'hidden');
                    $_e.AddEventClick(btn, modalUnpack);
                    self.DOM_unpack_cntx = btn;
                break;
                case 'pack':
                    $_e.AddEventClick(btn, modalPack);
                    self.btns_with_selections.push(btn);
                    self.DOM_pack_cntx = btn;
                break;
                case 'share':
                    $_e.AddEventClick(btn, modalShare);
                    self.btns_with_selections.push(btn);
                    self.DOM_share_ctnx = btn;
                break;
                case 'link':
                    $_e.AddEventClick(btn, modalLink);
                    self.DOM_link_cntx = btn;
                break;
                case 'to_bin':
                    $_e.AddEventClick(btn, onClickDelete);
                    self.btns_with_selections.push(btn);
                break;
            }
            
            lst_btns[key] = btn;
        });
        
        let domId = 'cntx_tree_'+self.domId;
        let settings = {
            'buttons': lst_btns,
            'openCallback': openContextMenu,
            'hideCallback': ()=>{$_e.AddEventClickOutside(self.DOM_panel,onClickOutsidePanel);}
        };
        self.cntxMenu = UI_Context_Menu.create_instance(domId, settings);
    }
    
    this.follow_process_modal = false;
    this.follow_process_original = false;
    this.follow_process_items = false;
    function followProcessModal(result){
        if (!self.follow_process_modal){
            self.follow_process_modal = UI_Class.AddWindow(document.body, {'nodrag': true, 'hidden': true, 'modal': true, 'class': 'ui_window special process_follow', 'special':true, 'disableKeydownClose': true, 'disableBackgroundClick': true});
            self.follow_process_modal.domElement.setAttribute('id', 'popup_special_process_follow');
            
            self.follow_process_modal.Hide = function(){
                if(this._modal){
                    this._modalMask.classList.toggle('hidden',true);
                }
                this.domElement.classList.toggle('hidden',true);
                $_e.AddEventClickOutside(self.DOM_panel,onClickOutsidePanel);
            };
            
            self.follow_process_modal.Show = function(){
                if(this._modal){
                    this._modalMask.classList.toggle('hidden',false);
                }
                this.domElement.classList.toggle('hidden',false);
                
                $_e.RemoveEvent(self.DOM_panel,$_e.EVENT_MOUSEDOWN_OUTSIDE);
                
                DOM_Class.SetAlignment(this.domElement, 0.5, 0.5);
            };
        }
        
        self.follow_process_modal.SetContent(result.html);
        
        self.follow_process_modal.Show();
        
        self.follow_process_original = result;
        
        followProcessRefresh(200);
    }
    function followProcessRefresh(refreshTime = 1000){
        let settings = Object.assign({}, setts);
        settings.notimer = true;
        settings.data = {
            'filemanager_action': 'filemanager_follow_processes',
            'domId': self.domId
        };
        
        settings.success = function(res){
            let result = JSON.parse(res);
            
            if (result.state == 'finished'){
                
                self.follow_process_modal.Hide();
                followProcessEnd(self.follow_process_original);
                self.follow_process_original = false;
                
            }
            
            if (result.state == 'working'){
                followProcessUpdate(result.details);
                followProcessRefresh(refreshTime);
            }
        };
        $_a.send(settings, refreshTime);
    }
    function followProcessUpdate(items){
        if (!self.follow_process_items){
            self.follow_process_items = [];
            items.forEach((item)=>{
                self.follow_process_items[item['domID']] = {
                    'percent': document.getElementById(item['domID'] + '-process_percent'),
                    'bar': document.getElementById(item['domID'] + '-process_bar_progress')
                };
                
                let progress = (item['state'] == 'ok!') ? '100%' : item['state'] + '%';
                self.follow_process_items[item['domID']].percent.textContent = progress;
                self.follow_process_items[item['domID']].bar.style.width = progress;
            });
            
            return;
        }
        
        items.forEach((item)=>{
            let progress = (item['state'] == 'ok!') ? '100%' : item['state'] + '%';
            self.follow_process_items[item['domID']].percent.textContent = progress;
            self.follow_process_items[item['domID']].bar.style.width = progress;
        });
    }
    function followProcessEnd(result){
        if (result){
            if (result.moved && result.moved != 'bin'){
                result.moved.forEach((id)=>{
                    for (var key in trees) {
                        trees[key].removeItem(id);
                    }
                });
            }

            if (result.rename) {
                // when renaming we want to refresh the parent element
                self.current_target_action = getParentItem(self.current_target_action.parentElement);
                // if the parent is the root path
                self.current_target_action = self.current_target_action ? self.current_target_action : self.DOM_path_last;
            }
            if (!result.norefresh) openAndRefresh();

            if (result.clean_viewer) {
                result.clean_viewer.forEach((domId)=>{
                    cleanArtiViewer(domId);
                    let side = domId.split('_')[1];
                    if (separators["sep_" + side].state == 'open'){
                        let btn = document.getElementById('oclo_' + side); // oclo_left or oclo_right
                        separators["sep_" + side].toogle_separator(btn,"before");
                    }
                    separators["sep_" + side].domElem.style.display = 'none';
                    separators["sep_" + side].already_opened = false;
                });
            }
            
            self.current_target_action = false;
            
            self.follow_process_items = false;
            
            if (result.error_on_file && result.error_on_file != ''){
                UI_Class.popupSpecial['filemanager'].SetContent(result.error_on_file);
                UI_Class.popupSpecial['filemanager'].Show();
            }
            
            if (result.proxies){
                // proxyOnSuccess(JSON.stringify({'code': 0, 'lst':result.proxies}));
            }
        }
    }
    
    // var proxyPreUpload;
    this.proxyInit = function(preUpload){
        // proxyPreUpload = preUpload;
        let btn_apply = document.getElementById('tree_proxy_btn_' + self.domId);
        $_e.AddEventClick(btn_apply, (evt)=>{proxyOnSubmit(evt,preUpload);});
    };
    function proxyOnSubmit(evt,preUpload){
        let form = evt.target.form;
        
        // when choosing proxy for an already uploaded video or sequence
        // check if there is a checked proxy for changing the icon or not
        
        let no_more_proxy = true;
        let path;
        if (!preUpload){
            for (let i = 0; i < form.length; i++){
                let child = form[i];
                if (child.name.includes('paths')) path = child.value;
                if (child.tagName == 'INPUT' && child.name.includes('proxy') && child.checked){
                    no_more_proxy = false;
                    break;
                }
            }
        }
        
        let settings = Object.assign({}, setts);
        settings.data = form;
        
        settings.success = (res)=>{
            UI_Class.popupSpecial['filemanager'].Hide();
            let result = JSON.parse(res);
            if (result.code == 0){
                if (preUpload){
                    let time = (result.time) ? result.time : false;
                    uploadFile(time);
                } else {
                    if (result.job){
                        let domElem = self.DOM_panel.querySelector('[data-path="' + path + '"]');
                        DOM_Class.ToggleClass(domElem,'processing', true);
                        sp3_job.newJob(result.job);
                    } else if (no_more_proxy) Filemanager_refreshProxyIcon(path, false); // remove video icon
                }
                //  else {
                //     if (to_check.length > 0){
                //         // proxyCheck(to_check);
                //     } else {
                //         // no proxy, change icon and remove callback call
                        
                //         let domElem = document.querySelector('[data-path="' + path + '"]');
                //         if (domElem){
                //             domElem.dataset.callback = 'false';
                            
                //             if (domElem.dataset.type == 'sequence') DOM_Class.ReplaceClass(domElem.firstElementChild.firstElementChild, 'sequence-video', 'sequence');
                //             if (domElem.dataset.type == 'video') {
                //                 domElem.dataset.type = 'file';
                //                 DOM_Class.ReplaceClass(domElem.firstElementChild.firstElementChild, 'video', 'file');
                //             }

                //             self.updateEntry(domElem);
                //         }
                //     }
                // }
            }
            //~ UI_Class.popupSpecial['filemanager'].Hide();
            //~ proxyOnSuccess(res);
        };

        $_a.send(settings);
    }
    /*
    function proxyOnSuccess(res){
        // proxies are generating, check each x seconds that a proxy has finished
        let result = JSON.parse(res);
        if (result.code == 0){
            let to_check = [];
            result.lst.forEach(obj=>{
                if (obj.state == 'wait'){
                    to_check.push(obj.path);
                } else if (obj.state == 'ready'){
                    let domElem = document.querySelector('[data-path="' + obj.path + '"]');
                    if (domElem && domElem.dataset.type != 'video'){
                        if (domElem.dataset.type != 'sequence'){
                            domElem.dataset.type = 'video';
                        }
                        domElem.dataset.callback = 'true';
                        
                        // the icon
                        
                        if (domElem.dataset.type == 'sequence'){
                            DOM_Class.RemoveClass(domElem.firstElementChild.firstElementChild, 'sequence');
                            DOM_Class.AddClass(domElem.firstElementChild.firstElementChild, 'sequence-video');
                        } else {
                            DOM_Class.RemoveClass(domElem.firstElementChild.firstElementChild, 'file');
                            DOM_Class.AddClass(domElem.firstElementChild.firstElementChild, 'video');
                        }
                        
                        
                        self.updateEntry(domElem);
                    }
                }
                
                
                    //~ if (obj.state == 'ready'){
                        
                        
                        
                    //~ } else {
                        //~ to_check.push(obj.path);
                    //~ }
                //~ }
            });
            
            if (to_check.length > 0){
                proxyCheck(to_check);
            }
        }
    }
    // wait 5s before sendig a request to verify the presence of a proxy for a list of path
    function proxyCheck(list){ 
        let settings = Object.assign({}, setts);
        settings.notimer = true;
        settings.data = {
            'filemanager_action': 'filemanager_check_proxy',
            'domId': self.domId,
            'paths': list,
        };
        settings.success = proxyOnSuccess;
        $_a.send(settings, 2500);
    }
    */
    
    this.scrollPanelAuto = false;
    function scrollPanel(side = false){
        if (self.scrollPanelAuto && side){
            let change;
            if (side == 'top'){
                if (self.DOM_container.scrollTop > 0 && self.DOM_container.scrollHeight > 0){
                    change = ()=>{self.DOM_container.scrollTop -= 2;};
                }
            } else if (side == 'bottom'){
                if (self.DOM_container.scrollTop < self.DOM_container.scrollHeight){
                    change = ()=>{self.DOM_container.scrollTop += 2;};
                }
            }
            
            let anim = {
                elements: self.DOM_container,
                duration: 100,
                change: change,
                easing: 'linear'
            };
            spanim(anim);
            setTimeout(()=>{scrollPanel(side);}, 100);
        }
    }
    function detectOutsidePanel(evt){
        let container = document.getElementById('tree_ui_' + self.domId);
        if (container){
            if (self.draggingItem){
                let rect = DOM_Class.GetGlobalRect(self.DOM_container, true);
                if (evt.clientY < rect.top){
                    if (!self.scrollPanelAuto){
                        self.scrollPanelAuto = true;
                        scrollPanel('top');
                    }
                } else if (evt.clientY > rect.bottom){
                    if (!self.scrollPanelAuto){
                        self.scrollPanelAuto = true;
                        scrollPanel('bottom');
                    }
                } else if (self.scrollPanelAuto) {
                    self.scrollPanelAuto = false;
                }
            }
        }
    }
    
    function modalUnpack(evt){
        //~ closeContextMenu();
        
        let items = getItems();
        let params = {
            'filemanager_action':'filemanager_form_unpack',
            'domId': self.domId,
            'items': items,
            'path': self.DOM_path_last.dataset.path,
        };
        UI_Class.openPopupModal(evt,'public/filemanager',params,'filemanager');
    }
    this.initModalPack = function(){
        let apply = document.getElementById('btn_apply_pack');
        $_e.AddEventClick(apply, submitModalPack);
        
        let replace = document.getElementById('btn_pack_replace');
        if (replace) $_e.AddEventClick(replace, (event)=>{submitModalPack(event,true);});
    };
    function modalPack(evt){
        //~ closeContextMenu();
        //~ if (!self.current_target_action){
        //~ }
        let items = getItems();
        let params = {
            'filemanager_action':'filemanager_form_pack',
            'domId': self.domId,
            'items': items,
            'path': self.DOM_path_last.dataset.path,
        };
        UI_Class.openPopupModal(evt,'public/filemanager',params,'filemanager');
    }
    function submitModalPack(evt, replace=false){
        let form = evt.target.form;
        
        if (replace){
            let input = DOM_Class.CreateElement('INPUT',{'type':'hidden','name':'replace','value':1});
            DOM_Class.AppendContent(form,input);
        }
        
        let settings = Object.assign({}, setts);
        settings.data = form;

        let domPath = document.getElementById('widgetFolderSelected');
        if (domPath){
            let path = domPath.innerText == '/' ? '' : domPath.innerText;
            let domElem = self.DOM_panel.querySelector('[data-path="' + path + '"]');
            if (domElem){
                self.current_target_action = domElem;
            }
        }
        
        settings.success = onItemActionSuccess;

        $_a.send(settings);
    }
    function onRestore(evt){
        let items = getItems();
        let settings = Object.assign({}, setts);
        settings.data = {
            'filemanager_action': 'filemanager_restore',
            'domId': self.domId,
            'items': items,
        };
        settings.success = onItemActionSuccess;
        $_a.send(settings);
    }
    // this.displaySharedState = function(ids){

    //     let settings = Object.assign({}, setts);
    //     settings.notimer = true;
    //     settings.data = {
    //         'filemanager_action': 'filemanager_shared_state',
    //         'domId': self.domId,
    //     };
    //     settings.data.lst = [];
    //     ids.forEach((id)=>{
    //         settings.data.lst.push({
    //             id: id,
    //             path: document.getElementById(id).dataset.path
    //         });
    //     });
    //     // self.entries.forEach((entry, key)=>{
    //     //     settings.data.lst.push({
    //     //         id: entry.id,
    //     //         path: entry.domElem.dataset.path
    //     //     });
    //     // });
    //     settings.success = function(res){
    //         let result = JSON.parse(res);
    //         if (result.code == 0){
    //             if (result.shared){
    //                 result.shared.forEach((id)=>{
    //                     let domElem = document.getElementById(id + '_shared_state');
    //                     if (domElem){
    //                         DOM_Class.ToggleClass(domElem, 'hidden');
    //                     }
    //                 });
    //             }
    //         }
    //     };
    //     $_a.send(settings);
    // };
    
    init();
};

var Filemanager_displaySharedState = function(ids, fromFS = false){
    if (!ids) return false;

    let settings = {
        'url': CONSTANTS.base_url + 'public/filemanager/index.php',
        'skip_container': true,
        'dom_container': '',
        'notimer': true,
        'data': {
            'filemanager_action': 'filemanager_shared_state'
        },
        'lst': []
    };
    settings.data.lst = [];
    ids.forEach((id)=>{
        settings.data.lst.push({
            id: id,
            path: document.getElementById(id).dataset.path
        });
    });
    settings.success = function(res){
        let result = JSON.parse(res);

        if (result.code == 0){
            if (result.shared){
                ids.forEach((id)=>{
                    let domElem = document.getElementById(id + '_shared_state');
                    if (domElem){
                        if (result.shared.indexOf(id) > -1){
                            DOM_Class.ToggleClass(domElem, 'hidden', false);
                        } else {
                            DOM_Class.ToggleClass(domElem, 'hidden', true);
                        }
                    }
                    if (!fromFS){
                        let domId = id.slice(id.indexOf('_')+1, id.indexOf('-'));
                        trees[domId].updateEntry(document.getElementById(id));
                    }
                });
                // result.shared.forEach((id)=>{

                //     let domElem = document.getElementById(id + '_shared_state');
                //     if (domElem){
                //         DOM_Class.ToggleClass(domElem, 'hidden', true);
                //     }
                // });
            }
            // if (result.notshared){
            //     result.notshared.forEach((id)=>{
            //         let domElem = document.getElementById(id + '_shared_state');
            //         if (domElem){
            //             DOM_Class.ToggleClass(domElem, 'hidden', false);
            //         }
            //     });
            // }
        }
    };
    $_a.send(settings);
};
// function called when proxies are finished to display the icon video or to remove it
var Filemanager_refreshProxyIcon = function(path, video = true){
    if (!path) return false;

    let domElems = document.querySelectorAll('[data-path="' + path + '"]');
    if (domElems){
        for (let index = 0; index < domElems.length; index++) {
            let domElem = domElems[index];
            if (domElem){
                let str = domElem.id;
                let domId = str.slice(str.indexOf('_')+1, str.indexOf('-'));
                if (!video){
                    domElem.dataset.callback = 'false';
                    let icon = domElem.firstElementChild.firstElementChild;
                    if (!icon.classList.contains('filemanager_tree_item_icon')) { // vignet
                        icon = icon.nextElementSibling;
                        DOM_Class.RemoveElement(domElem.firstElementChild.firstElementChild);
                        $_e.RemoveEvent(domElem, _Class.EVENT_MOUSEENTER, trees[domId].vignetOnEnter);
                        $_e.RemoveEvent(domElem, EVENTS_Class.EVENT_MOUSELEAVE, trees[domId].vignetOnLeave);
                    }
                    if (domElem.dataset.type == 'sequence') DOM_Class.ReplaceClass(icon, 'sequence-video', 'sequence');
                    if (domElem.dataset.type == 'video') {
                        domElem.dataset.type = 'file';
                        DOM_Class.ReplaceClass(icon, 'video', 'file');
                    }

                    // clear artiviewer if currently open on same page
                    for (let domId in artiviewers){
                        if (artiviewers[domId].path == path){
                            cleanArtiViewer(domId);
                            let parent = document.getElementById(domId);
                            while(parent.firstChild) DOM_Class.RemoveElement(parent.firstChild);
                            let side = domId.split('_')[1];
                            let btn = document.getElementById('oclo_' + side); // oclo_left or oclo_right
                            if (separators["sep_" + side].state=="open") separators["sep_" + side].toogle_separator(btn,"before");
                            separators["sep_" + side].domElem.style.display = 'none';
                        }
                    }
                } else {
                    DOM_Class.ToggleClass(domElem,'processing',false);
                    if (domElem.dataset.callback == 'true') continue;
                    domElem.dataset.callback = 'true';
                    if (trees[domId].display_mode == 2) {
                        trees[domId].observerScroll.observe(domElem);
                        trees[domId].observerList.push(domElem);
                    }
                    if (domElem.dataset.type == 'sequence') DOM_Class.ReplaceClass(domElem.firstElementChild.firstElementChild, 'sequence', 'sequence-video');
                    else {
                        domElem.dataset.type = 'video';
                        DOM_Class.ReplaceClass(domElem.firstElementChild.firstElementChild, 'file', 'video');
                    }
                }
                trees[domId].updateEntry(domElem);
            }
        }
    }
};
var Filemanager_refresh = function(path){
    if (!path) return false;
    path = (path == '/') ? '' : path;
    let domElems = document.querySelectorAll('[data-path="' + path + '"]');
    if (domElems){
        for (let index = 0; index < domElems.length; index++) {
            let domElem = domElems[index];
            if (domElem){
                if (domElem.classList.contains('filemanager_tree_item')){
                    let str = domElem.id;
                    let domId = str.slice(str.indexOf('_')+1, str.indexOf('-'));
                    if (domElem.dataset.loaded == '1') {
                        trees[domId].loadPath(domElem,true,true);
                    }
                }
                if (domElem.classList.contains('filemanager_path_part')) {
                    let str = domElem.id;
                    let domId = str.replace(str.split('_', 4).join('_') + '_', '');
                    if (trees[domId].DOM_path_last == domElem){
                        $_e.SendEventClick(domElem);
                        return;
                    }
                }
            }
        }
    }
};

var widgetFolder = function(){};
widgetFolder.input;
widgetFolder.lastSelected = false;
widgetFolder.toggle = function(evt){
    DOM_Class.ToggleClass(evt.target, 'open');
    DOM_Class.ToggleClass(evt.target, 'selected', false);

    if (UI_Class.popupSpecial['filemanager']){
        DOM_Class.SetAlignment(UI_Class.popupSpecial['filemanager'].domElement, 0.5, 0.5);
    }

    // let targ = evt.target;
    // let parent = targ.parentElement;
    //~ let base_id = targ.id;
    
    //~ let icon = document.getElementById(base_id + '_icon');
    //~ let childs = document.getElementById(base_id + '_childs');
    
    // if (parent){
        // DOM_Class.ToggleClass(parent, 'close');
        // DOM_Class.ToggleClass(parent, 'open');
        //~ DOM_Class.ToggleClass(parent.lastElementChild, 'hidden');
    // }
};
widgetFolder.select = function(evt){
    let targ = evt.target;
    if (targ.tagName != 'LI'){
        while(targ.tagName != 'LI') targ = targ.parentElement;
    }
    
    if (widgetFolder.lastSelected){
        DOM_Class.RemoveClass(widgetFolder.lastSelected, 'selected');
    }
    
    if (widgetFolder.lastSelected != targ){
        widgetFolder.lastSelected = targ;
        DOM_Class.AddClass(widgetFolder.lastSelected, 'selected');
    } else {
        widgetFolder.lastSelected = false;
    }
    
    let path = (widgetFolder.lastSelected) ? widgetFolder.lastSelected.dataset.path : '/';
    
    widgetFolder.input.value = path;
    document.getElementById('widgetFolderSelected').textContent = path;


};
var artigroup_selectEntry = function(id){
    let settings = {};
    settings.url = CONSTANTS.base_url + 'public/artigroup/index.php';
    settings.dom_target = 'artigroup_container';
    settings.skip_target = true;
    settings.data = {
        'artigroup_action': 'artigroup_edit',
        'artigroup-data-id': id
    };
    $_a.send(settings);
};
var separators=[];
var dispoObserver=false;
function initSeparators(){
    separators=[];
    let sepas = document.querySelectorAll('div.separator_open,div.separator_closed');
    if (sepas){
        for (let i = 0; i < sepas.length; i++){
            let sep = sepas[i];
            //let id = parseInt(separator.dataset.id);
            //$_e.AddEvent(sep, 'dblclick', function(){
                //open_close
            //});
            let sepid =sep.id;
            //~ console.log(sepid);
            //~ if (separators[sepid]==undefined){
                separators[sepid]=new separator(sep);
                separators[sepid].initSeparator();
                separators[sepid].resizeContainers();
            //~ }
                
        }
    }
    // parent.document.addEventListener("orientationchange", function(){console.log('orientation');});
    // $_e.AddResizeHandler(trucmuche); 
    // window.addEventListener("resize", function() {
    //     setTimeout(function(){resizeSeparators();},200);
    // });

    // first time artidispo is opened, change the onclick on link in hierarchy that opens artidispo
    let elems = document.querySelectorAll('.Conversation, .Filemanager');
    if (elems){
        if (elems[0].onclick != specialChangeHash){
            for (let index = 0; index < elems.length; index++) {
                let elem = elems[index];
                elem.onclick = specialChangeHash;
            }
        }
    }

    if (dispoObserver){
        // dispoObserver.unobserve(document.getElementById('artidispo_container'));
        // dispoObserver.unobserve(document.getElementById('right_side'));
        // dispoObserver.unobserve(document.getElementById('left_side'));
        if (dispoObserver.disconnect === "function" ){
            dispoObserver.disconnect();
        }
    }
    dispoObserver = new ResizeObserver(entries => {
        // resizeSeparators();
        let globalresize=false;
        for (let entry of entries) {
            if (entry.target.id =='artidispo_container'){
                globalresize=true;
                resizeSeparators();
            }
            // console.log(entry.target.id+'--'+globalresize);
            if (entry.target.id =='right_side' && !globalresize){
                separators['sep_right'].resizeContainers();
            }
            
            if (entry.target.id =='left_side' && !globalresize){
                separators['sep_left'].resizeContainers();
            }

        }
        
    });

    dispoObserver.observe(document.getElementById('artidispo_container'));
    dispoObserver.observe(document.getElementById('right_side'));
    dispoObserver.observe(document.getElementById('left_side'));

}
function specialChangeHash(event){
    let current = document.location.hash.substring(1);
    let hash = event.currentTarget.href.split('?')[1];
    if (hash == current){
        // jump_hash to prevent change in hash history but reload the module
        if(event.preventDefault) event.preventDefault();
        else event.returnValue = false;
        jump_hash(hash);
    } else {
        // normal way
        if(event.preventDefault) event.preventDefault();
        else event.returnValue = false;
        location.hash=hash;
    }
}

function resizeSeparators(){
    //  let sepas = document.querySelectorAll('div.separator_open,div.separator_closed');
    if (separators){
        if(separators['sep_middle'].state=='closed'){
            let dispocontainer =document.getElementById('artidispo_container');
            if (dispocontainer!=undefined){
                let global_container_rect=DOM_Class.GetGlobalRect(dispocontainer,true);
                // let domElem_rect=DOM_Class.GetGlobalRect(separators['sep_middle'].domElem,true);
                // console.log(global_container_rect.width-domElem_rect.width);
                separators['sep_middle'].domElem.style.left=(global_container_rect.width)+'px';
            }
        //  separators['sep_middle'].domElem.style.left=(global_container_rect.width-domElem_rect.width)+'px';
        }
        for (var domId in separators){
            separators[domId].resizeContainers();
        }
    }
}

var separator = function(sep){
    var self = this;
        
    this.initSeparator = function(){
        //dom elements
        this.domElem=sep;
        this.container_before= document.getElementById(sep.dataset.targetsbefore);
        this.container_after= document.getElementById(sep.dataset.targetsafter);
        this.global_container=sep.parentNode;
        
        
        //some data from the separator domelem
        this.sepid=sep.id;
        this.state=sep.dataset.state;
        if (this.state=='open'){
            this.already_opened=true;
            this.enableDrag();
        }else{
            this.already_opened=false;
        }
        this.type=sep.dataset.type;
        
        //fix default css before calling recontainer :
        let domElem_rect=DOM_Class.GetGlobalRect(this.domElem,true);
        if (this.type=='horizontal'){
            this.domElem.style.top=domElem_rect.top+'px';
        }else{
            this.domElem.style.left=domElem_rect.left+'px';
        }
        
        //other...
        this.minimumWH=300;

        
    };
    
    this.enableDrag =function(){
        EVENTS_Class.EnableDrag(this.domElem, this.OnStartDrag, this.OnDrag , this.OnEndDrag );
        $_e.AddEvent(this.domElem,'touchstart',(event)=>{
            event.preventDefault();
            this.OnStartDrag(event);
        });
        $_e.AddEvent(this.domElem,'touchmove',(event)=>{
            event.preventDefault();
            this.OnDrag(event);
        });
        $_e.AddEvent(this.domElem,'touchend',(event)=>{
            event.preventDefault();
            this.OnEndDrag(event);
        });
    };
    
    this.disableDrag =function(){
         EVENTS_Class.DisableDrag(this.domElem);
    };
    this.OnStartDrag = function(event){};
    
    this.OnDrag = function(event){
        if (!self.draginterval){
            self.resizeContainers();
            self.draginterval=setInterval(self.cleardragint, 15);
        }
    };
    this.cleardragint =function(){
        clearInterval(self.draginterval);
        self.draginterval=false;
    };
    this.OnEndDrag = function(event){
    };
    this.resizeContainers = function(){
        let domElem_rect=DOM_Class.GetGlobalRect(this.domElem,true);
        domElem_rect.width=(domElem_rect.width==0 && this.state!='closed' )?25:domElem_rect.width;
        domElem_rect.height=(domElem_rect.height==0 && this.state!='closed' )?25:domElem_rect.height;
        let global_container_rect=DOM_Class.GetGlobalRect(this.global_container,true);
        let container_before_rect=DOM_Class.GetGlobalRect(this.container_before,true);
        let container_after_rect=DOM_Class.GetGlobalRect(this.container_after,true);
        //~ let module_container_rect=DOM_Class.GetGlobalRect(document.getElementById(sep.dataset.targetsafter));
       
        if (this.type=='horizontal'){
            let FHeightBefore=(parseInt(this.domElem.style.top) - container_before_rect.top);
            let FHeightafter=parseInt(global_container_rect.height-parseInt(this.domElem.style.top)-domElem_rect.height-container_before_rect.top);
            if ((FHeightBefore> this.minimumWH && FHeightafter>this.minimumWH) || this.state=='closed'){
                this.container_before.style.height=FHeightBefore+'px';
                this.container_after.style.height=FHeightafter+'px';
            }
        }else{
            let FWidthBefore=parseInt(this.domElem.style.left) - container_before_rect.left + domElem_rect.width;
            let FWidthafter=parseInt(global_container_rect.width-parseInt(this.domElem.style.left)+container_before_rect.left-domElem_rect.width);
            // console.log(global_container_rect.width+'-'+this.domElem.style.left+'-'+container_before_rect.left+'-'+domElem_rect.width);
            // console.log(FWidthBefore+'-'+FWidthafter+'-'+this.state);
            if ((FWidthBefore>this.minimumWH && FWidthafter>this.minimumWH) || this.state=='closed' ){
                // console.log(this.container_before.id+'--'+this.container_after.id);
                this.container_before.style.width=FWidthBefore+'px';
                this.container_after.style.width=FWidthafter+'px';
            }
        }   
    };
    
    this.toogle_separator = function(openClose_button,targeted_container){
        let domElem_rect=DOM_Class.GetGlobalRect(this.domElem,true);
        let global_container_rect=DOM_Class.GetGlobalRect(this.global_container,true);   
        let toopenclose='';
        let toresize='';

        //ordering targets :
        if(targeted_container=="before"){
            toopenclose=this.container_before;
            toresize=this.container_after;
        }else{
            toopenclose=this.container_after;
            toresize=this.container_before;
        }
        
        if (this.state=="open"){
            toopenclose.classList.replace('container_open','container_closed');
            this.domElem.classList.replace('separator_open','separator_closed');
            toopenclose.dataset.previousdisplay=toopenclose.style.display;
            toopenclose.style.display='none';
            if (this.type=='horizontal'){
                toopenclose.style.height='0px';
                this.domElem.style.top='0px';
                //~ console.log(global_container_rect.height+'-'+domElem_rect.height);
                toresize.style.height=(global_container_rect.height-global_container_rect.top-domElem_rect.height-10)+'px';
                //~ openClose_button.innerHTML='v';
                openClose_button.style='background-position: calc(-14px * var(--fhd-hr)) calc(-20px * var(--fhd-hr));';
            }else{
                this.domElem.style.left='0px';
                toopenclose.style.width='0px';
                toresize.style.width=(global_container_rect.width-domElem_rect.width)+'px';
                //~ openClose_button.innerHTML='<';
                if (openClose_button.id=="oclo_middle"){
                    openClose_button.style='background-position: 0px calc(-14px * var(--fhd-hr));';
                }else{
                    openClose_button.style='background-position: calc(-20px * var(--fhd-vr)) calc(-14px * var(--fhd-hr));';
                }
            }
           this.resizeContainers();
           this.disableDrag();
           this.state='closed';
           openClose_button.dataset.state='closed';
           this.domElem.dataset.state='closed';
        }else{
            toopenclose.classList.replace('container_closed','container_open');
            this.domElem.classList.replace('separator_closed','separator_open');
            toopenclose.style.display=(toopenclose.dataset.previousdisplay!=undefined)?toopenclose.dataset.previousdisplay:''; 
            if (this.type=='horizontal'){
                this.domElem.style.top=((global_container_rect.height-domElem_rect.height+72)/2)+'px'; 
                toopenclose.style.height=(((global_container_rect.height-domElem_rect.height)/2)+domElem_rect.height)+'px'; 
                //~ openClose_button.innerHTML='ʌ'; 
                openClose_button.style='background-position: calc(-14px * var(--fhd-hr)) 0px;';
            }else{
                this.domElem.style.left=((global_container_rect.width-domElem_rect.width)/2)+'px'; 
                toresize.style.width=(((global_container_rect.width-domElem_rect.width)/2)+domElem_rect.width)+'px'; 
                //~ openClose_button.innerHTML='>'; 
                //~ ='background-position: calc(-120px * var(--fhd-vr)) 0px;'
                if (openClose_button.id=="oclo_middle"){
                    openClose_button.style='background-position: calc(-20px * var(--fhd-vr)) calc(-14px * var(--fhd-hr));';
                }else{
                    openClose_button.style='background-position: 0px calc(-14px * var(--fhd-hr));';
                }
                
            }
           this.state='open';
           openClose_button.dataset.state='open';
           this.domElem.dataset.state='open';
           this.resizeContainers();
           this.enableDrag();
        }
    };
    
    this.switchType = function(switch_button){
        //getting oclo  button to change its aspect
        let ocloid=this.sepid.split('_');
        ocloid='oclo_'+ocloid[1];
        let openClose_button = document.getElementById(ocloid);
        
        if (this.type=='horizontal'){
            this.type='vertical';
            this.global_container.style.display="flex";
            this.domElem.classList.replace('artidispo_separator_horizontal','artidispo_separator_vertical');
            let domElem_rect=DOM_Class.GetGlobalRect(this.domElem,true);
            let global_container_rect=DOM_Class.GetGlobalRect(this.global_container,true); 
            if (this.state=='open'){
                this.domElem.style.left=((global_container_rect.width-domElem_rect.width)/2)+'px';
                this.container_after.style.width=((global_container_rect.width-domElem_rect.width)/2)+'px'; 
                this.container_before.style.width=((global_container_rect.width-domElem_rect.width)/2)+'px'; 
                openClose_button.style='background-position: 0px calc(-14px * var(--fhd-hr));';
            }else{
                this.domElem.style.left='0px';
                this.container_after.style.width=(global_container_rect.width-domElem_rect.width)+'px'; 
                this.container_before.style.width='0px';
                
                openClose_button.style='background-position: calc(-20px * var(--fhd-vr)) calc(-14px * var(--fhd-hr));';
            }
            this.container_before.style.height='100%';
            this.container_after.style.height='100%';
            //~ switch_button.innerHTML='V';
            DOM_Class.ReplaceClass(switch_button , 'switch_state_hori', 'switch_state_vert');
            //~ openClose_button.innerHTML=(this.state=="open")?'<':'>';
        }else{
            this.type='horizontal';
            this.global_container.style.display="";
            // console.log(this.global_container.id);
            this.domElem.classList.replace('artidispo_separator_vertical','artidispo_separator_horizontal');
            let domElem_rect=DOM_Class.GetGlobalRect(this.domElem,true);
            let global_container_rect=DOM_Class.GetGlobalRect(this.global_container,true); 
            if (this.state=='open'){
                this.domElem.style.top=((global_container_rect.height-global_container_rect.top-domElem_rect.height)/2)+'px'; 
                this.container_after.style.height=((global_container_rect.height-global_container_rect.top-domElem_rect.height)/2)+'px'; 
                this.container_before.style.height=((global_container_rect.height-global_container_rect.top-domElem_rect.height)/2)+'px'; 
                openClose_button.style='background-position: calc(-14px * var(--fhd-hr)) 0px;';
            }else{
                this.domElem.style.top='0px'; 
                this.container_after.style.height=(global_container_rect.height-global_container_rect.top-domElem_rect.height)+'px'; 
                this.container_before.style.height='0px'; 
                openClose_button.style='background-position: 0px calc(-14px * var(--fhd-hr));';
            }
            this.container_before.style.width='100%';
            this.container_after.style.width='100%';
            //~ switch_button.innerHTML='H'; 
            //~ openClose_button.innerHTML=(this.state=="open")?'ʌ':'V';
            DOM_Class.ReplaceClass(switch_button , 'switch_state_vert', 'switch_state_hori');
        }
        this.resizeContainers();
    };
    
};
//~ var right_file_manager_opened=false;
function open_right_file_manager(){
    if (!separators['sep_middle'].already_opened){

        let settings = {};
        settings.url = CONSTANTS.base_url + 'public/filemanager/index.php';
        settings.skip_container = true;
        settings.dom_target='filemanager_right';
        settings.data = {
            'tree':1,
            'callback': 'artiviewerSelect',
            'callback_param': 'viewer_right',
            'target_switch': 'filemanager_right',
            'domId': 'right_side'
        };
        settings.success = function(res, e){
            separators['sep_middle'].already_opened=true;
            
        };
        $_a.send(settings);
    }
    if (artiviewers_synctoogled){
        toogleSyncPlay();
    }
    resizeSeparators();
}
//~ var right_file_manager_opened=false;
function open_right_conversation(){
    if (!separators['sep_middle'].already_opened){

        let settings = {};
        settings.url = CONSTANTS.base_url + 'public/conversation/index.php';
        settings.dom_target='conversation_right';
        settings.skip_container = true;
        settings.data = {
            'target_switch': 'conversation_right',
            'domId': 'right_side'
        //     'tree':1,
        //     'callback': 'artiviewerSelect',
        //     'callback_param': 'viewer_right'
        };
        settings.success = function(res, e){
            separators['sep_middle'].already_opened=true;
            
        };
        $_a.send(settings);
    }
    // if (artiviewers_synctoogled){
    //     toogleSyncPlay();
    // }
    resizeSeparators();
}
var left_viewer_opened=false;
function open_left_viewer(button){
    // console.log('open left');
    if (!separators['sep_left'].already_opened){
        separators['sep_left'].domElem.style.display='block';
        //~ let settings = {};
        //~ settings.url = CONSTANTS.base_url + 'public/artiviewer/index.php';
        //~ settings.dom_target='viewer_left';
        //~ settings.data = {
            //~ 'path':path,
            //~ 'name':'viewer_left'
        //~ };
        //~ settings.success = function(res, e){
            //~ separators['sep_left'].already_opened=true;
        //~ };
        //~ $_a.send(settings);
    }
    if (button.dataset.state=='closed' && artiviewers['viewer_left']!=undefined){
        if (artiviewers['viewer_left'].mode =='video'){
            artiviewers['viewer_left'].stop();
        }
    }
}

var right_viewer_opened=false;
function open_right_viewer(button){
    if (!separators['sep_right'].already_opened){
        separators['sep_right'].domElem.style.display='block';
        //~ let settings = {};
        //~ settings.url = CONSTANTS.base_url + 'public/artiviewer/index.php';
        //~ settings.dom_target='viewer_right';
        //~ settings.data = {
            //~ 'path':'',
            //~ 'name':'viewer_right'
        //~ };
        //~ settings.success = function(res, e){
            //~ separators['sep_right'].already_opened=true;
        //~ };
        //~ $_a.send(settings);
    }
    if (button.dataset.state=='closed' && artiviewers['viewer_right']!=undefined){
        if (artiviewers['viewer_right'].mode =='video'){
            artiviewers['viewer_right'].stop();
        }
    }
}

function switchConversationFilemanager(evt){
    // console.log('switch');

    let btnSwitch = evt.target;
    // console.log(btnSwitch);

    let from = btnSwitch.dataset.module; // conversation or filemanager
    let to = (from == 'conversation') ? 'filemanager' : 'conversation';
    let target = btnSwitch.dataset.target;

    // let parent = btnSwitch.parentElement;
    // while(!parent.classList.contains('artidispo_' + from) && parent.tagName != 'BODY') {
    //     parent = parent.parentElement;
    // }

    // if (parent && parent.tagName != 'BODY'){
        // console.log(parent);
    let targetdiv=document.getElementById(target);
    DOM_Class.ToggleClass(targetdiv,'artidispo_filemanager');
    DOM_Class.ToggleClass(targetdiv,'artidispo_conversation');
    
    let settings = {};
    settings.url = CONSTANTS.base_url + 'public/' + to + '/index.php';
    settings.skip_container = true;
    settings.dom_target = target;
    settings.data = {
        'target_switch': target,
        'domId': btnSwitch.dataset.domid
    };
    if (to == 'filemanager') {
        let side = target.split('_')[1]; // left or right
        settings.data.callback = 'artiviewerSelect';
        settings.data.callback_param = 'viewer_' + side;
    }
    $_a.send(settings);
    // }
}
function artiviewerSelect(viewer_name,params){
    //~ console.log(viewer_name);
    //~ console.log(params);
    //~ if (artiviewers[viewer]!=undefined){
    let idpart=viewer_name.split('_');
    let part=idpart[1];
    if (separators['sep_'+part] == undefined){
        $_e.SendEventClick(document.getElementById('oclo_'+part));
    }
    if (separators['sep_'+part].state=="closed"){
        $_e.SendEventClick(document.getElementById('oclo_'+part));
    }
    if (separators['sep_'+part] != undefined){
        let settings = {};
        settings.url = CONSTANTS.base_url + 'public/artiviewer/index.php';
        settings.dom_target=viewer_name;
        settings.data = {
            'path':params.path,
            'type':params.type,
            'filename':params.filename,
            'name':viewer_name
        };
        settings.success = function(res, e){
            //~ separators['sep_left'].already_opened=true;
            initArtiViewer(viewer_name,params);
            setTimeout(initRangeTracks,500);
        };
        $_a.send(settings);
           
    }else{
        console.log('viewer_undefined');
    }
    
}

var artiviewers=[];
var artiviewers_synctoogled=false;
var artiviewerKeypressedLock=false; //to stop keypressed listening for modal and text typing etc...
function cleanArtiViewer(viewer_name){
    if (artiviewers[viewer_name].ro){
        if (document.getElementById('artiviewer_'+self.name) != undefined) {
            artiviewers[viewer_name].ro.unobserve(document.getElementById('artiviewer_'+self.name));
            artiviewers[viewer_name].ro.unobserve(document.getElementById('artiplayer_'+self.name));
        }
        if (typeof artiviewers[viewer_name].ro.disconnect === "function" ){
            artiviewers[viewer_name].ro.disconnect();
        }
    }
    if (artiviewers[viewer_name].pan){
        if (document.getElementById('artiviewer_commentszone_'+self.name) != undefined) {
            artiviewers[viewer_name].pan.unobserve(document.getElementById('artiviewer_commentszone_'+self.name));
        }
        if (typeof artiviewers[viewer_name].pan.disconnect === "function" ){
            artiviewers[viewer_name].pan.disconnect();
        }
    }
    $_e.RemoveEvent(document,EVENTS_Class.EVENT_KEYDOWN, artiviewers[viewer_name].checkKey);
    $_e.RemoveEvent(artiviewers[viewer_name].artiviewercontainer, 'mouseenter', artiviewers[viewer_name].entering);
    $_e.RemoveEvent(artiviewers[viewer_name].artiviewercontainer, 'mouseleave', artiviewers[viewer_name].outering);
    delete artiviewers[viewer_name];
}
function initArtiViewer(viewer_name,params){
    //cleaning
    if (artiviewers[viewer_name]!=undefined){
        cleanArtiViewer(viewer_name);
    }
    artiviewers[viewer_name]=new artiviewer(viewer_name,params);
    artiviewers[viewer_name].initViewer();
    if (Object.keys(artiviewers).length>1){
        let testsyncable=0;
        let tfriends=[];
        for (const [key, viewer] of Object.entries(artiviewers)) {
        //~ console.log('artiplayer_'+artiviewers[key].name);
            let test=document.getElementById('artiplayer_'+artiviewers[key].name);
            if (test!=undefined){
            tfriends[testsyncable]=artiviewers[key].name;
            testsyncable++;
            }
        }
        let syncswitch=document.getElementById('switch_middle');
        if (testsyncable>1){
            DOM_Class.ReplaceClass(syncswitch , 'icon_disable', 'icon_enable');
            if (artiviewers_synctoogled){
                artiviewers[tfriends[0]].friend=artiviewers[tfriends[1]];
                artiviewers[tfriends[1]].friend=artiviewers[tfriends[0]];
            }else{
                artiviewers[tfriends[0]].friend=false;
                artiviewers[tfriends[1]].friend=false;
            }
        }else{
            DOM_Class.ReplaceClass(syncswitch , 'icon_enable', 'icon_disable');
            artiviewers_synctoogled=false;
            DOM_Class.RemoveClass(syncswitch , 'state_active');
        }
       
    }
}

function artiviewerShortcutJump(e,path,domId=false){
    var notfound=true;
    var partname='left';
    if (!domId){
        //search in already opened artiviewers
        for (const [key, viewer] of Object.entries(artiviewers)) {
        //~ console.log('artiplayer_'+artiviewers[key].name);
            let test=document.getElementById('artiplayer_'+artiviewers[key].name);
            if (test!=undefined){
                console.log(artiviewers[key].path+path);
                if (artiviewers[key].path==path){
                    let psplit=path.split('?');
                    artiviewers[key].settime(psplit[1]);
                    partname=artiviewers[key].name.split('_');
                    partname=partname[1];
                    notfound=false;
                    break;
                }
            }
        }
        //try to detect the parent id :
        if (notfound){
            var parents = [];
            let curnode=e.target;
            while(curnode.parentNode && curnode.parentNode.nodeName.toLowerCase() != 'body') {
                curnode = curnode.parentNode;
                if (curnode.id=="conversation_left" || curnode.id=="conversation_right" ){
                    partname=curnode.id.split('_');
                    partname=partname[1];
                }
            }
        }
    }else{
        partname=domId.split('_');
        partname=partname[1];
    }
    
    if (separators['sep_'+partname] == undefined){
        $_e.SendEventClick(document.getElementById('oclo_'+partname));
    }
    if (separators['sep_'+partname].state=="closed"){
        $_e.SendEventClick(document.getElementById('oclo_'+partname));
    }
    if (notfound){
        if (separators['sep_'+partname] != undefined){
            let settings = {};
            settings.url = CONSTANTS.base_url + 'public/artiviewer/index.php';
            settings.dom_target='viewer_'+partname;
            //FAIt LA DIF VIDEO/SEQUENCE
            let mtype='video';
            if (e.target==undefined){
                mtype=e;
            }else{
                mtype=(e.target.dataset.type!=undefined)? e.target.dataset.type:'video';
            }
            settings.data = {
                'path':path,
                'type':mtype,
                'filename':path.split('/').pop(),
                'name':'viewer_'+partname
            };
            params={};
            params.path=path;
            params.type=mtype;
            params.filename=path.split('/').pop();
            params.name='viewer_'+partname;
            settings.success = function(res, e){
                //~ separators['sep_left'].already_opened=true;
                initArtiViewer('viewer_'+partname,params);
                setTimeout(initRangeTracks,500);
                // if (chat){
                //     console.log('open chat here');
                // }
            };
            $_a.send(settings);
               
        }
    }
}

function toogleSyncPlay(){
    let syncswitch=document.getElementById('switch_middle');
    DOM_Class.ToggleClass(syncswitch , 'state_active');
    artiviewers_synctoogled=(artiviewers_synctoogled)?false:true;
    let tfriends=[];
    let friendcounter=0;
    for (const [key, viewer] of Object.entries(artiviewers)) {
      let test=document.getElementById('artiplayer_'+artiviewers[key].name);
        if (test!=undefined){
            tfriends[friendcounter]=artiviewers[key].name;
            friendcounter++;
        }
    }
    if (artiviewers_synctoogled){
        artiviewers[tfriends[0]].friend=artiviewers[tfriends[1]];
        artiviewers[tfriends[1]].friend=artiviewers[tfriends[0]];
    }else{
        artiviewers[tfriends[0]].friend=false;
        artiviewers[tfriends[1]].friend=false;
    }
}

var artiviewer = function(name,params){
    var self = this;
    this.initViewer = function(){
        //dom elements
        //~ console.log(name);
        this.name=name;
        if (params!=undefined){
            this.path=params.path;
            this.type=(params.type!=undefined)?params.type:'video';
        }
        this.artiviewer=document.getElementById('artiviewer_'+this.name);
        // this.artiviewer.style.width='100%';
        this.artiviewercontainer=document.getElementById(this.name);
        
        if (this.type=='video' || this.type=='sequence' ){
            this.initVideo();    
        }
        if (this.type=='image'){
            this.initImage();
        }
        if (this.type=='audio'){
            this.initAudio();
        }
        this.inputEditing=false;
        // setTimeout(function(){self.resizing();},200);
    };
    //reset viewer
    this.reset = function(){
    };
    this.initMarkers=function(){
        svgcontexts[self.name]=[];
        this.markerbar=document.getElementById('markersbar_'+this.name);
        this.markerlist=document.getElementById('artiviewer_commentszone_markers_'+this.name);
        this.markers=[];
        this.markerstimes=[];
        this.markersloaded=false;
        this.markerstodel=[];
        this.convtodel=[];
        this.selectedcolor='white';

        // this.buttondrawpencil=document.getElementById('drawpencil_'+this.name);
        // this.buttonaddtext=document.getElementById('addtext_'+this.name);
        // this.buttondrawline=document.getElementById('drawline_'+this.name);
        // this.buttondrawarrow=document.getElementById('drawarrow_'+this.name);
        // this.buttonerase=document.getElementById('erasepath_'+this.name);
        this.drawingmenu=document.getElementById('btns_draw_'+this.name);
        this.buttonsavemarker=document.getElementById('savemarker_'+this.name);

        this.currentSVG=false;
    };

    this.initPlayerButtons = function(){
        this.buttonforward=document.getElementById('forward_'+this.name);
        this.buttonbackward=document.getElementById('backward_'+this.name);
        this.buttononeframeback=document.getElementById('oneframeback_'+this.name);
        this.buttononeframeforward=document.getElementById('oneframeforward_'+this.name);
        this.buttonleftmarker=document.getElementById('leftmarker_'+this.name);
        this.buttonrightmarker=document.getElementById('rightmarker_'+this.name);
    };

    //init audio feature
    this.initAudio = function(){
        this.player=document.getElementById('artiplayer_'+this.name);
        this.initMarkers();
        this.timeline=document.getElementById('timeline_'+this.name);
        this.jogshutle=document.getElementById('jogshutle_'+this.name);
        
        this.initPlayerButtons();
        self.buttonbackward.style.display='none';
        this.ratefield=document.getElementById('rate_'+this.name);
        
        this.cfps=100;
        this.starttime=document.getElementById('starttime_'+this.name).value;
        this.starttime=hmsfToSeconds(this.starttime,this.cfps);
        
        this.pingpong=false;
        if (isNaN(this.starttime)){
            this.starttime=0;
        }
        //~ console.log('timecode:'+this.starttime);
        this.timecode=document.getElementById('timecode_'+this.name);
        this.timeformat='1';
        this.player.volume=0.5;
        this.scrubbing=false;
        this.intervalPlayer=0;
        this.speedrewind=1;
        this.player.ontimeupdate = (event) => {
            if (!this.forwarding){
                self.updatetimedisplay();
            }
        };
        setTimeout(function(){
            // console.log(document.getElementById('waveformpath_'+self.name).value);
            (function(Peaks) {
                self.peaksoptions = {
                    zoomview: {
                    container: document.getElementById('artiviewer_waveform_'+self.name),
                    playheadClickTolerance: 3
                    },
                    overview: {
                    container: document.getElementById('artiviewer_overview_'+self.name),
                    waveformColor: 'rgba(250,250,250,0.2)',
                    playheadColor: 'rgba(100,100,250,0.8)'
                    },
                    // mediaElement: document.getElementById('artiplayer_'+self.name),
                    // webAudio: {
                    //     audioContext: new AudioContext()
                    //   }
                    
                    mediaElement: document.getElementById('artiplayer_'+self.name),
                    dataUri: {
                    arraybuffer: document.getElementById('waveformpath_'+self.name).value
                    },
                    keyboard: false,
                    playheadColor: 'rgba(250, 250, 250, 1)',
                    waveformColor: 'rgba(8, 148, 210, 1)',
                    pointMarkerColor: '#006eb0',
                    showPlayheadTime: true,
                    waveformCache: true
                    // zoomLevels: [512, 1024, 2048, 4096]
                };
            
                peaks.init(self.peaksoptions, function(err, peaks) {
                    if (err) {
                        console.error('Failed to initialize Peaks instance: ' + err.message);
                        return;
                    }
                // Do something when the waveform is displayed and ready
                    self.peakwaveview = peaks.views.getView('zoomview');
                    self.peakoverview = peaks.views.getView('overview');
                    self.overlaysAndResizeInit();

                    //if the right pannel is resizing we must hide
                    self.pan = new ResizeObserver(entries => {
                        self.hidepeak();
                    });

                    self.pan.observe(document.getElementById('artiviewer_commentszone_'+self.name));
                    self.pan.observe(document.getElementById('artiviewer_'+self.name));
                    self.loadmarkers();
                    self.player.currentTime=0.01;
                });
                // const peakview = peaks.views.getView('zoomview');
            })(peaks);
        },800);
        
    };

    //init video features
    this.initVideo = function(){
        
        this.player=document.getElementById('artiplayer_'+this.name);
        
        this.initMarkers();
        self.markerbuttonstoogle('disable');
        this.timeline=document.getElementById('timeline_'+this.name);
        this.jogshutle=document.getElementById('jogshutle_'+this.name);
        
        this.initPlayerButtons();

        this.pensize=document.getElementById('pensize_'+this.name);
        this.ratefield=document.getElementById('rate_'+this.name);
        this.cfps=document.getElementById('fps_'+this.name).dataset.cfps;
        this.starttime=document.getElementById('starttime_'+this.name).value;
        this.starttime=hmsfToSeconds(this.starttime,this.cfps);
        
        this.pingpong=false;
        if (isNaN(this.starttime)){
            this.starttime=0;
        }
        //~ console.log('timecode:'+this.starttime);
        this.timecode=document.getElementById('timecode_'+this.name);
        this.timeformat='1';
        this.player.volume=0.5;
        this.scrubbing=false;
        this.intervalPlayer=0;
        this.speedrewind=1;
        //~ this.overlaycross=document.getElementById('artiviewer_'+this.name+'_overlaycross');
        
        //events setup
        this.player.ontimeupdate = (event) => {
            let ctime=precision6(self.player.currentTime);
            if (!this.forwarding){
                self.updatetimedisplay();
            }
            if (self.currentSVG && self.currentSVG.timing!=ctime){
                self.currentSVG.style.display='none';
                self.currentSVG=false;
                self.currentSVGContext=false;
            }
            if (!this.forwarding && !this.backwarding && svgcontexts[this.name][ctime] ){
                self.currentSVGContext=svgcontexts[this.name][ctime];
                self.svgcheckload();
                self.currentSVG=document.getElementById('artiviewer_svg_'+self.name+'_'+ctime);
                //~ console.log(self.currentSVG.id);
                // self.currentSVG.style.display='block';
                self.hidesvg('unhide');
                self.markerbuttonstoogle('enable');
                // self.hilightmarker(ctime);
            }else{
                self.markerbuttonstoogle('disable');
                // self.markerbuttonsactivate(false);
            }
        };

        this.firstload=true;

        this.player.onwaiting = (event) => {
            if (!this.firstload){ //the first waiting signal come from the first load....
                this.waitingTest();
            }else{
                this.firstload=false;
            }
        };
        this.videoWidth=0;
        this.videoHeight=0;
        $_e.AddEvent(this.player, 'loadedmetadata', getVideoDimension);
        $_e.AddEvent(this.player, 'canplaythrough', clearWaiting);
        $_e.AddEvent(this.player, 'ended', checklooping);
        $_e.AddEvent(this.player, 'contextmenu', EVENTS_Class.PreventDefault);
        
        this.backwarding=false;
        this.forwarding=false;
        
        $_e.AddEvent(this.pensize,EVENTS_Class.EVENT_KEYUP, manualbrush);
        $_e.AddEvent(this.ratefield,EVENTS_Class.EVENT_KEYUP, manualrate);
        $_e.AddEvent(this.pensize,'focus', editing);
        $_e.AddEvent(this.ratefield,'focus', editing);
        $_e.AddEvent(this.pensize,'blur', notEditing);
        $_e.AddEvent(this.ratefield,'blur', notEditing);
        $_e.AddEvent(this.timeline,EVENTS_Class.EVENT_MOUSEUP, clearscrub);
        //got a friend to sync with ?
        this.friend=false;
        this.forcemuted=false;
        this.loadmarkers();
        // console.log('init video');
    };

    this.hidepeak=function(){
        clearTimeout(self.hidenpeakInterval);
        document.getElementById('artiviewer_waveform_'+self.name).style.display='none';
        document.getElementById('artiviewer_overview_'+self.name).style.display='none';
        self.hidenpeakInterval = setTimeout(function() {
            self.unhidepeak();
        }, 100);
    };

    this.unhidepeak=function(){
        document.getElementById('artiviewer_waveform_'+self.name).style.display='block';
        document.getElementById('artiviewer_overview_'+self.name).style.display='block';
    };


    this.overlaysAndResizeInit = function(){
        self.mouseisover=true;
        //overlays
        if (self.type!='image' && self.type!='audio' ){
            self.overlayaction=document.getElementById('artiviewer_'+self.name+'_overlayaction');
            self.overlayactioninner=document.getElementById('artiviewer_'+self.name+'_overlayactioninner');
            self.overlayoverscan=document.getElementById('artiviewer_'+self.name+'_overlayoverscan');
        }
        $_e.AddEvent(self.artiviewercontainer, 'mouseenter', entering);
        $_e.AddEvent(self.artiviewercontainer, 'mouseleave', outering);
        //~ $_e.AddEvent(this.player, 'onresize', resizing);
        //~ this.player.addEventListener('resize', resizing);
        
        
        self.ro = new ResizeObserver(entries => {
            for (let entry of entries) {
                    // console.log(entry.contentRect.width);
                    // let targetrect=DOM_Class.GetGlobalRect(document.getElementById('artiplayer_'+self.name),true);
                    self.resizing();
            }
            });
        self.ro.observe(document.getElementById('artiviewer_'+self.name));
        self.ro.observe(document.getElementById('artiplayer_'+self.name));
        $_e.AddEvent(document,EVENTS_Class.EVENT_KEYDOWN, checkKey);
        $_e.AddEvent(document,EVENTS_Class.EVENT_KEYUP, checkKeyUp);    
    };
    //init picture features
    this.initImage = function(){
        if (self.currentSVG){
            self.currentSVG.style.display='none';
            self.currentSVG=false;
            self.currentSVGContext=false;
        }
        this.image=document.getElementById('artiplayer_'+this.name);
        //for some function redondancy
        this.player=this.image;
        this.initMarkers();
        self.markerbuttonstoogle('disable');
        this.image.setAttribute('onload','artiviewers["'+this.name+'"].imgLoaded();');
        this.overlaysAndResizeInit();
        this.panpx=0;
        this.panpy=0;
        this.dx=0;
        this.dy=0;
        this.canvasRotation=0;
        this.canvasZoomFactor=1;
        this.canvasTranslate='0px, 0px';
        this.pensize=document.getElementById('pensize_'+this.name);
        $_e.AddEvent(this.pensize,'focus', editing);
        $_e.AddEvent(this.pensize,'blur', notEditing);
        $_e.AddEvent(this.pensize,EVENTS_Class.EVENT_KEYUP, manualbrush);
        //init will finish when the image is loaded to be be able to create corresponding svg
        // console.log('init image');
    };
    this.imgLoaded=function(){
        self.imageWidth=self.image.naturalWidth;
        self.imageHeight=self.image.naturalHeight;
        self.loadmarkers();
        let ctime=0;
        if (svgcontexts[self.name][ctime] ){
            self.currentSVGContext=svgcontexts[self.name][ctime];
            self.svgcheckload();
            self.currentSVG=document.getElementById('artiviewer_svg_'+self.name+'_'+ctime);
            self.currentSVG.style.display='block';
            self.markerbuttonstoogle('enable');
            // self.markerbuttonsactivate(false);
        }
        self.artiviewercontainer.onwheel = self.zoomMolette;

        // self.resizing();
    };
    //left toolbar*
    //-------------------------------------------------------
    
    //add new marker 
    this.addmark = function(loaded=false,firstload=false){
        var colorsel=loaded.color;
        var toload=loaded.filename;
        var ctime=(loaded.time)?precision6(loaded.time):false;
        var idconv=loaded.idconv;
        idconv=(idconv!=undefined)?idconv:0;
        var isdisabled=loaded.disabled;
        isdisabled=(isdisabled!=undefined)?isdisabled:false;
        if (this.type=="image"){
            ctime=0;
            if (loaded.time==undefined){
                colorsel=this.selectedcolor;
                toload=false;
            }
            if (this.markers[ctime]==undefined) {
                this.markerstimes.push(ctime);
                svgcontexts[self.name][ctime] = new svgdrawer(this.name,ctime,self.imageWidth,self.imageHeight,toload);
                svgcontexts[self.name][ctime].init();
                //update
                if (loaded.time==undefined){
                    self.currentSVGContext=svgcontexts[self.name][ctime];
                    self.currentSVG=document.getElementById('artiviewer_svg_'+self.name+'_'+ctime);
                }else{
                    document.getElementById('artiviewer_svg_'+self.name+'_'+ctime).style.display='none';
                    self.currentSVG=false;
                    self.currentSVGContext=false;
                }
                this.markers[ctime]={'time': ctime,'color': colorsel,'filename': toload};
            }else{
                self.currentSVG=document.getElementById('artiviewer_svg_'+self.name+'_'+ctime);
                self.currentSVG.style.display='block';
                self.currentSVGContext=svgcontexts[self.name][ctime];
                this.markers[ctime].color=colorsel;
            }
            
            self.applyCanvasTransform();
            
        }else{
        //type video or sequence or audio
            var timelinepos=loaded.time/self.player.duration*100;
            if (loaded.time==undefined){
                ctime=precision6(self.player.currentTime);
                timelinepos=ctime/self.player.duration*100;
                colorsel=this.selectedcolor;
                toload=false;
            }
            
            ctime=precision6(ctime);
            //~ console.log(ctime+'-'+self.player.currentTime+'-'+self.player.duration+'-'+loaded);
            let marker_exist=document.getElementById('artiviewer_marker_'+this.name+'_'+ctime);
            if (marker_exist==undefined) {
                let nmarker = DOM_Class.CreateElement('DIV',{'class':'artiviewer_marker filter-'+colorsel,'id':'artiviewer_marker_'+this.name+'_'+ctime,'style':'left:calc('+timelinepos+'% - 5px);','data-time':ctime});
                this.markerbar.appendChild(nmarker);
                this.markers[ctime]={'time': ctime,'color': colorsel,'filename': toload,'idconv':idconv,'disabled':isdisabled};
                this.markerstimes.push(ctime);
                $_e.AddEventClick(document.getElementById('artiviewer_marker_'+this.name+'_'+ctime),markerjump);
                if (this.type!="audio"){
                    svgcontexts[self.name][ctime] = new svgdrawer(this.name,ctime,self.videoWidth,self.videoHeight,toload);
                    svgcontexts[self.name][ctime].init();
                    //update
                    if (loaded.time==undefined){
                        self.currentSVGContext=svgcontexts[self.name][ctime];
                        self.currentSVG=document.getElementById('artiviewer_svg_'+self.name+'_'+ctime);
                        this.refreshmarkerlist();
                    }else{
                        document.getElementById('artiviewer_svg_'+self.name+'_'+ctime).style.display='none';
                        self.currentSVG=false;
                        self.currentSVGContext=false;
                    }
                }else{
                    this.refreshmarkerlist();
                }
            }else{
                //~ this.markers[ctime]={'time': ctime,'color': this.selectedcolor};
                // this.markers[precision6(ctime)]={'time': ctime,'color': colorsel,'filename': toload,'idconv':idconv,'disabled':isdisabled};
                this.markers[precision6(ctime)].color=colorsel;
                marker_exist.setAttribute('class','artiviewer_marker filter-'+this.selectedcolor);
                document.getElementById('artiviewer_markerinlist_'+this.name+'_'+ctime).setAttribute('class','artiviewer_marker markerinlist filter-'+colorsel);
                if (this.type!="audio"){
                    self.currentSVG=document.getElementById('artiviewer_svg_'+self.name+'_'+ctime);
                    self.currentSVG.style.display='block';
                    self.currentSVGContext=svgcontexts[self.name][ctime];
                }
            }
            if (!firstload) {
                self.hilightmarker(ctime);
            }
        }
        
        if (this.type!="audio"){
            this.markerbuttonstoogle('enable');
            self.hidesvg('unhide');
        }
        DOM_Class.ReplaceClass(self.buttonsavemarker , 'icon_disable', 'icon_enable');
        if(!firstload){
                self.timedsavemarker();
        }
        
    };
    this.hilightmarker =function(ctime,notforced=true){
        let mlist=document.getElementById('artiviewer_markerinlist_'+self.name+'_'+ctime);
        if (notforced){
            if (self.currentMarker!=undefined){
                if(ctime !=self.currentMarker){
                    DOM_Class.ToggleClass(document.getElementById('artiviewer_marker_'+self.name+'_'+ctime),'current_marker');
                    DOM_Class.ToggleClass(document.getElementById('artiviewer_markerinlist_'+self.name+'_'+ctime),'current_markerlist');     
                    DOM_Class.ToggleClass(document.getElementById('artiviewer_marker_'+self.name+'_'+self.currentMarker),'current_marker',false);
                    DOM_Class.ToggleClass(document.getElementById('artiviewer_markerinlist_'+self.name+'_'+self.currentMarker),'current_markerlist',false);
                    if(mlist){
                        document.getElementById('artiviewer_markerinlist_'+self.name+'_'+ctime).scrollIntoView({behavior: "smooth", block: "end", inline: "nearest"});
                    }
                }
            }else{
                DOM_Class.ToggleClass(document.getElementById('artiviewer_marker_'+self.name+'_'+ctime),'current_marker');
                DOM_Class.ToggleClass(document.getElementById('artiviewer_markerinlist_'+self.name+'_'+ctime),'current_markerlist');     
            }
        }else{
            DOM_Class.ToggleClass(document.getElementById('artiviewer_marker_'+self.name+'_'+self.currentMarker),'current_marker',false);
            DOM_Class.ToggleClass(document.getElementById('artiviewer_markerinlist_'+self.name+'_'+self.currentMarker),'current_markerlist',false);
            DOM_Class.ToggleClass(document.getElementById('artiviewer_marker_'+self.name+'_'+ctime),'current_marker',true);
            DOM_Class.ToggleClass(document.getElementById('artiviewer_markerinlist_'+self.name+'_'+ctime),'current_markerlist',true);
            if(mlist){
                document.getElementById('artiviewer_markerinlist_'+self.name+'_'+ctime).scrollIntoView({behavior: "smooth", block: "end", inline: "nearest"});
            }
        }
        
        self.currentMarker=ctime;
        DOM_Class.ReplaceClass(document.getElementById('movemark_'+self.name) , 'icon_disable', 'icon_enable'); 
    };

    function jumpdel(ctime){
        self.player.currentTime=ctime;
        // self.delmark;
        self.delmark(ctime);
    }

    this.delmark = function(forcedtime=false){
        if ((self.currentSVGContext != false && self.currentSVG!=false)||forcedtime){
            // console.log(self.currentSVGContext);
            let ctime=(forcedtime !== false)?forcedtime:self.currentSVGContext.timing;
            if (self.markers[ctime].idconv!=0){
                UI_Class.ConfirmPopup(CONSTANTS.texts.tlc_del_marker_commentary,function(){self.delmarkconfirmed(ctime);},function(){return false;});
            }else{
                self.delmarkconfirmed(ctime);
            }
           
        }
    };
    this.delmarkconfirmed = function(ctime){
        delete svgcontexts[self.name][ctime];
        self.markerstodel.push(self.markers[ctime].filename);
        //test delete or disable
        let testdel=document.getElementById('delconv_'+self.name);
        // console.log(testdel);
        if (testdel!='undefined'){
            
            if (self.markers[ctime].idconv!=0){
                self.convtodel.push(self.markers[ctime].idconv);
                document.getElementById('artiviewer_commentszone_comments_'+self.name).innerHTML='';
            }
           
            if (this.type !='image'){
                // console.log('removemarinlinst');
                document.getElementById('artiviewer_marker_'+self.name+'_'+ctime).remove();
            }
            if (self.markers[ctime]!='undefined') {
                delete self.markers[ctime];
            }
            // delete self.markerstimes[ctime];
            for( var i = 0; i < self.markerstimes.length; i++){ 
                if ( self.markerstimes[i] === ctime) { 
                    self.markerstimes.splice(i, 1); 
                    // console.log('splicing'+ ctime);
                }
            }
            if (svgcontexts[self.name][ctime]!='undefined') {
                delete svgcontexts[self.name][ctime];
            }
            
        }else{
            self.markers[ctime].disabled=true;
            if (this.type !='image'){
                document.getElementById('artiviewer_marker_'+self.name+'_'+ctime).disabled=true;
            }
        }
        if (document.getElementById('artiviewer_svg_'+self.name+'_'+ctime)!='undefined'){
            document.getElementById('artiviewer_svg_'+self.name+'_'+ctime).remove();
        }
        self.currentSVGContext=false;
        self.currentSVG=false;
        self.refreshmarkerlist();
        self.markerbuttonstoogle('disable');
        // self.markerbuttonsactivate(false);
        DOM_Class.ReplaceClass(self.buttonsavemarker , 'icon_disable', 'icon_enable');
        self.timedsavemarker();

    };

    this.movemark=function(){
        if (self.currentMarker!=undefined){
            if (self.markers[self.player.currentTime]==undefined && self.player.currentTime != self.currentMarker){
                self.markers[self.currentMarker].time=self.player.currentTime;
                self.markers[self.player.currentTime]=self.markers[self.currentMarker];
                self.markerstimes.push(self.player.currentTime);
                //moving marker :
                let timelinemarker=document.getElementById('artiviewer_marker_'+this.name+'_'+self.currentMarker);
                timelinemarker.dataset.time=self.player.currentTime;
                timelinemarker.id='artiviewer_marker_'+this.name+'_'+self.player.currentTime;
                timelinepos=Math.floor(self.player.currentTime/self.player.duration*100000)/1000;
                timelinemarker.style.left='calc( '+timelinepos+'% - 5px )';
                //modifying svg 
                if (self.type!='audio'){
                    let svgcont=svgcontexts[self.name][self.currentMarker];
                    if (svgcont!=undefined){
                        svgcont.timing=self.player.currentTime;
                        svgcont.domID='artiviewer_svg_'+self.name+'_'+self.player.currentTime;
                        svgcont.SGVcontext.id=svgcont.domID;
                        svgcont.saved=false;
                        svgcontexts[self.name][self.player.currentTime]=svgcontexts[self.name][self.currentMarker];
                        delete(svgcontexts[self.name][self.currentMarker]);
                        self.currentSVGContext=svgcontexts[self.name][self.player.currentTime];
                        self.currentSVG=document.getElementById('artiviewer_svg_'+self.name+'_'+self.player.currentTime);
                        self.currentSVG.style.display='block';
                    }
                }
                DOM_Class.ToggleClass(document.getElementById('artiviewer_markerinlist_'+self.name+'_'+self.player.currentTime),'current_marker',true);
                delete(self.markers[self.currentMarker]);
                delete(self.markerstimes[self.currentMarker]);
                self.currentMarker=self.player.currentTime;
                self.refreshmarkerlist();
                DOM_Class.ReplaceClass(self.buttonsavemarker , 'icon_disable', 'icon_enable');
                self.timedsavemarker();
            }
        }
    };
    
    this.hidesvg=function(force){
        if (self.currentSVG ){
            let ctime=self.currentSVGContext.timing;
            if (document.getElementById('artiviewer_svg_'+self.name+'_'+ctime).style.display=='none' || force=='unhide'){
                document.getElementById('artiviewer_svg_'+self.name+'_'+ctime).style.display='block';
                if (self.type=='image'){
                    DOM_Class.RemoveClass(document.getElementById('hidesvg_'+self.name) , 'drawbar_active_icon');
                }
            }else{
                document.getElementById('artiviewer_svg_'+self.name+'_'+ctime).style.display='none';
                if (self.type=='image'){
                    DOM_Class.AddClass(document.getElementById('hidesvg_'+self.name) , 'drawbar_active_icon');
                }
            }
        }
    };

    this.refreshmarkerlist= function(){

        self.markerstimes.sort(function(a, b) { return a - b; });
        self.markerlist.innerHTML='';
        // if (self.type == 'video'){
            // add general to marker list for video, to access the general chat of the file
            // let iscurrent=(self.currentMarker=='general')?' current_marker':'';
            let markertext = DOM_Class.CreateElement('SPAN', {'class':'markertext','id':'artiviewer_markerinlist_markertext_'+self.name+'_general'},'   General');
            let markergeneral = DOM_Class.CreateElement('DIV',{'class':'markerinlist filter-white generalmarker','id':'artiviewer_markerinlist_'+self.name+'_general','style':'position:unset !important;display:block;'});
            DOM_Class.AppendContent(markergeneral,markertext);
            let idgeneral = (self.markers[-1] != undefined)?self.markers[-1].idconv:0;
            $_e.AddEventClick(markergeneral,(event)=>{Conv.Load(false,self.name,idgeneral,'artiviewer_commentszone_comments_' + self.name, self.path);});
            $_e.AddEventClick(markergeneral,(event)=>{self.hilightmarker('general');});
            let unread = DOM_Class.CreateElement('SPAN', {'class':'unread','id':'artiviewer_markerinlist_unread_'+self.name+'_general'});
            DOM_Class.AppendContent(markergeneral,unread);
            self.markerlist.appendChild(markergeneral);
            // let spacer = DOM_Class.CreateElement('DIV',{},' ');
            // self.markerlist.appendChild(spacer);
        // }
        if (self.type!='image'){
            self.markerstimes.forEach(function(ctime){
                if (ctime!= -1){
                    // iscurrent=(self.currentMarker==ctime)?' current_marker':'';
                    let marker=self.markers[ctime];
                    //fixing precision !
                    marker.time=precision6(marker.time);
                    if (marker != undefined){
                        let deletebutton = DOM_Class.CreateElement('BUTTON',{'class':'artiviewer_markerdel', 'id':'artiviewer_markerdl_'+self.name+'_'+marker.time},'X');
                        $_e.AddEventClick(deletebutton,function(){jumpdel(marker.time);});
                        let markertext = DOM_Class.CreateElement('SPAN', {'class':'markertext','id':'artiviewer_markerinlist_markertext_'+self.name+'_'+marker.time},'   '+secondsToHmsf(marker.time,self.cfps));
                        let markerinlist = DOM_Class.CreateElement('DIV',{'class':'markerinlist filter-'+marker.color,'id':'artiviewer_markerinlist_'+self.name+'_'+marker.time,'style':'position:unset !important;display:block;','data-time':marker.time});
                        DOM_Class.AppendContent(markerinlist,markertext);
                        let unread = DOM_Class.CreateElement('SPAN', {'class':'unread','id':'artiviewer_markerinlist_unread_'+self.name+'_'+marker.time});
                        DOM_Class.AppendContent(markerinlist,unread);
                        markerinlist.appendChild(unread);
                        $_e.AddEventClick(markerinlist,markerjump);
                    
                        self.markerlist.appendChild(markerinlist);
                        self.markerlist.appendChild(deletebutton);
                    }
                }
            });
        }
        self.hilightmarker(self.currentMarker,false);
    };

    function precision6(val){
        return Math.round( parseFloat(val) * 10000) / 10000;
    }

    function markerjump(event){
        if (self.currentSVG ){
            self.currentSVG.style.display='none';
        }
        
        let timetojump=event.target.dataset.time;
        self.settime(timetojump);
        self.stop();
        // let prev=(self.currentMarker!=undefined)?self.currentMarker:undefined;
        self.currentMarker=timetojump;
        let marker_exist=document.getElementById('artiviewer_marker_'+self.name+'_'+timetojump);
        if (marker_exist!=undefined) {
            let pannel = document.getElementById('artiviewer_commentszone_'+self.name);
            if (!pannel.classList.contains('hidden')){
                let marker=self.markers[timetojump];
                if (marker.idconv !=undefined){
                    Conv.Load(false,self.name,marker.idconv,'artiviewer_commentszone_comments_' + self.name, self.path, marker.time);
                }else{
                    Conv.Load(false,self.name,0,'artiviewer_commentszone_comments_' + self.name, self.path, marker.time);
                }
                // DOM_Class.ToggleClass(document.getElementById('artiviewer_markerinlist_'+self.name+'_'+timetojump),'current_marker');

            }
        }
        // self.savepossession();
    }
    
    this.drawpencil = function(){
        self.currentSVGContext.drawmode='crayon';
        if (self.RZPMode){
            //we quit the tools
            DOM_Class.RemoveClass(document.getElementById(self.RZPMode+'_'+self.name) , 'drawbar_active_icon');
            pencil.leavePencil();
            self.panzoomRelax();
            self.RZPMode=false;
        }
        UI_Multi_State_lst['btns_draw_' + self.name].setAvatar('drawpencil_'+ self.name);
        // self.markerbuttonsactivate(self.buttondrawpencil);
    };
    this.addtext = function(){
        self.currentSVGContext.drawmode='texte';
        if (self.RZPMode){
            //we quit the tools
            DOM_Class.RemoveClass(document.getElementById(self.RZPMode+'_'+self.name) , 'drawbar_active_icon');
            pencil.leavePencil();
            self.panzoomRelax();
            self.RZPMode=false;
        }
        UI_Multi_State_lst['btns_draw_' + self.name].setAvatar('addtext_'+ self.name);
        // self.markerbuttonsactivate(self.buttonaddtext);
    };
    this.drawline = function(){
        self.currentSVGContext.drawmode='line';
        if (self.RZPMode){
            //we quit the tools
            DOM_Class.RemoveClass(document.getElementById(self.RZPMode+'_'+self.name) , 'drawbar_active_icon');
            pencil.leavePencil();
            self.panzoomRelax();
            self.RZPMode=false;
        }
        UI_Multi_State_lst['btns_draw_' + self.name].setAvatar('drawline_'+ self.name);
        // self.markerbuttonsactivate(self.buttondrawline);
    };
    this.drawarrow = function(){
        self.currentSVGContext.drawmode='arrow';
        if (self.RZPMode){
            //we quit the tools
            DOM_Class.RemoveClass(document.getElementById(self.RZPMode+'_'+self.name) , 'drawbar_active_icon');
            pencil.leavePencil();
            self.panzoomRelax();
            self.RZPMode=false;
        }
        UI_Multi_State_lst['btns_draw_' + self.name].setAvatar('drawarrow_'+ self.name);
        // self.markerbuttonsactivate(self.buttondrawarrow);
    };
    this.erasepath= function(){
        self.currentSVGContext.drawmode='erase';
        if (self.RZPMode){
            //we quit the tools
            DOM_Class.RemoveClass(document.getElementById(self.RZPMode+'_'+self.name) , 'drawbar_active_icon');
            pencil.leavePencil();
            self.panzoomRelax();
            self.RZPMode=false;
        }
        UI_Multi_State_lst['btns_draw_' + self.name].setAvatar('erasepath_'+ self.name);
        // self.markerbuttonsactivate(self.buttonerase);
    };
    this.zoom=function(){
        self.panzoom('zoom');
    };
    this.pan=function(){
        self.panzoom('pan');
    };
    this.rotate=function(){
        if (self.canvasRotation==undefined){
            self.canvasRotation=90; 
        }else{
            // self.canvasRotation+=90;
            self.canvasRotation=(self.canvasRotation==270)?0:self.canvasRotation+90;
        }
        self.applyCanvasTransform();
    };
    this.resetRotate=function(){
        self.canvasRotation=0; 
        self.applyCanvasTransform();
    };
    this.panzoom= function(mode,reset=false){
        if (reset){
            switch(mode){
                case 'zoom':
                    self.canvasZoomFactor=1;
                    self.applyCanvasTransform();
                    //souci de delay !
                    // let targetrect=DOM_Class.GetGlobalRect(document.getElementById('artiplayer_'+self.name),true);
                    self.resizing();
                    break;
                case 'pan':
                    self.canvasTranslate='0px, 0px';
                    self.applyCanvasTransform();
                    break;
            }
            return;
        }
        if (self.RZPMode==mode){
            //we quit the tools
            DOM_Class.RemoveClass(document.getElementById(mode+'_'+self.name) , 'drawbar_active_icon');
            pencil.leavePencil();
            self.panzoomRelax();
            return;
        }
        self.RZPMode=mode;
        if (self.currentSVG) {
            self.currentSVG.parentElement.style.pointerEvents='none';
            self.currentSVG.style.pointerEvents='none';
            self.currentSVG.style.userSelect='none';
            self.currentSVG.setAttribute('draggable', false);
        }
        self.image.style.userSelect='none';
        self.image.setAttribute('draggable', false);

        DOM_Class.AddClass(document.getElementById(mode+'_'+self.name) , 'drawbar_active_icon');
        switch(mode){
            case 'zoom':
                DOM_Class.RemoveClass(document.getElementById('pan_'+self.name) , 'drawbar_active_icon');
                self.image.style.cursor='zoom-in';
                if (self.currentSVG) {
                    self.currentSVG.parentElement.style.cursor='zoom-in';
                    self.currentSVG.style.cursor='zoom-in';
                }
                break;
            case 'pan':
                DOM_Class.RemoveClass(document.getElementById('zoom_'+self.name) , 'drawbar_active_icon');
                self.image.style.cursor='move';
                if (self.currentSVG) {
                    self.currentSVG.parentElement.style.cursor='move';
                    self.currentSVG.style.cursor='move';
                }
                break;
        }
        //events
        if(self.eventsRZP==undefined){
            if (isMac){
                self.image.addEventListener("mousedown", function(e){
                    if (self.RZPMode!=false) {
                        self.startpoint(e);
                    }
                });
                self.image.addEventListener("mouseup", function(){
                    if (self.RZPMode!=false) {
                        pencil.leavePencil();
                        // self.panzoomRelax();
                    }
                });
                self.artiviewercontainer.addEventListener("mouseup", function(){
                    if (self.RZPMode!=false) {
                        pencil.leavePencil();
                        // self.panzoomRelax();
                    }
                });
            }else{
                self.image.addEventListener("pointerdown", function(e){
                    if (self.RZPMode!=false) {
                        self.startpoint(e);
                    }
                });
                self.image.addEventListener("pointerup", function(){
                    if (self.RZPMode!=false) {
                        pencil.leavePencil();
                        // self.panzoomRelax();
                    }
                });
                self.artiviewercontainer.addEventListener("mouseup", function(){
                    if (self.RZPMode!=false) {
                        pencil.leavePencil();
                        // self.panzoomRelax();
                    }
                });
            }
            self.image.addEventListener("touchmove", EVENTS_Class.disableScrollOnTouch, {'passive':false});
            
            self.eventsRZP=true;
            // self.image.addEventListener("pointerleave", function(){
            //     self.panzoomRelax();
            // });

        }
    };
    this.startpoint= function(e){
        // console.log('starting');
        if (svgtargeted && svgtargeted != self.image ){
            self.svgtargetedbackup=svgtargeted;
        }
        svgtargeted=self.image;
        if (!pencil) {
            pencil= new Pencil();
            pencil.init();
        }
        pencil.forceCalculPos(e);
        // let root = document.documentElement;
        // let pencilCoordinates = pencil.getPencilCoordinates();
        
        // if (self.canvasZoomFactor!=1){
            self.mnx=pencil.mouseX-self.panpx;
            self.mny=pencil.mouseY-self.panpy;
        // }else{
        //     self.mnx=pencil.mouseX;
        //     self.mny=pencil.mouseY;
        // }
        self.startingZoomFactor=self.canvasZoomFactor;
        
        // self.nx= (pencilCoordinates.x * self.imageWidth / parseInt(root.style.getPropertyValue('--artiviewersvgwidth_'+self.name)));
        // console.log('NXXXXXX :'+self.nx);
        // self.ny= (pencilCoordinates.y * self.imageHeight / parseInt(root.style.getPropertyValue('--artiviewersvgheight_'+self.name)));

        let pointerType = (e.pointerType) ? e.pointerType : 'mouse';
        switch (pointerType) {
          case 'mouse':
          case 'pen':
            if(e.button===0){
                self.pencilRefreshRate=pencil.getPencilRefreshRate();
                pencil.usePencil();
                let pencilTimemout = setTimeout(panzoomApply, self.pencilRefreshRate);
            }
            break;
          case 'touch':
            e.preventDefault(e);
            setTimeout(function() {
                self.pencilRefreshRate=pencil.getPencilRefreshRate();
                pencil.usePencil();
                let pencilTimemout = setTimeout(panzoomApply, self.pencilRefreshRate);
            }, 100);
            break;
        }

    };
    this.zoomMolette=function(e){
        e.preventDefault();
        self.canvasZoomFactor += e.deltaY * -0.005;
        self.canvasZoomFactor = Math.min(Math.max(0.1, self.canvasZoomFactor), 5);
        self.applyCanvasTransform();
    };

    function panzoomApply(){
        if (self.RZPMode!=false) {
            let pencilCoordinates = pencil.getPencilCoordinates();
            
            let pused=pencil.isPencilUsed();

            if (pencilCoordinates!=undefined && pused ){
                // let root = document.documentElement;
                self.mdx=pencil.mouseX;
                self.mdy=pencil.mouseY;
                // self.dx= (pencilCoordinates.x * self.imageWidth / parseInt(root.style.getPropertyValue('--artiviewersvgwidth_'+self.name)));
                // self.dy= (pencilCoordinates.y * self.imageHeight / parseInt(root.style.getPropertyValue('--artiviewersvgheight_'+self.name)));
                switch(self.RZPMode){
                    case 'zoom':
                        let dif=self.mdx-self.panpx-self.mnx;
                        // let dif=Math.round((Math.round(self.dx)-Math.round(self.nx))*self.startingZoomFactor);
                        // console.log(self.mdx+'-'+self.panpx+'-'+self.mnx+'='+dif);
                        if (dif>1 || dif<-1){
                            self.canvasZoomFactor=self.startingZoomFactor+((dif*2)/window.screen.availWidth);
                            self.canvasZoomFactor = Math.min(Math.max(0.1, self.canvasZoomFactor), 5);
                        }
                        break;
                    case 'pan':

                            self.panpx= self.mdx-self.mnx;
                            self.panpy= self.mdy-self.mny;                           
                            self.canvasTranslate=self.panpx+'px, '+self.panpy+'px';
                        
                        break;

                }
                self.applyCanvasTransform();
                        
            }
            let pencilRefreshRate = pencil.getPencilRefreshRate();
            if(pencil.isPencilUsed()) {
                setTimeout(panzoomApply, pencilRefreshRate);
            }
        }
    }
    this.applyCanvasTransform= function(){
        let transString='';
        if (self.canvasTranslate != undefined){
            transString+='translate('+self.canvasTranslate+')';
        }
        if (self.canvasRotation != undefined){
            transString+='rotate('+self.canvasRotation+'deg)';
        }
        if (self.canvasZoomFactor != undefined){
            transString+=' scale('+self.canvasZoomFactor+')';
        }
        
        // console.log(transString);
        self.image.style.transform=transString;
        if (self.currentSVG) {
            self.currentSVG.parentElement.style.transform=transString;
        }
    };
    this.panzoomRelax= function(){
        if (self.currentSVG) {
            self.currentSVG.parentElement.style.removeProperty('pointer-events');
            self.currentSVG.parentElement.style.removeProperty('cursor');
            self.currentSVG.style.removeProperty('pointer-events');
            self.currentSVG.style.removeProperty('cursor');
        }
        self.image.style.removeProperty('cursor');
        self.RZPMode=false;
        svgtargeted = false;
        if(pencil) {
            pencil.leavePencil();
        }
    };
    this.timedsavemarker=function(){
        // console.log('timedsavedcalled');
        clearTimeout(self.waitingforsave);
        if(!pencil.pencilInUse){
            // console.log('relaunchsave');
            self.waitingforsave = setTimeout(function() {
                self.savemarker();
                // console.log('saving marker!');
            }, 5000);
        }
    };
    this.savemarker= function(){
        // console.log('saving marker');
        self.refreshmarkerlist();
        let settings = {};
        settings.url = CONSTANTS.base_url + 'public/artiviewer/index.php';
        settings.skip_container = true;
        settings.notimer=true;
        let data = new FormData();
        data.append('path', this.player.currentSrc);
        data.append('artiviewer_action', 'savemarkers');
        // let tt =Date.now();
        var myObjectStringify = "{\"markers\":[";
        var filetodel='';
        for (var x in self.markers) {
            if (self.type!='audio'){
                if (svgcontexts[self.name][self.markers[x].time]!=undefined){
                    if (svgcontexts[self.name][self.markers[x].time].saved==false) {
                        //filename will change 
                        if (self.markers[x].filename!=false){
                            self.markerstodel.push(self.markers[x].filename);
                        }
                        self.markers[x].filename=self.markers[x].time+'.svg';
                        // self.markers[x].filename=tt+'_'+self.markers[x].time+'.svg';
                    }
                }
            }
            myObjectStringify += JSON.stringify(self.markers[x])+",";
        }
        filetodel=self.markerstodel.join('¤');
        var convtodel=self.convtodel.join('¤');
        self.markerstodel=[];
        self.convtodel=[];
        data.append('fdel', filetodel);
        data.append('convtodel', convtodel);
        if (myObjectStringify!= "{\"markers\":["){
            myObjectStringify=myObjectStringify.slice(0, -1);
        }
        myObjectStringify += "]}";
        // console.log(myObjectStringify);
        data.append('markerlist', myObjectStringify);
        if (self.type!='audio'){
            this.markerstimes.forEach(function(ctime){
                let svgcontext=svgcontexts[self.name][ctime];
                if (svgcontext!=undefined){
                    if (svgcontext.saved==false){
                        let svgblob=save_svg(svgcontext.SVG);
                        // console.log(ctime+'.svg');
                        data.append('file[]', svgblob, ctime+'.svg');
                        // data.append('file[]', svgblob, tt+'_'+ctime+'.svg');
                    }
                }
            });
        }
        settings.data = data;
        settings.success = function(res){
            if (res == 'saved') {
                DOM_Class.ReplaceClass(self.buttonsavemarker , 'icon_enable', 'icon_disable');
            }else{
                JSON.parse(res);
                if (res['code'] != 0){
                    UI_Class.MessagePopup(res['html']);
                }
                
            }
        };
        
        $_a.send(settings);
    };
    
    this.loadmarkers= function(){
        if (!isNaN(self.player.duration) || this.type=='image' ){
            let markerhiddeninput=document.getElementById('markerjson_'+self.name);
            if (markerhiddeninput!=undefined){
                let markerstring=markerhiddeninput.value;
                if (markerstring!='' && markerstring!="{\"markers\":]}"){
                    let markerstoadd=JSON.parse(markerstring);
                    if (markerstoadd.markers != undefined){
                        for (var i = markerstoadd.markers.length - 1; i > -1;  i--) {
                            if (markerstoadd.markers[i].time!='-1'){
                                self.addmark(markerstoadd.markers[i],true);
                            }
                        }
                    }
                }
                if (this.mode!='image') {
                   
                    self.player.currentTime=0;
                }
                self.currentSVGContext=false;
                self.currentSVG=false;
                
            }
            self.refreshmarkerlist();
            Conv.UpdateListReadState(true,self.name);
        }else{
            self.loadmarkertries=(self.loadmarkertries==undefined)?1:self.loadmarkertries+1;
            if (self.loadmarkertries<10){
                setTimeout(self.loadmarkers,500);
            }
        }
    };
    
    this.svgcheckload=function(){
        let ctime=self.currentSVGContext.timing;
        if (svgcontexts[self.name][ctime].toload!=false){
            let settings = {};
            settings.url = CONSTANTS.base_url + 'public/artiviewer/index.php';
            settings.skip_container = true;
            settings.data = {
                'path':self.path,
                // 'path':this.player.currentSrc,
                'artiviewer_action':'getsvg',
                'svg':svgcontexts[self.name][ctime].toload
            };
            settings.success = function(res, e){
               let parser = new DOMParser();
               let loadedsvg = parser.parseFromString(res, "image/svg+xml");
               loadedsvg.documentElement.id=svgcontexts[self.name][ctime].SGVcontext.id;
               document.getElementById('artiviewer_svg_'+self.name+'_'+ctime).remove();
               svgcontexts[self.name][ctime].SGVcontext=loadedsvg.documentElement;
               svgcontexts[self.name][ctime].createSVG();
               svgcontexts[self.name][ctime].toload=false;
               self.currentSVG=document.getElementById('artiviewer_svg_'+self.name+'_'+ctime);
               self.currentSVG.style.display='block';
            };
            $_a.send(settings);
        }
    };
    
    this.colorpicker = function(event){
        this.selectedcolor=event.target.dataset.value;
    };
    
    // this.markerbuttonsactivate=function(buttonToActivate){
    //     DOM_Class.RemoveClass(this.buttondrawpencil , 'drawbar_active_icon');
    //     DOM_Class.RemoveClass(this.buttondrawline , 'drawbar_active_icon');
    //     DOM_Class.RemoveClass(this.buttonaddtext , 'drawbar_active_icon');
    //     DOM_Class.RemoveClass(this.buttondrawarrow , 'drawbar_active_icon');
    //     DOM_Class.RemoveClass(this.buttonerase , 'drawbar_active_icon');
    //     if (buttonToActivate){
    //         DOM_Class.AddClass(buttonToActivate , 'drawbar_active_icon');
    //     }
    // };
    
    this.markerbuttonstoogle= function(state){
        if (state=='disable'){
            // DOM_Class.ReplaceClass(this.buttondrawpencil , 'icon_enable', 'icon_disable');
            // DOM_Class.ReplaceClass(this.buttonaddtext , 'icon_enable', 'icon_disable');
            // DOM_Class.ReplaceClass(this.buttondrawline , 'icon_enable', 'icon_disable');
            // DOM_Class.ReplaceClass(this.buttondrawarrow , 'icon_enable', 'icon_disable');
            // DOM_Class.ReplaceClass(this.buttonerase , 'icon_enable', 'icon_disable');
            DOM_Class.ReplaceClass(this.drawingmenu.firstChild , 'icon_enable', 'icon_disable');
            self.drawingmode=false;
        }else{
            // DOM_Class.ReplaceClass(this.buttondrawpencil , 'icon_disable', 'icon_enable');
            // DOM_Class.ReplaceClass(this.buttonaddtext , 'icon_disable', 'icon_enable');
            // DOM_Class.ReplaceClass(this.buttondrawline , 'icon_disable', 'icon_enable');
            // DOM_Class.ReplaceClass(this.buttondrawarrow , 'icon_disable', 'icon_enable');
            // DOM_Class.ReplaceClass(this.buttonerase , 'icon_disable', 'icon_enable');
            DOM_Class.ReplaceClass(this.drawingmenu.firstChild , 'icon_disable', 'icon_enable');
            self.drawingmode=true;
        }
    };

    function getVideoDimension(event){
        self.videoWidth = event.target.videoWidth,
        self.videoHeight = event.target.videoHeight;
        self.overlaysAndResizeInit();
        
        if (self.player.dataset.stime != undefined){
            //un shortcut a été employé on doit jumper
            setTimeout(function(){
                let marker=self.markers[self.player.dataset.stime];
                if (marker!=undefined && marker.idconv !=undefined){
                    //force pannel openingpannel,'hidden');
                    DOM_Class.RemoveClass(document.getElementById('artiviewer_commentszone_'+self.name),'hidden');
                    //simulate click on marker to open conv:
                    let targ='';
                    // console.log(self.player.dataset.stime);
                    if (self.player.dataset.stime==-1){
                        targ='artiviewer_markerinlist_'+self.name+'_general';
                    }else{
                        targ='artiviewer_marker_'+self.name+'_'+self.player.dataset.stime;
                    }
                    EVENTS_Class.SendEventClick(document.getElementById(targ));
                }else{
                    self.settime(precision6(self.player.dataset.stime));
                }

            },500);
        }else{
            // console.log(1/self.cfps);
            setTimeout(function(){self.begining();},400);
        }
        // setTimeout(function(){self.resizing();},200);
    }
    
    function entering(){
        self.mouseisover=true;
    }
    function outering(){
        self.mouseisover=false;

    }
    
    this.resizing=function(){
        
        //en mode horizontal il faut tenir compte du changmeent d'aspect ratio car la height retournée ne corrspond pas à l'affichage de la vidéo mais de la balise
        // console.log('resize');
        let margintopadd=0;
        let theight=0;
        let tratio=1;
        let playerrect = DOM_Class.GetGlobalRect(document.getElementById('artiplayer_'+self.name),true);
            if(playerrect!=undefined){
            var width=playerrect.width;
            var height=playerrect.height;
            if ( this.type=='image') {
                
                tratio=self.imageWidth/self.imageHeight;
            }else{
                if (this.player.style.aspectRatio!=''){
                    tratio=eval(this.player.style.aspectRatio);
                }else{
                    tratio=self.videoWidth/self.videoHeight;
                }
            }
            theight= width/tratio;
            if (theight<height){
                margintopadd=((height-theight)/2);
            }else{
                theight=height;
            }
            //resizing svg vars
            let root = document.documentElement;

            if (this.type=='video' || this.type=='sequence'){
                let zone =width/100*7.5;
                let subzone = zone/2;
                this.overlayaction.style.width=(width-zone)+'px';
                this.overlayaction.style.height=(theight-zone)+'px';
                this.overlayactioninner.style.width=(width-(zone*2))+'px';
                this.overlayactioninner.style.height=(theight-(zone*2))+'px';
                this.overlayaction.style.margin=subzone+'px';
                // this.overlayaction.style.marginTop='calc('+(subzone+margintopadd)+'px + calc(10px * var(--fhd-vr)))';
                this.overlayaction.style.marginTop='calc('+(subzone+margintopadd)+'px * var(--fhd-vr))';
                this.overlayactioninner.style.margin=subzone+'px';
                
                this.overlayoverscan.style.width=(width-zone)+'px';
                // this.overlayoverscan.style.width=(width-zone-2)+'px';
                this.overlayoverscan.style.height=(theight-zone+1)+'px';
                // this.overlayoverscan.style.height=(theight-zone-2)+'px';
                this.overlayoverscan.style.borderLeft=(subzone+1)+'px solid var(--back-color)';           
                this.overlayoverscan.style.borderRight=(subzone+1)+'px solid var(--back-color)';           
                this.overlayoverscan.style.borderBottom=(subzone+1)+'px solid var(--back-color)';           
                // this.overlayoverscan.style.borderBottom=(subzone-1)+'px solid var(--back-color)';           
                // this.overlayoverscan.style.borderTop=(subzone)+'px solid var(--back-color)';
                this.overlayoverscan.style.borderTop=(subzone+1)+'px solid var(--back-color)';
                // this.overlayoverscan.style.marginTop='calc('+(margintopadd)+'px + calc(10px * var(--fhd-vr)))';      
                this.overlayoverscan.style.marginTop='calc('+(margintopadd)+'px * var(--fhd-vr))';      
                // -this.overlayoverscan.style.marginTop='calc('+(margintopadd)+'px + calc(10px * var(--fhd-vr)))';      
                    
                // root.style.setProperty('--artiviewercontmarg_'+self.name, 'calc('+(margintopadd)+'px + calc(10px * var(--fhd-vr)))');artiviewercontmarg_viewer_left 
                root.style.setProperty('--artiviewercontmarg_'+self.name, 'calc('+(margintopadd)+'px * var(--fhd-vr))');
                setTimeout(function(){
                    document.getElementById('artiviewer_'+self.name+'_svgcontainer').style.marginTop='var(--artiviewercontmarg_'+self.name+')'; 
                    self.cleanratio();
                },200);
            }
            

          
            root.style.setProperty('--artiviewersvgwidth_'+self.name, width+'px');
            root.style.setProperty('--artiviewersvgheight_'+self.name, theight+'px');
            root.style.setProperty('--artiviewersvgratio_'+self.name, tratio);
            if (self.type=='audio'){
                // console.log((width-76)+'px');
                // setTimeout(function(){
                    let pannelrect = DOM_Class.GetGlobalRect(document.getElementById('artiviewer_commentszone_'+self.name),true);
                    let viewerRect=DOM_Class.GetGlobalRect(document.getElementById(self.name),true);
                    document.getElementById('artiviewer_waveform_'+self.name).style.width=((viewerRect.width-pannelrect.width)-125)+'px';
                    // console.log((viewerRect.width-pannelrect.width)-125);
                    // document.getElementById('artiviewer_waveform_'+self.name).style.width='100%';
                    let timelinerect=DOM_Class.GetGlobalRect(document.getElementById('timeline_'+self.name),true);
                    document.getElementById('artiviewer_overview_'+self.name).style.width=(timelinerect.width)+'px';
                    // document.getElementById('artiviewer_overview_'+self.name).style.width='100%';
                setTimeout(function(){
                    self.peakwaveview.fitToContainer();
                    self.peakoverview.fitToContainer();
                },200);
            }
        }
    };

    
    //keyboard events for video
    //------------------------------------------------------------
    this.jogj = function(){
            if (this.player.paused && this.backwarding==false){
                this.jogshutle.value=40;
            }else{
            if (this.jogshutle.value > 0){
                this.jogshutle.value-=10;
                if (this.jogshutle.value==50) {
                    this.jogshutle.value=40;
                }
            }
        }
        this.jogshutle.style.setProperty('--value', this.jogshutle.value);
        this.changerate(parseInt(this.jogshutle.value));   
    };
    
    this.jogk = function(){
        if (this.player.paused && !this.backwarding){
            this.jogshutle.value=60;
            this.jogshutle.style.setProperty('--value', this.jogshutle.value);           
            this.changerate(parseInt(this.jogshutle.value));
            
        }else{
            this.stop();
        }
        
    };
    
    this.jogl = function(){
        if (this.player.paused){
            this.jogshutle.value=60;
        }else{
            if (this.jogshutle.value < 100){
                this.jogshutle.value=parseInt(this.jogshutle.value)+10;
                if (this.jogshutle.value==50) {
                    this.jogshutle.value=60;
                }
            }
        }
        
        this.jogshutle.style.setProperty('--value', this.jogshutle.value);
        this.changerate(parseInt(this.jogshutle.value));
    };
    function checkKeyUp(e){
        if (self.mouseisover==true && !artiviewerKeypressedLock && !self.inputEditing){
            switch (e.key){
                case ' ':
                e.preventDefault();
                    if (self.type=='image'){
                        if(self.RZPMode=="pan"){
                            DOM_Class.RemoveClass(document.getElementById(self.RZPMode+'_'+self.name) , 'drawbar_active_icon');
                            pencil.leavePencil();
                            self.panzoomRelax();
                            self.RZPMode=false;
                            self.panMode=false;
                        }
                    }
                
                    break;
            }
        }
    }
    function checkKey(e){
        if (self.mouseisover==true && !artiviewerKeypressedLock && !self.inputEditing){
            // console.log(e);
            switch (e.key){
                case ' ':
                    e.preventDefault();
                    if (self.type=='image'){
                        if (e.ctrlKey) {
                            self.panzoom('pan',true);
                        }else{
                            if(!self.panMode || self.panMode==undefined){
                                self.panMode=true;
                                self.panzoom('pan');
                            }
                        }
                    }else{
                        // console.log(e);
                        if (self.backwarding==true){
                            self.backward(e);
                        }else{
                            // console.log('pouet');
                            self.forward(e);
                        }
                    }
                    break;
                case 'f' :
                    UI_Multi_State_lst['fullscreen_' + self.name].next(true);
                    break;
                case 'a' :
                    if (this.type!='image'){
                        UI_Multi_State_lst['aspectratio_' + self.name].next(true);
                    }
                    break;
                case 'h' :
                    self.hidesvg();
                    break;
                case 'j' :
                    if (this.type!='image'){
                        self.jogj();
                    }
                    break;
                case 'k' :
                    if (this.type!='image'){
                        self.jogk();
                    }
                    break;
                case 'l' :
                    if (this.type!='image'){
                        self.jogl();
                    }
                    break;
                case 'Delete' :
                case 'Backspace' :
                    self.delmark();
                    break;
                case '!' :
                    self.movemark();
                    break;
                case 'm' :
                    self.addmark();
                    break;
                case 'p' :
                    self.drawpencil();
                    break;
                case 'c' :
                    EVENTS_Class.SendEventClick(document.getElementById('colorpicker_'+self.name).firstChild);
                    break;
                case 't' :
                    self.addtext();
                    break;
                case 'i' :
                    self.drawline();
                    break;
                case 'o' :
                    self.drawarrow();
                    break;
                case 'e' :
                    self.erasepath();
                    break;
                case 's' :
                    self.savemarker();
                    break;
                case 'g' :
                    self.shortcutage();
                    break;
                case 'n' :
                    self.mute();
                    break;
                case 'w' :
                    if (e.ctrlKey && e.altKey) {
                        UI_Class.MessagePopup('Made By :<br>---<br>Mickael Bourgeoisat<br>Emile Steiner<br>Francois Grassard<br>---<br>Left Angle 2022<br>');
                    }
                    break;
                case '+' :
                    if (self.drawingmode){
                        if (strokeWidth<51){
                            strokeWidth++;
                            document.getElementById('pensize_' + self.name).value=strokeWidth;
                            if (self.friend){
                                document.getElementById('pensize_' + self.friend.name).value=strokeWidth;
                            }
                        }
                    }else{
                        if (self.player.volume<1){
                            let new_volume=parseInt(self.player.volume*100+5);
                            self.setvolume(new_volume);
                            document.getElementById('volume_' + self.name).value=new_volume;
                            document.getElementById('volume_' + self.name).style.setProperty('--value',new_volume);
                            self.setvolume(new_volume);
                        }
                    }
                    break;
                case '-' :
                    if (self.drawingmode){
                        if (strokeWidth>0.9){
                            strokeWidth--;
                            document.getElementById('pensize_' + self.name).value=strokeWidth;
                            if (self.friend){
                                document.getElementById('pensize_' + self.friend.name).value=strokeWidth;
                            }
                        }
                    }else{
                        if (self.player.volume>0){
                            let new_volume=parseInt(self.player.volume*100-5);
                            document.getElementById('volume_' + self.name).value=new_volume;
                            document.getElementById('volume_' + self.name).style.setProperty('--value',new_volume);
                            self.setvolume(new_volume);
                        }
                    }
                    break;
                case 'ArrowUp' :
                    // up arrow
                    e.preventDefault();
                    self.scrubbing=false;
                    
                    if (self.player.currentTime + 1 > self.player.duration){
                        self.player.currentTime =  self.player.duration - 0.01;
                    }else{
                        self.player.currentTime += 1;
                        if (self.friend){
                            self.friend.settime(self.player.currentTime,true);
                        }
                    }
                    //loop mode 
                    //~ self.player.currentTime += 1;
                    //~ if (self.player.currentTime>=(self.player.duration-(1 / self.cfps))){
                        //~ self.player.currentTime=(1 / self.cfps);
                    //~ }
                    
                    break;
                case 'ArrowDown' :
                    // down arrow
                    e.preventDefault();
                    self.scrubbing=false;
                    self.player.currentTime -= 1;
                    if (self.player.currentTime < 0){
                        self.player.currentTime =  0 ;
                    }
                    //loop mode
                    //~ if ( self.player.currentTime<=0){
                        //~ self.player.currentTime=self.player.duration-1;
                    //~ }
                    if (self.friend){
                        self.friend.settime(self.player.currentTime,true);
                    }
                    break;
                case 'ArrowLeft' :
                   if (e.ctrlKey) {
                        self.begining();
                   }else if (e.shiftKey){
                        e.preventDefault();
                        self.scrubbing=false;
                        self.leftmarker();
                   }else{
                   // right arrow
                        self.oneframeback(e);
                   }
                   break;
                case 'ArrowRight' :
                   if (e.ctrlKey) {
                        self.end();
                   }else if (e.shiftKey){
                        e.preventDefault();
                        self.scrubbing=false;
                        self.rightmarker();
                   }else{
                        self.oneframeforward(e);
                   }
                   break;
                case 'z' :
                    if((e.ctrlKey || e.metaKey) && self.currentSVGContext){
                        self.currentSVGContext.removeLast();
                    }else{
                        if (self.type=='image'){
                                if (e.altKey) {
                                    self.panzoom('zoom',true);
                                }else{
                                    self.panzoom('zoom');
                                }
                            
                        }
                    }
                    break;
                case 'd' :
                    if (self.type=='image'){
                        DOM_Class.RemoveClass(document.getElementById('pan_'+self.name) , 'drawbar_active_icon');
                        DOM_Class.RemoveClass(document.getElementById('zoom_'+self.name) , 'drawbar_active_icon');
                        self.panpx=0;
                        self.panpy=0;
                        self.canvasRotation=0;
                        self.canvasZoomFactor=1;
                        self.canvasTranslate='0px, 0px';
                        self.applyCanvasTransform();
                        self.panzoomRelax();
                    }
                    break;
                case 'r' :
                    if (self.type=='image'){
                        if (e.altKey) {
                            self.resetRotate(true);
                        }else{
                            self.rotate();
                        }
                    }
                    break;
            }
        }
    }
    function editing(event){
        self.inputEditing=true;
    }
    
    function notEditing(event){
        self.inputEditing=false;
    }
    
    function manualbrush(event,called=false){
        //changement de la taille de la brush
        if (event.key=="Enter") {
            self.pensize.blur();
        }else{
            let value = parseInt(self.pensize.value);
            if (!isNaN(value)) {
                if (value< 51 && value > 0.9){
                    strokeWidth=value;
                    if (self.friend && !called){
                        self.friend.manualbrush(event,true);
                    }
                }else{
                    self.pensize.value=strokeWidth;
                }
            }
        }
    }
    //right toolbar for video
    //--------------------------------------------------------------
    this.mute = function(event){
        if (this.player.muted==true || this.forcemuted){
            this.player.muted=false;
            document.getElementById('mute_'+this.name).style.backgroundPositionX='calc(-540px * var(--fhd-vr))';
            this.forcemuted=false;
        }else{
            this.player.muted=true;
            document.getElementById('mute_'+this.name).style.backgroundPositionX='calc(-570px * var(--fhd-vr))';
        }
    };
    this.forcemute =function(){
        if (this.player.muted!=true) {
            this.forcemuted=true;
        }
        this.player.muted=true;
        // document.getElementById('mute_'+this.name).innerHTML='<div class="artiviewer_cross"></div>';
        document.getElementById('mute_'+this.name).style.backgroundPositionX='calc(-570px * var(--fhd-vr))';
    };
    
    this.setvolume = function(volume){
        document.getElementById('volume_value_'+this.name).innerHTML=volume+'%';
        this.player.volume=volume/100;
    };
    
    this.cleanratio =function(){
        let selectedRatio=self.player.style.aspectRatio;
        let playercontainer = DOM_Class.GetGlobalRect(this.player.parentNode,true);
        switch (selectedRatio){
            case '16 / 9' :
            case '21 / 9' :
            case '4 / 3' :
            case '1 / 1' :
                // this.player.style.width='unset';
               
                this.player.style.height='calc('+playercontainer.width+'px / calc('+selectedRatio+'))';
                this.player.style.maxWidth='100%';
                this.player.style.objectFit='fill';
                this.player.style.aspectRatio=selectedRatio;
                break;
            case '9 / 16' :
                this.player.style.height='100%';
                this.player.style.maxWidth='';
                this.player.style.objectFit='fill';
                this.player.style.aspectRatio=selectedRatio;
                break;
            default :
                let tratio=self.videoWidth/self.videoHeight;
                if (tratio >= 1) {
                    let playercontainer = DOM_Class.GetGlobalRect(this.player.parentNode,true);
                    this.player.style.height='calc('+playercontainer.width+'px / calc('+tratio+'))';
                    this.player.style.maxWidth='100%';
                    this.player.style.objectFit='';
                    this.player.style.aspectRatio='';
                }else{
                    this.player.style.height='100%';
                    this.player.style.maxWidth='';
                    this.player.style.objectFit='';
                    this.player.style.aspectRatio='';
                }
                break;

        }
    };

    this.ratio = function(event){
        let button=event.target;
        let selectedRatio=button.dataset.value;
        switch (selectedRatio){
            case 'native' :
                // this.player.style.objectFit='fill';
                // this.player.style.aspectRatio='';
                // this.player.style.width='';
                // this.player.style.height='';
                // this.player.style.objectFit='';
                // this.player.style.maxWidth='100%';
                let tratio=self.videoWidth/self.videoHeight;
                if (tratio >= 1) {
                    let playercontainer = DOM_Class.GetGlobalRect(this.player.parentNode,true);
                    this.player.style.height='calc('+playercontainer.width+'px / calc('+tratio+'))';
                    this.player.style.maxWidth='100%';
                    this.player.style.objectFit='';
                    this.player.style.aspectRatio='';
                }else{
                    this.player.style.height='100%';
                    this.player.style.maxWidth='';
                    this.player.style.objectFit='';
                    this.player.style.aspectRatio='';
                }
                
                break;
            // case '16/9' :
            // case '21/9' :
            //     this.player.style.maxWidth='100%';
            //     this.player.style.height='fit-content';
            //     this.player.style.objectFit='fill';
            //     this.player.style.aspectRatio=selectedRatio;
            //     break;
            case '16/9' :
            case '21/9' :
            case '4/3' :
            case '1/1' :
                // this.player.style.width='unset';
                let playercontainer = DOM_Class.GetGlobalRect(this.player.parentNode,true);

                this.player.style.height='calc('+playercontainer.width+'px / calc('+selectedRatio+'))';
                this.player.style.maxWidth='100%';
                this.player.style.objectFit='fill';
                this.player.style.aspectRatio=selectedRatio;
                break;
            case '9/16' :
                this.player.style.height='100%';
                //  this.player.style.height='calc(100% * 0,5625)';
                this.player.style.maxWidth='';
                this.player.style.objectFit='fill';
                this.player.style.aspectRatio=selectedRatio;
                break;
        }
        this.player.style.aspectRatio=selectedRatio;
        // setTimeout(function(){self.resizing();},100);
        // console.log('artiviewer_'+self.name+'_svgcontainer');
        
    };
    
    this.resolution = function(event){
        let button=event.target;
        this.selectedRes=button.dataset.value;
        clearTimeout(self.waitingInterval);
        this.firstload=true;
        if (this.selectedRes!='download'){
            let settings = {};
            settings.url = CONSTANTS.base_url + 'public/artiviewer/index.php';
            settings.skip_container = true;
            settings.data = {
                'path':this.player.currentSrc,
                'artiviewer_action':'newres',
                'resolution':this.selectedRes
            };
            settings.success = function(res, e){
                self.changeSource(res);
            };
            $_a.send(settings);
        }else{
            if(this.selectedRes!=undefined){
                let settings = {};
                settings.url = CONSTANTS.base_url + 'public/artiviewer/index.php';
                settings.skip_container = true;
                settings.data = {
                    'path':this.player.currentSrc,
                    'artiviewer_action':'downproxy',
                    'resolution':this.selectedRes
                };
                settings.success = function(res){
                    res = JSON.parse(res);
                    if (res['code'] == 0){
                        window.open(res['url'],'_blank');
                        // let tempIframe = DOM_Class.CreateElement("iframe", {"src": res['url'], "id": "download_iframe", "title": "DOWNLOAD"});
                        // UI_Class.popupSpecial['filemanager'].SetContent(tempIframe.outerHTML);
                        // UI_Class.popupSpecial['filemanager'].Show();
                        // let downloadPopup = window.open(res['url'],'_blank');
                    } else {
                        UI_Class.popupSpecial['filemanager'].SetContent(res['html']);
                        UI_Class.popupSpecial['filemanager'].Show();
                    }
                };
                
                $_a.send(settings);
            
            }
        }
    };
    
    this.changeSource = function(source){
        let ttime=self.player.currentTime;
        this.firstload=true;
        clearTimeout(self.waitingInterval);
        self.player.src=source;
        self.player.dataset.stime=ttime;
        self.player.load();
        // setTimeout(function(){self.player.currentTime=ttime;},200);
         //avoid missmatch with a real lag
        if (self.backwarding){
            setTimeout(self.backward('rate'),2000);
        }else if (self.forwarding){
            self.forwarding=false;
            setTimeout(self.forward(),2000);
        }
    };
    
   
    this.waitingTest =function(){
        console.log('waiting data....');
             self.waitingInterval = setTimeout(function() {
                self.reduceResolution();
                console.log('too much network lag!');
            }, 5000);

    };
    
    function clearWaiting(){
        clearTimeout(self.waitingInterval);
        if (!timer_modal_is_hide){
            timer_modal.Hide();
        }
    }
    
    this.reduceResolution = function(){
        console.log('we must reduce quality...');
        clearTimeout(self.waitingInterval);
        let currentVal=document.getElementById('resolution_'+self.name).firstChild.dataset.value;
        if (currentVal !='360' && currentVal !='download'){
            UI_Multi_State_lst['resolution_' + self.name].next();
        }
    };
    
    this.overlay = function(event){
        let overlaytotoogle=event.target.dataset.value;
        let overlaytarget='';
        switch (overlaytotoogle){
            case '1' :
                    overlaytarget=this.overlayaction;
                break;
            case '2' :
                    overlaytarget=this.overlayoverscan;
                break;
            case '3' :
                    overlaytarget=this.overlaycross;
                break;
        }
        overlaytarget.style.display=(overlaytarget.style.display=='none')?'block':'none';
    };
    
    this.fullscreen = function(event){
        let dismode=event.target.dataset.value;
        switch (dismode){
            case '1' :
                DOM_Class.RemoveClass(this.artiviewercontainer,'artiviewer_maximized');
                if (document.fullscreen){
                    document.exitFullscreen();
                }
                if (self.type=='image'){
                    self.panzoom('zoom',true);
                    // let targetrect=DOM_Class.GetGlobalRect(document.getElementById('artiplayer_'+self.name),true);
                    
                }
                // setTimeout(function(){self.resizing();},300);
                break;
            case '2' :
                DOM_Class.AddClass(this.artiviewercontainer,'artiviewer_maximized');
                if (self.type=='image'){
                    self.panzoom('zoom',true);
                    // let targetrect=DOM_Class.GetGlobalRect(document.getElementById('artiplayer_'+self.name),true);
                }
                // $_e.SendEvent(self.artiviewer,'click');
                // setTimeout(function(){self.resizing();},300);
                break;
            case '3' :
                self.player.requestFullscreen();
                break;
        }
        
    };
    
    
    //main video controls 
    //--------------------------------------------------------------------
    this.begining = function(event,called=false){
        self.player.currentTime=(1/self.cfps);
        if (self.friend && !called){
            self.friend.begining(event,true);
        }
    };

    //create a path shortcut callable with artiviewerSelect and paste it in the clipboard.
    this.shortcutage = function(){
        if (this.type=='image'){
            $uri=document.getElementById('orpath_'+this.name).value;
            $formateduri=document.getElementById('orpath_'+this.name).value;
        }else{
            $uri=document.getElementById('orpath_'+this.name).value+"?"+self.player.currentTime;
            $formateduri=document.getElementById('orpath_'+this.name).value+" - "+secondsToHmsf(self.player.currentTime,self.cfps);
        }
        $contentToCopy='<span onclick="artiviewerShortcutJump(event,\''+$uri+'\');" data-type="artiviewerShortcutJump(event,\''+$uri+'\');" data-type="'+this.type+'" class="shortmarker mceNonEditable">'+$formateduri+'</span>';
        // console.log($contentToCopy);
        copyToClipboard($contentToCopy,true,true);
    };

    this.leftmarker = function(event){
        var founded=false;
        for (var i = 0; i < this.markerstimes.length; i++){    
            let marker=self.markers[self.markerstimes[i]];
            if (marker!=undefined){
                if (marker.time < (self.player.currentTime - 0.001)){
                    founded=marker.time;
                }
                if (marker.time >= self.player.currentTime){
                    break;
                }
            }
        }
        if (founded || founded === 0){
            
            if (self.currentSVG ){
                self.currentSVG.style.display='none';
            }
            console.log(founded);
            // self.stop();
            self.settime(founded);
            // $_e.SendEventClick(document.getElementById('artiviewer_marker_'+self.name+'_'+founded));
        }
    };
    
    this.oneframeback = function(event,called=false){
       //~ event.preventDefault();
        this.timeline.blur();
        self.scrubbing=false;
        self.player.currentTime -= (1 / self.cfps);
        if (self.player.currentTime < (1 / self.cfps)){
            self.player.currentTime =  (1 / self.cfps) ;
        }
        //loopmode
        //~ self.player.currentTime -= (1 / self.cfps);
        //~ if ( self.player.currentTime<=(1 / self.cfps)){
            //~ self.player.currentTime=self.player.duration-(1 / self.cfps);
        //~ }
        if (self.friend && !called){
            self.friend.settime(this.player.currentTime,true);
        }
    };
    
    this.navbuttonstoggle= function(state){
        if (state=='disable'){
            DOM_Class.ReplaceClass(this.buttononeframeback , 'icon_enable', 'icon_disable');
            DOM_Class.ReplaceClass(this.buttononeframeforward , 'icon_enable', 'icon_disable');
            DOM_Class.ReplaceClass(this.buttonleftmarker , 'icon_enable', 'icon_disable');
            DOM_Class.ReplaceClass(this.buttonrightmarker , 'icon_enable', 'icon_disable');
        }else{
            DOM_Class.ReplaceClass(this.buttononeframeback , 'icon_disable', 'icon_enable');
            DOM_Class.ReplaceClass(this.buttononeframeforward , 'icon_disable', 'icon_enable');
            DOM_Class.ReplaceClass(this.buttonleftmarker , 'icon_disable', 'icon_enable');
            DOM_Class.ReplaceClass(this.buttonrightmarker , 'icon_disable', 'icon_enable');
        }
    };
    
    
    this.backward = function(force,called=false){
        clearInterval(self.intervalPlayer);
        clearInterval(self.waitingInterval);
        self.waitingInterval=false;
        this.forwarding=false;
        if (this.backwarding==true && force!="rate"){
            this.stop();
        }else{
            if(!this.backwarding){
                
                if (self.currentSVG){
                    self.currentSVG.style.display='none';
                }
                
                this.backwarding=true;
                this.scrubbing=false;
                if (this.type!='audio'){
                    this.buttonbackward.style='background-position: calc(-90px * var(--fhd-vr)) 0px;';
                }
                this.buttonforward.style='background-position: calc(-120px * var(--fhd-vr)) 0px;';
                
                this.navbuttonstoggle('disable');
                
                this.jogshutle.value=40;
                this.jogshutle.style.setProperty('--value', this.jogshutle.value);
                
                this.player.pause();
                self.speedrewind=1;
                this.ratefield.value=-1;
                this.intervalPlayer = setInterval(function() {
                    
                    if(self.player.currentTime < (1/self.cfps)){
                        
                       if (self.player.loop==true){
                            self.player.currentTime=self.player.duration-(1/self.cfps);
                       }else{
                            if(self.pingpong==false){
                                self.stop();
                            }else{
                                self.stop();
                                self.forward();
                            }
                       }
                    }
                    else {
                        self.backwarding=true;
                        self.player.currentTime += -(1/self.cfps);
                    }
                }, 1000/ self.speedrewind / self.cfps);

            }else{
                //we change the interval rate !
                this.intervalPlayer = setInterval(function() {
                    
                    if(self.player.currentTime < (1/self.cfps)){
                       if (self.player.loop==true){
                            self.player.currentTime=self.player.duration-(1/self.cfps);
                       }else{
                            if(self.pingpong==false){
                                self.stop();
                            }else{
                                self.stop();
                                self.forward();
                            }
                       }
                    }
                    else {
                        self.backwarding=true;
                        self.player.currentTime += -(1/self.cfps);
                    }
                }, 1000/ self.speedrewind / self.cfps);
                
            }
            if (self.friend && !called){
                self.friend.backward(force,true);
            }
        }
        
       
    };
    
    
    this.forward = function(event,called=false){
        this.backwarding=false;
        clearInterval(self.intervalPlayer);
        clearInterval(self.waitingInterval);
        self.waitingInterval=false;
        if (this.forwarding==true){
            this.stop();
        }else{
            
            if (self.currentSVG){
                self.currentSVG.style.display='none';
            }
            
            this.backwarding=false;
            this.scrubbing=false;
            this.forwarding=true;
            if (this.type!='audio'){
                this.buttonbackward.style='background-position: calc(-60px * var(--fhd-vr)) 0px;';
            }
            this.buttonforward.style='background-position: calc(-90px * var(--fhd-vr)) 0px;';
            
            this.navbuttonstoggle('disable');
            
            this.jogshutle.value=60;
            this.ratefield.value=1;
            this.player.playbackRate=1;
            this.jogshutle.style.setProperty('--value', this.jogshutle.value);
            try {
                if (this.forcemuted && !called) {
                    this.mute();
                }
                this.player.play(); //trig a waiting sometime later...
               
            } catch (err) {
                setTimeout(self.forward(),2000);
            }
            this.intervalPlayer = setInterval(function() {
                self.updatetimedisplay();
            }, 1000/self.cfps);
            if (self.friend && !called){
                self.friend.forcemute();
                self.friend.forward(event,true);
            }
            
            
        }
        
    };
    
    checklooping=function(){
        //~ if (self.pingpong==true && self.player.currentTime==self.player.duration){
        if (self.pingpong==true){
            //~ self.stop();
            self.backward();
        }else{
            if (self.player.currentTime==self.player.duration){
                self.stop();
            }
        }
    };
    
    this.updatetimedisplay = function(){
        switch (self.timeformat){
            case '1' :
                    self.timecode.innerHTML=secondsToHmsf(self.player.currentTime,self.cfps);
                break;
            case '2' :
                    self.timecode.innerHTML=secondsToHmsf((self.player.currentTime+self.starttime),self.cfps);
                break;
            case '3' :
                    self.timecode.innerHTML=Math.floor(self.player.currentTime*self.cfps)+'/'+Math.floor(self.player.duration*self.cfps);
                    // self.timecode.innerHTML=Math.round(precision6(self.player.currentTime*self.cfps))+'/'+Math.round(precision6(self.player.duration*self.cfps));
                break;
            }
        self.timeline.value=self.player.currentTime/self.player.duration*100;
        self.timeline.style.setProperty('--value', self.timeline.value);
    };
    
    this.oneframeforward = function(event,called=false){
       this.timeline.blur();
       self.scrubbing=false;
       
       if (self.player.currentTime + (1 / self.cfps) >= self.player.duration){
            self.player.currentTime =  self.player.duration - 0.01 ;
        }else{
            self.player.currentTime += (1 / self.cfps);
            if (self.friend){
                self.friend.settime(self.player.currentTime,true);
            }
        }
       //loop mode
       //~ self.player.currentTime += (1 / self.cfps);
        //~ if ( self.player.currentTime>=(self.player.duration-(1 / self.cfps))){
            //~ self.player.currentTime=(1 / self.cfps);
       //~ }
       //~ if (self.friend && !called){
            //~ self.friend.settime(this.player.currentTime,true);
        //~ }
    };
    
    this.rightmarker = function(button){
        var founded=false;
        for (var i = 0; i < this.markerstimes.length; i++){    
            let marker=self.markers[self.markerstimes[i]];
            if (marker!=undefined){
                if (marker.time  > ( self.player.currentTime + 0.001)){
                    founded=marker.time;
                    break;
                }
            }
        }
        
        if (founded){
            if (self.currentSVG ){
                self.currentSVG.style.display='none';
            }
            self.settime(founded);
        }
        
    };
    this.end = function(event,called=false){
         this.player.currentTime=this.player.duration-((1 / self.cfps)/10);
        if (self.friend && !called){
            self.friend.end(event,true);
        }
    };
    this.changeloop = function(event,called=false){
        let selectedloopmode=event.target.dataset.value;
        switch (selectedloopmode){
            case '1' :
                    this.player.loop=true;
                    this.pingpong=false;
                break;
            case '2' :
                    this.player.loop=false;
                    this.pingpong=false;
                break;
            case '3' :
                    this.player.loop=false;
                    this.pingpong=true;
                    //~ console.log('PINNNNGG');
                break;
        }
        if (self.friend && !called){
            let tnamep=event.target.parentElement.id.split(self.name);
            let tname=event.target.id.split(self.name);
            UI_Multi_State_lst[tnamep[0] + self.friend.name].setAvatar(tname[0] + self.friend.name+tname[1]);
            self.friend.changeloop(event,true);
        }
    };
    
    this.stop = function(event,called=false){
        // let ttime=this.player.currentTime; // keep it to force refresh it after stoping instruction.
        //precision ...
        let ttime=precision6(self.player.currentTime);
        this.player.pause();
        clearInterval(this.intervalPlayer);
        clearInterval(this.waitingInterval);
        this.jogshutle.value=50;
        this.jogshutle.style.setProperty('--value', this.jogshutle.value);
        this.backwarding=false;
        this.forwarding=false;
        this.ratefield.value=0;
        this.buttonforward.style='background-position: calc(-120px * var(--fhd-vr)) 0px;';
        if (this.type!='audio'){
            this.buttonbackward.style='background-position: calc(-60px * var(--fhd-vr)) 0px;';
        }
        
        this.navbuttonstoggle('enable');
        this.player.currentTime=ttime;
        this.savepossession();
        if (self.friend && !called){
            self.friend.stop(event,true);
            self.friend.player.currentTime=ttime;
        }
    };

    this.savepossession=function(){
        let settings = {};
        settings.url = CONSTANTS.base_url + 'public/artiviewer/index.php';
        // settings.dom_target='viewer_'+partname;
        let pannel = document.getElementById('artiviewer_commentszone_'+self.name);
        let mlist=(!pannel.classList.contains('hidden'))?true:false;

        settings.data = {
            'artiviewer_action':'artiviewer_session_update',
            'path':self.path,
            'mlist':mlist,
            'currentTime':self.player.currentTime,
        };
        settings.notimer=true;
        // settings.success = function(res, e){
            // console.log(res);
        // };
        $_a.send(settings);
    };
    
    this.changetimecode = function(event,called=false){
        this.timeformat=event.target.dataset.value;
        this.updatetimedisplay();
        if (self.friend && !called){
            let tnamep=event.target.parentElement.id.split(self.name);
            let tname=event.target.id.split(self.name);
            UI_Multi_State_lst[tnamep[0] + self.friend.name].setAvatar(tname[0] + self.friend.name+tname[1]);
            self.friend.changetimecode(event,true);
        }
    };
    
    this.settimeline = function(perce,called=false){
        this.firstload=true;
        this.scrubbing=true;
        let timedif=(this.player.duration/100*perce)%(1/this.cfps);
        if (timedif!=0){
            if (perce==100){
                this.player.currentTime=this.player.duration-0.01;
            }else{
                this.player.currentTime=(this.player.duration/100*perce)-timedif;
            }
            self.timeline.value=self.player.currentTime/self.player.duration*100;
            self.timeline.style.setProperty('--value', self.timeline.value);
            
        }else{
            this.player.currentTime=(this.player.duration/100*perce);
        }
        if (self.friend && !called){
            self.friend.settime(this.player.currentTime,true);
        }
        
    };
    
    this.settime = function(ntime,called=false){
        this.firstload=true;
        this.scrubbing=true;
        this.player.pause();
        this.player.currentTime=(ntime < this.player.duration)?ntime:(this.player.duration-((1 / self.cfps)/10));
        // this.player.currentTime=(this.player.currentTime < (1 / self.cfps))?(1 / self.cfps):this.player.currentTime;

        self.hilightmarker(ntime);
        if (self.friend && !called){
            self.friend.settime(ntime,true);
        }
    };
    
    function clearscrub(called=false){
        //~ console.log('clear');
         if (self.backwarding){
            self.backward('rate');
        }else if (self.forwarding){
            self.forwarding=false;
            self.forward();
        }else{
            self.savepossession();
        }
        if (self.friend && !called){
            self.friend.clearscrub(true);
        }
    }
    
    this.changerate = function(rate,called=false){
        //changement du rate depuis le job shuttle, les raccourcits claviers ou appelée par la saisie dans le field rate
        // if (this.jogshutle.value > 49 || this.type =='audio'){
        if (this.jogshutle.value > 49){
            if (this.backwarding) {
                clearInterval(this.intervalPlayer);
                clearInterval(this.waitingInterval);
                this.backwarding=false;
            }
            this.scrubbing=false;
            let tval=(this.type !='audio')?this.jogshutle.value-50:this.jogshutle.value/2;
            let pspeed=1*(tval/10);
            this.ratefield.value=pspeed;
            this.player.playbackRate=pspeed;
            if (this.player.paused ) {
                this.forward();
            }
        }else{
            let pspeed=(this.jogshutle.value-50)/10;
            this.speedrewind= pspeed - (pspeed * 2);
            this.ratefield.value=pspeed;
            this.backward('rate');
        }
        if (self.friend && !called){
            self.friend.jogshutle.value=this.jogshutle.value;
            self.friend.jogshutle.style.setProperty('--value', this.jogshutle.value);
            self.friend.changerate(rate,true);
        }
    };
    
    function manualrate(event,called=false){
        //changement du rate depuis la saisie dans le champs rate
        if (event.key=="Enter") {
            self.ratefield.blur();
        }else{
            let value = parseInt(self.ratefield.value);
            if (!isNaN(value)) {
                if (value< 6 && value > -6){
                    let nrate=(value+5)*10;
                    self.jogshutle.value=nrate;
                    self.jogshutle.style.setProperty('--value', self.jogshutle.value);
                    self.changerate(nrate);
                    if (self.friend && !called){
                        self.friend.manualrate(event,true);
                    }
                }
            }
        }
    }
    
    this.tooglerightpannel=function(){
        let pannel = document.getElementById('artiviewer_commentszone_'+this.name);
        // if (pannel.style.display=='none'){
        //     // if (this.type=='audio'){

        //     // }
        //     pannel.style.display='block';
        //     this.artiviewer.style.width='unset';
        // }else{
        //     pannel.style.display='none';
            // this.artiviewer.style.width='100%';
            DOM_Class.ToggleClass(pannel,'hidden');
            if (!pannel.classList.contains('hidden')){
                let marker=self.markers[self.currentMarker];
                if (marker.idconv!=undefined){
                    Conv.Load(false,self.name,marker.idconv,'artiviewer_commentszone_comments_' + self.name, self.path, marker.time);
                }
            }
        // }
        
    };
};
// time display converters
secondsToHmsf = ( d, fps = 24 ) => {
   let h =  ('0' + Math.floor( d / 3600 )).substr( -2 );
   let m =  ('0' + Math.floor( d % 3600 / 60 )).substr( -2 );
   let s =  ('0' + Math.floor( d % 60 )).substr( -2 );
   let f =Math.floor((d*fps)%fps);
//    let f =Math.round( parseFloat((d*fps)%fps) * 10000) / 10000;
   f =  ('0' + f).substr( -2 );
   if (f=='-1'){
    f='00';
   }
   return `${h}:${m}:${s}:${f}`;
};

hmsfToSeconds = ( d, fps = 24 ) => {
   let timecode = d.split(':');
   let seconds = (+timecode[0]) * 3600 + (+timecode[1]) * 60 + (+timecode[2]);
   if (timecode[3]>0 && timecode[3]<fps){
       //~ seconds+= 1/fps*((+timecode[3])-1);
       seconds+= 1/fps*(+timecode[3]);
   }
   return seconds;
};

//drawinf svg section

var pencil=false;
var svgtargeted=false;
var strokeWidth = 8;
var svgcontexts=[];

var svgdrawer = function (viewername,timing,width,height,toload) {
    var self = this;
    this.init = function(){
        this.toload=toload;
        this.viewer_name=viewername;
        this.timing=timing;
        this.svgwidth=width;
        this.svgheight=height;
        this.svgcontainer=document.getElementById('artiviewer_'+this.viewer_name+'_svgcontainer');
        //creating the SVG:
        this.domID='artiviewer_svg_'+viewername+'_'+timing;
        this.svgcontainer.style='width:var(--artiviewersvgwidth_'+viewername+');height:var(--artiviewersvgheight_'+viewername+');';
        this.SGVcontext = DOM_Class.CreateElement('SVG',{'xmlns':'http://www.w3.org/2000/svg','version':'1.2','id':this.domID,'class':'artiviewer_svg','viewBox':'0 0 '+this.svgwidth+' '+this.svgheight,'preserveAspectRatio':'none'});
        //arrow head !
        let defs = document.createElementNS('http://www.w3.org/2000/svg', 'defs');
        let arrow = document.createElementNS('http://www.w3.org/2000/svg', 'marker');
        arrow.setAttribute("id","arrowhead"+this.timing);
        arrow.setAttribute("markerWidth","10");
        arrow.setAttribute("markerHeight","7");
        arrow.setAttribute("refX","0");
        arrow.setAttribute("refY","3.5");
        arrow.setAttribute("orient","auto");
        let polygon = document.createElementNS('http://www.w3.org/2000/svg', 'polygon');
        polygon.setAttribute("points","0 0, 10 3.5, 0 7");
        polygon.setAttribute("fill","#FFF");
        //~ let arrowhead = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        //~ arrowhead.setAttribute("d","M 0 0 L 10 5 L 0 10 z");
        //~ arrowhead.setAttribute("fill","context-stroke");
        arrow.appendChild(polygon);
        defs.appendChild(arrow);
        this.SGVcontext.appendChild(defs);
        this.erasepossible=false;
        self.createSVG();        
    };
    this.removeLast=function(){
        // console.log('eee');
        self.SVG.removeChild(self.SVG.lastChild);
    };
    this.createSVG=function(){
        self.svgcontainer.appendChild(this.SGVcontext);
        self.SVG=document.getElementById(this.domID);
        self.drawmode='crayon';
        settarget();
        if (!pencil) {
            pencil= new Pencil();
            pencil.init();
        }
        self.initEvents();
    };
    
    this.initEvents=function(){
        if ((isMac || isMacLike) && !isIOS){
            this.SVG.addEventListener("mousedown", function(e){
                self.erasepossible=true;
                if (self.drawmode!='erase'){
                    draw(e);
                }
            });
        }else{
            this.SVG.addEventListener("pointerdown", function(e){
                self.erasepossible=true;
                if (self.drawmode!='erase'){
                    draw(e);
                }
            });
        }
        this.SVG.addEventListener("pointermove", function(e){
            if (self.drawmode=='erase'){
                erase(e);
            }
        });
        if ((isMac || isMacLike) && !isIOS){
            this.SVG.addEventListener("mouseup", function(){
                self.erasepossible=false;
                pencil.leavePencil();
                self.saved=false;
                DOM_Class.ReplaceClass(document.getElementById('savemarker_'+viewername) , 'icon_disable', 'icon_enable');
                artiviewers[viewername].timedsavemarker();
            });
        }else{
             this.SVG.addEventListener("pointerup", function(){
                self.erasepossible=false;
                pencil.leavePencil();
                self.saved=false;
                DOM_Class.ReplaceClass(document.getElementById('savemarker_'+viewername) , 'icon_disable', 'icon_enable');
                artiviewers[viewername].timedsavemarker();
            });
        }
        this.SVG.addEventListener("touchmove", EVENTS_Class.disableScrollOnTouch, {'passive':false});
    
        $_e.AddEvent(this.SVG, 'pointerenter', settarget);
        $_e.AddEvent(this.SVG, 'pointerleave', killtarget);
    };
    
    function settarget(){
        svgtargeted = self.SVG;
    }
    function killtarget(){
        svgtargeted = false;
        pencil.leavePencil();
    }
    function draw(e){
        let pointerType = (e.pointerType) ? e.pointerType : 'mouse';
        pencil.forceCalculPos(e);
        //    
        if (artiviewers[self.viewer_name].type=='image'){
            //can be RPZed ...
            self.canvasZoomFactor=artiviewers[self.viewer_name].canvasZoomFactor;
            self.canvasTranslate=artiviewers[self.viewer_name].canvasTranslate;
            self.canvasRotation=artiviewers[self.viewer_name].canvasRotation;
            self.parentType='image';
        }else{
            self.parentType='video';
        }
        switch (pointerType) {
          case 'mouse':
          case 'pen':
            if(e.button===0){
                self.path=self.createPath(e);
                self.pencilRefreshRate=pencil.getPencilRefreshRate();
                pencil.usePencil();
                let pencilTimemout = setTimeout(completePath, self.pencilRefreshRate, self.path);
            }
            break;
          case 'touch':
            event.preventDefault(e);
            setTimeout(function() {
                self.path=self.createPath();
                self.pencilRefreshRate=pencil.getPencilRefreshRate();
                pencil.usePencil();
                let pencilTimemout = setTimeout(completePath, self.pencilRefreshRate, self.path);
            }, 100);
            break;
        }
        //change mode to add 
        
    }
    function erase(e){
        if(self.erasepossible){
            var element = document.elementFromPoint(e.pageX, e.pageY);
            if (element.tagName=="path" || element.tagName=="line" || element.tagName=="text"){
                element.remove();
                self.saved=false;
            } 
        }
    }

    this.createPath=function(e) {
        var path='';
        if (self.drawmode=='crayon'){
            path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        }
        if (self.drawmode=='texte'){
            path = document.createElementNS('http://www.w3.org/2000/svg', 'text');
            
        }
        if (self.drawmode=='line' || self.drawmode=='arrow'){
            path = document.createElementNS('http://www.w3.org/2000/svg', 'line');
        }
        if (self.drawmode=='arrow'){
            path.setAttribute("marker-end","url(#arrowhead"+self.timing+")");
        }
        let pencilCoordinates = pencil.getPencilCoordinates();
        var nx=0;
        var ny=0;
        let root = document.documentElement;
        if ( self.parentType=='image') {
            self.strokeScale=1;
            self.strokeScale=self.canvasZoomFactor;
           
            nx= pencilCoordinates.x * self.svgwidth / ((parseInt(root.style.getPropertyValue('--artiviewersvgwidth_'+self.viewer_name))) *self.canvasZoomFactor);
            ny= pencilCoordinates.y * self.svgheight / ((parseInt(root.style.getPropertyValue('--artiviewersvgheight_'+self.viewer_name))) *self.canvasZoomFactor);
            if( self.canvasRotation==90){
                let tc=nx;
                nx=ny;
                ny=self.svgheight-tc;
            }
            if( self.canvasRotation==180){
                nx=self.svgwidth-nx;
                ny=self.svgheight-ny;
            }
            if( self.canvasRotation==270){
                let tc=nx;
                nx=self.svgwidth-ny;
                ny=tc;
            }
            nx =(nx>self.svgwidth)?self.svgwidth:nx;
            nx =(nx<0)?0:nx;
            ny =(ny>self.svgheight)?self.svgheight:ny;
            ny =(ny<0)?0:ny;

        }else{

            self.strokeScale=1;
            nx= pencilCoordinates.x * self.svgwidth / parseInt(root.style.getPropertyValue('--artiviewersvgwidth_'+self.viewer_name));
            nx =(nx>self.svgwidth)?self.svgwidth:nx;
            nx =(nx<0)?0:nx;
            ny= pencilCoordinates.y * self.svgheight / parseInt(root.style.getPropertyValue('--artiviewersvgheight_'+self.viewer_name));
            ny =(ny>self.svgheight)?self.svgheight:ny;
            ny =(ny<0)?0:ny;

        }
        if (self.drawmode!='texte'){
            path.setAttribute("fill","none");
            path.setAttribute("stroke","#fff");
            path.setAttribute("stroke-width",strokeWidth/self.strokeScale);
        }
        path.setAttribute("class","filter-"+artiviewers[self.viewer_name].selectedcolor);
        
        if (self.drawmode=='crayon'){
            path.setAttribute("d","M"+nx+" "+ny);
            self.SVG.appendChild(path);
        }
        if (self.drawmode=='line' || self.drawmode=='arrow'){
            path.setAttribute("x1",nx);
            path.setAttribute("y1",ny);
            path.setAttribute("x2",nx);
            path.setAttribute("y2",ny);
            self.SVG.appendChild(path);
        }
        if (self.drawmode=='texte'){
            element = document.elementFromPoint(e.pageX, e.pageY);
            if (element.tagName=="text"){
                //we got already a text element
                self.currenttext=element;
                self.currenttextpath=false;
                pencil.leavePencil();
                self.modalAskText();
            }else{
                //nope we should add a new one
                path.setAttribute("x",nx);
                path.setAttribute("y",ny);
                path.setAttribute("fill","#fff");
                path.setAttribute("font-size",(strokeWidth*3/self.strokeScale));
                self.currenttext=false;
                self.currenttextpath=path;
                pencil.leavePencil();
                self.modalAskText();
            }
        }
        
        return path;
    };

    this.modalAskText=function(){
        artiviewerKeypressedLock=true;
        if (!this.textmodal){
            this.textmodal = UI_Class.AddWindow(null, {'modal': true, 'class': 'artiviewer_text_modal ui_window special', 'hidden': true});
            let div_form = DOM_Class.CreateElement('DIV', {'class': 'artiviewer_text_modal_form', 'id':'text_form_'+self.domID});
            let title = DOM_Class.CreateElement('DIV', {'class': 'artiviewer_text_modal_title'}, 'Please insert text');
            div_form.appendChild(title);
            let inp = DOM_Class.CreateElement('INPUT', {'id': 'text_modal_inp_'+self.domID, 'size':'50','class': 'artiviewer_text_modal_inp'});
            $_e.AddEvent(inp, 'keypress', function(evt){
                        if(evt.keyCode == 13){
                            setTextContent(event.target.value);
                        }
                    });
            div_form.appendChild(inp);
            let ok = DOM_Class.CreateElement('BUTTON', {'class': 'artiviewer_text_modal_ok'}, 'Ok');
            $_e.AddEvent(ok, 'mousedown', function(event){
                        setTextContent(event.target.previousElementSibling.value);
                    });
            div_form.appendChild(ok);
            this.textmodal.SetContent(div_form);
            this.textmodal.SetParent(document.getElementById('artiviewer_'+this.viewer_name+'_svgcontainer'));
        }
        let inputt=document.getElementById('text_modal_inp_'+self.domID);
        if (self.currenttext){
            inputt.value=self.currenttext.textContent;
        }else{
            inputt.value='';
        }
        this.textmodal.Show();
        setTimeout(function(){
            let inputt=document.getElementById('text_modal_inp_'+self.domID);
            inputt.focus();
            inputt.select();
        },200);
    };
    
    function setTextContent(textContent){
        if (self.currenttext){
            self.currenttext.textContent=textContent;
            self.currenttext=false;
            if (textContent==''){
                self.currenttext.remove();
            }
        }
        if (self.currenttextpath){
            if (textContent!=''){
                self.currenttextpath.textContent=textContent;
                self.SVG.appendChild(self.currenttextpath);
                self.currenttextpath=false;
            }
        }
        self.textmodal.Hide();
        artiviewerKeypressedLock=false;
        self.saved=false;
        DOM_Class.ReplaceClass(document.getElementById('savemarker_'+viewername) , 'icon_disable', 'icon_enable');
        artiviewers[viewername].timedsavemarker();
    }
    
    
    function completePath(path) {
        let pencilCoordinates = pencil.getPencilCoordinates();
        
        let pused=pencil.isPencilUsed();
        var nx=0;
        var ny=0;
        if (pencilCoordinates!=undefined && pused ){
            
            let d = path.getAttribute("d");
            let root = document.documentElement;
            if ( self.parentType=='image') {
                nx= pencilCoordinates.x * self.svgwidth / ((parseInt(root.style.getPropertyValue('--artiviewersvgwidth_'+self.viewer_name))) *self.canvasZoomFactor);
                ny= pencilCoordinates.y * self.svgheight / ((parseInt(root.style.getPropertyValue('--artiviewersvgheight_'+self.viewer_name))) *self.canvasZoomFactor);
                if( self.canvasRotation==90){
                    let tc=nx;
                    nx=ny;
                    ny=self.svgheight-tc;
                }
                if( self.canvasRotation==180){
                    nx=self.svgwidth-nx;
                    ny=self.svgheight-ny;
                }
                if( self.canvasRotation==270){
                    let tc=nx;
                    nx=self.svgwidth-ny;
                    ny=tc;
                }
                nx =(nx>self.svgwidth)?self.svgwidth:nx;
                nx =(nx<0)?0:nx;
                ny =(ny>self.svgheight)?self.svgheight:ny;
                ny =(ny<0)?0:ny;
    
            }else{
                nx= pencilCoordinates.x * self.svgwidth / parseInt(root.style.getPropertyValue('--artiviewersvgwidth_'+self.viewer_name));
                nx =(nx>self.svgwidth)?self.svgwidth:nx;
                nx =(nx<0)?0:nx;
                ny= pencilCoordinates.y * self.svgheight / parseInt(root.style.getPropertyValue('--artiviewersvgheight_'+self.viewer_name));
                ny =(ny>self.svgheight)?self.svgheight:ny;
                ny =(ny<0)?0:ny;
            }
            if (self.drawmode=='crayon'){
                d += " L"+nx+" "+ny;
                path.setAttribute("d",d); 
            }
            if (self.drawmode=='line' || self.drawmode=='arrow'){
                d = self.startingpoint+" L"+nx+" "+ny;
                path.setAttribute("x2",nx);
                path.setAttribute("y2",ny);
            }
                      
        }
        let pencilRefreshRate = pencil.getPencilRefreshRate();
        if(pencil.isPencilUsed()) {
            setTimeout(completePath, pencilRefreshRate, path);
        }
    }
};

//pencil for draw...
var Pencil = function () {
    var self = this;

    this.init = function(){
        this.pencilCoordinates=false;
        this.pencilVelocity=0;
        this.pencilInUse=false;
        window.addEventListener("pointermove", calculPos);
    };
    
    this.getPencilCoordinates = function() {
        return self.pencilCoordinates;
    };

    this.getPencilVelocity = function() {
        return self.pencilVelocity;
    };
    
    this.getPencilRefreshRate = function() {
        let invVelocity = 1 / ((self.pencilVelocity > 1) ? self.pencilVelocity : 1);
        self.refreshRate = invVelocity * 80 * (strokeWidth / 50);
        self.refreshRate;
    };
    
    this.isPencilUsed = function() {
        return self.pencilInUse;
    };
    
    this.usePencil = function() {
        self.pencilInUse = true;
    };
    
    this.leavePencil = function() {
        self.pencilInUse = false;
        self.pencilCoordinates = undefined;
    };
    this.forceCalculPos = function(e) {
        calculPos(e);
    };
    function calculPos(e){
        if (svgtargeted){
            let rect = DOM_Class.GetGlobalRect(svgtargeted,true);

            
            //~ switch (e.pointerType) {
              //~ case 'mouse':
              //~ case 'pen':
                nextPencilCoordinates = {
                    x: e.pageX - rect.left,
                    y: e.pageY - rect.top
                };
                //~ break;
              //~ case 'touch':
                //~ nextPencilCoordinates = {
                    //~ x: e.clientX||e.touches[0].clientX - rect.left,
                    //~ y: e.clientY||e.touches[0].clientY - rect.top
                //~ };
                //~ break;
            //~ }
          
            if(!self.pencilCoordinates) {
                self.pencilCoordinates = nextPencilCoordinates;
            }
            self.mouseX=e.pageX;
            self.mouseY=e.pageY;

            const pencilXDelta = nextPencilCoordinates.x - self.pencilCoordinates.x;
            const pencilYDelta = nextPencilCoordinates.y - self.pencilCoordinates.y;
            self.pencilVelocity = Math.sqrt(Math.pow(pencilXDelta,2)+Math.pow(pencilYDelta,2));
            self.pencilCoordinates = nextPencilCoordinates;
            // console.log(self.pencilCoordinates);
        }
    }
};

function save_svg(SVG,targetdl=false){
    let serializer = new XMLSerializer();
    let source = serializer.serializeToString(SVG);

    //add name spaces.
    if(!source.match(/^<svg[^>]+xmlns="http\:\/\/www\.w3\.org\/2000\/svg"/)){
        source = source.replace(/^<svg/, '<svg xmlns="http://www.w3.org/2000/svg"');
    }
    if(!source.match(/^<svg[^>]+"http\:\/\/www\.w3\.org\/1999\/xlink"/)){
        source = source.replace(/^<svg/, '<svg xmlns:xlink="http://www.w3.org/1999/xlink"');
    }

    //add xml declaration
    //~ source = '<'+'?xml version="1.0" standalone="no"?'+'>\r\n' + source;

    //convert to blob
    let blob = new Blob([source], {type: 'image/svg+xml'});
    if(!targetdl){
        return blob;
    }else{
        //convert svg source to URI data scheme.
        let url = "data:image/svg+xml;charset=utf-8,"+encodeURIComponent(source);
        //set url value to a element's href attribute.
        //we(ll fill an href src to permit download on click
        document.getElementById(targetdl).href = url;  
        document.getElementById(targetdl).style = "display:inline-block;";  
    }
}

var Artiuser = function(){
    this.submitOnChangeRight = function(evt){
        let targ = evt.target;
        let settings = {};
        settings.url = CONSTANTS.base_url + 'public/artiuser/index.php';
        settings.dom_container = '';
        settings.skip_container = true;
        settings.data = {
            'artiuser_action': 'artiuser_save',
            'type': targ.name,
            'id': targ.value,
            'val': (targ.checked) ? 1 : 0
        };
        $_a.send(settings);
    };
    
    this.refreshPending = function(){
        let settings = {};
        settings.url = CONSTANTS.base_url + 'public/artiuser/index.php';
        settings.dom_container = '';
        //~ settings.skip_container = true;
        settings.data = {
            'artiuser_action': 'artiuser_refresh_pending'
        };
        settings.success = function(res){
            let targ = document.getElementById('artiuser_block_pending');
            if (targ){
                DOM_Class.WriteHtml(targ, res);
                //~ targ.innerHTML = res;
            }
        };
        $_a.send(settings);
    };
};
var artiuser = new Artiuser();
var Artipermission = function(){
    this.submitOnChangeRight = function(evt){
        let targ = evt.target;
        let settings = {};
        settings.url = CONSTANTS.base_url + 'public/artipermission/index.php';
        settings.dom_container = '';
        settings.skip_container = true;
        settings.data = {
            'artipermission_action': 'artipermission_save_field',
            'type': targ.name,
            'id': targ.value,
            'val': (targ.checked) ? 1 : 0
        };
        $_a.send(settings);
    };
    this.deleteRight = function(evt,id,path=false){
        let targ = evt.target;
        let settings = {};
        settings.url = CONSTANTS.base_url + 'public/artipermission/index.php';
        settings.dom_container = '';
        settings.skip_container = true;
        settings.data = {
            'artipermission_action': 'artipermission_delete',
            'id':id,
            'widget': path ? 1 : 0
        };
        // on success delete row from DOM
        settings.success = function(res){
            // debugger;
            let row = document.getElementById('artipermission_line_'+id);
            DOM_Class.RemoveElement(row);
            if (path){
            //     let container = document.getElementById('artipermission_container');
            //     if (container){
            //         DOM_Class.WriteHtml(container,res);
            //     }

                let domElems = document.querySelectorAll('.filemanager_tree_item[data-path="'+ path + '/"], .filemanager_tree_item[data-path="'+ path + '"]');
                let ids = [];
                for (let index = 0; index < domElems.length; index++) {
                    ids.push(domElems[index].id);
                }
                Filemanager_displaySharedState(ids);
            }

            // }
        };
        $_a.send(settings);
    };
    this.addRight = function(domId, path=false){
        let form = document.getElementById(domId);
        let settings = {};
        settings.url = CONSTANTS.base_url + 'public/artipermission/index.php';
        settings.dom_container = 'artipermission_container';
        settings.skip_container = true;
        settings.data = form;
        settings.success = function(res){
            let container = document.getElementById('artipermission_container');
            if (container){
                DOM_Class.WriteHtml(container,res);
            }
            // debugger;
            if (path){
                let domElems = document.querySelectorAll('.filemanager_tree_item[data-path="'+ path + '/"], .filemanager_tree_item[data-path="'+ path + '"]');
                let ids = [];
                for (let index = 0; index < domElems.length; index++) {
                    ids.push(domElems[index].id);
                }
                Filemanager_displaySharedState(ids);
            }
        };
        $_a.send(settings);
    };
};
var artipermission = new Artipermission();
var Settings = function(){};
Settings.onChangeMultipleCheckbox = function(event){
    
    let input = event.target;
    // if unchecked, verify that it's not the last
    if (input.checked == false){
        let form = input.form;
    
        let realName = input.dataset.name;
        let inputLst = form.querySelectorAll('[data-name="' + realName + '"]');
        
        let nothing_checked = true;
        for (let i = 0; i < inputLst.length; i++){
            if (inputLst[i] != input && inputLst[i].checked){
                nothing_checked = false;
                break;
            }
        }
        
        if (nothing_checked){
            input.checked = true;
        }
    }
    
    
};

Settings.autoSave = function(evt){
    // save all field
    //~ let targ = evt.target.parentElement.parentElement;
    //~ let btn_save = false;
    //~ let next = true;
    //~ while(!btn_save && next){
        //~ next = targ.nextElementSibling;
        //~ if (next.tagName == 'BUTTON' && next.value == 'settings_save') btn_save = next;
        //~ else targ = next;
    //~ }
    //~ if (btn_save) btn_save.click();
    
    let targ = evt.target;
    let exist = document.querySelector('[name="'+targ.name+'¤id"]');
    
    let settings = {};
    settings.url = CONSTANTS.base_url + 'public/settings/index.php';
    settings.dom_target = '';
    settings.skip_container = true;
    settings.data = {
        'settings_action': 'settings_save'
    };
    if (exist) settings[exist.name] = exist.value;
    if (targ.tagName == 'INPUT' && targ.type == 'checkbox'){
        if (targ.checked) settings.data[targ.name] = targ.value;
    } else if (targ.tagName == 'INPUT' && targ.type == 'text' && targ.type == 'number'){
        if (targ.value != '') settings.data[targ.name] = targ.value;
    } else {
        console.error('NEED TO ADD AUTOSAVE FOR THIS INPUT', targ);
    }

    // add others elems from form
    let form = targ.form;
    for (let index = 0; index < form.length; index++) {
        let input = form[index];
        if (input.type == 'hidden' && !input.name.includes('¤')) settings.data[input.name] = input.value;
    }

    $_a.send(settings);
};
function externalInit(){
   var btn= document.getElementById('btn_download');
   $_e.AddEventClick(btn,externalTodl);
}

function externalTodl(){
    var token= document.getElementById('extToken').value;
    window.open(CONSTANTS.base_url+"public/external.php?idl="+token,"_new");
} 
var Conv = function(){};
Conv.tl = false;
Conv.selected = {}; // domElement clicked on when select from list
Conv.Load = function(evt,domId,id,target=false,path=false,marker=false){
    if (Conv.selected[domId] && Conv.selected[domId] != evt.target){
        if (Conv.selected[domId]) DOM_Class.ToggleClass(Conv.selected[domId],'selected',false);
    }
    Conv.selected[domId] = evt.target;
    DOM_Class.ToggleClass(Conv.selected[domId],'selected',true);
    let settings = {};
    settings.url = CONSTANTS.base_url + 'public/conversation/index.php';
    target = target ? target : 'conversation_chat_' + domId;
    settings.dom_target = target;
    settings.skip_container = true;
    settings.data = {
        'conversation_action': 'conversation_load',
        'conv_id': id,
        'domId': domId,
        'path': (path) ? path : '',
        'marker': (marker) ? marker : '',
        'target': target
    };
    settings.success = function(){
        // clean unread indicator on the list
        let indic = document.getElementById('conv_list_elem_unread_' + domId + '_' + id);
        if (indic) indic.innerHTML = '';
    };
    $_a.send(settings);
};
Conv.HideList = function(evt,domId){
    let list = document.getElementById('conversation_list_' + domId);
    if (list){
        DOM_Class.ToggleClass(evt.target, 'closed');
        DOM_Class.ToggleClass(list, 'hidden');
    }
};
Conv.UpdateList = function(domId, id_selected= 0){
    if (!id_selected){
        let selected = document.querySelector('#conversation_list_' + domId + ' > .conversation_list_conv.selected');
        id_selected = (selected) ? selected.id.replace('conv_list_elem_' + domId + '_', '') : 0;
    }
    let settings = {};
    settings.url = CONSTANTS.base_url + 'public/conversation/index.php';
    settings.dom_target = 'conversation_list_' + domId;
    settings.skip_container = true;
    settings.notimer = true;
    settings.data = {
        'conversation_action': 'conversation_list',
        'domId': domId,
        'id_selected': id_selected
    };
    settings.success = function(){
        if (id_selected > 0){
            Conv.selected[domId] = document.getElementById('conv_list_elem_' + domId + '_' + id_selected);
        }
    };
    $_a.send(settings);
};
// update read state and connection status
Conv.UpdateListReadState = function(){
    let send = false;
    let settings = {};
    settings.url = CONSTANTS.base_url + 'public/conversation/index.php';
    settings.dom_target = '';
    settings.skip_container = true;
    settings.notimer = true;
    settings.data = {
        'conversation_action': 'conversation_read_state'
    };
    var dom_lists = document.getElementsByClassName('conversation_list');
    if (dom_lists.length > 0){
        send = true;
        settings.data.list = 1;
    }
    var dom_markers = document.querySelectorAll('.artiviewer_commentszone:not(.hidden)');
    if (dom_markers.length > 0){
        send = true;
        settings.data.id_markers = [];
        var domIds_markers = Array.from(dom_markers, x => x.id.replace('artiviewer_commentszone_', ''));
        domIds_markers.forEach( domId => {
            artiviewers[domId].markerstimes.forEach(function(ctime){
                marker = artiviewers[domId].markers[ctime];
                if (marker.idconv && marker.idconv > 0){
                    settings.data.id_markers.push(marker.idconv);
                }
            });
        });
    }
    settings.success = function(res){
        let json = JSON.parse(res);
        if (json){
            if (json.list && json.list.length > 0){
                // get all domId for each module loaded
                let domIds = Array.from(dom_lists, x => x.id.replace('conversation_list_', ''));
                json.list.forEach(data => {
                    domIds.forEach( domId => {
                        let parent = document.getElementById('conv_list_elem_' + domId + '_' + data['id']);
                        if (parent && !parent.classList.contains('selected')){
                            let unread = document.getElementById('conv_list_elem_unread_' + domId + '_' + data.id);
                            if (data.unread != '') unread.textContent = '(' + data.unread + ')';
                            else unread.textContent = '';
                        }
                    });
                });
            }
            if (json.connected_users){
                let array = document.getElementsByClassName('conversation_list_conv_user_status_connection');
                for (let index = 0; index < array.length; index++) {
                    let elem = array[index];
                    let id = elem.id.substring(elem.id.lastIndexOf('_') + 1);
                    DOM_Class.ToggleClass(elem, 'connected', (json.connected_users.indexOf(id) > -1));

                }
            }
            if (json.markers && json.markers.length > 0){
                json.markers.forEach(data => {
                    domIds_markers.forEach( domId => {
                        artiviewers[domId].markerstimes.forEach(function(ctime){
                            marker = artiviewers[domId].markers[ctime];
                            if (marker.idconv && marker.idconv == data['id']){
                                if (ctime == -1) ctime = 'general';
                                let elem = document.getElementById('artiviewer_markerinlist_unread_' + domId + '_' + ctime);
                                if (elem) elem.textContent = (data.unread != '') ? '(' + data.unread + ')' : '';
                            }
                        });
                    });
                });
            }
        }
    };
    if (send) $_a.send(settings); // do not send if nothing opened
};
Conv.Edit = function(evt,domId,id){
    let settings = {};
    settings.url = CONSTANTS.base_url + 'public/conversation/index.php';
    settings.dom_target = 'conversation_chat_' + domId;
    settings.skip_container = true;
    settings.data = {
        'conversation_action': 'conversation_edit',
        'domId': domId,
        'conv_id': id
    };
    $_a.send(settings);
};
Conv.Delete = function(domId,id){
    let settings = {};
    settings.url = CONSTANTS.base_url + 'public/conversation/index.php';
    settings.dom_target = '';
    settings.skip_container = true;
    settings.data = {
        'conversation_action': 'conversation_delete',
        'conv_id': id,
        'domId': domId
    };
    settings.success = function(res){
        if (res == 'ok'){
            // remove for each loaded conversation the element from the list.
            let lists = document.getElementsByClassName('conversation_list');
            if (!lists){
                return;
            }
            for (let index = 0; index < lists.length; index++) {
                let elem = lists[index];
                let list_domId = elem.id.replace('conversation_list_','');
                let targ = document.getElementById('conv_list_elem_' + list_domId + '_' + id);
                if (targ) {
                    if (Conv.selected[list_domId] == targ){ // selected chat in this list is the one deleted
                        Conv.Chats[list_domId].clean();
                        let chat = document.getElementById('conversation_chat_' + list_domId);
                        if (chat){
                            while(chat.firstChild){
                                DOM_Class.RemoveElement(chat.firstChild);
                            }
                        }
                        let chatname = document.getElementById('conversation_bar_name_' + list_domId);
                        if (chatname) chatname.innerHTML = '';
                    }
                    DOM_Class.RemoveElement(targ);
                }
            }
        }
    };
    $_a.send(settings);
};
Conv.UpdateMarker = function(domId, id_conv, markerTime){
    if (!artiviewers[domId].markers[markerTime]) artiviewers[domId].markers[markerTime] = {'time': -1};
    artiviewers[domId].markers[markerTime].idconv = id_conv;
    artiviewers[domId].savemarker();
};
Conv.ToggleFormNew = function(evt){
    let form_private = document.getElementById('conversation_form_new_private');
    let form_group = document.getElementById('conversation_form_new_group');
    if (evt.target.checked) {
        DOM_Class.ToggleClass(form_private,'hidden',false);
        DOM_Class.ToggleClass(form_group,'hidden',true);
    } else {
        DOM_Class.ToggleClass(form_group,'hidden',false);
        DOM_Class.ToggleClass(form_private,'hidden',true);
    }
};
Conv.Private = function(evt,domId, id_user){
    if (Conv.selected[domId] && Conv.selected[domId] != evt.target){
        if (Conv.selected[domId]) DOM_Class.ToggleClass(Conv.selected[domId],'selected');
    }
    Conv.selected[domId] = evt.target;
    DOM_Class.ToggleClass(Conv.selected[domId],'selected');

    let settings = {};
    settings.url = CONSTANTS.base_url + 'public/conversation/index.php';
    settings.dom_target = 'conversation_chat_' + domId;
    settings.skip_container = true;
    settings.data = {
        'conversation_action': 'conversation_save',
        'private': 1,
        'domId': domId,
        'id_user': id_user,
    };
    settings.success = function(res){
        // clean unread indicator on the list
        // let indic = document.getElementById('conv_list_elem_unread_' + domId + '_' + id);
        // if (indic) indic.innerHTML = '';
    };
    $_a.send(settings);
};
Conv.MsgEdited = function(data){
    data = JSON.parse(data);
    let edited = document.querySelectorAll('.conversation_conv_msg[id$="_'+data.id+'"]');
    if (edited){
        for (let index = 0; index < edited.length; index++) {
            let domElem = edited[index];
            domElem.outerHTML = data.html;
        }
    }
};
Conv.MsgDeleted = function(id){
    let deleted = document.querySelectorAll('.conversation_conv_msg[id$="_'+id+'"]');
    if (deleted){
        for (let index = 0; index < deleted.length; index++) {
            let domElem = deleted[index];
            if (domElem.previousElementSibling.classList.contains('conversation_avatar')) DOM_Class.RemoveElement(domElem.previousElementSibling);
            DOM_Class.RemoveElement(domElem);
        }
    }
};
Conv.displayDate = function(domId, target, date){
    let id = 'conversation_date_' + domId + date.replace(' / ', '');
    let domDate = DOM_Class.CreateElement('DIV', {'class': 'conversation_conv_date', 'id': id}, date);
    let targ = document.getElementById(target);
    let exist = document.getElementById(id);
    if (exist){
        DOM_Class.RemoveElement(exist);
    }
    // put the date before the user avatar
    if (targ.previousElementSibling.classList.contains('conversation_avatar')) targ = targ.previousElementSibling;
    DOM_Class.InsertBefore(domDate,targ);
};

Conv.Puller = {};
Conv.Chats = {};
Conv.create_chat = function(settings){
    if (Conv.Chats[settings.domId]){
        Conv.Chats[settings.domId].clean();
        delete(Conv.Chats[settings.domId]);
    }
    Conv.Chats[settings.domId] = new chat(settings);
    Conv.Chats[settings.domId].init();

    Conv.clean_chat();
};
Conv.clean_chat = function(){
    let toClean = [];
    for (var key in Conv.Chats) {
        let exist = document.getElementById(Conv.Chats[key].target);
        if (!exist) {
            Conv.Chats[key].clean();
            toClean.push(key);
        }
    }
    toClean.forEach((key)=>{
        delete(Conv.Chats[key]);
    });
};

function chat(settings){
    var self = this;

    var url = CONSTANTS.base_url + 'public/conversation/index.php';
    var waitingMsg = false;
    var waitingLoad = false;
    var identifiant_key_press_pos = false;
    // var saving = false;

    this.current_id = settings.id_conv;
    this.current_name = settings.conv_name ? settings.conv_name : '';

    this.visible_msgs = settings.msgs;
    this.id_last_msg = settings.last_id; // last displayed message
    this.id_last_msg_sent = settings.last_id_sent;// last sent message
    this.id_first_msg = settings.first_id;// first displayed message
    this.id_last_msg_read = settings.last_message_read;
    this.id_last_msg_read_send = this.id_last_msg_read; // use to compare with id_last_msg_read to send it only if there is a change.
    this.domId = settings.domId;
    this.more_to_load = settings.more_msg;
    this.demo = settings.demo;

    this.path = settings.path ? settings.path : '';
    this.target = settings.target ? settings.target : 'conversation_chat_' + this.domId;

    this.current_joined = false;
    this.editing_msg = false;
    this.observer_scroll = false;
    
    this.puller = false;
    var pullTime = 5000;

    this.domElements = {};

    this.clean = function(){
        clearTimeout(self.puller);
        if (self.observerScroll) {
            self.observerScroll.disconnect();
            self.observerScroll = false;
        }

        $_e.RemoveAllEvents(self.domElements.btnSend);
        $_e.RemoveAllEvents(self.domElements.btnCancelEdit);
        $_e.RemoveAllEvents(self.domElements.msgsList);
    };
    this.init = function() {
        this.domElements.inputMsg = document.getElementById('conv_msg_content_' + this.domId);
        this.domElements.inputJoinedFiles = document.getElementById('conv_msg_joined_files_' + this.domId);
        this.domElements.inputEdit = document.getElementById('conv_msg_editing_' + this.domId);
        this.domElements.editOverlay = document.getElementById('conv_msg_overlay_edit_' + this.domId);
        
        let domttl = document.getElementById('conversation_bar_name_' + this.domId);
        if (domttl && this.current_name != ''){
            domttl.innerHTML = this.current_name;
        }

        tinymce_init();

        this.domElements.btnSend = document.getElementById('conversation_chat_send_msg_' + this.domId);
        $_e.AddEventClick(this.domElements.btnSend,(evt)=>{sendMsg(evt);});

        this.domElements.btnCancelEdit = document.getElementById('conv_msg_cancel_edit_' + this.domId);
        $_e.AddEventClick(this.domElements.btnCancelEdit,toggleEditing);

        this.domElements.msgsList = document.getElementById('conversation_msgs_' + this.domId);
        
        // if (this.domElements.msgsList.lastElementChild) setTimeout(()=>{scrollToElem(this.domElements.msgsList.lastElementChild);},500);
        // if (this.domElements.msgsList.lastElementChild) this.domElements.msgsList.lastElementChild.scrollIntoView({behavior: "smooth",block: 'end'});

        // detect scroll to top to load more messages
        if (this.more_to_load){
            $_e.AddEvent(this.domElements.msgsList,'scroll',onScroll);
        }

        waitingLoad = UI_Class.AddWindow(null, {'modal': false, 'nodrag': true, 'class':'chat_loading', 'disableBackgroundClick': true});
        waitingLoad.SetParent(self.domElements.inputMsg.form.parentElement, false, false);

        // add btn edit to the last msg sent
        if (this.id_last_msg_sent > 0) {
            addBtnEdit();
        }

        // context menu for images
        let lst_btns = ['download','copy'];
        lst_btns.forEach((action,key)=>{
            let icon = DOM_Class.CreateElement('SPAN',{'class':'icon'});
            let text = DOM_Class.CreateElement('SPAN',{'class':'text'}, CONSTANTS.texts['tlc_' + action]);
            let btn = DOM_Class.CreateElement('DIV',{'id': 'chat_context_menu'+action+'_' + self.domId, 'class': 'chat_btn icon_text context_menu '+action, 'title': CONSTANTS.texts['tlc_' + action]});
            DOM_Class.AppendContent(btn, [icon, text]);
            switch(action){
                case 'download':
                    $_e.AddEventClick(btn, onImageDownload);
                break;
                case 'copy':
                    $_e.AddEventClick(btn, onImageCopy);
                break;
            }
            lst_btns[key] = btn;
        });
        let settings = {
            'buttons': lst_btns,
            'openCallback': onOpenContextMenu,
            'hideCallback': onHideContextMenu
        };
        this.domElements.context_menu = UI_Context_Menu.create_instance('cntx_chat_images_' + this.domId, settings);
        
        this.observerScroll = new IntersectionObserver(handleScroll, {'root': this.domElements.msgsList});

        // send a pull message request to get the unread messages and trigg the setTimeout
        pullMsg(true, false, true);
    };
    function onPaste(plugin, args){
        var doc = new DOMParser().parseFromString(args.content, "text/html");
        if (args.content.includes("&lt;") || args.content.includes("&gt;")) {
            args.content = doc.documentElement.textContent;
        } else {
            args.content = doc.body.innerHTML;
        }
    }
    function onScroll(evt){
        let targ = evt.target;
        if (evt.target.scrollTop === 0){
            loadMoreMsg();
        }
    }
    function pullMsg(restart_timer = true, force_scroll_to_bottom = false, first_call = false){
        let parent = document.getElementById('conversation_msgs_' + self.domId);
        if (!parent){ // stop here
            return false;
        }
        let settings = {};
        settings.url = url;
        settings.dom_target = '';
        settings.skip_container = true;
        settings.notimer = true;
        settings.data = {
            'conversation_action': 'conversation_last_msg',
            'domId': self.domId,
            'conv_id': self.current_id,
            'id_last_msg': self.id_last_msg,
            'path': self.path
        };
        // if first call to pullMsg, don't check the scroll position to let the user read each new message if any
        // when seeing a conversation with a bunch of message for the first time. The first load will not display any message and the scroll will be at the bottom
        // the force_scroll_to_bottom will automaticly active and it will not let the user scroll by himsel to read each message
        var scroll_to_last_new_msg = false;
        if (!force_scroll_to_bottom && !first_call){
            // detect position of the scroll, if it the bottom, force the scroll after loading new message
            let a = parent.scrollTop;
            let b = parent.scrollHeight - parent.clientHeight;
            if (a == b) force_scroll_to_bottom = true;
        }
        if (force_scroll_to_bottom){
            if (!spd3_alert.isVisible){
                force_scroll_to_bottom = false;
                scroll_to_last_new_msg = true;
            } else {
                self.HideNewMessageButton();
                if (self.id_last_msg_read_send != self.id_last_msg_read){
                    settings.data.save_last_read = self.id_last_msg_read;
                    self.id_last_msg_read_send = self.id_last_msg_read;
                    if (self.timer_sendLastRead) clearTimeout(self.timer_sendLastRead); // can be waiting
                }
            }
        }
        settings.success = function(res){
            let json = JSON.parse(res);
            if (json && json.code == 0){
                if (json.msgs) {
                    // debugger;
                    if (!force_scroll_to_bottom && !scroll_to_last_new_msg) self.DisplayNewMessageButton();
                    json.msgs.forEach((msg)=>{
                        if (self.visible_msgs.indexOf(msg.id) == -1){
                            self.visible_msgs.push(msg.id);
                            DOM_Class.WriteHtml(parent,msg.html,true);
                            let elem = document.getElementById('conversation_msg_' + self.domId + '_' + msg.id);
                            self.observerScroll.observe(elem);
                        }
                    });
                    // parent.lastElementChild.scrollIntoView({behavior: "smooth",block: 'end'});
                    // DOM_Class.WriteHtml(parent,json.html,true);
                    // json.id_msgs.forEach((id)=>{
                    //     let elem = document.getElementById('conversation_msg_' + self.domId + '_' + id);
                    //     self.observerScroll.observe(elem);
                    // });
                } else {
                    // desactive every scroll action because if there is no new messages there is no need to scroll
                    force_scroll_to_bottom = false;
                    scroll_to_last_new_msg = false;
                }
                if (json.last_id && json.last_id != self.id_last_msg) self.id_last_msg = json.last_id;
                if (json.last_id_sent && json.last_id_sent != self.id_last_msg_sent) {
                    setTimeout(addBtnEdit, 100);
                    self.id_last_msg_sent = json.last_id_sent;
                }
                if (json.fast) pullTime = 500;
                else pullTime = 5000;
            }
            // scroll to bottom only if not scrolled at all or if it's force (when calling pullMsg after sendMsg, it's forced)
            if (force_scroll_to_bottom){
                if (parent.lastElementChild) {
                    scrollToElem(parent.lastElementChild);
                    // parent.lastElementChild.scrollIntoView({behavior: "smooth",block: 'end'});
                }
            }
            if (scroll_to_last_new_msg){
                let elem = document.getElementById('conversation_msg_' + self.domId + '_' + self.id_last_msg_read);
                elem = elem.nextElementSibling;
                if (elem){
                    while (!elem.classList.contains('conversation_conv_msg')){
                        elem = elem.nextElementSibling;
                    }
                    scrollToElem(elem);
                }
            }
            if (restart_timer) {
                clearTimeout(self.puller);
                self.puller = setTimeout(pullMsg, pullTime);
            }
        };
        $_a.send(settings);
    }
    this.lastSaveTime = 0;
    function sendMsg(evt){
        // saving = true;
        // retrieve msg content from tinymce
        let content = self.domElements.inputMsg._tinymce.getContent();
        // console.log(content);
        if (identifiant_key_press_pos){
            // when pressing enter to send a message, tinymce add an indesirable br.
            // to detect it, add a random string to the cotent of tinymce, the br is positionned before it.
            // but have to be carefull, after pressing enter, the user can still write some text that is undesirable too.
            let toTest = '&nbsp; &nbsp; &nbsp;';
            // let pos = content.indexOf(identifiant_key_press_pos);
            let pos = content.indexOf(toTest);
            if (pos > -1){
                // let parsedContent = content.substring(0, pos) + content.substring(pos + identifiant_key_press_pos.length);
                let parsedContent = content.substring(0, pos) + content.substring(pos + toTest.length);
                let br = '<br />';
                let brpos = parsedContent.indexOf(br);
                content = parsedContent.substring(0, brpos) + parsedContent.substring(brpos + br.length);
                // console.log(content);
            }
        }

        if (self.lastSaveTime == 0){
            self.lastSaveTime = Date.now();
        } else {
            let now = Date.now();
            let diff = now - self.lastSaveTime;
            self.lastSaveTime = now;
            // console.log(diff);
            if (diff < 300){
                return false;
            }
        }

        // remove all \r\n
        content = content.replace("\\r\\n","").replace("\\n","").replace("\\r","").replace(/\&nbsp;/g, ' ');
        content = content.trim();
        let contentToDom = DOM_Class.dom_parser.parseFromString(content,'text/html');
        if (contentToDom.body.textContent == '' && !content.includes('<img')){
            self.domElements.inputMsg.form.focus();
            // self.domElements.inputMsg._tinymce.setMode('readonly');
            // self.domElements.inputMsg._tinymce.setMode('design');
            // modal can't send empty message
            // UI_Class.MessagePopup(Conv.tl.no_empty_msg,()=>{self.domElements.inputMsg._tinymce.setMode('design');});
            initMsg();
            return false;
        }
        self.domElements.inputMsg._tinymce.setMode('readonly');

        // when editing a message with images inside, for image to don't break we need to reformat the path like for an upload ¤IMG_S¤'.$filename.'¤IMG_E¤ as url 
        // and without other stuff like onclick, dataset, etc...
        if (self.editing_msg && content.includes('<img')){
            let imgs = contentToDom.body.getElementsByTagName('img');
            for(let i = 0; i < imgs.length; i++){
                let cur = imgs[i];
                if (!self.current_joined || self.current_joined.indexOf(cur.src) == -1){ // not updated during edition
                    let filename = cur.dataset.name;
                    // replace the url with media.php with the one saved in db
                    content = content.replace(cur.outerHTML.replace('>',' />'), '<img src="¤IMG_S¤' + filename + '¤IMG_E¤">');
                }
            }
        }
        
        self.domElements.inputMsg.value = content;
        self.domElements.inputMsg._validator.checkField(self.domElements.inputMsg);

        if (self.current_joined && self.domElements.inputJoinedFiles){
            self.domElements.inputJoinedFiles.value = self.current_joined.join('¤&¤');
        }
        // stop the puller
        clearTimeout(self.puller);
        // stop writing inside tinymce

        let settings = {};
        settings.dom_target = '';
        settings.skip_container = true;
        settings.data = evt.target.form;
        settings.success = sendMsgSuccess;
        $_a.send(settings);
    }
    function sendMsgSuccess(res){
        let parent = document.getElementById('conversation_msgs_' + self.domId);
        let json = JSON.parse(res);
        self.domElements.inputMsg._tinymce.setMode('design');
        if (parent && json && json.code == 0){
            if (json && json.edit) {
                let edited = document.querySelector('#conversation_msg_' + self.domId + '_' + json.edit.id);
                edited.outerHTML = json.edit.html;
                addBtnEdit();
            }
            pullMsg(false,true);
            // reinit joined file and current msg form
            initMsg(json);
        }
        // start the puller again
        clearTimeout(self.puller);
        self.puller = setTimeout(pullMsg, pullTime);
    }
    // reinit joined file and current msg form
    function initMsg(json){
        self.current_joined = false;
        self.domElements.inputMsg._tinymce.resetContent();
        self.domElements.inputMsg.value = '';
        if (self.domElements.inputJoinedFiles){
            self.domElements.inputJoinedFiles.value = '';
        }
        // remove editing
        if (self.editing_msg) {
            toggleEditing();
        }
        // saving = false;
    }
    // add btns to edit or delete the last messages sent
    function addBtnEdit(){
        let last_msg_sent = document.getElementById('conversation_msg_' + self.domId + '_' + self.id_last_msg_sent);
        if (last_msg_sent) {
            let prevBtns = document.getElementById('conv_btns_last_msg_' + self.domId);
            if (prevBtns) DOM_Class.RemoveElement(prevBtns);
            
            let btns = DOM_Class.CreateElement('DIV',{'class':'conv_btns_last_msg', 'id': 'conv_btns_last_msg_' + self.domId});
            let edit = DOM_Class.CreateElement('BUTTON',{'class':'conv_btn_edit', 'id': 'conv_btn_edit_last_msg_' + self.domId},CONSTANTS.texts.tlc_edit);
            let del = DOM_Class.CreateElement('BUTTON',{'class':'conv_btn_delete dangerous', 'id': 'conv_btn_del_last_msg_' + self.domId},CONSTANTS.texts.tlc_delete);
            DOM_Class.AppendContent(btns, [edit, del]);
            DOM_Class.AppendContent(last_msg_sent,btns);
            $_e.AddEventClick(edit,toggleEditing);
            $_e.AddEventClick(del,deleteLastMsg);
        }
    }
    function toggleEditing(){
        let last = document.getElementById('conversation_msg_' + self.domId + '_' + self.id_last_msg_sent);
        if (!self.editing_msg && last) {
            // edit mode
            self.editing_msg = true;
            self.domElements.inputEdit.value = self.id_last_msg_sent;
            let content = last.getElementsByClassName('content')[0];
            self.domElements.inputMsg._tinymce.resetContent(content.innerHTML);
            self.domElements.inputMsg._tinymce.selection.select(self.domElements.inputMsg._tinymce.getBody(), true);
            self.domElements.inputMsg._tinymce.selection.collapse(false);
            DOM_Class.ToggleClass(self.domElements.editOverlay,'hidden',false);
        } else {
            // normal mode
            self.editing_msg = false;
            self.domElements.inputEdit.value = 0;
            self.domElements.inputMsg._tinymce.resetContent();
            DOM_Class.ToggleClass(self.domElements.editOverlay,'hidden',true);
        }
    }
    function deleteLastMsg(){
        if (self.id_last_msg == 0){
            return false;
        }

        let dom_last_msg = document.getElementById('conversation_msg_' + self.domId + '_' + self.id_last_msg);
        if (!dom_last_msg){
            return false;
        }

        let settings = {};
        settings.url = url;
        settings.dom_target = '';
        settings.skip_container = true;
        settings.notimer = true;
        settings.data = {
            'conversation_action': 'conversation_delete_last_msg',
            'domId': self.domId,
            'conv_id': self.current_id,
            'id_last_msg': self.id_last_msg,
            'path': self.path,
        };
        settings.success = function(json){
            json = JSON.parse(json);
            if (json.code == 0){
                if (dom_last_msg.previousElementSibling.classList.contains('conversation_avatar')){
                    DOM_Class.RemoveElement(dom_last_msg.previousElementSibling);
                }
                DOM_Class.RemoveElement(dom_last_msg);
                let index = self.visible_msgs.indexOf(self.id_last_msg);
                if (index > 0) self.id_last_msg = self.visible_msgs[index - 1];
                else self.id_last_msg = 0;
                self.visible_msgs.splice(index, 1);
                if (self.editing_msg) toggleEditing();
            }
        };
        $_a.send(settings);
    }
    function tinymce_init(){
        let domTest=document.getElementById('conv_msg_content_' + self.domId);
        self.tinyInit=(self.tinyInit==undefined)?0:self.tinyInit+1;
        if (typeof tinymce == 'undefined' || typeof domTest == 'undefined'){
            if (self.tinyInit<20){
                setTimeout(function () {
                    tinymce_init();
                },250);
            }else{
                console.log("tinyMCE init issue");
                alert('Something went wrong with your internet connection, please refresh this page.');
            }
        }else{
            self.tinyInit='initialised';
            var tinymceEd = new tinymce.Editor('conv_msg_content_' + self.domId, {
                width: "100%",
                height: "calc(80px * var(--fhd-vr))",
                plugins: "lists link autolink charmap emoticons paste quickbars textpattern  wordcount charmap hr pagebreak nonbreaking visualchars spd3_scode spd3_media",
                menubar: false,
                toolbar: false,
                // toolbar: 'formatgroup paragraphgroup insertgroup',
                // toolbar: " undo redo searchreplace styleselect fontsizeselect | bold italic forecolor backcolor | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | removeformat code fullscreen animation  | spd3_scode spd3_media",
                // a11y_advanced_options: "true",
                skin: "oxide-dark",
                placeholder: Conv.tl.placeholder_msg,
                content_css: "default",
                content_style: '.mce-resizehandle {display: none;} img{max-width:120px;max-height:120px;filter:invert();} p{margin: 0;}',
                contextmenu: "link selectall copy cut paste charmap",
                relative_urls: true,
                document_base_url: CONSTANTS.base_url,
                // forced_root_block: "span",
                remove_trailing_brs: false,
                extended_valid_elements: 'span[onclick|class|id|data-type]',
                // extended_valid_elements: "img[class|id|src|border=0|alt|title|hspace|vspace|width|height|align|onmouseover|onmouseout|name|onclick|onmousedown|onmouseup|style]",
                convert_urls: false,
                statusbar: false,
                // context toolbar on selection specific (plugin quickbars)
                quickbars_insert_toolbar: false,
                quickbars_selection_toolbar: 'bold italic | quicklink blockquote',
                quickbars_image_toolbar: false,
                // image and file specific
                file_picker_types: (self.demo) ? '' : 'file image media',
                image_file_types: (self.demo) ? '' : 'jpeg,jpg,jpe,jfi,jif,jfif,png,gif,bmp,webp,svg',
                images_upload_handler: tinymce_image_upload_handler.bind({action: "tinymceupload", url: url}),
                images_upload_url: (self.demo) ? '' : self.url,
                image_dimensions: false,
                images_reuse_filename: true,
                // paste specific
                paste_data_images: (self.demo) ? false : true,
                paste_preprocess: (self.demo) ? false : onPaste,
                paste_merge_formats: (self.demo) ? false : true,
                setup: function(editor){
                    editor.render();
                    editor.on('init', function(e){
                        waitingLoad.Hide();
                        editor.on("keydown", tinymce_on_key_press);
                        self.domElements.inputMsg._tinymce = editor;
                        // scroll to bottom of the list of messages
                        // let parent = document.getElementById('conversation_msgs_' + self.domId);
                        // if (parent.lastElementChild) {
                        //     parent.lastElementChild.scrollIntoView({behavior: "smooth",block: 'end'});
                        // }
                        // if (self.domElements.msgsList.lastElementChild) setTimeout(()=>{scrollToElem(self.domElements.msgsList.lastElementChild);},500);
                        if (self.domElements.msgsList.lastElementChild) scrollToElem(self.domElements.msgsList.lastElementChild);

                        // make a div in front of tinymce that is activate when tinymce isn't focusin.
                        // otherwise mouseover event will break when going threw tinymce
                        self.domElements.overlayTinymce = DOM_Class.CreateElement('DIV', {'class': 'conversation_overlay_tinymce', 'id': 'conversation_overlay_tinymce_'+self.domId});
                        DOM_Class.AppendContent(document.getElementById('conv_tinymce_' + self.domId), self.domElements.overlayTinymce);
                        $_e.AddEventClick(self.domElements.overlayTinymce, function(evt){
                            DOM_Class.AddClass(self.domElements.overlayTinymce, 'inactive');
                            self.domElements.inputMsg._tinymce.focus();
                            $_e.AddEventClickOutside(self.domElements.overlayTinymce, activeOverlayTinymce);
                        });
                    });
                    editor.on('focus', function(e){
                        // close context menu if any
                        self.domElements.context_menu.hide();
                    });
                }
            }, tinymce.EditorManager);
        }
    }
    function activeOverlayTinymce(evt){
        DOM_Class.RemoveClass(self.domElements.overlayTinymce, 'inactive');
        $_e.RemoveEventClickOutside(self.domElements.overlayTinymce, activeOverlayTinymce);
        self.domElements.inputMsg._tinymce.setMode('readonly');
        self.domElements.inputMsg._tinymce.setMode('design');
    }
    function tinymce_on_key_press(evt){
        if (evt.key == 'Enter' && evt.shiftKey){
            
            // add a randomly generated string to the content of tinymce when pressing enter to detect where the indesirable br is added.
            // identifiant_key_press_pos = Math.random().toString(16).substring(2, 10);
            identifiant_key_press_pos = "     ";
            self.domElements.inputMsg._tinymce.insertContent(identifiant_key_press_pos);
            $_e.SendEventClick(self.domElements.btnSend);
            evt.preventDefault();
            evt.stopPropagation();
            return false;
        }
        if (evt.code == 'ArrowUp' && evt.ctrlKey && !self.editing_msg && self.id_last_msg > 0){
            toggleEditing();
            evt.preventDefault();
            evt.stopPropagation();
            return false;
        }
        if (evt.code == 'Escape' && self.editing_msg) {
            toggleEditing();
            evt.preventDefault();
            evt.stopPropagation();
            return false;
        }
    }
    function tinymce_image_upload_handler(blobInfo, success, failure) {
        var xhr, formData;
        
        // display a waiting modal in front of the form to send/write message until the file has been received
        // otherwise it will break the upload and the joined_files system
        if (!waitingMsg){
            waitingMsg = UI_Class.AddWindow(null, {'modal': true, 'nodrag': true, 'class':'timer_requete', 'disableBackgroundClick': true});
            waitingMsg.SetParent(self.domElements.inputMsg.form, 0.5, 0.5);
        } else {
            waitingMsg.Show();
        }

        xhr = new XMLHttpRequest();
        xhr.withCredentials = false;
        xhr.open('POST', this.url);
    
        xhr.onload = function() {
            let json;
    
            if (xhr.status != 200) {
                failure('HTTP Error: ' + xhr.status);
                return;
            }
    
            try{
                json = JSON.parse(xhr.responseText);
            }catch(e){
                json = false;
                console.log(e);
            }
    
            if (!json || typeof json.location != 'string') {
                failure('Invalid JSON: ' + xhr.responseText);
                return;
            }

            // chat exception
            // add to the joined files array each file uploaded from tinymce
            if (!self.current_joined) self.current_joined = [];
            self.current_joined.push(json.location);

            waitingMsg.Hide();

            success(json.location);
        };
    
        formData = new FormData();
        formData.append('file', blobInfo.blob(), blobInfo.filename());
        formData.set('action', this.action);
    
        xhr.send(formData);
    }
    function loadMoreMsg(){
        let settings = {};
        settings.url = url;
        settings.dom_target = '';
        settings.skip_container = true;
        settings.data = {
            'conversation_action': 'conversation_load_more_msg',
            'domId': self.domId,
            'conv_id': self.current_id,
            'id_msg': self.id_first_msg,
            'path': self.path
        };
        settings.success = loadMoreMsgSuccess;
        $_a.send(settings);
    }
    function loadMoreMsgSuccess(res){
        let parent = document.getElementById('conversation_msgs_' + self.domId);
        let json = JSON.parse(res);
        if (parent && json && json.code == 0){
            if (json.msgs) {
                // if (!force_scroll_to_bottom) self.DisplayNewMessageButton();
                json.msgs.forEach((msg)=>{
                    if (self.visible_msgs.indexOf(msg.id) == -1){
                        self.visible_msgs.push(msg.id);
                        DOM_Class.WriteHtml(parent,msg.html,false,true);
                    }
                });
            }
            // if (json.html) {
            //     DOM_Class.WriteHtml(parent,json.html,false,true);
            let firstBefore = document.getElementById('conversation_msg_' + self.domId + '_' + self.id_first_msg);
            if (json.same_user) {
                // need to fix the position of the scroll to the first element visible before the addition of the old messages
                DOM_Class.RemoveElement(firstBefore.previousElementSibling);
                scrollToElem(firstBefore, false);
                // firstBefore.scrollIntoView({behavior: "auto",block: 'start'});
            } else {
                scrollToElem(firstBefore.previousElementSibling, false);
                // firstBefore.previousElementSibling.scrollIntoView({behavior: "auto",block: 'start'});
            }
            // }
            if (json.id_msg) self.id_first_msg = json.id_msg;
            if (json.no_more_msg) {
                self.more_to_load = false;
                $_e.RemoveEvent(self.domElements.msgsList,'scroll',onScroll);
            }
        }
    }
    var imgSelected = false;
    this.onClickImg = function(evt){
        if (evt.button == 0){
            UI_Class.ShowBigImage(evt);
        }
        if (evt.button == 2){
            self.domElements.context_menu.open(evt);
        }
    };
    
    function onOpenContextMenu(evt){
        if (evt.target.dataset.name) imgSelected = evt.target.dataset.name;
    }
    function onHideContextMenu(){
        imgSelected = false;
    }
    function onImageDownload(evt){
        if (!imgSelected){
            return false;
        }
        let settings = {};
        settings.url = url;
        settings.dom_target = '';
        settings.skip_container = true;
        settings.data = {
            'conversation_action': 'conversation_download_file',
            'domId': self.domId,
            'conv_id': self.current_id,
            'path': self.path,
            'file': imgSelected
        };
        settings.success = function(res){
            res = JSON.parse(res);
            if (res['code'] == 0){
                let downloadPopup = window.open(res['url'],'_blank');
            } else {
                // UI_Class.popupSpecial['filemanager'].SetContent(res['html']);
                // UI_Class.popupSpecial['filemanager'].Show();
            }
        };
        $_a.send(settings);
    }
    function onImageCopy(evt){
        let params = {
            'conversation_action': 'conversation_modal_copy_file',
            'domId': self.domId,
            'conv_id': self.current_id,
            'path': self.path,
            'file': imgSelected
        };
        UI_Class.openPopupModal(evt,'public/conversation', params);
    }
    this.timer_sendLastRead = false;
    function handleScroll(changes, observer){
        let has_read = false;
        changes.forEach((entry, index) => {
            if (entry.isIntersecting){
                observer.unobserve(entry.target);
                let id = entry.target.id.split('_').pop();
                self.id_last_msg_read = parseInt(id);
                has_read = true;
            }
        });
        if (has_read){
            if (self.timer_sendLastRead) clearTimeout(self.timer_sendLastRead);
            self.timer_sendLastRead = setTimeout(sendLastReadMsg,3000);
        }
    }
    function sendLastReadMsg(){
        let settings = {};
        settings.url = url;
        settings.dom_target = '';
        settings.skip_container = true;
        settings.notimer = true;
        settings.data = {
            'conversation_action': 'conversation_save_last_message_read',
            'domId': self.domId,
            'conv_id': self.current_id,
            'path': self.path,
            'id_msg': self.id_last_msg_read
        };
        self.id_last_msg_read_send = self.id_last_msg_read;
        $_a.send(settings);
    }
    this.DisplayNewMessageButton = function(){
        // console.log('display button new message');
        if (!this.domElements.buttonNewMsg){
            this.domElements.buttonNewMsg = DOM_Class.CreateElement('BUTTON',{'class':'conversation_button_new_msg','id':'conv_button_new_msg_' + this.domId,'data-id_msg':this.id_last_msg_read}, Conv.tl.new_msg);

            DOM_Class.AppendContent(document.getElementById('conversation_msgs_' + this.domId).parentElement, this.domElements.buttonNewMsg);
            $_e.AddEventClick(this.domElements.buttonNewMsg, this.scrollToLastReadMessage);
        }
    };
    this.scrollToLastReadMessage = function(evt){
        let domElem = document.getElementById('conversation_msg_' + self.domId + '_' + self.id_last_msg_read);
        if (domElem){
            scrollToElem(domElem);
            // domElem.scrollIntoView({behavior: "smooth",block: 'end'});
        }
    };
    this.HideNewMessageButton = function(){
        if (self.domElements.buttonNewMsg){
            $_e.RemoveEventClick(self.domElements.buttonNewMsg, self.scrollToLastReadMessage);
            DOM_Class.RemoveElement(self.domElements.buttonNewMsg);
            self.domElements.buttonNewMsg = false;
        }
    };
    // this.DisplayNewMessageSeparator = function(parent){
    //     let exist = document.getElementById('conv_separator_new_msg_' + self.domId);
    //     if (exist){
    //         let id_msg = exist.dataset.id_msg;
    //         if (id_msg < self.id_last_msg_read) DOM_Class.RemoveElement(exist);
    //         else return false;
    //     }
    //     self.domElements.new_msg = DOM_Class.CreateElement('DIV',{'class':'conversation_separator_new_msg','id':'conv_separator_new_msg_' + self.domId,'data-id_msg':self.id_last_msg_read}, Conv.tl.new_msg);
    //     parent.innerHTML += self.domElements.new_msg.outerHTML;
    // };
    function scrollToElem(elem, blockend = true){
        // debugger;
        // console.log(elem, blockend);
        if (blockend){
            elem.scrollIntoView({behavior: "smooth",block: 'end'});
        } else {
            let parent = elem.parentElement;
            let top = elem.offsetTop + parent.scrollTop;
            parent.scrollTo(0, top);
            // elem.scrollIntoView({behavior: "smooth",block: 'start'});
        }
        
        // let parent = elem.parentElement;
        // let top = elem.offsetHeight + elem.offsetTop + parent.scrollTop;
        // parent.scrollTo(0, top);
    }
    // this.clearPreviousDate = function(date, id){
    //     let elems = document.querySelectorAll('.conversation_conv_date[data-date="' + date + '"]:not(#'+id+')');
    //     debugger;
    //     console.log(elems);
    //     if (elems){
    //         for (let index = 0; index < elems.length; index++) {
    //             let elem = elems[index];
    //             DOM_Class.RemoveElement(elem);
    //         }
    //     }
    // };
}
/*jshint esversion: 6 */
function alert(){
  var interval = false;
  var self = this;
  self.ids=[];
  self.isVisible=true;
//   document.title ="Artisan";
//   window.parent.postMessage("title-Artisan", '*');
window.parent.postMessage(JSON.stringify({
    "type": "title",
    "content" :"Artisan"
}), '*');
  this.initWidget = function(){
        if (!interval){
            // console.log('INIT');
            interval = setInterval(()=>{
                RefreshAlert();
            }, 5000);
            
        }
        
        document.addEventListener('visibilitychange', function() {
            if (document.visibilityState === 'visible') {
              // L'onglet est désormais visible et la notification n'est plus pertinente
              // on peut la fermer
              self.isVisible=true;
              if (self.currentNotif !=undefined) {
                self.currentNotif.close();
              }
            }else{
                self.isVisible=false;
            }
          });
    };
    
    function RefreshAlert(){
        
        let settings = {};
        settings.url = CONSTANTS.base_url + 'public/alert/index.php';
        settings.dom_target = 'alert_widget';
        settings.skip_container = true;
        settings.notimer = true;
        settings.data = {
            'alert_action': 'alert_widget',
            'prev_idmsg': self.lastidmsg,
            'prev_totalmsg': self.lasttotalmsg
        };
        $_a.send(settings);
        // update converstaion and marker (if they are open)
        Conv.UpdateListReadState();
    }
    
  this.weGotAModal=function(evt){
    if (UI_Class.popupSpecial["alert"] !=undefined){
        if (!UI_Class.popupSpecial["alert"].visible){
            let params = {
                'alert_action':'alert_modal'
                };
            UI_Class.openPopupModal(evt,'public/alert',params,'alert');
        }
    }else{
        let params = {
            'alert_action':'alert_modal'
            };
        UI_Class.openPopupModal(evt,'public/alert',params,'alert');
        }
        
    };
    this.noalert=function(){
        // document.title ="Artisan";
        // parent.postMessage("Artisan","*");
        // window.parent.postMessage("title-Artisan", '*');
        window.parent.postMessage(JSON.stringify({
            "type": "title",
            "content" :"Artisan"
        }), '*');
    };
    this.lastidmsg = 0;
    this.lasttotalmsg = 0;
    this.majconvicon=function(total,id_msg){
        self.lastidmsg = id_msg;
        self.lasttotalmsg = total;
        let convicon=document.querySelector('.Conversation > .menu_public_text_link');
        convicon.innerHTML=total;
        // console.log('new message : '+total);
        convicon.style.color=(total>0)?'black':'transparent';
        // detect if conversation module is open
        // let is_open = document.getElementsByClassName('conversation_list');
        // if (is_open){
        //     Conv.UpdateListReadState();
        // }
    }; 

    this.asknotif=function(e){
        // let itsok=false;
        // if (Notification.permission === 'granted' ){
        //     self.nomorecheck=false;
        //     itsok=true;
        // }else{
        //     Notification.requestPermission().then((permission) => {
        //         if (permission === "granted") {
        //             self.nomorecheck=false;
        //             itsok=true;
        //         }else{
        //             self.nomorecheck=true;
        //         }
        //     });
        // }
        // if (itsok){
            // const img = 'images/favicon.png';
            // self.currentNotif = new Notification('System notification test', { body: 'System notification access is granted', icon: img });
            window.parent.postMessage(JSON.stringify({
                "type": "askNotif"
            }), '*');
            document.getElementById('alert_sound').play();
            // document.title ="(!) Artisan";
            // window.parent.postMessage("title-(!) Artisan", '*');
            window.parent.postMessage(JSON.stringify({
                "type": "title",
                "content" :"(!) Artisan"
            }), '*');
        // }
    };

    this.notify=function(title,msg,id){
        // console.log(self.ids.includes(id)+'-'+self.isVisible);
        if (!self.ids.includes(id) && !self.isVisible) {
            // document.title ="(!) Artisan";
            window.parent.postMessage(JSON.stringify({
                "type": "title",
                "content" :"(!) Artisan"
            }), '*');
            self.ids.push(id);
            // if (window.Notification) {
            //     const img = 'images/favicon.png';
            //     // Vérifions si les autorisations de notification ont déjà été accordées
            //     if (Notification.permission === 'granted' ) {
            //         // console.log("notify1");
            //         self.currentNotif = new Notification(title, { body: msg, icon: img });
                    // document.getElementById('alert_sound').play();
                    
                    
            //     }// Sinon, nous devons demander la permission à l'utilisateur
            //     else if (self.nomorecheck==undefined && Notification.permission !== 'denied') {
            //         Notification.requestPermission().then((permission) => {
            //             if (permission === 'granted') {
            //                 // console.log("notify2");
            //                 self.currentNotif = new Notification(title, { body: msg, icon: img });
            //                 document.getElementById('alert_sound').play();
            //             }else{
            //                 self.nomorecheck=true;
            //             }
            //         });
            //     }
            //     else if (Notification.permission == 'denied'){
            //         self.nomorecheck=true;
            //     }
            // }
            window.parent.postMessage(JSON.stringify({
                "type": "notify",
                "title" :title,
                "msg":msg
            }), '*');
            document.getElementById('alert_sound').play();
        }else{
            if (!self.ids.includes(id)){
                self.ids.push(id);
            }
            if (self.isVisible){
                // document.title ="Artisan";
                // window.parent.postMessage("title-Artisan", '*');
                window.parent.postMessage(JSON.stringify({
                    "type": "title",
                    "content" :"Artisan"
                }), '*');
            }
        }
    };
    
}
var spd3_alert = new alert();
function job_manager(){
    var self = this;

    this.jobs = [];
    this.main_job = false; // the job displayed in the widget icon

    this.uploads = [];
    this.upload = false;

    // dom elements 
    this.domElems = {};
    this.domElems.details = {};

    this.following_job = false;
    this.pullTime = 1000;

    this.init = function(tl){
        this.tl = tl;

        this.get_jobs();

        this.domElems.widget_icon = document.getElementById('jobs_widget_icon');
        this.domElems.widget_number = document.getElementById('jobs_widget_number');
        this.domElems.bar = document.getElementById('jobs_widget_mini_progress_bar');
        this.domElems.bar_progress = document.getElementById('jobs_widget_mini_progress_bar_state');
        this.domElems.detailsParent = document.getElementById('jobs_widget_details');
    };
    this.get_jobs = function(){
        let settings = {};
        settings.url = CONSTANTS.base_url + 'public/jobs/index.php';
        settings.dom_target = '';
        settings.notimer = true;
        settings.skip_container = true;
        settings.data = {
            'jobs_action': 'jobs_get_all'
        };
        settings.success = function(res){
            let json = JSON.parse(res);
            if (json.code == 0){
                if (json.jobs) {
                    self.jobs = json.jobs;
                    self.domElems.widget_number.textContent = self.jobs.length;
                    // call function to display progress bar
                    self.initBar();
                    self.jobs.forEach((job)=>{
                        self.displayJobDetail(job);
                    });
                    self.followJob();
                } else {
                    self.domElems.details.none = DOM_Class.CreateElement('SPAN', {'class':'jobs_widget_details_line_none'}, self.tl.no_job);
                    DOM_Class.AppendContent(self.domElems.detailsParent, self.domElems.details.none);
                }
            }
        };
        $_a.send(settings);
    };
    this.newJob = function(job){
        this.jobs.push(job);
        this.displayJobDetail(job);
        this.initBar();
        if (!this.following_job) this.following_job = setTimeout(this.followJob, this.pullTime);
    };
    this.displayJobDetail = function(job){
        let domElem = DOM_Class.CreateElement('DIV', {'class':'jobs_widget_details_line'});
            let content = DOM_Class.CreateElement('SPAN', {'class':'jobs_widget_details_line_label'}, job.label);
            let progress = DOM_Class.CreateElement('DIV', {'class':'jobs_widget_details_line_progress', 'style': 'width: 0%;'});
            let detail = DOM_Class.CreateElement('DIV', {'class':'jobs_widget_details_line_detail hidden'});
            if (job.detail){
                job.detail.forEach((elem)=>{
                    let row = DOM_Class.CreateElement('DIV', {'class':'jobs_widget_details_line_detail_row'}, elem);
                    DOM_Class.AppendContent(detail, row);
                });
            }
        DOM_Class.AppendContent(domElem, [content,progress,detail]);
        $_e.AddEventClick(domElem, this.toggleLineDetails);
        
        this.domElems.details[job.start] = {};
        this.domElems.details[job.start].domElem = domElem;
        this.domElems.details[job.start].progress = progress;

        DOM_Class.AppendContent(this.domElems.detailsParent, this.domElems.details[job.start].domElem);

        if (job.type == 'copy'){
            this.domElems.details[job.start].progress.style.width = job.state + '%';
        }
    };
    this.toggleLineDetails = function(evt){
        let targ = evt.target.lastElementChild;
        DOM_Class.ToggleClass(targ, 'hidden');
    };
    this.updateJob = function(job){
        if (this.main_job.start == job.start){
            this.main_job.state = job.state;
            this.domElems.bar_progress.style.width = this.main_job.state+'%';
        }
        
        if (job.type == 'copy' && this.domElems.details[job.start]){
            this.domElems.details[job.start].progress.style.width = job.state + '%';
        }
    };
    this.initBar = function(){
        if (this.main_job !== false) return;
        if (this.jobs){
            if (self.domElems.details.none) {
                DOM_Class.RemoveElement(this.domElems.details.none);
                this.domElems.details.none = false;
            }
            let i = 0;
            while(this.jobs[i] && this.jobs[i].state == 'ok!'){
                i++;
            }
            if (!this.jobs[i]) return;

            this.main_job = this.jobs[i];

            if (this.main_job.type == 'copy' || this.main_job.type == 'upload'){
                DOM_Class.ToggleClass(this.domElems.bar, 'hidden', false);
                this.domElems.bar_progress.style.width = this.main_job.state+'%';
            }
            this.domElems.widget_number.textContent = this.jobs.length;
        }
    };
    this.cleanBar = function(){
        this.main_job = false;
        DOM_Class.ToggleClass(this.domElems.bar, 'hidden', true);
        this.domElems.bar_progress.style.width = '0%';
        this.domElems.widget_number.textContent = '';
    };
    this.followJob = function(){
        let settings = {};
        settings.url = CONSTANTS.base_url + 'public/jobs/index.php';
        settings.dom_target = '';
        settings.notimer = true;
        settings.skip_container = true;
        settings.data = {
            'jobs_action': 'jobs_get_all',
            'follow': 1,
        };
        settings.success = function(res){
            let json = JSON.parse(res);
            // console.log(json);
            if (json.code == 0){
                // first clean finished job
                if (json.finished){
                    json.finished.forEach((job)=>{
                        DOM_Class.RemoveElement(self.domElems.details[job.start].domElem);
                        delete(self.domElems.details[job.start]);
                        if (job.start == self.main_job.start){
                            self.cleanBar();
                        }
                        // refresh the folders where the copy happened to display the new file
                        if (job.type == 'copy') {
                            Filemanager_refresh(job.params.path);
                        }
                    });
                }

                self.jobs = [];
                if (self.uploads){
                    self.jobs.push(...self.uploads);
                }
                if (json.jobs){
                    self.jobs.push(...json.jobs);
                }
                if (self.jobs.length > 0){
                    let only_upload = true;
                    self.jobs.forEach((job)=>{
                        if (job.type != 'upload'){
                            only_upload = false;
                            self.updateJob(job);
                        }
                    });
                    self.domElems.widget_number.textContent = self.jobs.length;
                    self.initBar();
                    if (!only_upload) self.following_job = setTimeout(self.followJob, self.pullTime);
                } else {
                    self.domElems.widget_number.textContent = '';
                    self.following_job = false;

                    self.domElems.details.none = DOM_Class.CreateElement('SPAN', {'class':'jobs_widget_details_line_none'}, self.tl.no_job);
                    DOM_Class.AppendContent(self.domElems.detailsParent, self.domElems.details.none);
                }
            }
        };
        $_a.send(settings);
    };
    this.newUpload = function(files){
        
        let job = {'type': 'upload', 'state':'0', 'start': Date.now()};
        job.ui_progress = new UI_Upload_Progress(files, this.domElems.detailsParent, job.start);

        this.uploads.push(job);
        this.jobs.push(job);
        
        this.initBar();

        return job.start;
    };
    this.lastupdate=0;
    this.updateUpload = function(res,req,time){
        if (!req.all) return;
        // if (self.main_job.type == 'upload' && self.main_job.start == time){
        //     self.upload.state = Math.round(req.all.progress * 100);
        //     self.main_job = self.upload;
        //     self.domElems.bar_progress.style.width = self.main_job.state + '%';
        // }
        if ( (Date.now() - self.lastupdate) > 1000) {
            self.lastupdate=Date.now();
            self.uploads.forEach((job)=>{
                if (job.start == time){
                    job.ui_progress.update(res,req);
                    job.state  = Math.round(req.all.progress * 100);
                    if (self.main_job.type == 'upload' && self.main_job.start == job.start){
                        self.main_job = job;
                        self.domElems.bar_progress.style.width = self.main_job.state + '%';
                    }
                }
            });
        }
        
    };
    this.endUpload = function(time){
        // debugger;
        let index_to_remove = -1;
        this.uploads.forEach((job, key)=>{
            if (job.start == time){
                let index = this.jobs.indexOf(job);
                if (index > -1){
                    this.jobs.splice(index, 1);
                }
                index_to_remove = key;
                job.ui_progress.hide();
            }
        });
        if (index_to_remove > -1){
            this.uploads.splice(index_to_remove, 1);
        }

        if (this.jobs.length == 0) {
            this.cleanBar();
            self.domElems.details.none = DOM_Class.CreateElement('SPAN', {'class':'jobs_widget_details_line_none'}, self.tl.no_job);
            DOM_Class.AppendContent(self.domElems.detailsParent, self.domElems.details.none);
        }
    };
}
var sp3_job = new job_manager();
var spatimeout = function(call,time,timed=0){
    try{
        eval(call);
    } catch(e){
        timed++;
        if (timed<3){
            setTimeout(spatimeout , time , call, time, timed);
        }
    }
};
//ajax.js
//------------------------------
var $_a = new AJAX_Class();

//events.js
//------------------------------
var $_e = EVENTS_Class;
$_e.Init(); 

//validator.js
//------------------------------
$_v = new VALIDATOR_Class();

//detect_hash in history.js
//------------------------------
$_e.AddLoadHandler(detect_hash); 
//~ $_e.AddEvent(window,'hashchange',detect_hash);
window.onhashchange = function(evt){
    //~ console.log(evt);
    detect_hash();
};
//~ window.onpopstate = function(evt){
    //~ console.log(evt);
    //~ console.log('popstate');
    //~ return false;
    //~ detect_hash();
//~ }

//initialvar for VerticalRatio based on FHD size
var fhdVR=1;
//update root css var on load, detect_screen_infos is in ui.js
$_e.AddLoadHandler(detect_screen_infos); 
//should update fhdVR and some root css vars on resize , still in ui.js
$_e.AddResizeHandler(updateCssfhdvr); 
